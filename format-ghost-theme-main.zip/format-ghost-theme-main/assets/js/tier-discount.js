function calculateDiscountPercentage(originalPrice, discountedPrice) {
	return Math.round(((originalPrice - discountedPrice) / originalPrice) * 100);
}

document.querySelectorAll('.tier-discount').forEach((el) => {
	const month = parseInt(el.getAttribute('data-tier-month').replace(/\D/g, ''));
	const year = parseInt(el.getAttribute('data-tier-year').replace(/\D/g, ''));
	const discountedPrice = year / 12;

	el.setAttribute(
		'data-tier-discount',
		calculateDiscountPercentage(month, discountedPrice),
	);
});

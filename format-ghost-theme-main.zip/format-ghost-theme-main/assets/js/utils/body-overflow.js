const { body } = document;

export default function bodyOverflow($overflow = true) {
	if ($overflow) {
		body.style.setProperty('overflow', 'hidden');
	} else {
		body.style.setProperty('overflow', '');
	}
}

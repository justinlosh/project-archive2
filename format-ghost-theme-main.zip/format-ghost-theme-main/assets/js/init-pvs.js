/**
 * Init features from our PVS framework.
 */

const { pvs } = window;

if (pvs) {
	pvs.initDarkMode();
	pvs.initLightbox();
	pvs.initScrollProgress();
	pvs.initPagination();
	pvs.initDropdown();
}

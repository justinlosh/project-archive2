const { on } = window.ivent;

// Only secondary menu nav-links.
const popup = document.querySelector('.popup-navigation');
const allItems = popup.querySelectorAll('.navigation-secondary .nav-link');
const secondaryItems = popup.querySelectorAll(
	'.navigation-secondary:not(.navigation-main) .nav-link',
);

on(document, 'format.popup.show', ({ data }) => {
	if (data.popupId !== 'popup-navigation') {
		return;
	}

	// Scroll to top.
	window.scrollTo({ top: 0, behavior: 'smooth' });

	// Add transition delay.
	let index = 0;
	const animateItems = window.innerWidth > 540 ? secondaryItems : allItems;

	animateItems.forEach((item) => {
		index += 1;
		item.style.setProperty('--navigation--item-index', index);
	});
});

on(document, 'format.popup.hide', ({ data }) => {
	if (data.popupId !== 'popup-navigation') return;

	allItems.forEach((item) => {
		item.style.setProperty('--navigation--item-index', '');
	});
});

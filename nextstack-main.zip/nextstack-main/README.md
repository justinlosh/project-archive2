>[!IMPORTANT]
>This is an experimental project _(social experiment)_ for learning and testing. I am by no means a developer and this software comes with no warranty and I suggest you use this at your own risk.

# NextStack
NextStack (```next-stack```) is a Flat-File Content Management System (CMS) created as an expierment to see what can be accomplished with just AI. The platform is built using [v0.dev](https://v0.dev) and deployed on [Vercel](https://vercel.com).

***
## Overview
_A work in progress_

### Features

#### Core Funcitonality (```core```)
* **Frontend**
  * Notes _(Blog)_
  * Pages
  * Forms
    
* **Backend**
  * Notes
    * Create, Modify, Delete
    * "Slug" Mangement
    * Publishing Status (Draft, Published, Scheduled)
    * Markdown Editor

  * Pages
     * Create, Modify, Delete
     * "Slug" Management
     * Markdown Editor
       
  * Forms
    * Create, Modify, Delete
    * Interactive (Drag + Drop) Form Builder
    * Form Submission Storage

  * Admin
    * Dashboard
    * Content Management (Notes, Pages, Forms)
    * General
      * Site Information
        * Site Name
        * Description
        * Site URL
        * Author
      * SEO Settings
        * Default Title
        * Default Description
        * Keyboards
        * Open Graph Image
      * Robots.txt
        * Configuration Editor
        * Live Robots.txt Builder + Preview
      * Security.txt
        * Configuration Editor
        * Live Robots.txt Builder + Preview
      * Sitemap.xml
        * Sitemap Configuration
      * Social Media
        * Social Media Profile Configuration
    * Media Library
      * Upload, Edit, Delete
      * Taxonomy Management
      * Image Compression
    * Navigation Editor
    * Analytics
    * Security
    * Integrations
    * Theme Management (Editor, Interactive Style Guide)
    * System
      * Backups (GitHub, Export)
      * Performance
      * Error Logging
    * Utilities
      * Content Management
        * Initilize Content Directories
        * Sync Content Files
      * Logs + Cleanup
        * Clear System Logs
      * Backup + Restore
        * Manual Backup (File Storage)

#### Deployment (```deployment```)

* Build Scripts
  * Build Scaffolding (```/content```)

#### Integrations (```integrations```)

* Analytics (Google Analytics, Fathom, Unami, Ackee, Custom)
* Backups (GitHub Repo, Build Export)
* Captcha (hCaptcha, Cloudflare Turnstile) 

## Roadmap
_A work in progress_

* **Phase 1**: UI for basic flat file CMS: list markdown files, view content, minimal layout.
* **Phase 2**: Add file upload and markdown rendering support to CMS UI.
* **Phase 3**: Add sidebar navigation and responsive layout to flat file CMS.
* **Phase 4**: Enable file editing and saving in CMS with markdown editor.
* **Phase 5**: Add authentication and access control to CMS UI.


## Contributing
_A work in progress_

## Security
_A work in progress_

# My Experiences
>[!NOTE]
>This will eventually be a blog post on my site, but this will help me keep track of my thoughts.

***

Moving from Phase 1 to 2, removing Neon, it seems while progressing forward, I've lost the ```/admin``` dashboard and previous work. v0 seems to have moved focus more onto Phase 2 once it had been forked. Based on this, it seems I might have to shuffle some steps around. Inital thoughts are reasigning phases (e.g. Phase 2, Phase 1).

The struggle here, might be trying to piece everything back togther without anything breaking. I plan on running through the rest of the prompts to see where this gets me, I mean this is a "social experiment" afterall.

When working through this it seems that forking isn't the best option to create a "point in time" restore or protecting your work. Although, if this was created as a single project and you have your various chats, creating a new chat with the following:

```Integrate all previous conversations and associated codebases into a unified Next.js project. The merged project should encompass all features, functionalities, and design elements discussed and implemented in the prior interactions. Ensure that the integration is seamless, resolving any conflicts or redundancies, and maintaining the integrity of the original components. The final output should be a fully functional Next.js application that reflects the cumulative development efforts.```

This might work, by consolidating everything, but end-results are currently unknown and if I can "recover" from this or have to start over.

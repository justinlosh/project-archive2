## Next Steps
After running through all of the prompts for Phases 1-4. I created a fork, to version the app before proceding. There were various errors on the frontend that needed fixing, after a few attempts scouring the app, most of these were fixed.

```
Conduct a comprehensive review of the entire codebase to identify and rectify any errors, vulnerabilities, or areas for improvement. The goal is to ensure the application is production-ready, adhering to best practices for performance, security, and maintainability. The review should encompass all aspects of the codebase, including but not limited to: code structure, component design, state management, data fetching, error handling, user interface, and overall user experience. Provide specific recommendations for improvements, including code refactoring, optimization strategies, and security enhancements. The final output should include a detailed report summarizing the findings, along with actionable steps to address any identified issues and ensure the application meets the highest standards of quality and readiness for production deployment.
```

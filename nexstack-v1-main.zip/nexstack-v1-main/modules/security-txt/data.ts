export default {
  title: "Security.txt",
  description: "Security contact information and policy",
  contacts: ["mailto:security@example.com"],
  encryption: "https://example.com/pgp-key.txt",
  acknowledgments: "https://example.com/security/hall-of-fame",
  policy: "https://example.com/security-policy",
  hiring: "https://example.com/jobs/security",
  expires: new Date(new Date().setFullYear(new Date().getFullYear() + 1)).toISOString(), // 1 year from now
}

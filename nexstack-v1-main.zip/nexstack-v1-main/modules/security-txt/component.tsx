// This component doesn't render anything visible
// It's used to generate the security.txt file
export default function SecurityTxtModule() {
  return null
}

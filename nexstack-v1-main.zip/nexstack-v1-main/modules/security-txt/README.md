# Security.txt Module

This module implements a `security.txt` file in the `.well-known` directory, following the RFC standard for security.txt files. This allows security researchers to easily find contact information for reporting security vulnerabilities.

## Features

- Generates a security.txt file at `/.well-known/security.txt`
- Configurable contact information, encryption, policy, and more
- Follows the RFC standard for security.txt files

## Configuration

The Security.txt module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_SECURITY_TXT` | Enable/disable the security.txt module | `false` |
| `MODULE_SECURITY_TXT_CONTACT` | Contact information for security issues | `mailto:security@example.com` |
| `MODULE_SECURITY_TXT_ENCRYPTION` | URL to encryption key | `https://example.com/pgp-key.txt` |
| `MODULE_SECURITY_TXT_ACKNOWLEDGMENTS` | URL to acknowledgments page | `https://example.com/security/hall-of-fame` |
| `MODULE_SECURITY_TXT_POLICY` | URL to security policy | `https://example.com/security-policy` |
| `MODULE_SECURITY_TXT_HIRING` | URL to security jobs page | `https://example.com/jobs/security` |
| `MODULE_SECURITY_TXT_EXPIRES` | Number of days until expiration | `365` |

## Usage

The Security.txt module automatically generates a security.txt file at the `/.well-known/security.txt` route. No additional setup is required beyond enabling the module.

## RFC Standard

This module follows the RFC standard for security.txt files. For more information, see [securitytxt.org](https://securitytxt.org/).
\`\`\`

Now, let's create the Security.txt component:

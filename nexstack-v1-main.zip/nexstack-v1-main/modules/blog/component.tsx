import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"
import { getModuleData } from "@/lib/module-loader"

interface BlogModuleProps {
  config: Record<string, string>
}

export default async function BlogModule({ config }: BlogModuleProps) {
  const title = config.TITLE || "Latest Blog Posts"
  const postsToShow = Number.parseInt(config.POSTS_TO_SHOW || "3", 10)

  const blogData = await getModuleData("blog")
  const posts = blogData?.posts || []

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-bold tracking-tight">{title}</h2>
        <Button asChild variant="outline" size="sm">
          <Link href="/blog" className="flex items-center">
            View All
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {posts.slice(0, postsToShow).map((post: any) => (
          <Card key={post.id} className="overflow-hidden flex flex-col">
            <CardHeader className="pb-0">
              <CardTitle className="line-clamp-1">{post.title}</CardTitle>
              <CardDescription>{new Date(post.date).toLocaleDateString()}</CardDescription>
            </CardHeader>
            <CardContent className="py-4 flex-grow">
              <p className="line-clamp-3 text-muted-foreground">{post.excerpt}</p>
            </CardContent>
            <CardFooter className="pt-0">
              <Button asChild variant="ghost" size="sm" className="gap-1">
                <Link href={`/blog/${post.slug}`}>
                  Read More
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

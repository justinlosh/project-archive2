export default {
  name: "blog",
  enabled: true,
  posts: [
    {
      id: "1",
      title: "Getting Started with Next.js",
      slug: "getting-started-with-nextjs",
      date: "2023-01-15",
      excerpt: "Learn how to build modern web applications with Next.js, the React framework for production.",
      content: "This is the full content of the blog post...",
    },
    {
      id: "2",
      title: "Understanding Server Components",
      slug: "understanding-server-components",
      date: "2023-02-20",
      excerpt:
        "Server Components allow you to render components on the server and reduce the amount of JavaScript sent to the client.",
      content: "This is the full content of the blog post...",
    },
    {
      id: "3",
      title: "Building a Modular Next.js Application",
      slug: "building-modular-nextjs-application",
      date: "2023-03-10",
      excerpt:
        "Learn how to structure your Next.js application in a modular way for better maintainability and scalability.",
      content: "This is the full content of the blog post...",
    },
  ],
}

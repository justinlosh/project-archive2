import { type NextRequest, NextResponse } from "next/server"
import { getModuleStatus } from "@/lib/module-loader"
import { getModuleConfig } from "@/lib/module-system"

export async function maintenanceMiddleware(request: NextRequest) {
  // Check if maintenance mode module is enabled
  const isMaintenanceModeModuleEnabled = getModuleStatus("maintenance-mode")
  if (!isMaintenanceModeModuleEnabled) {
    return NextResponse.next()
  }

  // Get maintenance mode configuration
  const config = getModuleConfig("maintenance-mode")
  const isMaintenanceModeEnabled = config.ENABLED === "true"

  // If maintenance mode is not enabled, continue
  if (!isMaintenanceModeEnabled) {
    return NextResponse.next()
  }

  // Check for admin access
  const allowAdminAccess = config.ALLOW_ADMIN_ACCESS === "true"
  if (allowAdminAccess) {
    // Get admin IP addresses
    const adminIpAddresses = (config.ADMIN_IP_ADDRESSES || "127.0.0.1").split(",").map((ip) => ip.trim())

    // Get client IP address
    const clientIp = request.headers.get("x-forwarded-for") || request.ip || "0.0.0.0"

    // If client IP is in admin IP addresses, allow access
    if (adminIpAddresses.includes(clientIp)) {
      return NextResponse.next()
    }
  }

  // Check if the request is already for the maintenance page
  const { pathname } = request.nextUrl
  if (pathname === "/maintenance") {
    return NextResponse.next()
  }

  // Check if the request is for static assets
  if (
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon.ico") ||
    pathname.startsWith("/images/") ||
    pathname.startsWith("/fonts/")
  ) {
    return NextResponse.next()
  }

  // Redirect to maintenance page
  const url = request.nextUrl.clone()
  url.pathname = "/maintenance"
  return NextResponse.redirect(url)
}

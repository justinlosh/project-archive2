"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getModuleStatus } from "@/lib/module-loader"
import { ModuleLoader } from "@/lib/module-loader"
import { Clock, AlertTriangle } from "lucide-react"

interface MaintenanceModeProps {
  config: Record<string, string>
}

export default function MaintenanceMode({ config }: MaintenanceModeProps) {
  const [countdown, setCountdown] = useState<string | null>(null)
  const isSocialMediaEnabled = getModuleStatus("social-media")

  // Get configuration values
  const title = config.TITLE || "Site Under Maintenance"
  const message = config.MESSAGE || "We're currently performing scheduled maintenance. Please check back soon."
  const estimatedCompletionTime = config.ESTIMATED_COMPLETION_TIME || ""
  const showSocialLinks = config.SHOW_SOCIAL_LINKS !== "false" && isSocialMediaEnabled
  const customCss = config.CUSTOM_CSS || ""
  const backgroundImage = config.BACKGROUND_IMAGE || ""
  const logoImage = config.LOGO_IMAGE || ""

  // Calculate countdown if estimated completion time is provided
  useEffect(() => {
    if (!estimatedCompletionTime) return

    const targetDate = new Date(estimatedCompletionTime)
    if (isNaN(targetDate.getTime())) return

    const updateCountdown = () => {
      const now = new Date()
      const difference = targetDate.getTime() - now.getTime()

      if (difference <= 0) {
        setCountdown("Maintenance should be complete soon")
        return
      }

      const hours = Math.floor(difference / (1000 * 60 * 60))
      const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((difference % (1000 * 60)) / 1000)

      setCountdown(`${hours}h ${minutes}m ${seconds}s`)
    }

    updateCountdown()
    const interval = setInterval(updateCountdown, 1000)

    return () => clearInterval(interval)
  }, [estimatedCompletionTime])

  // Apply custom CSS if provided
  useEffect(() => {
    if (!customCss) return

    const styleElement = document.createElement("style")
    styleElement.textContent = customCss
    document.head.appendChild(styleElement)

    return () => {
      document.head.removeChild(styleElement)
    }
  }, [customCss])

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4"
      style={
        backgroundImage
          ? {
              backgroundImage: `url(${backgroundImage})`,
              backgroundSize: "cover",
              backgroundPosition: "center",
            }
          : {}
      }
    >
      <Card className="w-full max-w-md shadow-lg">
        <CardHeader className="text-center">
          {logoImage && (
            <div className="flex justify-center mb-4">
              <img src={logoImage || "/placeholder.svg"} alt="Logo" className="h-16 w-auto" />
            </div>
          )}
          <CardTitle className="text-2xl flex items-center justify-center gap-2">
            <AlertTriangle className="h-6 w-6 text-yellow-500" />
            {title}
          </CardTitle>
          <CardDescription>{message}</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {countdown && (
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-1">Estimated time remaining:</p>
              <div className="flex items-center justify-center gap-2 text-lg font-semibold">
                <Clock className="h-5 w-5" />
                {countdown}
              </div>
            </div>
          )}

          {showSocialLinks && (
            <div className="mt-6">
              <p className="text-sm text-center mb-2">Follow us for updates:</p>
              <ModuleLoader moduleName="social-media" />
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

export default {
  title: "Maintenance Mode",
  description: "Site-wide maintenance mode with customizable page",
  defaultSettings: {
    enabled: false,
    title: "Site Under Maintenance",
    message: "We're currently performing scheduled maintenance. Please check back soon.",
    estimatedCompletionTime: "",
    showSocialLinks: true,
    allowAdminAccess: true,
    adminIpAddresses: ["127.0.0.1"],
    customCss: "",
    backgroundImage: "",
    logoImage: "",
  },
}

# Maintenance Mode Module

This module provides a site-wide maintenance mode that redirects all traffic to a customizable maintenance page.

## Features

- Enable/disable maintenance mode via environment variables
- Customizable maintenance page content and design
- Option to allow admin access based on IP addresses
- Estimated completion time display
- Social media links integration (requires social-media module)
- Custom CSS and background image options

## Configuration

The Maintenance Mode module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_MAINTENANCE_MODE` | Enable/disable the maintenance mode module | `false` |
| `MODULE_MAINTENANCE_MODE_ENABLED` | Enable/disable maintenance mode | `false` |
| `MODULE_MAINTENANCE_MODE_TITLE` | Title for the maintenance page | `Site Under Maintenance` |
| `MODULE_MAINTENANCE_MODE_MESSAGE` | Message for the maintenance page | `We're currently performing scheduled maintenance. Please check back soon.` |
| `MODULE_MAINTENANCE_MODE_ESTIMATED_COMPLETION_TIME` | Estimated completion time (optional) | `` |
| `MODULE_MAINTENANCE_MODE_SHOW_SOCIAL_LINKS` | Show social media links | `true` |
| `MODULE_MAINTENANCE_MODE_ALLOW_ADMIN_ACCESS` | Allow admin access based on IP | `true` |
| `MODULE_MAINTENANCE_MODE_ADMIN_IP_ADDRESSES` | Comma-separated list of admin IP addresses | `127.0.0.1` |
| `MODULE_MAINTENANCE_MODE_CUSTOM_CSS` | Custom CSS for the maintenance page | `` |
| `MODULE_MAINTENANCE_MODE_BACKGROUND_IMAGE` | Background image URL | `` |
| `MODULE_MAINTENANCE_MODE_LOGO_IMAGE` | Logo image URL | `` |

## Usage

The Maintenance Mode module works by adding a middleware that checks if maintenance mode is enabled and redirects all traffic to the maintenance page if it is.

To use the Maintenance Mode module:

1. Enable the module by setting `MODULE_MAINTENANCE_MODE=true` in your environment variables
2. Enable maintenance mode by setting `MODULE_MAINTENANCE_MODE_ENABLED=true`
3. Customize the maintenance page using the configuration options

## Admin Access

You can allow admin access to the site during maintenance mode by setting `MODULE_MAINTENANCE_MODE_ALLOW_ADMIN_ACCESS=true` and adding your IP address to `MODULE_MAINTENANCE_MODE_ADMIN_IP_ADDRESSES`.

## Integration with Social Media Module

If the Social Media module is enabled, the maintenance page can display social media links by setting `MODULE_MAINTENANCE_MODE_SHOW_SOCIAL_LINKS=true`.

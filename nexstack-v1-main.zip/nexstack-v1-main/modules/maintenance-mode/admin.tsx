"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon, AlertTriangle } from "lucide-react"
import { getModuleStatus } from "@/lib/module-loader"

interface AdminMaintenanceModeProps {
  config: Record<string, string>
  onSave?: (config: Record<string, string>) => void
}

export function AdminMaintenanceMode({ config, onSave }: AdminMaintenanceModeProps) {
  const [enabled, setEnabled] = useState(config.ENABLED === "true")
  const [title, setTitle] = useState(config.TITLE || "Site Under Maintenance")
  const [message, setMessage] = useState(
    config.MESSAGE || "We're currently performing scheduled maintenance. Please check back soon.",
  )
  const [estimatedCompletionTime, setEstimatedCompletionTime] = useState(config.ESTIMATED_COMPLETION_TIME || "")
  const [showSocialLinks, setShowSocialLinks] = useState(config.SHOW_SOCIAL_LINKS !== "false")
  const [allowAdminAccess, setAllowAdminAccess] = useState(config.ALLOW_ADMIN_ACCESS !== "false")
  const [adminIpAddresses, setAdminIpAddresses] = useState(config.ADMIN_IP_ADDRESSES || "127.0.0.1")
  const [customCss, setCustomCss] = useState(config.CUSTOM_CSS || "")
  const [backgroundImage, setBackgroundImage] = useState(config.BACKGROUND_IMAGE || "")
  const [logoImage, setLogoImage] = useState(config.LOGO_IMAGE || "")

  const isSocialMediaEnabled = getModuleStatus("social-media")

  const handleSave = () => {
    if (onSave) {
      onSave({
        ENABLED: enabled.toString(),
        TITLE: title,
        MESSAGE: message,
        ESTIMATED_COMPLETION_TIME: estimatedCompletionTime,
        SHOW_SOCIAL_LINKS: showSocialLinks.toString(),
        ALLOW_ADMIN_ACCESS: allowAdminAccess.toString(),
        ADMIN_IP_ADDRESSES: adminIpAddresses,
        CUSTOM_CSS: customCss,
        BACKGROUND_IMAGE: backgroundImage,
        LOGO_IMAGE: logoImage,
      })
    }
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Maintenance Mode</CardTitle>
            <CardDescription>Configure maintenance mode settings</CardDescription>
          </div>
          <div className="flex items-center space-x-2">
            <Label htmlFor="maintenance-mode-toggle" className="font-medium">
              Enable Maintenance Mode
            </Label>
            <Switch
              id="maintenance-mode-toggle"
              checked={enabled}
              onCheckedChange={setEnabled}
              aria-label="Toggle maintenance mode"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {enabled && (
          <Alert variant="warning" className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Maintenance mode is currently enabled. All visitors will be redirected to the maintenance page.
            </AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="content">
          <TabsList className="mb-4">
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="access">Access Control</TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="maintenance-title">Page Title</Label>
              <Input
                id="maintenance-title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Site Under Maintenance"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="maintenance-message">Message</Label>
              <Textarea
                id="maintenance-message"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="We're currently performing scheduled maintenance. Please check back soon."
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="estimated-completion">Estimated Completion Time</Label>
              <Input
                id="estimated-completion"
                type="datetime-local"
                value={estimatedCompletionTime}
                onChange={(e) => setEstimatedCompletionTime(e.target.value)}
              />
              <p className="text-sm text-muted-foreground">
                If set, a countdown timer will be displayed on the maintenance page.
              </p>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="show-social-links" className="font-medium">
                  Show Social Media Links
                </Label>
                <p className="text-sm text-muted-foreground">Display social media links on the maintenance page</p>
              </div>
              <Switch
                id="show-social-links"
                checked={showSocialLinks}
                onCheckedChange={setShowSocialLinks}
                disabled={!isSocialMediaEnabled}
              />
            </div>

            {showSocialLinks && !isSocialMediaEnabled && (
              <Alert>
                <InfoIcon className="h-4 w-4" />
                <AlertDescription>
                  The Social Media module is not enabled. Enable it to display social media links on the maintenance
                  page.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="logo-image">Logo Image URL</Label>
              <Input
                id="logo-image"
                value={logoImage}
                onChange={(e) => setLogoImage(e.target.value)}
                placeholder="https://example.com/logo.png"
              />
              <p className="text-sm text-muted-foreground">URL to your logo image (optional)</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="background-image">Background Image URL</Label>
              <Input
                id="background-image"
                value={backgroundImage}
                onChange={(e) => setBackgroundImage(e.target.value)}
                placeholder="https://example.com/background.jpg"
              />
              <p className="text-sm text-muted-foreground">URL to a background image (optional)</p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="custom-css">Custom CSS</Label>
              <Textarea
                id="custom-css"
                value={customCss}
                onChange={(e) => setCustomCss(e.target.value)}
                placeholder=".maintenance-page { background-color: #f5f5f5; }"
                rows={6}
              />
              <p className="text-sm text-muted-foreground">
                Custom CSS to style the maintenance page (advanced users only)
              </p>
            </div>
          </TabsContent>

          <TabsContent value="access" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="allow-admin-access" className="font-medium">
                  Allow Admin Access
                </Label>
                <p className="text-sm text-muted-foreground">
                  Allow access to the site for administrators based on IP address
                </p>
              </div>
              <Switch id="allow-admin-access" checked={allowAdminAccess} onCheckedChange={setAllowAdminAccess} />
            </div>

            {allowAdminAccess && (
              <div className="space-y-2">
                <Label htmlFor="admin-ip-addresses">Admin IP Addresses</Label>
                <Input
                  id="admin-ip-addresses"
                  value={adminIpAddresses}
                  onChange={(e) => setAdminIpAddresses(e.target.value)}
                  placeholder="127.0.0.1, 192.168.1.1"
                />
                <p className="text-sm text-muted-foreground">
                  Comma-separated list of IP addresses that can access the site during maintenance
                </p>
              </div>
            )}

            <Alert>
              <InfoIcon className="h-4 w-4" />
              <AlertDescription>
                Your current IP address will be used to allow you access to the site during maintenance mode.
              </AlertDescription>
            </Alert>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave}>Save Configuration</Button>
      </CardFooter>
    </Card>
  )
}

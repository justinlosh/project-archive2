"use client"

import { useEffect, useState, useMemo, useCallback } from "react"
import { GoogleAnalytics } from "./providers/google-analytics"
import { Umami } from "./providers/umami"
import { Ackee } from "./providers/ackee"
import { Plausible } from "./providers/plausible"
import { Fathom } from "./providers/fathom"
import { ConsentBanner } from "./consent"
import { trackPageView } from "./events"
import { usePathname, useSearchParams } from "next/navigation"

interface AnalyticsModuleProps {
  config: Record<string, string>
}

export default function AnalyticsModule({ config }: AnalyticsModuleProps) {
  const [hasConsent, setHasConsent] = useState<boolean | null>(null)
  const pathname = usePathname()
  const searchParams = useSearchParams()

  // Memoize configuration values to prevent unnecessary recalculations
  const {
    provider,
    trackingId,
    scriptUrl,
    respectDoNotTrack,
    requireConsent,
    anonymizeIp,
    cookieless,
    debugMode,
    consentBannerConfig,
  } = useMemo(
    () => ({
      provider: config.PROVIDER || "google-analytics",
      trackingId: config.TRACKING_ID || "",
      scriptUrl: config.SCRIPT_URL || "",
      respectDoNotTrack: config.RESPECT_DO_NOT_TRACK !== "false",
      requireConsent: config.REQUIRE_CONSENT !== "false",
      anonymizeIp: config.ANONYMIZE_IP !== "false",
      cookieless: config.COOKIELESS === "true",
      debugMode: config.DEBUG_MODE === "true",
      consentBannerConfig: {
        title: config.CONSENT_BANNER_TITLE || "We value your privacy",
        description:
          config.CONSENT_BANNER_DESCRIPTION ||
          'We use cookies and similar technologies to help personalize content, enhance your experience, and analyze our traffic. By clicking "Accept", you consent to our use of cookies.',
        acceptText: config.CONSENT_ACCEPT_TEXT || "Accept",
        declineText: config.CONSENT_DECLINE_TEXT || "Decline",
        settingsText: config.CONSENT_SETTINGS_TEXT || "Cookie Settings",
        privacyLinkText: config.CONSENT_PRIVACY_LINK_TEXT || "Privacy Policy",
        privacyLinkUrl: config.CONSENT_PRIVACY_LINK_URL || "/privacy",
      },
    }),
    [config],
  )

  // Memoize the DoNotTrack check
  const isDoNotTrackEnabled = useMemo(() => {
    return typeof navigator !== "undefined" && navigator.doNotTrack === "1"
  }, [])

  // Check for consent
  useEffect(() => {
    if (!requireConsent) {
      setHasConsent(true)
      return
    }

    const consentStatus = localStorage.getItem("analytics-consent")
    if (consentStatus === "accepted") {
      setHasConsent(true)
    } else if (consentStatus === "declined") {
      setHasConsent(false)
    } else {
      setHasConsent(null)
    }
  }, [requireConsent])

  // Track page views with debounce
  useEffect(() => {
    if (hasConsent === true && !(respectDoNotTrack && isDoNotTrackEnabled)) {
      const timer = setTimeout(() => {
        const fullPath = pathname + (searchParams.toString() ? `?${searchParams.toString()}` : "")
        trackPageView(fullPath, document.title)
      }, 500)

      return () => clearTimeout(timer)
    }
  }, [pathname, searchParams, hasConsent, respectDoNotTrack, isDoNotTrackEnabled])

  // Memoize consent handlers
  const handleAcceptConsent = useCallback(() => {
    localStorage.setItem("analytics-consent", "accepted")
    setHasConsent(true)
  }, [])

  const handleDeclineConsent = useCallback(() => {
    localStorage.setItem("analytics-consent", "declined")
    setHasConsent(false)
  }, [])

  // Don't render analytics if Do Not Track is enabled and respected
  if (respectDoNotTrack && isDoNotTrackEnabled) {
    if (debugMode) {
      console.log("[Analytics] Respecting Do Not Track, analytics disabled")
    }
    return null
  }

  // Don't render analytics if consent is required but not given
  if (requireConsent && hasConsent !== true) {
    return (
      <ConsentBanner
        title={consentBannerConfig.title}
        description={consentBannerConfig.description}
        acceptText={consentBannerConfig.acceptText}
        declineText={consentBannerConfig.declineText}
        settingsText={consentBannerConfig.settingsText}
        privacyLinkText={consentBannerConfig.privacyLinkText}
        privacyLinkUrl={consentBannerConfig.privacyLinkUrl}
        onAccept={handleAcceptConsent}
        onDecline={handleDeclineConsent}
      />
    )
  }

  // Render the appropriate analytics provider
  if (hasConsent !== true) {
    return null
  }

  return (
    <>
      {provider === "google-analytics" && trackingId && (
        <GoogleAnalytics trackingId={trackingId} anonymizeIp={anonymizeIp} debug={debugMode} />
      )}
      {provider === "umami" && trackingId && scriptUrl && (
        <Umami trackingId={trackingId} scriptUrl={scriptUrl} debug={debugMode} />
      )}
      {provider === "ackee" && trackingId && scriptUrl && (
        <Ackee trackingId={trackingId} scriptUrl={scriptUrl} debug={debugMode} />
      )}
      {provider === "plausible" && trackingId && <Plausible trackingId={trackingId} debug={debugMode} />}
      {provider === "fathom" && trackingId && <Fathom trackingId={trackingId} debug={debugMode} />}
    </>
  )
}

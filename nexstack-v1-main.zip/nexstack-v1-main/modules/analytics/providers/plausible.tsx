"use client"

import Script from "next/script"
import { useEffect } from "react"

interface PlausibleProps {
  trackingId: string // Domain name
  debug?: boolean
}

export function Plausible({ trackingId, debug = false }: PlausibleProps) {
  useEffect(() => {
    if (debug) {
      console.log("[Analytics] Plausible initialized with domain:", trackingId)
    }
  }, [trackingId, debug])

  if (debug) {
    return null
  }

  return (
    <Script
      src="https://plausible.io/js/script.js"
      data-domain={trackingId}
      strategy="afterInteractive"
      data-testid="plausible-script"
    />
  )
}

"use client"

import Script from "next/script"
import { useEffect } from "react"

interface UmamiProps {
  trackingId: string
  scriptUrl: string
  debug?: boolean
}

export function Umami({ trackingId, scriptUrl, debug = false }: UmamiProps) {
  useEffect(() => {
    if (debug) {
      console.log("[Analytics] Umami initialized with tracking ID:", trackingId)
      console.log("[Analytics] Script URL:", scriptUrl)
    }
  }, [trackingId, scriptUrl, debug])

  if (debug) {
    return null
  }

  return <Script src={scriptUrl} data-website-id={trackingId} strategy="afterInteractive" data-testid="umami-script" />
}

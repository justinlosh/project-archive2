"use client"

import Script from "next/script"
import { useEffect } from "react"

interface AckeeProps {
  trackingId: string
  scriptUrl: string
  debug?: boolean
}

export function Ackee({ trackingId, scriptUrl, debug = false }: AckeeProps) {
  useEffect(() => {
    if (debug) {
      console.log("[Analytics] Ackee initialized with tracking ID:", trackingId)
      console.log("[Analytics] Script URL:", scriptUrl)
      return
    }
  }, [trackingId, scriptUrl, debug])

  if (debug) {
    return null
  }

  return (
    <Script id="ackee-tracker" strategy="afterInteractive">
      {`
        !function(e,t,n){
          var a=e.Ackee||(e.Ackee={});
          a.tracker=a.tracker||function(){(a.tracker.q=a.tracker.q||[]).push(arguments)},
          a.init=function(e,t){a.tracker("create",e,t)},
          a.clean=function(){a.tracker=function(){}};
          var r=t.createElement("script");
          r.async=!0,r.src=n;
          var c=t.getElementsByTagName("script")[0];
          c.parentNode.insertBefore(r,c)
        }(window,document,"${scriptUrl}");
        Ackee.init("${trackingId}", { ignoreLocalhost: true, detailed: true });
      `}
    </Script>
  )
}

"use client"

import { useEffect, useState } from "react"

interface GoogleAnalyticsProps {
  trackingId: string
  anonymizeIp?: boolean
  debug?: boolean
}

export function GoogleAnalytics({ trackingId, anonymizeIp = true, debug = false }: GoogleAnalyticsProps) {
  const [isScriptLoaded, setIsScriptLoaded] = useState(false)

  useEffect(() => {
    if (debug) {
      console.log("[Analytics] Google Analytics initialized with tracking ID:", trackingId)
      console.log("[Analytics] Anonymize IP:", anonymizeIp)
      return
    }

    // Lazy load the analytics script
    const loadAnalytics = () => {
      // Don't load if already loaded
      if (isScriptLoaded) return

      // Create script element
      const script = document.createElement("script")
      script.src = `https://www.googletagmanager.com/gtag/js?id=${trackingId}`
      script.async = true

      // Set up onload handler
      script.onload = () => {
        setIsScriptLoaded(true)

        // Initialize Google Analytics
        window.dataLayer = window.dataLayer || []
        function gtag(...args: any[]) {
          window.dataLayer.push(args)
        }
        gtag("js", new Date())
        gtag("config", trackingId, {
          anonymize_ip: anonymizeIp,
          send_page_view: true,
        })
      }

      // Add script to document
      document.head.appendChild(script)
    }

    // Load analytics after a short delay to prioritize core content
    const timer = setTimeout(() => {
      // Only load if the user is still on the page
      if (document.visibilityState === "visible") {
        loadAnalytics()
      } else {
        // If page is not visible, wait for it to become visible
        const handleVisibilityChange = () => {
          if (document.visibilityState === "visible") {
            loadAnalytics()
            document.removeEventListener("visibilitychange", handleVisibilityChange)
          }
        }
        document.addEventListener("visibilitychange", handleVisibilityChange)
      }
    }, 3000) // 3 second delay

    return () => {
      clearTimeout(timer)
    }
  }, [trackingId, anonymizeIp, debug, isScriptLoaded])

  return null
}

"use client"

import Script from "next/script"
import { useEffect } from "react"

interface FathomProps {
  trackingId: string // Site ID
  debug?: boolean
}

export function Fathom({ trackingId, debug = false }: FathomProps) {
  useEffect(() => {
    if (debug) {
      console.log("[Analytics] Fathom initialized with site ID:", trackingId)
    }
  }, [trackingId, debug])

  if (debug) {
    return null
  }

  return (
    <Script
      src="https://cdn.usefathom.com/script.js"
      data-site={trackingId}
      defer
      strategy="afterInteractive"
      data-testid="fathom-script"
    />
  )
}

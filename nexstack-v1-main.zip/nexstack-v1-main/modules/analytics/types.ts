// Type definitions for analytics providers
declare global {
  interface Window {
    // Google Analytics
    dataLayer: any[]
    gtag: (...args: any[]) => void

    // Umami
    umami: {
      track: (eventName: string, properties?: Record<string, any>) => void
      trackView: (url: string) => void
    }

    // Plausible
    plausible: (eventName: string, options?: { props?: Record<string, any> }) => void

    // Fathom
    fathom: {
      trackGoal: (eventName: string, value: number) => void
      trackPageview: (options?: { url?: string; title?: string }) => void
    }

    // Ackee
    Ackee: {
      tracker: (action: string, ...args: any[]) => void
      init: (server: string, options: Record<string, any>) => void
    }
  }
}

export interface AnalyticsProviderProps {
  trackingId: string
  scriptUrl?: string
  anonymizeIp?: boolean
  debug?: boolean
}

export interface ConsentSettings {
  requireConsent: boolean
  respectDoNotTrack: boolean
  anonymizeIp: boolean
  cookieless: boolean
}

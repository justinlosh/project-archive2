export default {
  title: "Analytics",
  description: "Track and analyze website traffic and user behavior",
  providers: [
    {
      id: "google-analytics",
      name: "Google Analytics",
      description: "Google's web analytics service that tracks and reports website traffic",
      scriptUrl: "https://www.googletagmanager.com/gtag/js?id=",
      requiresTrackingId: true,
      privacyPolicyUrl: "https://policies.google.com/privacy",
    },
    {
      id: "umami",
      name: "Umami",
      description: "A simple, fast, privacy-focused alternative to Google Analytics",
      scriptUrl: "", // Custom URL required
      requiresTrackingId: true,
      requiresScriptUrl: true,
      privacyPolicyUrl: "https://umami.is/docs/privacy-focused-web-analytics",
    },
    {
      id: "ackee",
      name: "Ackee",
      description: "Self-hosted, Node.js based analytics tool for those who care about privacy",
      scriptUrl: "", // Custom URL required
      requiresTrackingId: true,
      requiresScriptUrl: true,
      privacyPolicyUrl: "https://ackee.electerious.com/",
    },
    {
      id: "plausible",
      name: "Plausible",
      description: "Simple, lightweight, and privacy-friendly analytics",
      scriptUrl: "https://plausible.io/js/script.js",
      requiresTrackingId: true,
      privacyPolicyUrl: "https://plausible.io/privacy",
    },
    {
      id: "fathom",
      name: "Fathom",
      description: "Simple, privacy-focused website analytics",
      scriptUrl: "https://cdn.usefathom.com/script.js",
      requiresTrackingId: true,
      privacyPolicyUrl: "https://usefathom.com/privacy",
    },
  ],
  defaultProvider: "google-analytics",
  defaultPrivacySettings: {
    respectDoNotTrack: true,
    requireConsent: true,
    anonymizeIp: true,
    cookieless: false,
  },
}

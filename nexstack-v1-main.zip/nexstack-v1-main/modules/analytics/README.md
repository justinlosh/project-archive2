# Analytics Module

This module provides analytics tracking for your website, supporting multiple providers including Google Analytics, Umami, Ackee, Plausible, and Fathom. It includes privacy features for user consent and data collection preferences.

## Features

- Support for multiple analytics providers
- Provider-specific configuration options
- Privacy-focused consent management
- Script initialization and management
- Debug mode for development

## Configuration

The Analytics module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_ANALYTICS` | Enable/disable the analytics module | `false` |
| `MODULE_ANALYTICS_PROVIDER` | Selected analytics provider (google-analytics, umami, ackee, plausible, fathom) | `google-analytics` |
| `MODULE_ANALYTICS_TRACKING_ID` | Tracking ID for the selected provider | `G-XXXXXXXXXX` |
| `MODULE_ANALYTICS_SCRIPT_URL` | Custom script URL (required for Umami and Ackee) | `` |
| `MODULE_ANALYTICS_RESPECT_DO_NOT_TRACK` | Respect the user's Do Not Track setting | `true` |
| `MODULE_ANALYTICS_REQUIRE_CONSENT` | Require user consent before tracking | `true` |
| `MODULE_ANALYTICS_ANONYMIZE_IP` | Anonymize IP addresses | `true` |
| `MODULE_ANALYTICS_COOKIELESS` | Use cookieless tracking when possible | `false` |
| `MODULE_ANALYTICS_DEBUG_MODE` | Enable debug mode for development | `false` |
| `MODULE_ANALYTICS_CONSENT_BANNER_TITLE` | Title for the consent banner | `We value your privacy` |
| `MODULE_ANALYTICS_CONSENT_BANNER_DESCRIPTION` | Description for the consent banner | `We use cookies...` |
| `MODULE_ANALYTICS_CONSENT_ACCEPT_TEXT` | Text for the accept button | `Accept` |
| `MODULE_ANALYTICS_CONSENT_DECLINE_TEXT` | Text for the decline button | `Decline` |
| `MODULE_ANALYTICS_CONSENT_SETTINGS_TEXT` | Text for the settings button | `Cookie Settings` |
| `MODULE_ANALYTICS_CONSENT_PRIVACY_LINK_TEXT` | Text for the privacy policy link | `Privacy Policy` |
| `MODULE_ANALYTICS_CONSENT_PRIVACY_LINK_URL` | URL for the privacy policy | `/privacy` |

## Usage

To use the Analytics module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the analytics module
<ModuleLoader moduleName="analytics" />
\`\`\`

The Analytics module will automatically initialize the selected provider and handle user consent.

## Supported Providers

### Google Analytics

Google Analytics requires a tracking ID in the format `G-XXXXXXXXXX` for GA4.

### Umami

Umami requires both a tracking ID and a script URL. The script URL should point to your Umami instance.

### Ackee

Ackee requires both a tracking ID and a script URL. The script URL should point to your Ackee instance.

### Plausible

Plausible requires a tracking ID (your domain name).

### Fathom

Fathom requires a tracking ID (your site ID).

## Privacy Features

The Analytics module includes several privacy features:

- **Respect Do Not Track**: If enabled, the module will not track users who have enabled the Do Not Track setting in their browser.
- **Require Consent**: If enabled, the module will not track users until they have given consent.
- **Anonymize IP**: If enabled, the module will anonymize IP addresses before sending data to the analytics provider.
- **Cookieless**: If enabled, the module will use cookieless tracking when possible.

## Events

The Analytics module provides a simple API for tracking events:

\`\`\`tsx
import { trackEvent } from '@/modules/analytics/events'

// Track a simple event
trackEvent('button_click')

// Track an event with properties
trackEvent('form_submit', { formId: 'contact', success: true })
\`\`\`

## Debug Mode

Debug mode can be enabled for development purposes. When enabled, the module will log tracking information to the console instead of sending it to the analytics provider.
\`\`\`

## 2. Provider-specific Implementation Files

Let's create the provider-specific implementation files:

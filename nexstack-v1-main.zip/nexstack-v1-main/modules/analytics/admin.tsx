"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon } from "lucide-react"

interface AnalyticsProvider {
  id: string
  name: string
  description: string
  requiresScriptUrl: boolean
  privacyPolicyUrl: string
}

interface AdminAnalyticsProps {
  config: Record<string, string>
  data: {
    providers: AnalyticsProvider[]
    [key: string]: any
  }
  onSave?: (config: Record<string, string>) => void
}

interface AnalyticsFormState {
  provider: string
  trackingId: string
  scriptUrl: string
  respectDoNotTrack: boolean
  requireConsent: boolean
  anonymizeIp: boolean
  cookieless: boolean
  debugMode: boolean
}

export function AdminAnalytics({ config, data, onSave }: AdminAnalyticsProps) {
  // Initialize form state from config
  const [formState, setFormState] = useState<AnalyticsFormState>({
    provider: config.PROVIDER || "google-analytics",
    trackingId: config.TRACKING_ID || "",
    scriptUrl: config.SCRIPT_URL || "",
    respectDoNotTrack: config.RESPECT_DO_NOT_TRACK !== "false",
    requireConsent: config.REQUIRE_CONSENT !== "false",
    anonymizeIp: config.ANONYMIZE_IP !== "false",
    cookieless: config.COOKIELESS === "true",
    debugMode: config.DEBUG_MODE === "true",
  })

  // Get selected provider info
  const selectedProvider = useMemo(
    () => data.providers.find((p) => p.id === formState.provider),
    [data.providers, formState.provider],
  )

  // Update a single form field
  const updateField = <K extends keyof AnalyticsFormState>(field: K, value: AnalyticsFormState[K]) => {
    setFormState((prev) => ({ ...prev, [field]: value }))
  }

  // Handle form submission
  const handleSave = () => {
    if (onSave) {
      onSave({
        PROVIDER: formState.provider,
        TRACKING_ID: formState.trackingId,
        SCRIPT_URL: formState.scriptUrl,
        RESPECT_DO_NOT_TRACK: formState.respectDoNotTrack.toString(),
        REQUIRE_CONSENT: formState.requireConsent.toString(),
        ANONYMIZE_IP: formState.anonymizeIp.toString(),
        COOKIELESS: formState.cookieless.toString(),
        DEBUG_MODE: formState.debugMode.toString(),
      })
    }
  }

  // Render form control with consistent styling
  const FormControl = ({
    label,
    description,
    children,
  }: {
    label: string
    description?: string
    children: React.ReactNode
  }) => (
    <div className="space-y-2">
      <Label htmlFor={label.toLowerCase().replace(/\s+/g, "-")} className="font-medium">
        {label}
      </Label>
      {description && <p className="text-sm text-muted-foreground">{description}</p>}
      {children}
    </div>
  )

  // Render toggle control with consistent styling
  const ToggleControl = ({
    label,
    description,
    checked,
    onChange,
  }: {
    label: string
    description: string
    checked: boolean
    onChange: (checked: boolean) => void
  }) => (
    <div className="flex items-center justify-between">
      <div>
        <Label htmlFor={label.toLowerCase().replace(/\s+/g, "-")} className="font-medium">
          {label}
        </Label>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
      <Switch id={label.toLowerCase().replace(/\s+/g, "-")} checked={checked} onCheckedChange={onChange} />
    </div>
  )

  return (
    <Card>
      <CardHeader>
        <CardTitle>Analytics Configuration</CardTitle>
        <CardDescription>Configure your analytics provider and privacy settings</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="provider">
          <TabsList className="mb-4">
            <TabsTrigger value="provider">Provider</TabsTrigger>
            <TabsTrigger value="privacy">Privacy</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>

          <TabsContent value="provider" className="space-y-4">
            <FormControl label="Analytics Provider" description="Select the analytics service you want to use">
              <Select value={formState.provider} onValueChange={(value) => updateField("provider", value)}>
                <SelectTrigger id="provider">
                  <SelectValue placeholder="Select a provider" />
                </SelectTrigger>
                <SelectContent>
                  {data.providers.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {selectedProvider && <p className="text-sm text-muted-foreground mt-2">{selectedProvider.description}</p>}
            </FormControl>

            <FormControl
              label="Tracking ID"
              description={`The unique identifier for your ${selectedProvider?.name || "analytics"} property`}
            >
              <Input
                id="tracking-id"
                value={formState.trackingId}
                onChange={(e) => updateField("trackingId", e.target.value)}
                placeholder={`Enter your ${selectedProvider?.name || "analytics"} tracking ID`}
              />
            </FormControl>

            {selectedProvider?.requiresScriptUrl && (
              <FormControl label="Script URL" description={`The URL to your ${selectedProvider?.name} instance script`}>
                <Input
                  id="script-url"
                  value={formState.scriptUrl}
                  onChange={(e) => updateField("scriptUrl", e.target.value)}
                  placeholder={`Enter your ${selectedProvider?.name} script URL`}
                />
              </FormControl>
            )}

            {selectedProvider && (
              <Alert variant="outline" className="mt-4">
                <InfoIcon className="h-4 w-4" />
                <AlertDescription>
                  <a
                    href={selectedProvider.privacyPolicyUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-primary hover:underline"
                  >
                    View {selectedProvider.name} privacy policy
                  </a>
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="privacy" className="space-y-4">
            <ToggleControl
              label="Respect Do Not Track"
              description="Don't track users who have enabled the Do Not Track setting in their browser"
              checked={formState.respectDoNotTrack}
              onChange={(value) => updateField("respectDoNotTrack", value)}
            />

            <ToggleControl
              label="Require Consent"
              description="Show a consent banner and only track users who have given consent"
              checked={formState.requireConsent}
              onChange={(value) => updateField("requireConsent", value)}
            />

            <ToggleControl
              label="Anonymize IP Addresses"
              description="Remove the last octet of the IP address before sending data to the analytics provider"
              checked={formState.anonymizeIp}
              onChange={(value) => updateField("anonymizeIp", value)}
            />

            <ToggleControl
              label="Cookieless Tracking"
              description="Use cookieless tracking when possible (not supported by all providers)"
              checked={formState.cookieless}
              onChange={(value) => updateField("cookieless", value)}
            />
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <ToggleControl
              label="Debug Mode"
              description="Log tracking information to the console instead of sending it to the analytics provider"
              checked={formState.debugMode}
              onChange={(value) => updateField("debugMode", value)}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave}>Save Configuration</Button>
      </CardFooter>
    </Card>
  )
}

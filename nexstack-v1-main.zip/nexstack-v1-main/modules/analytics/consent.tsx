"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import Link from "next/link"
import { X } from "lucide-react"
import { secureStore, secureRetrieve } from "@/lib/security"

interface ConsentBannerProps {
  title: string
  description: string
  acceptText: string
  declineText: string
  settingsText: string
  privacyLinkText: string
  privacyLinkUrl: string
  onAccept: () => void
  onDecline: () => void
}

export function ConsentBanner({
  title,
  description,
  acceptText,
  declineText,
  settingsText,
  privacyLinkText,
  privacyLinkUrl,
  onAccept,
  onDecline,
}: ConsentBannerProps) {
  const [showBanner, setShowBanner] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [analyticsConsent, setAnalyticsConsent] = useState(false)

  useEffect(() => {
    // Check if consent has already been given using secure storage
    const consentStatus = secureRetrieve("analytics-consent", null)
    if (consentStatus === null) {
      // No decision has been made yet, show the banner
      setShowBanner(true)
    }
  }, [])

  const handleAccept = () => {
    secureStore("analytics-consent", { status: "accepted", timestamp: Date.now() })
    setShowBanner(false)
    onAccept()
  }

  const handleDecline = () => {
    secureStore("analytics-consent", { status: "declined", timestamp: Date.now() })
    setShowBanner(false)
    onDecline()
  }

  const handleSaveSettings = () => {
    if (analyticsConsent) {
      secureStore("analytics-consent", { status: "accepted", timestamp: Date.now() })
      onAccept()
    } else {
      secureStore("analytics-consent", { status: "declined", timestamp: Date.now() })
      onDecline()
    }
    setShowSettings(false)
    setShowBanner(false)
  }

  if (!showBanner) {
    return null
  }

  return (
    <>
      <div className="fixed bottom-0 left-0 right-0 z-50 p-4 md:p-6">
        <Card className="mx-auto max-w-4xl shadow-lg">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle>{title}</CardTitle>
              <Button variant="ghost" size="icon" onClick={handleDecline} aria-label="Close">
                <X className="h-4 w-4" />
              </Button>
            </div>
            <CardDescription>{description}</CardDescription>
          </CardHeader>
          <CardFooter className="flex flex-col sm:flex-row gap-2 pt-2">
            <div className="flex-1 flex justify-start">
              <Button variant="link" size="sm" asChild className="h-auto p-0">
                <Link href={privacyLinkUrl}>{privacyLinkText}</Link>
              </Button>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <Button variant="outline" size="sm" onClick={() => setShowSettings(true)} className="flex-1 sm:flex-none">
                {settingsText}
              </Button>
              <Button variant="outline" size="sm" onClick={handleDecline} className="flex-1 sm:flex-none">
                {declineText}
              </Button>
              <Button size="sm" onClick={handleAccept} className="flex-1 sm:flex-none">
                {acceptText}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </div>

      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cookie Settings</DialogTitle>
            <DialogDescription>
              Configure your cookie preferences. Essential cookies are always enabled as they are necessary for the
              website to function properly.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="essential-cookies" className="font-medium">
                  Essential Cookies
                </Label>
                <p className="text-sm text-muted-foreground">
                  These cookies are necessary for the website to function properly.
                </p>
              </div>
              <Switch id="essential-cookies" checked disabled />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="analytics-cookies" className="font-medium">
                  Analytics Cookies
                </Label>
                <p className="text-sm text-muted-foreground">
                  These cookies help us understand how visitors interact with our website.
                </p>
              </div>
              <Switch id="analytics-cookies" checked={analyticsConsent} onCheckedChange={setAnalyticsConsent} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowSettings(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveSettings}>Save Preferences</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}

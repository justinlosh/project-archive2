"use client"

import { secureRetrieve } from "@/lib/security"

type EventProperties = Record<string, any>

/**
 * Track an event with the configured analytics provider
 * @param eventName The name of the event to track
 * @param properties Optional properties to include with the event
 */
export function trackEvent(eventName: string, properties?: EventProperties): void {
  // Check if consent has been given using secure storage
  const consentData = secureRetrieve("analytics-consent", { status: "declined" })
  if (consentData.status !== "accepted") {
    console.log("[Analytics] Event not tracked due to missing consent:", eventName, properties)
    return
  }

  // Check if Do Not Track is enabled and respected
  const respectDoNotTrack = process.env.MODULE_ANALYTICS_RESPECT_DO_NOT_TRACK !== "false"
  if (respectDoNotTrack && navigator.doNotTrack === "1") {
    console.log("[Analytics] Event not tracked due to Do Not Track:", eventName, properties)
    return
  }

  // Debug mode
  const debugMode = process.env.MODULE_ANALYTICS_DEBUG_MODE === "true"
  if (debugMode) {
    console.log("[Analytics] Event tracked:", eventName, properties)
    return
  }

  // Track with Google Analytics
  if (typeof window !== "undefined" && window.gtag && process.env.MODULE_ANALYTICS_PROVIDER === "google-analytics") {
    window.gtag("event", eventName, properties)
  }

  // Track with Umami
  if (typeof window !== "undefined" && window.umami && process.env.MODULE_ANALYTICS_PROVIDER === "umami") {
    window.umami.track(eventName, properties)
  }

  // Track with Plausible
  if (typeof window !== "undefined" && window.plausible && process.env.MODULE_ANALYTICS_PROVIDER === "plausible") {
    window.plausible(eventName, { props: properties })
  }

  // Track with Fathom
  if (typeof window !== "undefined" && window.fathom && process.env.MODULE_ANALYTICS_PROVIDER === "fathom") {
    window.fathom.trackGoal(eventName, properties?.value || 0)
  }

  // Track with Ackee
  if (typeof window !== "undefined" && window.Ackee?.tracker && process.env.MODULE_ANALYTICS_PROVIDER === "ackee") {
    window.Ackee.tracker("record", eventName, properties)
  }
}

/**
 * Track a page view with the configured analytics provider
 * @param url The URL of the page to track
 * @param title The title of the page
 */
export function trackPageView(url: string, title?: string): void {
  // Check if consent has been given using secure storage
  const consentData = secureRetrieve("analytics-consent", { status: "declined" })
  if (consentData.status !== "accepted") {
    console.log("[Analytics] Page view not tracked due to missing consent:", url, title)
    return
  }

  // Check if Do Not Track is enabled and respected
  const respectDoNotTrack = process.env.MODULE_ANALYTICS_RESPECT_DO_NOT_TRACK !== "false"
  if (respectDoNotTrack && navigator.doNotTrack === "1") {
    console.log("[Analytics] Page view not tracked due to Do Not Track:", url, title)
    return
  }

  // Debug mode
  const debugMode = process.env.MODULE_ANALYTICS_DEBUG_MODE === "true"
  if (debugMode) {
    console.log("[Analytics] Page view tracked:", url, title)
    return
  }

  // Track with Google Analytics
  if (typeof window !== "undefined" && window.gtag && process.env.MODULE_ANALYTICS_PROVIDER === "google-analytics") {
    window.gtag("config", process.env.MODULE_ANALYTICS_TRACKING_ID || "", {
      page_path: url,
      page_title: title,
    })
  }

  // Track with Umami
  if (typeof window !== "undefined" && window.umami && process.env.MODULE_ANALYTICS_PROVIDER === "umami") {
    window.umami.trackView(url)
  }

  // Track with Plausible
  if (typeof window !== "undefined" && window.plausible && process.env.MODULE_ANALYTICS_PROVIDER === "plausible") {
    window.plausible("pageview", { props: { url, title } })
  }

  // Track with Fathom
  if (typeof window !== "undefined" && window.fathom && process.env.MODULE_ANALYTICS_PROVIDER === "fathom") {
    window.fathom.trackPageview({ url, title })
  }

  // Track with Ackee
  if (typeof window !== "undefined" && window.Ackee?.tracker && process.env.MODULE_ANALYTICS_PROVIDER === "ackee") {
    window.Ackee.tracker("navigate", { url, title })
  }
}

// This component doesn't render anything visible
// It's used to generate the robots.txt file
export default function RobotsTxtModule() {
  return null
}

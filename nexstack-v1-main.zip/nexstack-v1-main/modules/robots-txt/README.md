# Robots.txt Module

This module provides a configurable robots.txt file for controlling search engine crawling behavior.

## Features

- Generate a robots.txt file based on configuration
- Predefined presets for common scenarios
- Custom rules for specific user agents
- Support for Sitemap, Crawl-delay, and Host directives
- Admin interface for easy configuration

## Configuration

The Robots.txt module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_ROBOTS_TXT` | Enable/disable the robots.txt module | `false` |
| `MODULE_ROBOTS_TXT_ALLOW_ALL` | Allow all search engines to crawl all pages | `true` |
| `MODULE_ROBOTS_TXT_DISALLOW_ALL` | Prevent all search engines from crawling any page | `false` |
| `MODULE_ROBOTS_TXT_CUSTOM_RULES` | JSON string of custom rules | `` |
| `MODULE_ROBOTS_TXT_SITEMAP_URL` | URL to your sitemap | `` |
| `MODULE_ROBOTS_TXT_CRAWL_DELAY` | Crawl delay in seconds | `` |
| `MODULE_ROBOTS_TXT_HOST_URL` | Host URL for the Host directive | `` |

## Usage

The Robots.txt module automatically generates a robots.txt file at the `/robots.txt` route based on your configuration.

### Custom Rules

Custom rules can be defined as a JSON string in the `MODULE_ROBOTS_TXT_CUSTOM_RULES` environment variable. The format is:

\`\`\`json
[
  {
    "userAgent": "*",
    "allow": ["/"],
    "disallow": ["/admin/", "/private/"]
  },
  {
    "userAgent": "Googlebot",
    "allow": ["/public/"],
    "disallow": ["/private/"]
  }
]
\`\`\`

## Integration with Sitemap Module

If the Sitemap module is enabled, the robots.txt file will automatically include a reference to your sitemap.

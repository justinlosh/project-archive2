export default {
  title: "Robots.txt",
  description: "Configurable robots.txt file for search engine crawling",
  defaultSettings: {
    allowAll: true,
    disallowAll: false,
    customRules: [],
    sitemapUrl: "",
    crawlDelay: "",
    hostUrl: "",
  },
  presets: {
    allowAll: {
      name: "Allow All",
      description: "Allow all search engines to crawl all pages",
      rules: [{ userAgent: "*", allow: ["/"], disallow: [] }],
    },
    disallowAll: {
      name: "Disallow All",
      description: "Prevent all search engines from crawling any page",
      rules: [{ userAgent: "*", allow: [], disallow: ["/"] }],
    },
    standardProtection: {
      name: "Standard Protection",
      description: "Allow most pages but protect sensitive areas",
      rules: [{ userAgent: "*", allow: ["/"], disallow: ["/admin/", "/private/", "/*.json$", "/*.xml$"] }],
    },
  },
}

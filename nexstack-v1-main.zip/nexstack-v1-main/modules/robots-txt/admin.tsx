"use client"

import { useState, useEffect, useMemo } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { InfoIcon, Plus, Trash2 } from "lucide-react"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { getModuleStatus } from "@/lib/module-loader"

interface RobotRule {
  userAgent: string
  allow: string[]
  disallow: string[]
}

interface AdminRobotsTxtProps {
  config: Record<string, string>
  onSave?: (config: Record<string, string>) => void
}

/**
 * Admin interface for configuring robots.txt settings
 */
export function AdminRobotsTxt({ config, onSave }: AdminRobotsTxtProps) {
  // Form state
  const [allowAll, setAllowAll] = useState(config.ALLOW_ALL !== "false")
  const [disallowAll, setDisallowAll] = useState(config.DISALLOW_ALL === "true")
  const [sitemapUrl, setSitemapUrl] = useState(config.SITEMAP_URL || "")
  const [crawlDelay, setCrawlDelay] = useState(config.CRAWL_DELAY || "")
  const [hostUrl, setHostUrl] = useState(config.HOST_URL || "")
  const [customRules, setCustomRules] = useState<RobotRule[]>([])
  const [selectedPreset, setSelectedPreset] = useState<string>("custom")
  const [formTouched, setFormTouched] = useState(false)

  const isSitemapEnabled = getModuleStatus("sitemap")

  // Parse custom rules from config
  useEffect(() => {
    try {
      if (config.CUSTOM_RULES) {
        setCustomRules(JSON.parse(config.CUSTOM_RULES))
      }
    } catch (error) {
      console.error("Error parsing custom rules:", error)
      setCustomRules([])
    }
  }, [config.CUSTOM_RULES])

  // Track form changes
  useEffect(() => {
    setFormTouched(true)
  }, [allowAll, disallowAll, sitemapUrl, crawlDelay, hostUrl, customRules])

  // Handle preset selection
  const handlePresetChange = (value: string) => {
    setSelectedPreset(value)
    setFormTouched(true)

    if (value === "allow-all") {
      setAllowAll(true)
      setDisallowAll(false)
      setCustomRules([])
    } else if (value === "disallow-all") {
      setAllowAll(false)
      setDisallowAll(true)
      setCustomRules([])
    } else if (value === "standard-protection") {
      setAllowAll(false)
      setDisallowAll(false)
      setCustomRules([
        {
          userAgent: "*",
          allow: ["/"],
          disallow: ["/admin/", "/private/", "/*.json$", "/*.xml$"],
        },
      ])
    }
  }

  // Add a new rule
  const addRule = () => {
    setCustomRules([...customRules, { userAgent: "*", allow: [], disallow: [] }])
    setFormTouched(true)
  }

  // Remove a rule
  const removeRule = (index: number) => {
    const newRules = [...customRules]
    newRules.splice(index, 1)
    setCustomRules(newRules)
    setFormTouched(true)
  }

  // Update a rule
  const updateRule = (index: number, field: keyof RobotRule, value: string | string[]) => {
    const newRules = [...customRules]
    newRules[index] = { ...newRules[index], [field]: value }
    setCustomRules(newRules)
    setFormTouched(true)
  }

  // Parse comma-separated paths
  const parsePaths = (input: string): string[] => {
    return input
      .split(",")
      .map((path) => path.trim())
      .filter((path) => path.length > 0)
  }

  // Handle save
  const handleSave = () => {
    if (onSave) {
      onSave({
        ALLOW_ALL: allowAll.toString(),
        DISALLOW_ALL: disallowAll.toString(),
        CUSTOM_RULES: JSON.stringify(customRules),
        SITEMAP_URL: sitemapUrl,
        CRAWL_DELAY: crawlDelay,
        HOST_URL: hostUrl,
      })
      setFormTouched(false)
    }
  }

  // Preview robots.txt content
  const robotsTxtPreview = useMemo((): string => {
    let content = ""

    if (disallowAll) {
      content += "User-agent: *\nDisallow: /\n"
    } else if (allowAll && customRules.length === 0) {
      content += "User-agent: *\nAllow: /\n"
    } else if (customRules.length > 0) {
      customRules.forEach((rule) => {
        content += `User-agent: ${rule.userAgent}\n`

        if (rule.allow && rule.allow.length > 0) {
          rule.allow.forEach((path) => {
            content += `Allow: ${path}\n`
          })
        }

        if (rule.disallow && rule.disallow.length > 0) {
          rule.disallow.forEach((path) => {
            content += `Disallow: ${path}\n`
          })
        }

        content += "\n"
      })
    } else {
      content += "User-agent: *\nAllow: /\n"
    }

    if (crawlDelay) {
      content += `Crawl-delay: ${crawlDelay}\n`
    }

    if (hostUrl) {
      content += `Host: ${hostUrl}\n`
    }

    if (sitemapUrl) {
      content += `Sitemap: ${sitemapUrl}\n`
    } else if (isSitemapEnabled) {
      content += `Sitemap: ${process.env.NEXT_PUBLIC_SITE_URL || "https://example.com"}/sitemap.xml\n`
    }

    return content
  }, [allowAll, disallowAll, customRules, crawlDelay, hostUrl, sitemapUrl, isSitemapEnabled])

  return (
    <Card>
      <CardHeader>
        <CardTitle>Robots.txt Configuration</CardTitle>
        <CardDescription>Configure how search engines crawl your website</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="presets">
          <TabsList className="mb-4">
            <TabsTrigger value="presets">Presets</TabsTrigger>
            <TabsTrigger value="custom-rules">Custom Rules</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="presets" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="preset-select">Select a Preset</Label>
              <Select value={selectedPreset} onValueChange={handlePresetChange}>
                <SelectTrigger id="preset-select">
                  <SelectValue placeholder="Select a preset" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="allow-all">Allow All</SelectItem>
                  <SelectItem value="disallow-all">Disallow All</SelectItem>
                  <SelectItem value="standard-protection">Standard Protection</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-sm text-muted-foreground">
                Choose a preset configuration or select "Custom" to define your own rules
              </p>
            </div>

            <div className="space-y-4 mt-6">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="allow-all" className="font-medium">
                    Allow All
                  </Label>
                  <p className="text-sm text-muted-foreground">Allow all search engines to crawl all pages</p>
                </div>
                <Switch
                  id="allow-all"
                  checked={allowAll}
                  onCheckedChange={(checked) => {
                    setAllowAll(checked)
                    if (checked) {
                      setDisallowAll(false)
                      setSelectedPreset("allow-all")
                    } else {
                      setSelectedPreset("custom")
                    }
                  }}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="disallow-all" className="font-medium">
                    Disallow All
                  </Label>
                  <p className="text-sm text-muted-foreground">Prevent all search engines from crawling any page</p>
                </div>
                <Switch
                  id="disallow-all"
                  checked={disallowAll}
                  onCheckedChange={(checked) => {
                    setDisallowAll(checked)
                    if (checked) {
                      setAllowAll(false)
                      setSelectedPreset("disallow-all")
                    } else {
                      setSelectedPreset("custom")
                    }
                  }}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="custom-rules" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-medium">Custom Rules</h3>
              <Button onClick={addRule} size="sm" variant="outline" className="flex items-center gap-1">
                <Plus className="h-4 w-4" /> Add Rule
              </Button>
            </div>

            {customRules.length === 0 ? (
              <div className="text-center p-6 border rounded-md bg-muted/50">
                <p className="text-muted-foreground">No custom rules defined. Click "Add Rule" to create one.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {customRules.map((rule, index) => (
                  <Card key={index} className="border border-muted">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-base">Rule {index + 1}</CardTitle>
                        <Button onClick={() => removeRule(index)} size="sm" variant="ghost" className="h-8 w-8 p-0">
                          <Trash2 className="h-4 w-4" />
                          <span className="sr-only">Remove rule</span>
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor={`user-agent-${index}`}>User Agent</Label>
                        <Input
                          id={`user-agent-${index}`}
                          value={rule.userAgent}
                          onChange={(e) => updateRule(index, "userAgent", e.target.value)}
                          placeholder="*"
                        />
                        <p className="text-xs text-muted-foreground">
                          Use * for all bots, or specify a bot name like Googlebot
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`allow-${index}`}>Allow Paths</Label>
                        <Textarea
                          id={`allow-${index}`}
                          value={rule.allow.join(", ")}
                          onChange={(e) => updateRule(index, "allow", parsePaths(e.target.value))}
                          placeholder="/public/, /blog/"
                        />
                        <p className="text-xs text-muted-foreground">
                          Comma-separated list of paths to allow (e.g., /, /blog/)
                        </p>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor={`disallow-${index}`}>Disallow Paths</Label>
                        <Textarea
                          id={`disallow-${index}`}
                          value={rule.disallow.join(", ")}
                          onChange={(e) => updateRule(index, "disallow", parsePaths(e.target.value))}
                          placeholder="/admin/, /private/"
                        />
                        <p className="text-xs text-muted-foreground">
                          Comma-separated list of paths to disallow (e.g., /admin/, /private/)
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="advanced" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="sitemap-url">Sitemap URL</Label>
              <Input
                id="sitemap-url"
                value={sitemapUrl}
                onChange={(e) => setSitemapUrl(e.target.value)}
                placeholder="https://example.com/sitemap.xml"
              />
              <p className="text-sm text-muted-foreground">
                URL to your sitemap (leave empty to use the default sitemap if the Sitemap module is enabled)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="crawl-delay">Crawl Delay</Label>
              <Input
                id="crawl-delay"
                value={crawlDelay}
                onChange={(e) => setCrawlDelay(e.target.value)}
                placeholder="10"
              />
              <p className="text-sm text-muted-foreground">
                Number of seconds to wait between successive crawl requests (optional)
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="host-url">Host URL</Label>
              <Input
                id="host-url"
                value={hostUrl}
                onChange={(e) => setHostUrl(e.target.value)}
                placeholder="example.com"
              />
              <p className="text-sm text-muted-foreground">Preferred domain name for your site (optional)</p>
            </div>

            {isSitemapEnabled && !sitemapUrl && (
              <Alert>
                <InfoIcon className="h-4 w-4" />
                <AlertDescription>
                  The Sitemap module is enabled. Your robots.txt will automatically include a reference to your sitemap.
                </AlertDescription>
              </Alert>
            )}
          </TabsContent>

          <TabsContent value="preview" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="robots-preview">Robots.txt Preview</Label>
              <Textarea id="robots-preview" value={robotsTxtPreview} readOnly className="font-mono text-sm" rows={10} />
              <p className="text-sm text-muted-foreground">
                This is a preview of your robots.txt file based on your current configuration
              </p>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div className="text-sm text-muted-foreground">{formTouched && "You have unsaved changes"}</div>
        <Button onClick={handleSave} disabled={!formTouched}>
          Save Configuration
        </Button>
      </CardFooter>
    </Card>
  )
}

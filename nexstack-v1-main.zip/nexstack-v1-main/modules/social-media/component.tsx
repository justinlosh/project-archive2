"use client"

import { useMemo } from "react"
import Link from "next/link"
import * as LucideIcons from "lucide-react"
import { cn } from "@/lib/utils"

interface SocialMediaProps {
  config: Record<string, string>
  iconSize?: number
  iconColor?: string
  displayNames?: boolean
  layout?: "horizontal" | "vertical" | "grid"
  className?: string
}

interface SocialPlatform {
  id: string
  name: string
  icon: keyof typeof LucideIcons
  url: string
  username: string
}

export default function SocialMedia({
  config,
  iconSize,
  iconColor,
  displayNames,
  layout,
  className,
}: SocialMediaProps) {
  // Get configuration values
  const configIconSize = Number(config.ICON_SIZE || "5")
  const configIconColor = config.ICON_COLOR || ""
  const configDisplayNames = config.DISPLAY_NAMES === "true"
  const configLayout = config.LAYOUT || "horizontal"

  // Use props if provided, otherwise use config values
  const size = iconSize || configIconSize
  const color = iconColor || configIconColor
  const showNames = displayNames !== undefined ? displayNames : configDisplayNames
  const socialLayout = layout || configLayout

  // Get platforms data
  const platforms = useMemo(() => {
    const result: SocialPlatform[] = []

    // Import platforms data
    const importPlatforms = async () => {
      const { default: data } = await import("./data")
      return data.platforms
    }

    // Process each platform
    importPlatforms().then((platforms) => {
      platforms.forEach((platform: any) => {
        const username = config[platform.id.toUpperCase()]
        if (username) {
          let url = ""

          // Handle Mastodon specially as it's a full URL
          if (platform.id === "mastodon") {
            url = username.startsWith("http") ? username : `https://${username}`
          } else {
            url = `${platform.baseUrl}${username}`
          }

          result.push({
            id: platform.id,
            name: platform.name,
            icon: platform.icon as keyof typeof LucideIcons,
            url,
            username,
          })
        }
      })
    })

    return result
  }, [config])

  // Calculate icon size class
  const getIconSizeClass = (size: number) => {
    const sizeMap: Record<number, string> = {
      1: "h-3 w-3",
      2: "h-4 w-4",
      3: "h-5 w-5",
      4: "h-6 w-6",
      5: "h-7 w-7",
      6: "h-8 w-8",
      7: "h-9 w-9",
      8: "h-10 w-10",
      9: "h-12 w-12",
      10: "h-14 w-14",
    }
    return sizeMap[size] || "h-5 w-5"
  }

  // Calculate layout class
  const getLayoutClass = (layout: string) => {
    const layoutMap: Record<string, string> = {
      horizontal: "flex flex-row flex-wrap gap-4",
      vertical: "flex flex-col gap-3",
      grid: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4",
    }
    return layoutMap[layout] || "flex flex-row flex-wrap gap-4"
  }

  // If no platforms are configured, show a message
  if (platforms.length === 0) {
    return <div className="text-center p-4 text-muted-foreground">No social media accounts configured.</div>
  }

  return (
    <div className={cn("social-media-links", getLayoutClass(socialLayout), className)}>
      {platforms.map((platform) => {
        const IconComponent = LucideIcons[platform.icon] || LucideIcons.Link

        return (
          <Link
            key={platform.id}
            href={platform.url}
            target="_blank"
            rel="noopener noreferrer"
            className={cn(
              "flex items-center gap-2 transition-colors",
              showNames ? "justify-start" : "justify-center",
              color ? `text-${color} hover:text-${color}/80` : "text-foreground hover:text-primary",
            )}
            aria-label={`Visit our ${platform.name} page`}
          >
            <IconComponent className={getIconSizeClass(size)} />
            {showNames && <span className="text-sm font-medium">{platform.name}</span>}
          </Link>
        )
      })}
    </div>
  )
}

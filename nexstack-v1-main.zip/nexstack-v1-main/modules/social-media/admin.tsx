"use client"

import React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import * as LucideIcons from "lucide-react"

interface AdminSocialMediaProps {
  config: Record<string, string>
  onSave?: (config: Record<string, string>) => void
}

interface Platform {
  id: string
  name: string
  icon: keyof typeof LucideIcons
  baseUrl: string
  placeholder: string
}

export function AdminSocialMedia({ config, onSave }: AdminSocialMediaProps) {
  const [platforms, setPlatforms] = useState<Platform[]>([])
  const [accounts, setAccounts] = useState<Record<string, string>>({})
  const [iconSize, setIconSize] = useState(Number(config.ICON_SIZE || "5"))
  const [iconColor, setIconColor] = useState(config.ICON_COLOR || "")
  const [displayNames, setDisplayNames] = useState(config.DISPLAY_NAMES === "true")
  const [layout, setLayout] = useState(config.LAYOUT || "horizontal")

  // Load platforms data
  useEffect(() => {
    const loadPlatforms = async () => {
      try {
        const { default: data } = await import("./data")
        setPlatforms(data.platforms)
      } catch (error) {
        console.error("Error loading platforms data:", error)
      }
    }

    loadPlatforms()
  }, [])

  // Initialize accounts from config
  useEffect(() => {
    const newAccounts: Record<string, string> = {}

    Object.keys(config).forEach((key) => {
      const platformKey = key.toLowerCase()
      if (
        platformKey !== "icon_size" &&
        platformKey !== "icon_color" &&
        platformKey !== "display_names" &&
        platformKey !== "layout"
      ) {
        newAccounts[platformKey] = config[key] || ""
      }
    })

    setAccounts(newAccounts)
  }, [config])

  // Update account
  const updateAccount = (platformId: string, value: string) => {
    setAccounts((prev) => ({ ...prev, [platformId]: value }))
  }

  // Handle save
  const handleSave = () => {
    if (onSave) {
      const newConfig: Record<string, string> = {
        ...accounts,
        ICON_SIZE: iconSize.toString(),
        ICON_COLOR: iconColor,
        DISPLAY_NAMES: displayNames.toString(),
        LAYOUT: layout,
      }

      onSave(newConfig)
    }
  }

  // Preview component
  const SocialMediaPreview = () => {
    // Filter platforms with accounts
    const activePlatforms = platforms.filter((platform) => accounts[platform.id])

    if (activePlatforms.length === 0) {
      return <div className="text-center p-4 text-muted-foreground">No social media accounts configured.</div>
    }

    // Calculate icon size class
    const getIconSizeClass = (size: number) => {
      const sizeMap: Record<number, string> = {
        1: "h-3 w-3",
        2: "h-4 w-4",
        3: "h-5 w-5",
        4: "h-6 w-6",
        5: "h-7 w-7",
        6: "h-8 w-8",
        7: "h-9 w-9",
        8: "h-10 w-10",
        9: "h-12 w-12",
        10: "h-14 w-14",
      }
      return sizeMap[size] || "h-5 w-5"
    }

    // Calculate layout class
    const getLayoutClass = (layout: string) => {
      const layoutMap: Record<string, string> = {
        horizontal: "flex flex-row flex-wrap gap-4",
        vertical: "flex flex-col gap-3",
        grid: "grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4",
      }
      return layoutMap[layout] || "flex flex-row flex-wrap gap-4"
    }

    return (
      <div className={`social-media-preview ${getLayoutClass(layout)}`}>
        {activePlatforms.map((platform) => {
          const IconComponent = LucideIcons[platform.icon] || LucideIcons.Link

          return (
            <div
              key={platform.id}
              className={`flex items-center gap-2 transition-colors ${displayNames ? "justify-start" : "justify-center"} ${
                iconColor ? `text-${iconColor}` : "text-foreground"
              }`}
            >
              <IconComponent className={getIconSizeClass(iconSize)} />
              {displayNames && <span className="text-sm font-medium">{platform.name}</span>}
            </div>
          )
        })}
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Social Media Configuration</CardTitle>
        <CardDescription>Configure your social media accounts and display settings</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="accounts">
          <TabsList className="mb-4">
            <TabsTrigger value="accounts">Accounts</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>

          <TabsContent value="accounts" className="space-y-4">
            <div className="grid gap-4">
              {platforms.map((platform) => (
                <div key={platform.id} className="space-y-2">
                  <Label htmlFor={`platform-${platform.id}`}>{platform.name}</Label>
                  <div className="flex items-center gap-2">
                    {LucideIcons[platform.icon] && (
                      <div className="flex-shrink-0">
                        {React.createElement(LucideIcons[platform.icon], { className: "h-5 w-5" })}
                      </div>
                    )}
                    <Input
                      id={`platform-${platform.id}`}
                      value={accounts[platform.id] || ""}
                      onChange={(e) => updateAccount(platform.id, e.target.value)}
                      placeholder={platform.placeholder}
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {platform.id === "mastodon"
                      ? "Enter your full Mastodon URL (e.g., https://mastodon.social/@username)"
                      : `Enter your ${platform.name} username (without the URL)`}
                  </p>
                </div>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="icon-size">Icon Size</Label>
              <div className="flex items-center gap-4">
                <Slider
                  id="icon-size"
                  min={1}
                  max={10}
                  step={1}
                  value={[iconSize]}
                  onValueChange={(value) => setIconSize(value[0])}
                  className="flex-1"
                />
                <span className="w-12 text-center">{iconSize}</span>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="icon-color">Icon Color</Label>
              <Input
                id="icon-color"
                value={iconColor}
                onChange={(e) => setIconColor(e.target.value)}
                placeholder="primary, blue-500, #3b82f6, etc."
              />
              <p className="text-xs text-muted-foreground">
                Enter a Tailwind color class (e.g., primary, blue-500) or a hex color code (e.g., #3b82f6)
              </p>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="display-names" className="font-medium">
                  Display Platform Names
                </Label>
                <p className="text-sm text-muted-foreground">Show the name of each platform alongside its icon</p>
              </div>
              <Switch id="display-names" checked={displayNames} onCheckedChange={setDisplayNames} />
            </div>

            <div className="space-y-2">
              <Label htmlFor="layout">Layout</Label>
              <Select value={layout} onValueChange={setLayout}>
                <SelectTrigger id="layout">
                  <SelectValue placeholder="Select a layout" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="horizontal">Horizontal</SelectItem>
                  <SelectItem value="vertical">Vertical</SelectItem>
                  <SelectItem value="grid">Grid</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="preview" className="space-y-4">
            <div className="border rounded-md p-6 bg-muted/20">
              <h3 className="text-sm font-medium mb-4">Preview</h3>
              <SocialMediaPreview />
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter>
        <Button onClick={handleSave}>Save Configuration</Button>
      </CardFooter>
    </Card>
  )
}

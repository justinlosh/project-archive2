# Social Media Module

This module provides social media integration with configurable accounts and icons.

## Features

- Configure social media accounts for various platforms
- Display social media links and icons throughout the website
- Customizable icon size, color, and layout
- Option to display platform names alongside icons
- Responsive design for all screen sizes

## Configuration

The Social Media module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_SOCIAL_MEDIA` | Enable/disable the social media module | `false` |
| `MODULE_SOCIAL_MEDIA_TWITTER` | Twitter username | `` |
| `MODULE_SOCIAL_MEDIA_FACEBOOK` | Facebook username | `` |
| `MODULE_SOCIAL_MEDIA_INSTAGRAM` | Instagram username | `` |
| `MODULE_SOCIAL_MEDIA_LINKEDIN` | LinkedIn username | `` |
| `MODULE_SOCIAL_MEDIA_GITHUB` | GitHub username | `` |
| `MODULE_SOCIAL_MEDIA_YOUTUBE` | YouTube channel | `` |
| `MODULE_SOCIAL_MEDIA_DRIBBBLE` | Dribbble username | `` |
| `MODULE_SOCIAL_MEDIA_TIKTOK` | TikTok username | `` |
| `MODULE_SOCIAL_MEDIA_PINTEREST` | Pinterest username | `` |
| `MODULE_SOCIAL_MEDIA_MASTODON` | Mastodon URL | `` |
| `MODULE_SOCIAL_MEDIA_ICON_SIZE` | Icon size (1-10) | `5` |
| `MODULE_SOCIAL_MEDIA_ICON_COLOR` | Icon color (hex code or Tailwind color) | `` |
| `MODULE_SOCIAL_MEDIA_DISPLAY_NAMES` | Display platform names | `false` |
| `MODULE_SOCIAL_MEDIA_LAYOUT` | Layout (horizontal, vertical, grid) | `horizontal` |

## Usage

To use the Social Media module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the social-media module
<ModuleLoader moduleName="social-media" />
\`\`\`

## Customization

You can customize the appearance of the social media links by passing props to the component:

\`\`\`tsx
<ModuleLoader 
  moduleName="social-media" 
  props={{
    iconSize: 6,
    iconColor: "blue-500",
    displayNames: true,
    layout: "grid"
  }}
/>
\`\`\`

## Supported Platforms

The Social Media module supports the following platforms:

- Twitter
- Facebook
- Instagram
- LinkedIn
- GitHub
- YouTube
- Dribbble
- TikTok
- Pinterest
- Mastodon

You can add more platforms by updating the `data.ts` file in the social-media module directory.

"use client"

import { useEffect, useRef } from "react"
import type { BotProtectionProvider } from "./provider-interface"
import Script from "next/script"

declare global {
  interface Window {
    turnstile: any
    onTurnstileLoad: () => void
  }
}

/**
 * Client component for Cloudflare Turnstile
 */
export function TurnstileComponent({ siteKey }: { siteKey: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const loadedRef = useRef(false)

  useEffect(() => {
    // Initialize Turnstile when the script is loaded
    window.onTurnstileLoad = () => {
      if (containerRef.current && !loadedRef.current) {
        window.turnstile.render(containerRef.current, {
          sitekey: siteKey,
          theme: "auto",
        })
        loadedRef.current = true
      }
    }

    // If turnstile is already loaded, initialize immediately
    if (window.turnstile && !loadedRef.current) {
      window.turnstile.render(containerRef.current, {
        sitekey: siteKey,
        theme: "auto",
      })
      loadedRef.current = true
    }

    return () => {
      // Cleanup
      loadedRef.current = false
    }
  }, [siteKey])

  return (
    <>
      <Script
        src="https://challenges.cloudflare.com/turnstile/v0/api.js?onload=onTurnstileLoad"
        strategy="lazyOnload"
      />
      <div className="cf-turnstile my-4" ref={containerRef} data-sitekey={siteKey}></div>
    </>
  )
}

/**
 * Cloudflare Turnstile provider implementation
 */
export const turnstileProvider: BotProtectionProvider = {
  getClientComponent: (siteKey: string) => <TurnstileComponent siteKey={siteKey} />,

  verifyToken: async (token: string, secretKey: string) => {
    try {
      const response = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          secret: secretKey,
          response: token,
        }),
      })

      const data = await response.json()
      return data.success === true
    } catch (error) {
      console.error("Turnstile verification error:", error)
      return false
    }
  },

  getTokenFieldName: () => "cf-turnstile-response",
}

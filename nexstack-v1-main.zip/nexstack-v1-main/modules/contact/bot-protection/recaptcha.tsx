"use client"

import { useEffect, useRef } from "react"
import type { BotProtectionProvider } from "./provider-interface"
import Script from "next/script"

declare global {
  interface Window {
    grecaptcha: any
    onRecaptchaLoad: () => void
  }
}

/**
 * Client component for reCAPTCHA
 */
export function ReCaptchaComponent({ siteKey }: { siteKey: string }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const loadedRef = useRef(false)

  useEffect(() => {
    // Initialize reCAPTCHA when the script is loaded
    window.onRecaptchaLoad = () => {
      if (containerRef.current && !loadedRef.current) {
        window.grecaptcha.render(containerRef.current, {
          sitekey: siteKey,
          size: "normal",
        })
        loadedRef.current = true
      }
    }

    // If grecaptcha is already loaded, initialize immediately
    if (window.grecaptcha && !loadedRef.current) {
      window.grecaptcha.render(containerRef.current, {
        sitekey: siteKey,
        size: "normal",
      })
      loadedRef.current = true
    }

    return () => {
      // Cleanup
      loadedRef.current = false
    }
  }, [siteKey])

  return (
    <>
      <Script src={`https://www.google.com/recaptcha/api.js?onload=onRecaptchaLoad`} strategy="lazyOnload" />
      <div className="g-recaptcha my-4" ref={containerRef} data-sitekey={siteKey}></div>
    </>
  )
}

/**
 * reCAPTCHA provider implementation
 */
export const reCaptchaProvider: BotProtectionProvider = {
  getClientComponent: (siteKey: string) => <ReCaptchaComponent siteKey={siteKey} />,

  verifyToken: async (token: string, secretKey: string) => {
    try {
      const response = await fetch("https://www.google.com/recaptcha/api/siteverify", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `secret=${secretKey}&response=${token}`,
      })

      const data = await response.json()
      return data.success === true
    } catch (error) {
      console.error("reCAPTCHA verification error:", error)
      return false
    }
  },

  getTokenFieldName: () => "g-recaptcha-response",
}

import type * as React from "react"

/**
 * Interface for bot protection providers
 */
export interface BotProtectionProvider {
  /**
   * Get the client-side component for the provider
   * @param siteKey - The site key for the provider
   * @returns JSX element for the client-side component
   */
  getClientComponent: (siteKey: string) => React.JSX.Element

  /**
   * Verify the token from the client-side component
   * @param token - The token from the client-side component
   * @param secretKey - The secret key for the provider
   * @returns Promise resolving to a boolean indicating if the verification was successful
   */
  verifyToken: (token: string, secretKey: string) => Promise<boolean>

  /**
   * Get the name of the token field in the form data
   * @returns The name of the token field
   */
  getTokenFieldName: () => string
}

/**
 * Configuration for bot protection
 */
export interface BotProtectionConfig {
  enabled: boolean
  provider: string
  siteKey: string
  secretKey: string
}

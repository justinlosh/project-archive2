import { BotProtectionProvider, BotProtectionConfig } from "./provider-interface"
import { reCaptchaProvider } from "./recaptcha"
import { turnstileProvider } from "./turnstile"

/**
 * Get the bot protection provider based on the configuration
 * @param config - The bot protection configuration
 * @returns The bot protection provider or null if disabled
 */
export function getBotProtectionProvider(config: BotProtectionConfig): BotProtectionProvider | null {
  if (!config.enabled) {
    return null
  }

  switch (config.provider.toLowerCase()) {
    case "recaptcha":
      return reCaptchaProvider
    case "turnstile":
      return turnstileProvider
    default:
      console.warn(`Unknown bot protection provider: ${config.provider}`)
      return null
  }
}

export { BotProtectionProvider, BotProtectionConfig }

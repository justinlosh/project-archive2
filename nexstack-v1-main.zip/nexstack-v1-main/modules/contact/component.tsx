"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Mail, Send } from "lucide-react"
import { validateEmail, sanitizeInput } from "@/lib/security"
import { getBotProtectionProvider, type BotProtectionConfig } from "./bot-protection"

interface ContactModuleProps {
  config: Record<string, string>
}

interface FormErrors {
  name?: string
  email?: string
  subject?: string
  message?: string
  general?: string
}

interface FormData {
  name: string
  email: string
  subject: string
  message: string
}

export default function ContactModule({ config }: ContactModuleProps) {
  const [formData, setFormData] = useState<FormData>({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [errors, setErrors] = useState<FormErrors>({})
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")

  const title = config.TITLE || "Contact Us"
  const description = config.DESCRIPTION || "Have questions or feedback? Get in touch with our team."
  const buttonText = config.BUTTON_TEXT || "Send Message"
  const successMessage = config.SUCCESS_MESSAGE || "Thank you for your message. We'll get back to you soon!"
  const errorMessage = config.ERROR_MESSAGE || "Something went wrong. Please try again."
  const showSubject = config.SHOW_SUBJECT !== "false"
  const nameLabel = config.NAME_LABEL || "Name"
  const emailLabel = config.EMAIL_LABEL || "Email"
  const subjectLabel = config.SUBJECT_LABEL || "Subject"
  const messageLabel = config.MESSAGE_LABEL || "Message"

  // Bot protection configuration
  const botProtectionConfig: BotProtectionConfig = {
    enabled: config.BOT_PROTECTION_ENABLED === "true",
    provider: config.BOT_PROTECTION_PROVIDER || "recaptcha",
    siteKey: config.BOT_PROTECTION_SITE_KEY || "",
    secretKey: config.BOT_PROTECTION_SECRET_KEY || "",
  }

  const botProtectionProvider = getBotProtectionProvider(botProtectionConfig)

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const { name, value } = e.target
      setFormData((prev) => ({ ...prev, [name]: value }))

      // Clear error when user starts typing
      if (errors[name as keyof FormErrors]) {
        setErrors((prev) => ({ ...prev, [name]: undefined }))
      }
    },
    [errors],
  )

  const validateForm = useCallback((): boolean => {
    const newErrors: FormErrors = {}

    // Validate name
    if (!formData.name.trim()) {
      newErrors.name = "Name is required"
    } else if (formData.name.length > 100) {
      newErrors.name = "Name is too long (maximum 100 characters)"
    }

    // Validate email
    if (!formData.email.trim()) {
      newErrors.email = "Email is required"
    } else if (!validateEmail(formData.email)) {
      newErrors.email = "Please enter a valid email address"
    }

    // Validate subject if shown
    if (showSubject && !formData.subject.trim()) {
      newErrors.subject = "Subject is required"
    } else if (formData.subject.length > 200) {
      newErrors.subject = "Subject is too long (maximum 200 characters)"
    }

    // Validate message
    if (!formData.message.trim()) {
      newErrors.message = "Message is required"
    } else if (formData.message.length > 5000) {
      newErrors.message = "Message is too long (maximum 5000 characters)"
    }

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }, [formData, showSubject])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate form
    if (!validateForm()) {
      return
    }

    setStatus("loading")

    try {
      // Create form data for submission
      const formDataToSubmit = new FormData()
      formDataToSubmit.append("name", sanitizeInput(formData.name))
      formDataToSubmit.append("email", sanitizeInput(formData.email))
      formDataToSubmit.append("subject", sanitizeInput(formData.subject))
      formDataToSubmit.append("message", sanitizeInput(formData.message))

      // Get the bot protection token if available
      if (botProtectionProvider) {
        const tokenFieldName = botProtectionProvider.getTokenFieldName()
        const tokenElement = document.querySelector(`[name="${tokenFieldName}"]`) as HTMLInputElement
        if (tokenElement && tokenElement.value) {
          formDataToSubmit.append(tokenFieldName, tokenElement.value)
        } else {
          setErrors({ general: "Please complete the bot protection challenge" })
          setStatus("error")
          return
        }
      }

      // Submit the form with timeout handling
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 15000) // 15-second timeout

      const response = await fetch("/api/contact", {
        method: "POST",
        body: formDataToSubmit,
        signal: controller.signal,
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`Server responded with status: ${response.status}`)
      }

      const result = await response.json()

      if (result.success) {
        setStatus("success")
        setFormData({
          name: "",
          email: "",
          subject: "",
          message: "",
        })
      } else {
        setErrors({ general: result.message || errorMessage })
        setStatus("error")
      }
    } catch (error: any) {
      console.error("Form submission error:", error)
      setErrors({
        general: error.name === "AbortError" ? "Request timed out. Please try again." : errorMessage,
      })
      setStatus("error")
    }
  }

  return (
    <Card className="border shadow-md">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Mail className="h-5 w-5 text-primary" />
          <CardTitle>{title}</CardTitle>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className={errors.name ? "text-destructive" : ""}>
                {nameLabel} <span className="text-destructive">*</span>
              </Label>
              <Input
                id="name"
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Your name"
                required
                maxLength={100}
                aria-invalid={!!errors.name}
                aria-describedby={errors.name ? "name-error" : undefined}
                className={errors.name ? "border-destructive" : ""}
              />
              {errors.name && (
                <p id="name-error" className="text-sm text-destructive">
                  {errors.name}
                </p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="email" className={errors.email ? "text-destructive" : ""}>
                {emailLabel} <span className="text-destructive">*</span>
              </Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="your.email@example.com"
                required
                aria-invalid={!!errors.email}
                aria-describedby={errors.email ? "email-error" : undefined}
                className={errors.email ? "border-destructive" : ""}
              />
              {errors.email && (
                <p id="email-error" className="text-sm text-destructive">
                  {errors.email}
                </p>
              )}
            </div>
          </div>

          {showSubject && (
            <div className="space-y-2">
              <Label htmlFor="subject" className={errors.subject ? "text-destructive" : ""}>
                {subjectLabel} <span className="text-destructive">*</span>
              </Label>
              <Input
                id="subject"
                name="subject"
                value={formData.subject}
                onChange={handleChange}
                placeholder="What is this regarding?"
                required
                maxLength={200}
                aria-invalid={!!errors.subject}
                aria-describedby={errors.subject ? "subject-error" : undefined}
                className={errors.subject ? "border-destructive" : ""}
              />
              {errors.subject && (
                <p id="subject-error" className="text-sm text-destructive">
                  {errors.subject}
                </p>
              )}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="message" className={errors.message ? "text-destructive" : ""}>
              {messageLabel} <span className="text-destructive">*</span>
            </Label>
            <Textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Your message"
              rows={5}
              required
              maxLength={5000}
              aria-invalid={!!errors.message}
              aria-describedby={errors.message ? "message-error" : undefined}
              className={errors.message ? "border-destructive" : ""}
            />
            {errors.message && (
              <p id="message-error" className="text-sm text-destructive">
                {errors.message}
              </p>
            )}
          </div>

          {/* Bot Protection Component */}
          {botProtectionProvider &&
            botProtectionConfig.siteKey &&
            botProtectionProvider.getClientComponent(botProtectionConfig.siteKey)}

          {errors.general && (
            <p className="text-sm text-destructive" role="alert">
              {errors.general}
            </p>
          )}

          <Button type="submit" className="w-full" disabled={status === "loading"} aria-busy={status === "loading"}>
            {status === "loading" ? (
              <span className="flex items-center gap-2">
                <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
                Sending...
              </span>
            ) : (
              <span className="flex items-center gap-2">
                <Send className="h-4 w-4" />
                {buttonText}
              </span>
            )}
          </Button>
        </form>
      </CardContent>
      <CardFooter>
        {status === "success" && (
          <p className="text-sm text-green-600" role="status">
            {successMessage}
          </p>
        )}
        {status === "error" && !errors.general && (
          <p className="text-sm text-red-600" role="alert">
            {errorMessage}
          </p>
        )}
      </CardFooter>
    </Card>
  )
}

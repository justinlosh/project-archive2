"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { AlertCircle, CheckCircle2, Info, Settings } from "lucide-react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { getModuleConfig, updateModuleConfig } from "@/lib/module-system"

export default function ContactAdmin() {
  const [config, setConfig] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [status, setStatus] = useState<"idle" | "success" | "error">("idle")
  const [message, setMessage] = useState("")

  useEffect(() => {
    async function loadConfig() {
      try {
        const contactConfig = await getModuleConfig("contact")
        setConfig(contactConfig)
        setLoading(false)
      } catch (error) {
        console.error("Error loading contact module config:", error)
        setStatus("error")
        setMessage("Failed to load configuration")
        setLoading(false)
      }
    }

    loadConfig()
  }, [])

  const handleChange = (key: string, value: string) => {
    setConfig((prev) => ({ ...prev, [key]: value }))
  }

  const handleToggle = (key: string, checked: boolean) => {
    setConfig((prev) => ({ ...prev, [key]: checked ? "true" : "false" }))
  }

  const handleSave = async () => {
    setSaving(true)
    setStatus("idle")

    try {
      await updateModuleConfig("contact", config)
      setStatus("success")
      setMessage("Configuration saved successfully")
    } catch (error) {
      console.error("Error saving contact module config:", error)
      setStatus("error")
      setMessage("Failed to save configuration")
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="pt-6">
          <div className="flex justify-center">
            <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Settings className="h-5 w-5 text-primary" />
          <CardTitle>Contact Module Settings</CardTitle>
        </div>
        <CardDescription>Configure your contact form and bot protection settings</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="general">
          <TabsList className="mb-4">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="bot-protection">Bot Protection</TabsTrigger>
          </TabsList>

          <TabsContent value="general" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="title">Form Title</Label>
                <Input
                  id="title"
                  value={config.TITLE || ""}
                  onChange={(e) => handleChange("TITLE", e.target.value)}
                  placeholder="Contact Us"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="description">Form Description</Label>
                <Input
                  id="description"
                  value={config.DESCRIPTION || ""}
                  onChange={(e) => handleChange("DESCRIPTION", e.target.value)}
                  placeholder="Have questions or feedback? Get in touch with our team."
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="button-text">Button Text</Label>
                <Input
                  id="button-text"
                  value={config.BUTTON_TEXT || ""}
                  onChange={(e) => handleChange("BUTTON_TEXT", e.target.value)}
                  placeholder="Send Message"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="recipient-email">Recipient Email</Label>
                <Input
                  id="recipient-email"
                  value={config.RECIPIENT_EMAIL || ""}
                  onChange={(e) => handleChange("RECIPIENT_EMAIL", e.target.value)}
                  placeholder="contact@example.com"
                  type="email"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="success-message">Success Message</Label>
                <Input
                  id="success-message"
                  value={config.SUCCESS_MESSAGE || ""}
                  onChange={(e) => handleChange("SUCCESS_MESSAGE", e.target.value)}
                  placeholder="Thank you for your message. We'll get back to you soon!"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="error-message">Error Message</Label>
                <Input
                  id="error-message"
                  value={config.ERROR_MESSAGE || ""}
                  onChange={(e) => handleChange("ERROR_MESSAGE", e.target.value)}
                  placeholder="Something went wrong. Please try again."
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="show-subject"
                checked={config.SHOW_SUBJECT !== "false"}
                onCheckedChange={(checked) => handleToggle("SHOW_SUBJECT", checked)}
              />
              <Label htmlFor="show-subject">Show Subject Field</Label>
            </div>
          </TabsContent>

          <TabsContent value="bot-protection" className="space-y-4">
            <Alert>
              <Info className="h-4 w-4" />
              <AlertTitle>Bot Protection</AlertTitle>
              <AlertDescription>
                Configure bot protection to prevent spam submissions. You'll need to register for API keys with your
                chosen provider.
              </AlertDescription>
            </Alert>

            <div className="flex items-center space-x-2">
              <Switch
                id="bot-protection-enabled"
                checked={config.BOT_PROTECTION_ENABLED === "true"}
                onCheckedChange={(checked) => handleToggle("BOT_PROTECTION_ENABLED", checked)}
              />
              <Label htmlFor="bot-protection-enabled">Enable Bot Protection</Label>
            </div>

            {config.BOT_PROTECTION_ENABLED === "true" && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="bot-protection-provider">Protection Provider</Label>
                  <Select
                    value={config.BOT_PROTECTION_PROVIDER || "recaptcha"}
                    onValueChange={(value) => handleChange("BOT_PROTECTION_PROVIDER", value)}
                  >
                    <SelectTrigger id="bot-protection-provider">
                      <SelectValue placeholder="Select a provider" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="recaptcha">Google reCAPTCHA</SelectItem>
                      <SelectItem value="turnstile">Cloudflare Turnstile</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="site-key">Site Key</Label>
                    <Input
                      id="site-key"
                      value={config.BOT_PROTECTION_SITE_KEY || ""}
                      onChange={(e) => handleChange("BOT_PROTECTION_SITE_KEY", e.target.value)}
                      placeholder="Your site key"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="secret-key">Secret Key</Label>
                    <Input
                      id="secret-key"
                      value={config.BOT_PROTECTION_SECRET_KEY || ""}
                      onChange={(e) => handleChange("BOT_PROTECTION_SECRET_KEY", e.target.value)}
                      placeholder="Your secret key"
                      type="password"
                    />
                  </div>
                </div>

                <div className="pt-2">
                  <Alert variant={config.BOT_PROTECTION_PROVIDER === "recaptcha" ? "default" : "secondary"}>
                    <Info className="h-4 w-4" />
                    <AlertTitle>
                      {config.BOT_PROTECTION_PROVIDER === "recaptcha" ? "Google reCAPTCHA" : "Cloudflare Turnstile"}
                    </AlertTitle>
                    <AlertDescription>
                      {config.BOT_PROTECTION_PROVIDER === "recaptcha" ? (
                        <>
                          Register for API keys at{" "}
                          <a
                            href="https://www.google.com/recaptcha/admin"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline text-primary"
                          >
                            Google reCAPTCHA Admin Console
                          </a>
                        </>
                      ) : (
                        <>
                          Register for API keys at{" "}
                          <a
                            href="https://dash.cloudflare.com/?to=/:account/turnstile"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="underline text-primary"
                          >
                            Cloudflare Dashboard
                          </a>
                        </>
                      )}
                    </AlertDescription>
                  </Alert>
                </div>
              </>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between">
        <div>
          {status === "success" && (
            <div className="flex items-center text-green-600">
              <CheckCircle2 className="h-4 w-4 mr-2" />
              <span>{message}</span>
            </div>
          )}
          {status === "error" && (
            <div className="flex items-center text-red-600">
              <AlertCircle className="h-4 w-4 mr-2" />
              <span>{message}</span>
            </div>
          )}
        </div>
        <Button onClick={handleSave} disabled={saving}>
          {saving ? (
            <span className="flex items-center gap-2">
              <span className="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full" />
              Saving...
            </span>
          ) : (
            "Save Changes"
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

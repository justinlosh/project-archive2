# Contact Module

The Contact Module provides a customizable contact form with bot protection to prevent spam submissions.

## Features

- Customizable contact form with configurable fields
- Support for multiple bot protection providers:
  - Google reCAPTCHA
  - Cloudflare Turnstile
- Comprehensive form validation
- Configurable success and error messages
- Admin interface for easy configuration

## Configuration

The Contact Module can be configured through environment variables or the admin interface.

### Environment Variables

\`\`\`env
# Contact Module Configuration
MODULE_CONTACT=true
MODULE_CONTACT_TITLE=Contact Us
MODULE_CONTACT_DESCRIPTION=Have questions or feedback? Get in touch with our team.
MODULE_CONTACT_BUTTON_TEXT=Send Message
MODULE_CONTACT_SUCCESS_MESSAGE=Thank you for your message. We'll get back to you soon!
MODULE_CONTACT_ERROR_MESSAGE=Something went wrong. Please try again.
MODULE_CONTACT_SHOW_SUBJECT=true
MODULE_CONTACT_NAME_LABEL=Name
MODULE_CONTACT_EMAIL_LABEL=Email
MODULE_CONTACT_SUBJECT_LABEL=Subject
MODULE_CONTACT_MESSAGE_LABEL=Message
MODULE_CONTACT_RECIPIENT_EMAIL=contact@example.com

# Bot Protection Configuration
MODULE_CONTACT_BOT_PROTECTION_ENABLED=true
MODULE_CONTACT_BOT_PROTECTION_PROVIDER=recaptcha
MODULE_CONTACT_BOT_PROTECTION_SITE_KEY=your-site-key
MODULE_CONTACT_BOT_PROTECTION_SECRET_KEY=your-secret-key
\`\`\`

### Bot Protection

To use bot protection, you'll need to register for API keys with your chosen provider:

- **Google reCAPTCHA**: Register at [Google reCAPTCHA Admin Console](https://www.google.com/recaptcha/admin)
- **Cloudflare Turnstile**: Register at [Cloudflare Dashboard](https://dash.cloudflare.com/?to=/:account/turnstile)

## Usage

To use the Contact Module in your application, import and use the `ContactModule` component:

\`\`\`tsx
import ContactModule from "@/modules/contact/component"
import { getModuleConfig } from "@/lib/module-system"

export default async function ContactPage() {
  const config = await getModuleConfig("contact")
  
  return (
    <div>
      <h1>Contact Us</h1>
      <ContactModule config={config} />
    </div>
  )
}
\`\`\`

## Admin Interface

The Contact Module includes an admin interface for configuring the contact form and bot protection settings. To access the admin interface, navigate to `/admin/contact` in your application.

## API

The Contact Module provides an API endpoint for form submissions:

- **POST /api/contact**: Submit a contact form
  - Request body: Form data with name, email, subject, message, and bot protection token (if enabled)
  - Response: JSON with success status and message

## Extending

To add support for additional bot protection providers:

1. Create a new provider implementation in `modules/contact/bot-protection/`
2. Implement the `BotProtectionProvider` interface
3. Add the provider to the provider factory in `modules/contact/bot-protection/index.ts`

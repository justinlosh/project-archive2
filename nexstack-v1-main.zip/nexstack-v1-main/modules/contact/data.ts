import type { BotProtectionConfig } from "./bot-protection/provider-interface"

export default {
  title: "Contact Us",
  description: "Have questions or feedback? Get in touch with our team.",
  contactInfo: {
    email: "contact@example.com",
    phone: "+1 (555) 123-4567",
    address: "123 Main Street, City, Country",
  },
  socialLinks: {
    twitter: "https://twitter.com/example",
    facebook: "https://facebook.com/example",
    linkedin: "https://linkedin.com/company/example",
  },
  botProtection: {
    enabled: true,
    provider: "recaptcha", // "recaptcha" or "turnstile"
    siteKey: "", // Will be populated from environment variables
    secretKey: "", // Will be populated from environment variables
  } as BotProtectionConfig,
}

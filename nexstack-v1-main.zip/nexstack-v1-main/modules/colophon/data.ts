export default {
  title: "Colophon",
  description: "Technical details about this website",
  technologies: [
    {
      category: "Framework",
      items: [
        {
          name: "Next.js",
          version: "15.0.0",
          url: "https://nextjs.org",
          description: "The React framework for production",
        },
        {
          name: "React",
          version: "18.3.0",
          url: "https://react.dev",
          description: "A JavaScript library for building user interfaces",
        },
      ],
    },
    {
      category: "Styling",
      items: [
        {
          name: "Tailwind CSS",
          version: "3.4.0",
          url: "https://tailwindcss.com",
          description: "A utility-first CSS framework",
        },
        {
          name: "shadcn/ui",
          version: "0.5.0",
          url: "https://ui.shadcn.com",
          description: "Re-usable components built with Radix UI and Tailwind CSS",
        },
      ],
    },
    {
      category: "Deployment",
      items: [
        {
          name: "Vercel",
          url: "https://vercel.com",
          description: "Platform for frontend frameworks and static sites",
        },
      ],
    },
    {
      category: "Development Tools",
      items: [
        {
          name: "TypeScript",
          version: "5.3.0",
          url: "https://www.typescriptlang.org",
          description: "Typed JavaScript at any scale",
        },
        {
          name: "ESLint",
          version: "8.56.0",
          url: "https://eslint.org",
          description: "Find and fix problems in your JavaScript code",
        },
        {
          name: "Prettier",
          version: "3.1.0",
          url: "https://prettier.io",
          description: "Opinionated code formatter",
        },
      ],
    },
    {
      category: "Content",
      items: [
        {
          name: "Markdown",
          url: "https://daringfireball.net/projects/markdown",
          description: "Lightweight markup language for formatting text",
        },
        {
          name: "Remark",
          url: "https://remark.js.org",
          description: "Markdown processor powered by plugins",
        },
      ],
    },
  ],
  credits: [
    {
      name: "Lucide Icons",
      url: "https://lucide.dev",
      description: "Beautiful & consistent icons",
    },
    {
      name: "Google Fonts",
      url: "https://fonts.google.com",
      description: "Making the web more beautiful, fast, and open through great typography",
    },
  ],
}

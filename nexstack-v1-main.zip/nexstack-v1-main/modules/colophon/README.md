# Colophon Module

This module provides a colophon page for your website, detailing the technical stack, including technologies, libraries, and frameworks used in its development.

## Features

- Display information about the technical stack
- List technologies, libraries, and frameworks by category
- Include version information and descriptions
- Link to the official websites of each technology

## Configuration

The Colophon module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_COLOPHON` | Enable/disable the colophon module | `false` |
| `MODULE_COLOPHON_TITLE` | Title for the colophon page | `Colophon` |
| `MODULE_COLOPHON_DESCRIPTION` | Description for the colophon page | `Technical details about this website` |
| `MODULE_COLOPHON_SHOW_VERSIONS` | Show/hide version information | `true` |
| `MODULE_COLOPHON_SHOW_DESCRIPTIONS` | Show/hide descriptions | `true` |

## Usage

To use the Colophon module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the colophon module
<ModuleLoader moduleName="colophon" />
\`\`\`

## Routes

The Colophon module provides the following routes:

- `/colophon` - Colophon page

## Customizing the Colophon

To customize the technologies and credits listed on the colophon page, update the `data.ts` file in the colophon module directory:

\`\`\`typescript
export default {
  title: "Colophon",
  description: "Technical details about this website",
  technologies: [
    {
      category: "Framework",
      items: [
        {
          name: "Next.js",
          version: "15.0.0",
          url: "https://nextjs.org",
          description: "The React framework for production",
        },
        // Add more technologies here
      ],
    },
    // Add more categories here
  ],
  credits: [
    {
      name: "Lucide Icons",
      url: "https://lucide.dev",
      description: "Beautiful & consistent icons",
    },
    // Add more credits here
  ],
}

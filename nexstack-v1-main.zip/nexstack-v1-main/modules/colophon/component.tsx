import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ExternalLink } from "lucide-react"

interface ColophonModuleProps {
  config: Record<string, string>
  data: any
}

export default function ColophonModule({ config, data }: ColophonModuleProps) {
  const title = config.TITLE || "Colophon"
  const description = config.DESCRIPTION || "Technical details about this website"
  const showVersions = config.SHOW_VERSIONS !== "false"
  const showDescriptions = config.SHOW_DESCRIPTIONS !== "false"

  if (!data) return null

  return (
    <div className="space-y-8">
      <div className="space-y-2">
        <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
        <p className="text-muted-foreground">{description}</p>
      </div>

      <div className="space-y-8">
        {data.technologies.map((category: any) => (
          <div key={category.category} className="space-y-4">
            <h2 className="text-2xl font-semibold tracking-tight">{category.category}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {category.items.map((item: any) => (
                <Card key={item.name}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl">
                          <Link
                            href={item.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline flex items-center"
                          >
                            {item.name}
                            <ExternalLink className="ml-1 h-4 w-4" />
                          </Link>
                        </CardTitle>
                        {showVersions && item.version && (
                          <CardDescription>
                            <Badge variant="outline">v{item.version}</Badge>
                          </CardDescription>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  {showDescriptions && item.description && (
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{item.description}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        ))}

        {data.credits && data.credits.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-2xl font-semibold tracking-tight">Credits</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.credits.map((credit: any) => (
                <Card key={credit.name}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <div className="space-y-1">
                        <CardTitle className="text-xl">
                          <Link
                            href={credit.url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="hover:underline flex items-center"
                          >
                            {credit.name}
                            <ExternalLink className="ml-1 h-4 w-4" />
                          </Link>
                        </CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  {showDescriptions && credit.description && (
                    <CardContent>
                      <p className="text-sm text-muted-foreground">{credit.description}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

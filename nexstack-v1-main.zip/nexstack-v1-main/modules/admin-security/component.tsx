"use client"

import { useState } from "react"
import { hashPassword } from "@/lib/security"

export function AdminSecurityComponent() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [generatedConfig, setGeneratedConfig] = useState<string | null>(null)

  const generateCredentials = () => {
    if (!username || !password) {
      alert("Please enter both username and password")
      return
    }

    const { hash, salt } = hashPassword(password)

    const config = `
# Admin Security Configuration
ADMIN_SECURITY_ENABLED=true
ADMIN_PASSWORD_PROTECTION_ENABLED=true
ADMIN_USERNAME=${username}
ADMIN_PASSWORD_HASH=${hash}
ADMIN_PASSWORD_SALT=${salt}
    `.trim()

    setGeneratedConfig(config)
  }

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 text-amber-800">
        <p className="text-sm">
          <strong>Warning:</strong> This tool generates credentials for development purposes. For production, use the
          command-line tool and securely store your credentials.
        </p>
      </div>

      <div className="space-y-4">
        <div>
          <label htmlFor="username" className="block text-sm font-medium text-gray-700">
            Admin Username
          </label>
          <input
            type="text"
            id="username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>

        <div>
          <label htmlFor="password" className="block text-sm font-medium text-gray-700">
            Admin Password
          </label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
          />
        </div>

        <button
          onClick={generateCredentials}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
        >
          Generate Credentials
        </button>
      </div>

      {generatedConfig && (
        <div className="mt-4">
          <label className="block text-sm font-medium text-gray-700">Configuration (Add to .env file)</label>
          <pre className="mt-1 block w-full rounded-md bg-gray-50 p-4 text-sm text-gray-800 overflow-auto">
            {generatedConfig}
          </pre>
        </div>
      )}
    </div>
  )
}

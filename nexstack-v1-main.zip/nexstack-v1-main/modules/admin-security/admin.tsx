import { AdminSecurityComponent } from "./component"

export function AdminSecurityAdmin() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-lg font-medium text-gray-900">Admin Security Configuration</h2>
        <p className="mt-1 text-sm text-gray-500">Configure security settings for the admin area.</p>
      </div>

      <AdminSecurityComponent />

      <div className="bg-gray-50 p-4 rounded-md">
        <h3 className="text-md font-medium text-gray-900 mb-2">Security Strategies</h3>

        <div className="space-y-4">
          <div>
            <h4 className="text-sm font-medium text-gray-900">Password Protection</h4>
            <p className="text-sm text-gray-500">Requires a username and password to access admin areas.</p>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900">IP Restriction</h4>
            <p className="text-sm text-gray-500">Limits access to specific IP addresses.</p>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900">Environment Restriction</h4>
            <p className="text-sm text-gray-500">Restricts access based on the deployment environment.</p>
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900">Vercel Edge Config</h4>
            <p className="text-sm text-gray-500">
              Uses Vercel Edge Config for dynamic access control without redeployment.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

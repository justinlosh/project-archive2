# Admin Security Module

This module provides comprehensive security for the admin area of your website, implementing multiple layers of protection to ensure that administrative routes are not publicly accessible.

## Features

- **Password Protection**: Secure authentication with username and password
- **IP Address Restriction**: Limit access to specific IP addresses
- **Environment-Based Restriction**: Control access based on deployment environment
- **Vercel Edge Config Integration**: Dynamic access control without redeployment
- **Customizable Security Policies**: Configure security settings through environment variables
- **Admin Interface**: Manage security settings through a user-friendly interface

## Configuration

The Admin Security module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `ADMIN_SECURITY_ENABLED` | Enable/disable admin security | `true` |
| `ADMIN_PASSWORD_PROTECTION_ENABLED` | Enable/disable password protection | `true` |
| `ADMIN_USERNAME` | Admin username | `admin` |
| `ADMIN_PASSWORD_HASH` | Hashed admin password | `` |
| `ADMIN_PASSWORD_SALT` | Salt used for password hashing | `` |
| `ADMIN_IP_RESTRICTION_ENABLED` | Enable/disable IP restriction | `false` |
| `ADMIN_ALLOWED_IPS` | Comma-separated list of allowed IP addresses | `127.0.0.1,::1` |
| `ADMIN_ALLOW_LOCALHOST` | Allow access from localhost | `true` |
| `ADMIN_ENVIRONMENT_RESTRICTION_ENABLED` | Enable/disable environment restriction | `true` |
| `ADMIN_ALLOWED_ENVIRONMENTS` | Comma-separated list of allowed environments | `development,preview` |
| `EDGE_CONFIG_ID` | Vercel Edge Config ID for dynamic access control | `` |

## Usage

The Admin Security module automatically protects all routes under `/admin/*`. No additional code is required in your pages.

### Generating Admin Credentials

Use the provided script to generate secure credentials:

\`\`\`bash
npm run generate-admin-credentials
\`\`\`

This will prompt you for a username and password, then generate the necessary environment variables.

### Vercel Edge Config Integration

For dynamic access control without redeployment, you can use Vercel Edge Config:

1. Create a Vercel Edge Config store in your Vercel dashboard
2. Set the `EDGE_CONFIG_ID` environment variable to your Edge Config ID
3. Configure allowed IPs and users through the Vercel dashboard

## Security Strategies

### Password Protection

This is the most basic form of security, requiring a username and password to access admin areas.

**Pros:**
- Simple to implement
- Works across all environments
- No database required

**Cons:**
- Credentials in environment variables need to be managed carefully
- Basic Authentication isn't the most user-friendly

### IP Address Restriction

This strategy limits access to specific IP addresses, providing an additional layer of security.

**Pros:**
- Very effective at preventing unauthorized access
- Works well for teams with static IP addresses
- Can be combined with password protection

**Cons:**
- Challenging for teams with dynamic IPs
- Requires updating configuration when IPs change
- May block legitimate users with changing IPs

### Environment-Based Restriction

This strategy restricts admin access based on the deployment environment, preventing access in production.

**Pros:**
- Automatically prevents production access
- No additional configuration needed for each deployment
- Provides a safety net against accidental exposure

**Cons:**
- May limit legitimate admin needs in production
- Requires alternative access methods for production administration

### Vercel Edge Config Integration

This advanced strategy uses Vercel's Edge Config for dynamic access control without redeployment.

**Pros:**
- Dynamic access control without redeployment
- Centralized management of security settings
- Easier to update than environment variables

**Cons:**
- Requires Vercel Edge Config setup
- Adds external dependency
- Slightly more complex implementation

## Recommended Security Approach

For most projects, we recommend a layered approach:

1. **Development Environment:**
   - Password protection with simple credentials
   - IP restriction disabled
   - Environment restriction enabled

2. **Preview Environment:**
   - Password protection with strong credentials
   - IP restriction enabled for team IPs
   - Environment restriction enabled

3. **Production Environment:**
   - Admin routes completely disabled via environment restriction
   - Alternative admin interfaces (e.g., Vercel dashboard integrations)
   - If admin access is required, use all security layers with Vercel Edge Config

## Implementation Details

The Admin Security module is implemented as middleware that intercepts requests to admin routes and applies the configured security measures. The middleware checks:

1. If the request is for an admin route
2. If admin security is enabled
3. If the request passes all enabled security checks

If any check fails, the user is redirected to a "Not Authorized" page or presented with an authentication prompt.

## Admin Interface

The module provides an admin interface for managing security settings. Access it at `/admin/security`.
\`\`\`

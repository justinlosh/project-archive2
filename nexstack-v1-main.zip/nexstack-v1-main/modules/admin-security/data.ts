export const adminSecurityModuleData = {
  name: "Admin Security",
  description: "Secure access to admin areas of the website",
  version: "1.0.0",
  author: "Modular Next.js",
  dependencies: [],
  configKeys: [
    "ADMIN_SECURITY_ENABLED",
    "ADMIN_PASSWORD_PROTECTION_ENABLED",
    "ADMIN_USERNAME",
    "ADMIN_PASSWORD_HASH",
    "ADMIN_PASSWORD_SALT",
    "ADMIN_IP_RESTRICTION_ENABLED",
    "ADMIN_ALLOWED_IPS",
    "ADMIN_ALLOW_LOCALHOST",
    "ADMIN_ENVIRONMENT_RESTRICTION_ENABLED",
    "ADMIN_ALLOWED_ENVIRONMENTS",
  ],
}

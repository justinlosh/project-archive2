"use client"

import type React from "react"

import { useState, useId, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Mail } from "lucide-react"
import { validateEmail } from "@/lib/security"
import { createFormFieldA11yProps } from "@/lib/accessibility"

interface NewsletterModuleProps {
  config: Record<string, string>
}

export default function NewsletterModule({ config }: NewsletterModuleProps) {
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [error, setError] = useState<string | null>(null)
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle")
  const formRef = useRef<HTMLFormElement>(null)

  const title = config.TITLE || "Subscribe to our Newsletter"
  const description = config.DESCRIPTION || "Get the latest updates delivered to your inbox"
  const buttonText = config.BUTTON_TEXT || "Subscribe"
  const successMessage = config.SUCCESS_MESSAGE || "Thanks for subscribing!"
  const errorMessage = config.ERROR_MESSAGE || "Something went wrong. Please try again."
  const showPrivacyPolicy = config.SHOW_PRIVACY_POLICY !== "false"
  const privacyPolicyText = config.PRIVACY_POLICY_TEXT || "We respect your privacy. Unsubscribe at any time."
  const collectName = config.COLLECT_NAME === "true"
  const nameLabel = config.NAME_LABEL || "Name"
  const emailLabel = config.EMAIL_LABEL || "Email address"
  const provider = config.PROVIDER || "default"

  // Generate unique IDs for accessibility
  const formId = useId()
  const emailId = `${formId}-email`
  const nameId = `${formId}-name`
  const emailA11y = createFormFieldA11yProps(emailId, !!error)
  const nameA11y = createFormFieldA11yProps(nameId, false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    // Validate email
    if (!email.trim()) {
      setError("Email is required")
      return
    }

    if (!validateEmail(email)) {
      setError("Please enter a valid email address")
      return
    }

    setError(null)
    setStatus("loading")

    try {
      // Prepare metadata
      const metadata: Record<string, any> = {}

      if (collectName && name.trim()) {
        metadata.firstName = name.trim()
      }

      // Call the newsletter subscription API with proper error handling
      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const response = await fetch("/api/newsletter/subscribe", {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email, metadata }),
      })

      clearTimeout(timeoutId)

      if (!response.ok) {
        throw new Error(`Request failed with status: ${response.status}`)
      }

      const data = await response.json()

      if (data.success) {
        setStatus("success")
        setEmail("")
        setName("")

        // Reset the form
        if (formRef.current) {
          formRef.current.reset()
        }
      } else {
        setStatus("error")
        setError(data.message || errorMessage)
      }
    } catch (err: any) {
      setStatus("error")
      setError(err.name === "AbortError" ? "Request timed out. Please try again." : errorMessage)
      console.error("Newsletter subscription error:", err)
    }
  }

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEmail(e.target.value.trim())
    if (error) {
      setError(null)
    }
  }

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setName(e.target.value)
  }

  return (
    <Card className="border-none shadow-none bg-muted/50 rounded-lg">
      <CardHeader>
        <div className="flex items-center gap-2">
          <Mail className="h-5 w-5 text-primary" aria-hidden="true" />
          <CardTitle>{title}</CardTitle>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent>
        <form ref={formRef} onSubmit={handleSubmit} className="flex flex-col gap-4">
          {collectName && (
            <div>
              <label {...nameA11y.label} className="sr-only">
                {nameLabel}
              </label>
              <Input {...nameA11y.input} type="text" placeholder={nameLabel} value={name} onChange={handleNameChange} />
            </div>
          )}
          <div>
            <label {...emailA11y.label} className="sr-only">
              {emailLabel}
            </label>
            <Input
              {...emailA11y.input}
              type="email"
              placeholder={emailLabel}
              value={email}
              onChange={handleEmailChange}
              required
            />
            {error && (
              <p {...emailA11y.error} className="text-sm text-destructive mt-1">
                {error}
              </p>
            )}
          </div>
          <Button
            type="submit"
            disabled={status === "loading"}
            aria-busy={status === "loading"}
            className="w-full sm:w-auto"
          >
            {status === "loading" ? "Subscribing..." : buttonText}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col items-start">
        {status === "success" && (
          <p className="text-sm text-green-600" role="status">
            {successMessage}
          </p>
        )}
        {status === "error" && error && (
          <p className="text-sm text-red-600" role="alert">
            {error}
          </p>
        )}
        {showPrivacyPolicy && <p className="text-xs text-muted-foreground mt-2">{privacyPolicyText}</p>}
        {provider !== "default" && (
          <p className="text-xs text-muted-foreground mt-2">
            Powered by {provider.charAt(0).toUpperCase() + provider.slice(1)}
          </p>
        )}
      </CardFooter>
    </Card>
  )
}

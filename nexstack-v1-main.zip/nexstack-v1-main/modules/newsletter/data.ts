import { createProvider, availableProviders } from "./providers"
import { getModuleConfig } from "@/lib/module-system"
import { logger } from "@/lib/logger"

export default {
  title: "Newsletter",
  description: "Subscribe to our newsletter to receive updates",

  // Get the configured provider
  getProvider: async () => {
    try {
      const config = getModuleConfig("newsletter")
      const providerId = config.PROVIDER || "mailchimp"

      return createProvider(providerId, config)
    } catch (error) {
      logger.error("Failed to initialize newsletter provider", { error })
      return null
    }
  },

  // Get available providers for admin UI
  getAvailableProviders: () => {
    return availableProviders
  },
}

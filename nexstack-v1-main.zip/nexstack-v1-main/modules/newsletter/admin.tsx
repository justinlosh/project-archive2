"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, RefreshCw, Send, Users } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

interface AdminNewsletterProps {
  config: Record<string, string>
}

export default function AdminNewsletter({ config }: AdminNewsletterProps) {
  const [activeTab, setActiveTab] = useState("settings")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [subscribers, setSubscribers] = useState<any[]>([])
  const [loadingSubscribers, setLoadingSubscribers] = useState(false)
  const [lists, setLists] = useState<any[]>([])
  const [loadingLists, setLoadingLists] = useState(false)
  const [selectedProvider, setSelectedProvider] = useState(config.PROVIDER || "mailchimp")
  const [formData, setFormData] = useState({
    title: config.TITLE || "Subscribe to our Newsletter",
    description: config.DESCRIPTION || "Get the latest updates delivered to your inbox",
    buttonText: config.BUTTON_TEXT || "Subscribe",
    successMessage: config.SUCCESS_MESSAGE || "Thanks for subscribing!",
    errorMessage: config.ERROR_MESSAGE || "Something went wrong. Please try again.",
    showPrivacyPolicy: config.SHOW_PRIVACY_POLICY !== "false",
    privacyPolicyText: config.PRIVACY_POLICY_TEXT || "We respect your privacy. Unsubscribe at any time.",
    collectName: config.COLLECT_NAME === "true",
    nameLabel: config.NAME_LABEL || "Name",
    emailLabel: config.EMAIL_LABEL || "Email address",
  })

  const [providerConfig, setProviderConfig] = useState({
    // Mailchimp
    mailchimpApiKey: config.MAILCHIMP_API_KEY || "",
    mailchimpListId: config.MAILCHIMP_LIST_ID || "",

    // Brevo
    brevoApiKey: config.BREVO_API_KEY || "",
    brevoListId: config.BREVO_LIST_ID || "",

    // ConvertKit
    convertKitApiKey: config.CONVERTKIT_API_KEY || "",
    convertKitApiSecret: config.CONVERTKIT_API_SECRET || "",
    convertKitFormId: config.CONVERTKIT_FORM_ID || "",
  })

  // Campaign form
  const [campaignData, setCampaignData] = useState({
    name: "",
    subject: "",
    fromName: "",
    fromEmail: "",
    content: "",
    listId: "",
  })

  // Load subscribers
  const loadSubscribers = async () => {
    try {
      setLoadingSubscribers(true)
      const response = await fetch("/api/newsletter/subscribers")

      if (!response.ok) {
        throw new Error("Failed to load subscribers")
      }

      const data = await response.json()
      setSubscribers(data.subscribers || [])
    } catch (error) {
      setError("Failed to load subscribers")
      console.error(error)
    } finally {
      setLoadingSubscribers(false)
    }
  }

  // Load lists
  const loadLists = async () => {
    try {
      setLoadingLists(true)
      const response = await fetch("/api/newsletter/lists")

      if (!response.ok) {
        throw new Error("Failed to load lists")
      }

      const data = await response.json()
      setLists(data.lists || [])

      // Set default list for campaign
      if (data.lists && data.lists.length > 0) {
        setCampaignData((prev) => ({
          ...prev,
          listId: data.lists[0].id,
        }))
      }
    } catch (error) {
      setError("Failed to load lists")
      console.error(error)
    } finally {
      setLoadingLists(false)
    }
  }

  // Load data when tab changes
  useEffect(() => {
    if (activeTab === "subscribers") {
      loadSubscribers()
    } else if (activeTab === "campaigns") {
      loadLists()
    }
  }, [activeTab])

  // Handle form input changes
  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Handle switch changes
  const handleSwitchChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      [name]: checked,
    }))
  }

  // Handle provider config changes
  const handleProviderConfigChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setProviderConfig((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Handle campaign form changes
  const handleCampaignChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setCampaignData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  // Save settings
  const saveSettings = async () => {
    try {
      setLoading(true)
      setError(null)
      setSuccess(null)

      // Prepare data to save
      const dataToSave = {
        ...formData,
        provider: selectedProvider,
        providerConfig: {
          // Only include config for selected provider
          ...(selectedProvider === "mailchimp" && {
            MAILCHIMP_API_KEY: providerConfig.mailchimpApiKey,
            MAILCHIMP_LIST_ID: providerConfig.mailchimpListId,
          }),
          ...(selectedProvider === "brevo" && {
            BREVO_API_KEY: providerConfig.brevoApiKey,
            BREVO_LIST_ID: providerConfig.brevoListId,
          }),
          ...(selectedProvider === "convertkit" && {
            CONVERTKIT_API_KEY: providerConfig.convertKitApiKey,
            CONVERTKIT_API_SECRET: providerConfig.convertKitApiSecret,
            CONVERTKIT_FORM_ID: providerConfig.convertKitFormId,
          }),
        },
      }

      const response = await fetch("/api/newsletter/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(dataToSave),
      })

      if (!response.ok) {
        throw new Error("Failed to save settings")
      }

      setSuccess("Settings saved successfully")
    } catch (error) {
      setError("Failed to save settings")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  // Create and send campaign
  const createCampaign = async () => {
    try {
      setLoading(true)
      setError(null)
      setSuccess(null)

      // Validate campaign data
      if (
        !campaignData.name ||
        !campaignData.subject ||
        !campaignData.fromName ||
        !campaignData.fromEmail ||
        !campaignData.content ||
        !campaignData.listId
      ) {
        setError("Please fill in all campaign fields")
        return
      }

      const response = await fetch("/api/newsletter/campaign", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(campaignData),
      })

      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.message || "Failed to create campaign")
      }

      setSuccess("Campaign created and sent successfully")

      // Reset form
      setCampaignData({
        name: "",
        subject: "",
        fromName: "",
        fromEmail: "",
        content: "",
        listId: lists.length > 0 ? lists[0].id : "",
      })
    } catch (error: any) {
      setError(error.message || "Failed to create campaign")
      console.error(error)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Newsletter Management</CardTitle>
        <CardDescription>Configure your newsletter settings, manage subscribers, and send campaigns</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-4">
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="provider">Provider</TabsTrigger>
            <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          </TabsList>

          {/* Settings Tab */}
          <TabsContent value="settings">
            <div className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input id="title" name="title" value={formData.title} onChange={handleFormChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Input id="description" name="description" value={formData.description} onChange={handleFormChange} />
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="buttonText">Button Text</Label>
                  <Input id="buttonText" name="buttonText" value={formData.buttonText} onChange={handleFormChange} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="successMessage">Success Message</Label>
                  <Input
                    id="successMessage"
                    name="successMessage"
                    value={formData.successMessage}
                    onChange={handleFormChange}
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="errorMessage">Error Message</Label>
                <Input
                  id="errorMessage"
                  name="errorMessage"
                  value={formData.errorMessage}
                  onChange={handleFormChange}
                />
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  id="showPrivacyPolicy"
                  checked={formData.showPrivacyPolicy}
                  onCheckedChange={(checked) => handleSwitchChange("showPrivacyPolicy", checked)}
                />
                <Label htmlFor="showPrivacyPolicy">Show Privacy Policy</Label>
              </div>

              {formData.showPrivacyPolicy && (
                <div className="space-y-2">
                  <Label htmlFor="privacyPolicyText">Privacy Policy Text</Label>
                  <Input
                    id="privacyPolicyText"
                    name="privacyPolicyText"
                    value={formData.privacyPolicyText}
                    onChange={handleFormChange}
                  />
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Switch
                  id="collectName"
                  checked={formData.collectName}
                  onCheckedChange={(checked) => handleSwitchChange("collectName", checked)}
                />
                <Label htmlFor="collectName">Collect Name</Label>
              </div>

              {formData.collectName && (
                <div className="space-y-2">
                  <Label htmlFor="nameLabel">Name Field Label</Label>
                  <Input id="nameLabel" name="nameLabel" value={formData.nameLabel} onChange={handleFormChange} />
                </div>
              )}

              <div className="space-y-2">
                <Label htmlFor="emailLabel">Email Field Label</Label>
                <Input id="emailLabel" name="emailLabel" value={formData.emailLabel} onChange={handleFormChange} />
              </div>
            </div>
          </TabsContent>

          {/* Provider Tab */}
          <TabsContent value="provider">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="provider">Email Service Provider</Label>
                <Select value={selectedProvider} onValueChange={setSelectedProvider}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select provider" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mailchimp">Mailchimp</SelectItem>
                    <SelectItem value="brevo">Brevo (formerly Sendinblue)</SelectItem>
                    <SelectItem value="convertkit">ConvertKit</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {selectedProvider === "mailchimp" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="mailchimpApiKey">Mailchimp API Key</Label>
                    <Input
                      id="mailchimpApiKey"
                      name="mailchimpApiKey"
                      value={providerConfig.mailchimpApiKey}
                      onChange={handleProviderConfigChange}
                      type="password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mailchimpListId">Mailchimp List ID</Label>
                    <Input
                      id="mailchimpListId"
                      name="mailchimpListId"
                      value={providerConfig.mailchimpListId}
                      onChange={handleProviderConfigChange}
                    />
                  </div>
                </div>
              )}

              {selectedProvider === "brevo" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="brevoApiKey">Brevo API Key</Label>
                    <Input
                      id="brevoApiKey"
                      name="brevoApiKey"
                      value={providerConfig.brevoApiKey}
                      onChange={handleProviderConfigChange}
                      type="password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="brevoListId">Brevo List ID</Label>
                    <Input
                      id="brevoListId"
                      name="brevoListId"
                      value={providerConfig.brevoListId}
                      onChange={handleProviderConfigChange}
                    />
                  </div>
                </div>
              )}

              {selectedProvider === "convertkit" && (
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="convertKitApiKey">ConvertKit API Key</Label>
                    <Input
                      id="convertKitApiKey"
                      name="convertKitApiKey"
                      value={providerConfig.convertKitApiKey}
                      onChange={handleProviderConfigChange}
                      type="password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="convertKitApiSecret">ConvertKit API Secret</Label>
                    <Input
                      id="convertKitApiSecret"
                      name="convertKitApiSecret"
                      value={providerConfig.convertKitApiSecret}
                      onChange={handleProviderConfigChange}
                      type="password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="convertKitFormId">ConvertKit Form ID</Label>
                    <Input
                      id="convertKitFormId"
                      name="convertKitFormId"
                      value={providerConfig.convertKitFormId}
                      onChange={handleProviderConfigChange}
                    />
                  </div>
                </div>
              )}
            </div>
          </TabsContent>

          {/* Subscribers Tab */}
          <TabsContent value="subscribers">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-medium">Subscriber List</h3>
                <Button variant="outline" size="sm" onClick={loadSubscribers} disabled={loadingSubscribers}>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Refresh
                </Button>
              </div>

              {loadingSubscribers ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : (
                <div className="border rounded-md">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Email</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Date</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {subscribers.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center">
                            No subscribers found
                          </TableCell>
                        </TableRow>
                      ) : (
                        subscribers.map((subscriber) => (
                          <TableRow key={subscriber.id}>
                            <TableCell>{subscriber.email}</TableCell>
                            <TableCell>{subscriber.name || "-"}</TableCell>
                            <TableCell>
                              <span
                                className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                  subscriber.status === "active"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-red-100 text-red-800"
                                }`}
                              >
                                {subscriber.status}
                              </span>
                            </TableCell>
                            <TableCell>{new Date(subscriber.subscriptionDate).toLocaleDateString()}</TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}

              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm text-muted-foreground">Total Subscribers: {subscribers.length}</span>
              </div>
            </div>
          </TabsContent>

          {/* Campaigns Tab */}
          <TabsContent value="campaigns">
            <div className="space-y-6">
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Create New Campaign</h3>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="name">Campaign Name</Label>
                    <Input
                      id="name"
                      name="name"
                      value={campaignData.name}
                      onChange={handleCampaignChange}
                      placeholder="Monthly Newsletter"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="subject">Email Subject</Label>
                    <Input
                      id="subject"
                      name="subject"
                      value={campaignData.subject}
                      onChange={handleCampaignChange}
                      placeholder="Your May Newsletter is here!"
                    />
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="fromName">From Name</Label>
                    <Input
                      id="fromName"
                      name="fromName"
                      value={campaignData.fromName}
                      onChange={handleCampaignChange}
                      placeholder="Your Company"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="fromEmail">From Email</Label>
                    <Input
                      id="fromEmail"
                      name="fromEmail"
                      value={campaignData.fromEmail}
                      onChange={handleCampaignChange}
                      placeholder="newsletter@example.com"
                      type="email"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="listId">Recipient List</Label>
                  <Select
                    value={campaignData.listId}
                    onValueChange={(value) => setCampaignData((prev) => ({ ...prev, listId: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a list" />
                    </SelectTrigger>
                    <SelectContent>
                      {loadingLists ? (
                        <SelectItem value="loading" disabled>
                          Loading lists...
                        </SelectItem>
                      ) : lists.length === 0 ? (
                        <SelectItem value="none" disabled>
                          No lists found
                        </SelectItem>
                      ) : (
                        lists.map((list) => (
                          <SelectItem key={list.id} value={list.id}>
                            {list.name} ({list.subscriberCount} subscribers)
                          </SelectItem>
                        ))
                      )}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Email Content (HTML)</Label>
                  <Textarea
                    id="content"
                    name="content"
                    value={campaignData.content}
                    onChange={handleCampaignChange}
                    placeholder="<h1>Your Newsletter</h1><p>Hello subscribers!</p>"
                    className="min-h-[200px] font-mono"
                  />
                </div>

                <Button onClick={createCampaign} disabled={loading} className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Create & Send Campaign
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        {error && (
          <Alert variant="destructive" className="mt-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert className="mt-4 bg-green-50 border-green-200">
            <CheckCircle2 className="h-4 w-4 text-green-600" />
            <AlertTitle className="text-green-800">Success</AlertTitle>
            <AlertDescription className="text-green-700">{success}</AlertDescription>
          </Alert>
        )}
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={() => setActiveTab("settings")}>
          Cancel
        </Button>
        <Button onClick={saveSettings} disabled={loading}>
          {loading ? "Saving..." : "Save Settings"}
        </Button>
      </CardFooter>
    </Card>
  )
}

import type {
  NewsletterProvider,
  SubscribeResult,
  UnsubscribeResult,
  List,
  Subscriber,
  CampaignData,
  Campaign,
  SendResult,
  CampaignStats,
} from "./provider-interface"
import { logger } from "@/lib/logger"

export class BrevoProvider implements NewsletterProvider {
  name = "Brevo"
  id = "brevo"

  private apiKey: string
  private listId: string
  private baseUrl = "https://api.brevo.com/v3"

  constructor(config: Record<string, string>) {
    this.apiKey = config.BREVO_API_KEY || ""
    this.listId = config.BREVO_LIST_ID || ""

    if (!this.apiKey) {
      logger.error("Brevo API key is not configured")
    }
  }

  private async makeRequest(endpoint: string, method: "GET" | "POST" | "PUT" | "DELETE", data?: any) {
    try {
      const url = `${this.baseUrl}${endpoint}`
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "api-key": this.apiKey,
        },
        body: data ? JSON.stringify(data) : undefined,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`Brevo API error: ${errorData.message || "Unknown error"}`)
      }

      // Some endpoints return no content
      if (response.status === 204) {
        return {}
      }

      return await response.json()
    } catch (error) {
      logger.error("Brevo API request failed", { error, endpoint, method })
      throw error
    }
  }

  async subscribe(email: string, metadata?: Record<string, any>): Promise<SubscribeResult> {
    try {
      if (!this.apiKey) {
        return {
          success: false,
          message: "Brevo is not properly configured",
          error: "Missing API key",
        }
      }

      const data: any = {
        email,
        attributes: metadata || {},
      }

      // Add to list if list ID is provided
      if (this.listId) {
        data.listIds = [Number.parseInt(this.listId)]
      }

      const result = await this.makeRequest("/contacts", "POST", data)

      return {
        success: true,
        message: "Successfully subscribed to the newsletter",
        subscriberId: result.id?.toString(),
      }
    } catch (error: any) {
      // Handle case where contact already exists
      if (error.message?.includes("Contact already exist")) {
        // If list ID is provided, add the contact to the list
        if (this.listId) {
          try {
            await this.makeRequest("/contacts/lists", "POST", {
              emails: [email],
              listIds: [Number.parseInt(this.listId)],
            })
          } catch (listError) {
            logger.error("Failed to add existing contact to list", { error: listError, email, listId: this.listId })
          }
        }

        return {
          success: true,
          message: "You are already subscribed to our newsletter",
        }
      }

      return {
        success: false,
        message: "Failed to subscribe to the newsletter",
        error: error.message,
      }
    }
  }

  async unsubscribe(email: string): Promise<UnsubscribeResult> {
    try {
      if (!this.apiKey) {
        return {
          success: false,
          message: "Brevo is not properly configured",
          error: "Missing API key",
        }
      }

      // In Brevo, we need to get the contact ID first
      const identifier = encodeURIComponent(email)
      const contact = await this.makeRequest(`/contacts/${identifier}`, "GET")

      if (!contact || !contact.id) {
        return {
          success: false,
          message: "Contact not found",
          error: "Contact not found",
        }
      }

      // If list ID is provided, remove from list instead of deleting
      if (this.listId) {
        await this.makeRequest("/contacts/lists", "POST", {
          emails: [email],
          listIds: [Number.parseInt(this.listId)],
          unlinkListIds: [Number.parseInt(this.listId)],
        })
      } else {
        // Otherwise, update the contact to opt out
        await this.makeRequest(`/contacts/${contact.id}`, "PUT", {
          emailBlacklisted: true,
        })
      }

      return {
        success: true,
        message: "Successfully unsubscribed from the newsletter",
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to unsubscribe from the newsletter",
        error: error.message,
      }
    }
  }

  async getLists(): Promise<List[]> {
    try {
      if (!this.apiKey) {
        return []
      }

      const result = await this.makeRequest("/contacts/lists", "GET")

      return result.lists.map((list: any) => ({
        id: list.id.toString(),
        name: list.name,
        subscriberCount: list.totalSubscribers || 0,
        createdAt: new Date(list.createdAt * 1000), // Convert Unix timestamp to Date
      }))
    } catch (error) {
      logger.error("Failed to fetch Brevo lists", { error })
      return []
    }
  }

  async getSubscribers(listId?: string): Promise<Subscriber[]> {
    try {
      if (!this.apiKey) {
        return []
      }

      const targetListId = listId || this.listId

      if (!targetListId) {
        // If no list ID, get all contacts (limited to 50 for performance)
        const result = await this.makeRequest("/contacts?limit=50", "GET")
        return this.mapContactsToSubscribers(result.contacts)
      }

      // Get contacts from specific list
      const result = await this.makeRequest(`/contacts/lists/${targetListId}/contacts?limit=50`, "GET")
      return this.mapContactsToSubscribers(result.contacts)
    } catch (error) {
      logger.error("Failed to fetch Brevo subscribers", { error, listId })
      return []
    }
  }

  private mapContactsToSubscribers(contacts: any[]): Subscriber[] {
    return contacts.map((contact) => ({
      id: contact.id.toString(),
      email: contact.email,
      name: contact.attributes?.FIRSTNAME
        ? `${contact.attributes.FIRSTNAME} ${contact.attributes.LASTNAME || ""}`.trim()
        : undefined,
      metadata: contact.attributes || {},
      subscriptionDate: new Date(contact.createdAt * 1000), // Convert Unix timestamp to Date
      status: contact.emailBlacklisted ? "unsubscribed" : "active",
    }))
  }

  async createCampaign(campaign: CampaignData): Promise<Campaign> {
    try {
      if (!this.apiKey) {
        throw new Error("Brevo is not properly configured")
      }

      // Create campaign
      const campaignResult = await this.makeRequest("/emailCampaigns", "POST", {
        name: campaign.name,
        subject: campaign.subject,
        sender: {
          name: campaign.fromName,
          email: campaign.fromEmail,
        },
        htmlContent: campaign.content,
        recipients: {
          listIds: campaign.listIds.map((id) => Number.parseInt(id)),
        },
      })

      return {
        id: campaignResult.id.toString(),
        name: campaign.name,
        subject: campaign.subject,
        status: "draft",
        createdAt: new Date(),
      }
    } catch (error: any) {
      logger.error("Failed to create Brevo campaign", { error, campaign })
      throw new Error(`Failed to create campaign: ${error.message}`)
    }
  }

  async sendCampaign(campaignId: string): Promise<SendResult> {
    try {
      if (!this.apiKey) {
        return {
          success: false,
          message: "Brevo is not properly configured",
          campaignId,
          error: "Missing API key",
        }
      }

      await this.makeRequest(`/emailCampaigns/${campaignId}/sendNow`, "POST")

      return {
        success: true,
        message: "Campaign sent successfully",
        campaignId,
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to send campaign",
        campaignId,
        error: error.message,
      }
    }
  }

  async getCampaignStats(campaignId: string): Promise<CampaignStats> {
    try {
      if (!this.apiKey) {
        throw new Error("Brevo is not properly configured")
      }

      const result = await this.makeRequest(`/emailCampaigns/${campaignId}`, "GET")

      return {
        sent: result.statistics?.globalStats?.sent || 0,
        delivered: result.statistics?.globalStats?.delivered || 0,
        opened: result.statistics?.globalStats?.uniqueOpens || 0,
        clicked: result.statistics?.globalStats?.uniqueClicks || 0,
        bounced: result.statistics?.globalStats?.softBounces + result.statistics?.globalStats?.hardBounces || 0,
        complained: result.statistics?.globalStats?.complaints || 0,
        unsubscribed: result.statistics?.globalStats?.unsubscriptions || 0,
      }
    } catch (error) {
      logger.error("Failed to fetch Brevo campaign stats", { error, campaignId })
      return {
        sent: 0,
        delivered: 0,
        opened: 0,
        clicked: 0,
        bounced: 0,
        complained: 0,
        unsubscribed: 0,
      }
    }
  }
}

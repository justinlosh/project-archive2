/**
 * Interface for newsletter service providers
 */
export interface NewsletterProvider {
  name: string
  id: string

  // Core functionality
  subscribe(email: string, metadata?: Record<string, any>): Promise<SubscribeResult>
  unsubscribe(email: string): Promise<UnsubscribeResult>

  // List management
  getLists(): Promise<List[]>
  getSubscribers(listId?: string): Promise<Subscriber[]>

  // Campaign management (optional)
  createCampaign?(campaign: CampaignData): Promise<Campaign>
  sendCampaign?(campaignId: string): Promise<SendResult>
  getCampaignStats?(campaignId: string): Promise<CampaignStats>
}

// Common types used across providers
export interface SubscribeResult {
  success: boolean
  message: string
  subscriberId?: string
  error?: any
}

export interface UnsubscribeResult {
  success: boolean
  message: string
  error?: any
}

export interface List {
  id: string
  name: string
  subscriberCount: number
  createdAt: Date
}

export interface Subscriber {
  id: string
  email: string
  name?: string
  metadata?: Record<string, any>
  subscriptionDate: Date
  status: "active" | "unsubscribed" | "bounced" | "complained"
}

export interface CampaignData {
  name: string
  subject: string
  fromName: string
  fromEmail: string
  content: string
  listIds: string[]
}

export interface Campaign {
  id: string
  name: string
  subject: string
  status: "draft" | "scheduled" | "sending" | "sent" | "failed"
  createdAt: Date
  sentAt?: Date
}

export interface SendResult {
  success: boolean
  message: string
  campaignId: string
  error?: any
}

export interface CampaignStats {
  sent: number
  delivered: number
  opened: number
  clicked: number
  bounced: number
  complained: number
  unsubscribed: number
}

import type {
  NewsletterProvider,
  SubscribeResult,
  UnsubscribeResult,
  List,
  Subscriber,
  CampaignData,
  Campaign,
  SendResult,
  CampaignStats,
} from "./provider-interface"
import { createHash } from "crypto"
import { logger } from "@/lib/logger"

export class MailchimpProvider implements NewsletterProvider {
  name = "Mailchimp"
  id = "mailchimp"

  private apiKey: string
  private serverPrefix: string
  private listId: string
  private baseUrl: string

  constructor(config: Record<string, string>) {
    this.apiKey = config.MAILCHIMP_API_KEY || ""

    // Extract server prefix from API key (e.g., us1, us2, etc.)
    this.serverPrefix = this.apiKey.split("-")[1] || "us1"
    this.listId = config.MAILCHIMP_LIST_ID || ""
    this.baseUrl = `https://${this.serverPrefix}.api.mailchimp.com/3.0`

    if (!this.apiKey) {
      logger.error("Mailchimp API key is not configured")
    }

    if (!this.listId) {
      logger.error("Mailchimp List ID is not configured")
    }
  }

  private async makeRequest(endpoint: string, method: "GET" | "POST" | "PUT" | "DELETE" | "PATCH", data?: any) {
    try {
      const url = `${this.baseUrl}${endpoint}`
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Basic ${Buffer.from(`apikey:${this.apiKey}`).toString("base64")}`,
        },
        body: data ? JSON.stringify(data) : undefined,
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(`Mailchimp API error: ${errorData.title} - ${errorData.detail}`)
      }

      return await response.json()
    } catch (error) {
      logger.error("Mailchimp API request failed", { error, endpoint, method })
      throw error
    }
  }

  // Generate MD5 hash of lowercase email for Mailchimp subscriber ID
  private getSubscriberId(email: string): string {
    return createHash("md5").update(email.toLowerCase()).digest("hex")
  }

  async subscribe(email: string, metadata?: Record<string, any>): Promise<SubscribeResult> {
    try {
      if (!this.apiKey || !this.listId) {
        return {
          success: false,
          message: "Mailchimp is not properly configured",
          error: "Missing API key or List ID",
        }
      }

      const data = {
        email_address: email,
        status: "subscribed",
        merge_fields: metadata || {},
      }

      const result = await this.makeRequest(`/lists/${this.listId}/members`, "POST", data)

      return {
        success: true,
        message: "Successfully subscribed to the newsletter",
        subscriberId: result.id,
      }
    } catch (error: any) {
      // Handle case where subscriber already exists
      if (error.message?.includes("Member Exists")) {
        return {
          success: true,
          message: "You are already subscribed to our newsletter",
          subscriberId: this.getSubscriberId(email),
        }
      }

      return {
        success: false,
        message: "Failed to subscribe to the newsletter",
        error: error.message,
      }
    }
  }

  async unsubscribe(email: string): Promise<UnsubscribeResult> {
    try {
      if (!this.apiKey || !this.listId) {
        return {
          success: false,
          message: "Mailchimp is not properly configured",
          error: "Missing API key or List ID",
        }
      }

      const subscriberId = this.getSubscriberId(email)

      await this.makeRequest(`/lists/${this.listId}/members/${subscriberId}`, "PATCH", { status: "unsubscribed" })

      return {
        success: true,
        message: "Successfully unsubscribed from the newsletter",
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to unsubscribe from the newsletter",
        error: error.message,
      }
    }
  }

  async getLists(): Promise<List[]> {
    try {
      if (!this.apiKey) {
        return []
      }

      const result = await this.makeRequest("/lists", "GET")

      return result.lists.map((list: any) => ({
        id: list.id,
        name: list.name,
        subscriberCount: list.stats.member_count,
        createdAt: new Date(list.date_created),
      }))
    } catch (error) {
      logger.error("Failed to fetch Mailchimp lists", { error })
      return []
    }
  }

  async getSubscribers(listId?: string): Promise<Subscriber[]> {
    try {
      if (!this.apiKey) {
        return []
      }

      const targetListId = listId || this.listId

      if (!targetListId) {
        return []
      }

      const result = await this.makeRequest(`/lists/${targetListId}/members`, "GET")

      return result.members.map((member: any) => ({
        id: member.id,
        email: member.email_address,
        name: member.merge_fields.FNAME
          ? `${member.merge_fields.FNAME} ${member.merge_fields.LNAME || ""}`.trim()
          : undefined,
        metadata: member.merge_fields,
        subscriptionDate: new Date(member.timestamp_signup),
        status: this.mapStatus(member.status),
      }))
    } catch (error) {
      logger.error("Failed to fetch Mailchimp subscribers", { error, listId })
      return []
    }
  }

  private mapStatus(mailchimpStatus: string): "active" | "unsubscribed" | "bounced" | "complained" {
    switch (mailchimpStatus) {
      case "subscribed":
        return "active"
      case "unsubscribed":
        return "unsubscribed"
      case "cleaned":
        return "bounced"
      case "pending":
        return "active" // Pending confirmation
      default:
        return "active"
    }
  }

  async createCampaign(campaign: CampaignData): Promise<Campaign> {
    try {
      if (!this.apiKey) {
        throw new Error("Mailchimp is not properly configured")
      }

      // Create campaign
      const campaignResult = await this.makeRequest("/campaigns", "POST", {
        type: "regular",
        settings: {
          subject_line: campaign.subject,
          title: campaign.name,
          from_name: campaign.fromName,
          reply_to: campaign.fromEmail,
        },
        recipients: {
          list_id: campaign.listIds[0] || this.listId,
        },
      })

      // Set campaign content
      await this.makeRequest(`/campaigns/${campaignResult.id}/content`, "PUT", {
        html: campaign.content,
      })

      return {
        id: campaignResult.id,
        name: campaignResult.settings.title,
        subject: campaignResult.settings.subject_line,
        status: this.mapCampaignStatus(campaignResult.status),
        createdAt: new Date(),
      }
    } catch (error: any) {
      logger.error("Failed to create Mailchimp campaign", { error, campaign })
      throw new Error(`Failed to create campaign: ${error.message}`)
    }
  }

  async sendCampaign(campaignId: string): Promise<SendResult> {
    try {
      if (!this.apiKey) {
        return {
          success: false,
          message: "Mailchimp is not properly configured",
          campaignId,
          error: "Missing API key",
        }
      }

      await this.makeRequest(`/campaigns/${campaignId}/actions/send`, "POST")

      return {
        success: true,
        message: "Campaign sent successfully",
        campaignId,
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to send campaign",
        campaignId,
        error: error.message,
      }
    }
  }

  async getCampaignStats(campaignId: string): Promise<CampaignStats> {
    try {
      if (!this.apiKey) {
        throw new Error("Mailchimp is not properly configured")
      }

      const result = await this.makeRequest(`/reports/${campaignId}`, "GET")

      return {
        sent: result.emails_sent,
        delivered: result.emails_sent - result.bounces.hard_bounces - result.bounces.soft_bounces,
        opened: result.opens.unique_opens,
        clicked: result.clicks.unique_clicks,
        bounced: result.bounces.hard_bounces + result.bounces.soft_bounces,
        complained: result.unsubscribed || 0,
        unsubscribed: result.unsubscribed || 0,
      }
    } catch (error) {
      logger.error("Failed to fetch Mailchimp campaign stats", { error, campaignId })
      return {
        sent: 0,
        delivered: 0,
        opened: 0,
        clicked: 0,
        bounced: 0,
        complained: 0,
        unsubscribed: 0,
      }
    }
  }

  private mapCampaignStatus(mailchimpStatus: string): "draft" | "scheduled" | "sending" | "sent" | "failed" {
    switch (mailchimpStatus) {
      case "save":
        return "draft"
      case "schedule":
        return "scheduled"
      case "sending":
        return "sending"
      case "sent":
        return "sent"
      default:
        return "draft"
    }
  }
}

import type {
  NewsletterProvider,
  SubscribeResult,
  UnsubscribeResult,
  List,
  Subscriber,
  CampaignData,
  Campaign,
  SendResult,
  CampaignStats,
} from "./provider-interface"
import { logger } from "@/lib/logger"

export class ConvertKitProvider implements NewsletterProvider {
  name = "ConvertKit"
  id = "convertkit"

  private apiKey: string
  private apiSecret: string
  private formId: string
  private baseUrl = "https://api.convertkit.com/v3"

  constructor(config: Record<string, string>) {
    this.apiKey = config.CONVERTKIT_API_KEY || ""
    this.apiSecret = config.CONVERTKIT_API_SECRET || ""
    this.formId = config.CONVERTKIT_FORM_ID || ""

    if (!this.apiKey || !this.apiSecret) {
      logger.error("ConvertKit API credentials are not configured")
    }

    if (!this.formId) {
      logger.error("ConvertKit Form ID is not configured")
    }
  }

  private async makeRequest(
    endpoint: string,
    method: "GET" | "POST" | "PUT" | "DELETE",
    data?: any,
    useSecret = false,
  ) {
    try {
      const authParam = useSecret ? `api_secret=${this.apiSecret}` : `api_key=${this.apiKey}`

      const url = `${this.baseUrl}${endpoint}${endpoint.includes("?") ? "&" : "?"}${authParam}`

      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: data ? JSON.stringify(data) : undefined,
      })

      if (!response.ok) {
        const errorText = await response.text()
        throw new Error(`ConvertKit API error: ${response.status} - ${errorText}`)
      }

      return await response.json()
    } catch (error) {
      logger.error("ConvertKit API request failed", { error, endpoint, method })
      throw error
    }
  }

  async subscribe(email: string, metadata?: Record<string, any>): Promise<SubscribeResult> {
    try {
      if (!this.apiKey || !this.formId) {
        return {
          success: false,
          message: "ConvertKit is not properly configured",
          error: "Missing API key or Form ID",
        }
      }

      const data: any = {
        email,
      }

      // Add first name and other fields if available
      if (metadata) {
        if (metadata.firstName || metadata.first_name) {
          data.first_name = metadata.firstName || metadata.first_name
        }

        // Add any custom fields
        if (Object.keys(metadata).length > 0) {
          data.fields = {}
          Object.entries(metadata).forEach(([key, value]) => {
            if (key !== "firstName" && key !== "first_name") {
              data.fields[key] = value
            }
          })
        }
      }

      const result = await this.makeRequest(`/forms/${this.formId}/subscribe`, "POST", data)

      return {
        success: true,
        message: "Successfully subscribed to the newsletter",
        subscriberId: result.subscription.subscriber.id.toString(),
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to subscribe to the newsletter",
        error: error.message,
      }
    }
  }

  async unsubscribe(email: string): Promise<UnsubscribeResult> {
    try {
      if (!this.apiSecret) {
        return {
          success: false,
          message: "ConvertKit is not properly configured",
          error: "Missing API secret",
        }
      }

      // Find subscriber by email
      const subscribers = await this.makeRequest(
        `/subscribers?email_address=${encodeURIComponent(email)}`,
        "GET",
        null,
        true,
      )

      if (!subscribers.subscribers || subscribers.subscribers.length === 0) {
        return {
          success: false,
          message: "Subscriber not found",
          error: "Subscriber not found",
        }
      }

      const subscriberId = subscribers.subscribers[0].id

      // Unsubscribe the subscriber
      await this.makeRequest(
        `/unsubscribe`,
        "PUT",
        {
          subscriber_id: subscriberId,
        },
        true,
      )

      return {
        success: true,
        message: "Successfully unsubscribed from the newsletter",
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to unsubscribe from the newsletter",
        error: error.message,
      }
    }
  }

  async getLists(): Promise<List[]> {
    try {
      if (!this.apiSecret) {
        return []
      }

      // In ConvertKit, "forms" and "sequences" are similar to lists
      const forms = await this.makeRequest("/forms", "GET", null, true)

      return forms.forms.map((form: any) => ({
        id: form.id.toString(),
        name: form.name,
        subscriberCount: form.total_subscriptions || 0,
        createdAt: new Date(), // ConvertKit doesn't provide creation date
      }))
    } catch (error) {
      logger.error("Failed to fetch ConvertKit forms", { error })
      return []
    }
  }

  async getSubscribers(listId?: string): Promise<Subscriber[]> {
    try {
      if (!this.apiSecret) {
        return []
      }

      let endpoint = "/subscribers"

      // If form ID is provided, get subscribers for that form
      if (listId) {
        endpoint = `/forms/${listId}/subscriptions`
      }

      const result = await this.makeRequest(endpoint, "GET", null, true)
      const subscribers = listId ? result.subscriptions : result.subscribers

      return subscribers.map((sub: any) => {
        // Extract subscriber data from different response formats
        const subscriber = listId ? sub.subscriber : sub

        return {
          id: subscriber.id.toString(),
          email: subscriber.email_address,
          name: subscriber.first_name ? subscriber.first_name : undefined,
          metadata: {
            first_name: subscriber.first_name,
            ...subscriber.fields,
          },
          subscriptionDate: new Date(subscriber.created_at),
          status: subscriber.state === "active" ? "active" : "unsubscribed",
        }
      })
    } catch (error) {
      logger.error("Failed to fetch ConvertKit subscribers", { error, listId })
      return []
    }
  }

  // ConvertKit calls campaigns "broadcasts"
  async createCampaign(campaign: CampaignData): Promise<Campaign> {
    try {
      if (!this.apiSecret) {
        throw new Error("ConvertKit is not properly configured")
      }

      // Create broadcast
      const result = await this.makeRequest(
        "/broadcasts",
        "POST",
        {
          broadcast: {
            subject: campaign.subject,
            content: campaign.content,
            description: campaign.name,
            email_layout_template: "default",
          },
        },
        true,
      )

      return {
        id: result.broadcast.id.toString(),
        name: campaign.name,
        subject: campaign.subject,
        status: "draft",
        createdAt: new Date(),
      }
    } catch (error: any) {
      logger.error("Failed to create ConvertKit broadcast", { error, campaign })
      throw new Error(`Failed to create campaign: ${error.message}`)
    }
  }

  async sendCampaign(campaignId: string): Promise<SendResult> {
    try {
      if (!this.apiSecret) {
        return {
          success: false,
          message: "ConvertKit is not properly configured",
          campaignId,
          error: "Missing API secret",
        }
      }

      await this.makeRequest(`/broadcasts/${campaignId}/send`, "POST", null, true)

      return {
        success: true,
        message: "Campaign sent successfully",
        campaignId,
      }
    } catch (error: any) {
      return {
        success: false,
        message: "Failed to send campaign",
        campaignId,
        error: error.message,
      }
    }
  }

  async getCampaignStats(campaignId: string): Promise<CampaignStats> {
    try {
      if (!this.apiSecret) {
        throw new Error("ConvertKit is not properly configured")
      }

      const result = await this.makeRequest(`/broadcasts/${campaignId}/stats`, "GET", null, true)

      return {
        sent: result.stats.recipients || 0,
        delivered: result.stats.recipients - result.stats.bounces || 0,
        opened: result.stats.opens || 0,
        clicked: result.stats.clicks || 0,
        bounced: result.stats.bounces || 0,
        complained: 0, // Not provided by ConvertKit
        unsubscribed: result.stats.unsubscribes || 0,
      }
    } catch (error) {
      logger.error("Failed to fetch ConvertKit campaign stats", { error, campaignId })
      return {
        sent: 0,
        delivered: 0,
        opened: 0,
        clicked: 0,
        bounced: 0,
        complained: 0,
        unsubscribed: 0,
      }
    }
  }
}

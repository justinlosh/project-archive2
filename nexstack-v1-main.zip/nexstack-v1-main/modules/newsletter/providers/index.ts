import type { NewsletterProvider } from "./provider-interface"
import { MailchimpProvider } from "./mailchimp"
import { BrevoProvider } from "./brevo"
import { ConvertKitProvider } from "./convertkit"
import { logger } from "@/lib/logger"

// Provider factory
export function createProvider(providerId: string, config: Record<string, string>): NewsletterProvider | null {
  try {
    switch (providerId.toLowerCase()) {
      case "mailchimp":
        return new MailchimpProvider(config)
      case "brevo":
        return new BrevoProvider(config)
      case "convertkit":
        return new ConvertKitProvider(config)
      default:
        logger.error(`Unknown newsletter provider: ${providerId}`)
        return null
    }
  } catch (error) {
    logger.error(`Failed to create newsletter provider: ${providerId}`, { error })
    return null
  }
}

// List of available providers
export const availableProviders = [
  { id: "mailchimp", name: "Mailchimp" },
  { id: "brevo", name: "Brevo (formerly Sendinblue)" },
  { id: "convertkit", name: "ConvertKit" },
]

# Newsletter Module

This module provides a newsletter subscription form that allows users to subscribe to your newsletter. It supports multiple email marketing service providers including Mailchimp, Brevo (formerly Sendinblue), and ConvertKit.

## Features

- Newsletter subscription form with customizable fields
- Support for multiple email marketing service providers
- Admin interface for managing subscribers and campaigns
- Campaign creation and sending
- Subscriber list management
- Comprehensive error handling and logging

## Supported Providers

- **Mailchimp**: Industry-standard email marketing platform
- **Brevo** (formerly Sendinblue): European email marketing service
- **ConvertKit**: Creator-focused email marketing platform

## Configuration

The Newsletter module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_NEWSLETTER` | Enable/disable the newsletter module | `false` |
| `MODULE_NEWSLETTER_PROVIDER` | Email service provider (mailchimp, brevo, convertkit) | `mailchimp` |
| `MODULE_NEWSLETTER_TITLE` | Title for the newsletter form | `Subscribe to our Newsletter` |
| `MODULE_NEWSLETTER_DESCRIPTION` | Description for the newsletter form | `Get the latest updates delivered to your inbox` |
| `MODULE_NEWSLETTER_BUTTON_TEXT` | Text for the subscribe button | `Subscribe` |
| `MODULE_NEWSLETTER_SUCCESS_MESSAGE` | Message shown after successful subscription | `Thanks for subscribing!` |
| `MODULE_NEWSLETTER_ERROR_MESSAGE` | Message shown if subscription fails | `Something went wrong. Please try again.` |
| `MODULE_NEWSLETTER_SHOW_PRIVACY_POLICY` | Show privacy policy text | `true` |
| `MODULE_NEWSLETTER_PRIVACY_POLICY_TEXT` | Privacy policy text | `We respect your privacy. Unsubscribe at any time.` |
| `MODULE_NEWSLETTER_COLLECT_NAME` | Collect subscriber's name | `false` |
| `MODULE_NEWSLETTER_NAME_LABEL` | Label for the name field | `Name` |
| `MODULE_NEWSLETTER_EMAIL_LABEL` | Label for the email field | `Email address` |

### Provider-Specific Configuration

#### Mailchimp

| Variable | Description |
| --- | --- |
| `MODULE_NEWSLETTER_MAILCHIMP_API_KEY` | Mailchimp API key |
| `MODULE_NEWSLETTER_MAILCHIMP_LIST_ID` | Mailchimp list/audience ID |

#### Brevo (formerly Sendinblue)

| Variable | Description |
| --- | --- |
| `MODULE_NEWSLETTER_BREVO_API_KEY` | Brevo API key |
| `MODULE_NEWSLETTER_BREVO_LIST_ID` | Brevo list ID |

#### ConvertKit

| Variable | Description |
| --- | --- |
| `MODULE_NEWSLETTER_CONVERTKIT_API_KEY` | ConvertKit API key |
| `MODULE_NEWSLETTER_CONVERTKIT_API_SECRET` | ConvertKit API secret |
| `MODULE_NEWSLETTER_CONVERTKIT_FORM_ID` | ConvertKit form ID |

## Usage

To use the Newsletter module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the newsletter module
<ModuleLoader moduleName="newsletter" />
\`\`\`

## Admin Interface

The module provides an admin interface for managing newsletter settings, subscribers, and campaigns. Access it at `/admin/newsletter`.

## Adding New Providers

The module is designed to be extensible. To add a new provider:

1. Create a new provider class in the `providers` directory that implements the `NewsletterProvider` interface
2. Add the provider to the `createProvider` factory function in `providers/index.ts`
3. Update the admin interface to include configuration options for the new provider

## Error Handling

The module includes comprehensive error handling and logging to facilitate debugging and troubleshooting. All API errors are logged and appropriate error messages are returned to the user.

"use client"

import { useEffect } from "react"
import Script from "next/script"

interface SEOModuleProps {
  config: Record<string, string>
}

export default function SEOModule({ config }: SEOModuleProps) {
  // Parse config values
  const defaultTitle = config.DEFAULT_TITLE || "Modular Next.js Project"
  const defaultDescription =
    config.DEFAULT_DESCRIPTION || "A modular Next.js website project optimized for v0 and Vercel deployment"
  const enableGoogleAnalytics = config.ENABLE_GOOGLE_ANALYTICS === "true"
  const googleAnalyticsId = config.GOOGLE_ANALYTICS_ID || ""
  const enableStructuredData = config.ENABLE_STRUCTURED_DATA === "true"
  const twitterUsername = config.TWITTER_USERNAME || ""
  const enableSocialMeta = config.ENABLE_SOCIAL_META === "true"
  const siteUrl = config.SITE_URL || "https://example.com"

  // Set up Google Analytics if enabled
  useEffect(() => {
    if (enableGoogleAnalytics && googleAnalyticsId) {
      // This would be replaced with actual Google Analytics setup
      console.log(`Google Analytics initialized with ID: ${googleAnalyticsId}`)
    }
  }, [enableGoogleAnalytics, googleAnalyticsId])

  // Currently this component doesn't render anything visible
  // It would be used in layout files to enhance SEO
  return (
    <>
      {/* Google Analytics */}
      {enableGoogleAnalytics && googleAnalyticsId && (
        <Script
          id="google-analytics"
          strategy="afterInteractive"
          dangerouslySetInnerHTML={{
            __html: `
              (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
              new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
              j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
              'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
              })(window,document,'script','dataLayer','${googleAnalyticsId}');
            `,
          }}
        />
      )}

      {/* This component is primarily for demonstration purposes.
          In a real application, you would use Next.js metadata API
          or a custom <Head> component at the page level. */}
      <div className="hidden">
        <p>SEO Module Active - Configuration:</p>
        <ul>
          <li>Default Title: {defaultTitle}</li>
          <li>Default Description: {defaultDescription}</li>
          <li>Google Analytics: {enableGoogleAnalytics ? "Enabled" : "Disabled"}</li>
          <li>Structured Data: {enableStructuredData ? "Enabled" : "Disabled"}</li>
          <li>Social Meta Tags: {enableSocialMeta ? "Enabled" : "Disabled"}</li>
          <li>Twitter Username: {twitterUsername}</li>
          <li>Site URL: {siteUrl}</li>
        </ul>
      </div>
    </>
  )
}

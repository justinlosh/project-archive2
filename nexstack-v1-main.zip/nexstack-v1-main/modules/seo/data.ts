export default {
  title: "SEO",
  description: "Search Engine Optimization settings and configurations",
  defaultMetaTags: [
    {
      name: "description",
      content: "A modular Next.js website project optimized for v0 and Vercel deployment",
    },
    {
      name: "keywords",
      content: "nextjs, react, modular, seo, vercel, v0",
    },
    {
      name: "author",
      content: "Modular Next.js Team",
    },
  ],
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://example.com",
    siteName: "Modular Next.js Project",
    images: [
      {
        url: "https://example.com/og-image.jpg",
        width: 1200,
        height: 630,
        alt: "Modular Next.js Project",
      },
    ],
  },
  twitter: {
    handle: "@username",
    site: "@site",
    cardType: "summary_large_image",
  },
  structuredData: {
    organization: {
      "@context": "https://schema.org",
      "@type": "Organization",
      name: "Modular Next.js Project",
      url: "https://example.com",
      logo: "https://example.com/logo.png",
      sameAs: ["https://twitter.com/username", "https://github.com/username/modular-nextjs"],
    },
  },
}

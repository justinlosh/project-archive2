import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getModuleData } from "@/lib/module-loader"

interface ChangelogModuleProps {
  config: Record<string, string>
  preview?: boolean
}

export default async function ChangelogModule({ config, preview = false }: ChangelogModuleProps) {
  const title = config.TITLE || "Changelog"
  const description = config.DESCRIPTION || "Track the latest updates and improvements to our platform"
  const showTypes = config.SHOW_TYPES !== "false"
  const showDates = config.SHOW_DATES !== "false"
  const entriesPerPage = Number.parseInt(config.ENTRIES_PER_PAGE || "10", 10)
  const sortOrder = config.SORT_ORDER || "desc"

  const changelogData = await getModuleData("changelog")
  if (!changelogData) return null

  // Sort versions by date
  const versions = [...changelogData.versions]
  if (sortOrder === "desc") {
    versions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
  } else {
    versions.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
  }

  // Limit the number of versions shown in preview mode
  const displayVersions = preview ? versions.slice(0, 3) : versions.slice(0, entriesPerPage)

  return (
    <div className="space-y-8">
      {!preview && (
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight">{title}</h1>
          <p className="text-muted-foreground">{description}</p>
        </div>
      )}

      <div className="space-y-8">
        {displayVersions.map((version) => (
          <Card key={version.version} id={`v${version.version}`}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <CardTitle className="text-xl">
                    <Link href={`/changelog#v${version.version}`} className="hover:underline">
                      Version {version.version}
                    </Link>
                  </CardTitle>
                  {showDates && (
                    <CardDescription>Released on {new Date(version.date).toLocaleDateString()}</CardDescription>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-4">
                {version.changes.map((change, index) => (
                  <li key={index} className="flex items-start gap-2">
                    {showTypes && (
                      <Badge
                        className={`mt-0.5 ${
                          change.type === "added"
                            ? "bg-green-500"
                            : change.type === "fixed"
                              ? "bg-blue-500"
                              : change.type === "improved"
                                ? "bg-amber-500"
                                : change.type === "removed"
                                  ? "bg-red-500"
                                  : "bg-gray-500"
                        }`}
                      >
                        {change.type}
                      </Badge>
                    )}
                    <span>{change.description}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>

      {preview && versions.length > 3 && (
        <div className="text-center">
          <Link href="/changelog" className="inline-flex items-center text-sm font-medium text-primary hover:underline">
            View full changelog
          </Link>
        </div>
      )}
    </div>
  )
}

export default {
  title: "Changelog",
  description: "Track the latest updates and improvements to our platform",
  versions: [
    {
      version: "1.2.0",
      date: "2024-05-04",
      changes: [
        {
          type: "added",
          description: "Added breadcrumb navigation for improved user experience",
        },
        {
          type: "added",
          description: "Implemented new page header component for consistent page layouts",
        },
        {
          type: "improved",
          description: "Enhanced mobile responsiveness across all pages",
        },
      ],
    },
    {
      version: "1.1.0",
      date: "2024-04-20",
      changes: [
        {
          type: "added",
          description: "Added dark mode support with automatic system preference detection",
        },
        {
          type: "fixed",
          description: "Fixed navigation issues on mobile devices",
        },
        {
          type: "improved",
          description: "Optimized page load performance",
        },
      ],
    },
    {
      version: "1.0.0",
      date: "2024-04-01",
      changes: [
        {
          type: "added",
          description: "Initial release of the modular website platform",
        },
        {
          type: "added",
          description: "Implemented blog module with post listing and detail pages",
        },
        {
          type: "added",
          description: "Added contact form with validation and submission handling",
        },
        {
          type: "added",
          description: "Created newsletter subscription component",
        },
      ],
    },
  ],
}

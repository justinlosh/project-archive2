# Changelog Module

This module provides a changelog feature for your website, allowing you to display version history and updates to your users.

## Features

- Display changelog entries with version numbers and dates
- Group entries by version
- Support for different types of changes (added, changed, fixed, etc.)
- Configurable display options

## Configuration

The Changelog module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_CHANGELOG` | Enable/disable the changelog module | `false` |
| `MODULE_CHANGELOG_TITLE` | Title for the changelog section | `Changelog` |
| `MODULE_CHANGELOG_DESCRIPTION` | Description for the changelog section | `Track the latest updates and improvements to our platform` |
| `MODULE_CHANGELOG_SHOW_TYPES` | Show/hide change types | `true` |
| `MODULE_CHANGELOG_SHOW_DATES` | Show/hide version dates | `true` |
| `MODULE_CHANGELOG_ENTRIES_PER_PAGE` | Number of entries per page | `10` |
| `MODULE_CHANGELOG_SORT_ORDER` | Sort order for versions (asc/desc) | `desc` |

## Usage

To use the Changelog module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the changelog module
<ModuleLoader moduleName="changelog" />
\`\`\`

## Routes

The Changelog module provides the following routes:

- `/changelog` - Changelog listing page

## Adding Changelog Entries

To add new changelog entries, update the `data.ts` file in the changelog module directory. Each entry should include:

- `version` - The version number
- `date` - The release date
- `changes` - An array of changes, each with a `type` and `description`

Example:

\`\`\`typescript
{
  version: "1.2.0",
  date: "2024-05-04",
  changes: [
    {
      type: "added",
      description: "Added breadcrumb navigation for improved user experience",
    },
    {
      type: "fixed",
      description: "Fixed navigation issues on mobile devices",
    },
  ],
}

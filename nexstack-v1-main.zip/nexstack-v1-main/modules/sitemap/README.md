# Sitemap Module

This module generates and manages the sitemap.xml file for your website to improve SEO and help search engines discover and index your pages.

## Features

- Automatically generates a sitemap.xml file
- Configurable change frequency and priority
- Support for including images
- Support for including last modified dates
- Ability to add custom URLs or exclude specific URLs

## Configuration

The Sitemap module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_SITEMAP` | Enable/disable the sitemap module | `false` |
| `MODULE_SITEMAP_DEFAULT_CHANGE_FREQUENCY` | Default change frequency for URLs | `weekly` |
| `MODULE_SITEMAP_DEFAULT_PRIORITY` | Default priority for URLs | `0.7` |
| `MODULE_SITEMAP_INCLUDE_IMAGES` | Include images in the sitemap | `true` |
| `MODULE_SITEMAP_INCLUDE_LASTMOD` | Include last modified dates | `true` |

## Usage

The Sitemap module automatically generates a sitemap.xml file at the `/sitemap.xml` route. No additional setup is required beyond enabling the module.

## Customizing the Sitemap

To add custom URLs or exclude specific URLs from the sitemap, update the `data.ts` file in the sitemap module directory:

\`\`\`typescript
export default {
  title: "Sitemap",
  description: "XML sitemap for search engine optimization",
  additionalUrls: [
    {
      url: "https://example.com/custom-page",
      changeFrequency: "monthly",
      priority: 0.8,
    },
  ],
  excludedUrls: [
    "https://example.com/private-page",
  ],
}
\`\`\`

## Integration with Next.js

This module uses Next.js's built-in sitemap generation capabilities. The sitemap is generated at build time and served at the `/sitemap.xml` route.
\`\`\`

Now, let's create the Sitemap component:

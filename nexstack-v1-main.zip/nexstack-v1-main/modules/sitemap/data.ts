export default {
  title: "Sitemap",
  description: "XML sitemap for search engine optimization",
  additionalUrls: [
    // Add any additional URLs that aren't automatically detected
  ],
  excludedUrls: [
    // Add any URLs that should be excluded from the sitemap
  ],
}

// This component doesn't render anything visible
// It's used to generate the sitemap.xml file
export default function SitemapModule() {
  return null
}

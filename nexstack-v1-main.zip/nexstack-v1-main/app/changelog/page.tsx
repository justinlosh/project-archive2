import { ModuleRoute } from "@/lib/module-loader"
import { ModuleLoader } from "@/lib/module-loader"
import { PageHeader } from "@/components/page-header"

export const metadata = {
  title: "Changelog | Modular Website",
  description: "Track the latest updates and improvements to our platform",
}

export default function ChangelogPage() {
  return (
    <ModuleRoute moduleName="changelog">
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          <PageHeader title="Changelog" description="Track the latest updates and improvements to our platform" />
          <ModuleLoader moduleName="changelog" />
        </div>
      </div>
    </ModuleRoute>
  )
}

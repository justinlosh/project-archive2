import { getModuleStatus, getModuleData, getModuleConfig } from "@/lib/module-loader"
import { NextResponse } from "next/server"

export async function GET() {
  // Check if security.txt module is enabled
  const isSecurityTxtEnabled = getModuleStatus("security-txt")
  if (!isSecurityTxtEnabled) {
    return new NextResponse("# Security.txt module is disabled", {
      status: 404,
      headers: {
        "Content-Type": "text/plain",
      },
    })
  }

  const securityTxtData = await getModuleData("security-txt")
  const securityTxtConfig = getModuleConfig("security-txt")

  // Get configuration values
  const contacts = securityTxtConfig.CONTACT
    ? [securityTxtConfig.CONTACT]
    : securityTxtData?.contacts || ["mailto:security@example.com"]
  const encryption = securityTxtConfig.ENCRYPTION || securityTxtData?.encryption
  const acknowledgments = securityTxtConfig.ACKNOWLEDGMENTS || securityTxtData?.acknowledgments
  const policy = securityTxtConfig.POLICY || securityTxtData?.policy
  const hiring = securityTxtConfig.HIRING || securityTxtData?.hiring

  // Calculate expiration date
  const expiresInDays = Number.parseInt(securityTxtConfig.EXPIRES || "365", 10)
  const expirationDate = new Date()
  expirationDate.setDate(expirationDate.getDate() + expiresInDays)
  const expires = securityTxtData?.expires || expirationDate.toISOString()

  // Build the security.txt content
  let content = ""

  // Add contacts
  contacts.forEach((contact) => {
    content += `Contact: ${contact}\n`
  })

  // Add other fields if they exist
  if (encryption) {
    content += `Encryption: ${encryption}\n`
  }
  if (acknowledgments) {
    content += `Acknowledgments: ${acknowledgments}\n`
  }
  if (policy) {
    content += `Policy: ${policy}\n`
  }
  if (hiring) {
    content += `Hiring: ${hiring}\n`
  }

  // Add expires
  content += `Expires: ${expires}\n`

  // Add canonical URL
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.com"
  content += `Canonical: ${baseUrl}/.well-known/security.txt\n`

  // Return the security.txt content
  return new NextResponse(content, {
    headers: {
      "Content-Type": "text/plain",
    },
  })
}

import { getModuleData } from "@/lib/module-system"
import AdminNewsletter from "@/modules/newsletter/admin"

export const metadata = {
  title: "Newsletter Management",
  description: "Manage your newsletter settings, subscribers, and campaigns",
}

export default async function NewsletterAdminPage() {
  const newsletterData = await getModuleData("newsletter")

  if (!newsletterData) {
    return (
      <div className="p-4">
        <h1 className="text-2xl font-bold mb-4">Newsletter Module</h1>
        <p>The Newsletter module is not enabled. Enable it in your environment configuration.</p>
      </div>
    )
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4">Newsletter Management</h1>
      <AdminNewsletter config={newsletterData.config} />
    </div>
  )
}

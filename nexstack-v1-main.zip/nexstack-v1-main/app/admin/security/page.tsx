import { PageHeader } from "@/components/page-header"
import { Breadcrumb } from "@/components/breadcrumb"
import { AdminSecurityAdmin } from "@/modules/admin-security/admin"

export const metadata = {
  title: "Admin Security Configuration",
  description: "Configure security settings for the admin area",
}

export default function AdminSecurityPage() {
  return (
    <div className="container px-4 md:px-6 py-8">
      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Admin", href: "/admin" },
          { label: "Security", href: "/admin/security" },
        ]}
      />
      <PageHeader heading="Admin Security Configuration" subheading="Configure security settings for the admin area" />
      <div className="mt-8">
        <AdminSecurityAdmin />
      </div>
    </div>
  )
}

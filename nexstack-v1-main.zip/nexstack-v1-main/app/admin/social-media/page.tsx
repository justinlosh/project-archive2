import { ModuleRoute } from "@/lib/module-loader"
import { getModuleConfig } from "@/lib/module-system"
import { PageHeader } from "@/components/page-header"
import { AdminSocialMedia } from "@/modules/social-media/admin"

export const metadata = {
  title: "Social Media Configuration | Admin",
  description: "Configure social media accounts and display settings",
}

export default async function AdminSocialMediaPage() {
  const socialMediaConfig = getModuleConfig("social-media")

  return (
    <ModuleRoute moduleName="social-media">
      <div className="container py-12">
        <div className="max-w-4xl mx-auto">
          <PageHeader
            title="Social Media Configuration"
            description="Configure social media accounts and display settings"
          />
          <AdminSocialMedia config={socialMediaConfig} />
        </div>
      </div>
    </ModuleRoute>
  )
}

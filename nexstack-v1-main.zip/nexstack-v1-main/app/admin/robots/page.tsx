import { ModuleRoute } from "@/lib/module-loader"
import { getModuleConfig } from "@/lib/module-system"
import { PageHeader } from "@/components/page-header"
import { AdminRobotsTxt } from "@/modules/robots-txt/admin"

export const metadata = {
  title: "Robots.txt Configuration | Admin",
  description: "Configure robots.txt settings for your website",
}

export default async function AdminRobotsTxtPage() {
  const robotsTxtConfig = getModuleConfig("robots-txt")

  return (
    <ModuleRoute moduleName="robots-txt">
      <div className="container py-12">
        <div className="max-w-4xl mx-auto">
          <PageHeader title="Robots.txt Configuration" description="Configure robots.txt settings for your website" />
          <AdminRobotsTxt config={robotsTxtConfig} />
        </div>
      </div>
    </ModuleRoute>
  )
}

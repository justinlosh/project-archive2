import { PageHeader } from "@/components/page-header"
import { Breadcrumb } from "@/components/breadcrumb"
import { ModuleInfo } from "@/components/module-info"
import { getModuleStatus } from "@/lib/module-loader"
import {
  BarChart,
  FileText,
  Mail,
  Search,
  History,
  Info,
  Share2,
  Wrench,
  Bot,
  Shield,
  Network,
  MailPlus,
} from "lucide-react"

export const metadata = {
  title: "Module Manager",
  description: "Enable or disable modules for your website",
}

export default function ModulesPage() {
  // Get module statuses
  const isBlogEnabled = getModuleStatus("blog")
  const isNewsletterEnabled = getModuleStatus("newsletter")
  const isContactEnabled = getModuleStatus("contact")
  const isSeoEnabled = getModuleStatus("seo")
  const isAnalyticsEnabled = getModuleStatus("analytics")
  const isChangelogEnabled = getModuleStatus("changelog")
  const isColophonEnabled = getModuleStatus("colophon")
  const isSocialMediaEnabled = getModuleStatus("social-media")
  const isMaintenanceModeEnabled = getModuleStatus("maintenance-mode")
  const isSitemapEnabled = getModuleStatus("sitemap")
  const isRobotsTxtEnabled = getModuleStatus("robots-txt")
  const isSecurityTxtEnabled = getModuleStatus("security-txt")

  return (
    <div className="container px-4 md:px-6 py-8">
      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Admin", href: "/admin" },
          { label: "Modules", href: "/admin/modules" },
        ]}
      />
      <PageHeader heading="Module Manager" subheading="Enable or disable modules for your website" />

      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <ModuleInfo
          name="Blog"
          description="Publish and manage blog posts with categories and tags"
          enabled={isBlogEnabled}
          icon={<FileText className="h-5 w-5" />}
          adminPath="/admin/blog"
          docsPath="/docs/modules/blog"
          configCount={8}
        />

        <ModuleInfo
          name="Newsletter"
          description="Collect email subscribers and send newsletters"
          enabled={isNewsletterEnabled}
          icon={<MailPlus className="h-5 w-5" />}
          adminPath="/admin/newsletter"
          docsPath="/docs/modules/newsletter"
          configCount={12}
        />

        <ModuleInfo
          name="Contact"
          description="Contact form with email notifications and spam protection"
          enabled={isContactEnabled}
          icon={<Mail className="h-5 w-5" />}
          adminPath="/admin/contact"
          docsPath="/docs/modules/contact"
          configCount={10}
        />

        <ModuleInfo
          name="SEO"
          description="Search engine optimization with meta tags and structured data"
          enabled={isSeoEnabled}
          icon={<Search className="h-5 w-5" />}
          docsPath="/docs/modules/seo"
          configCount={15}
        />

        <ModuleInfo
          name="Analytics"
          description="Track website traffic and user behavior"
          enabled={isAnalyticsEnabled}
          icon={<BarChart className="h-5 w-5" />}
          adminPath="/admin/analytics"
          configCount={8}
        />

        <ModuleInfo
          name="Changelog"
          description="Display product updates and version history"
          enabled={isChangelogEnabled}
          icon={<History className="h-5 w-5" />}
          docsPath="/docs/modules/changelog"
          configCount={5}
        />

        <ModuleInfo
          name="Colophon"
          description="Technical details about the website"
          enabled={isColophonEnabled}
          icon={<Info className="h-5 w-5" />}
          configCount={4}
        />

        <ModuleInfo
          name="Social Media"
          description="Social media links and sharing functionality"
          enabled={isSocialMediaEnabled}
          icon={<Share2 className="h-5 w-5" />}
          adminPath="/admin/social-media"
          configCount={12}
        />

        <ModuleInfo
          name="Maintenance Mode"
          description="Display maintenance page when site is under maintenance"
          enabled={isMaintenanceModeEnabled}
          icon={<Wrench className="h-5 w-5" />}
          adminPath="/admin/maintenance"
          configCount={6}
        />

        <ModuleInfo
          name="Sitemap"
          description="Generate XML sitemap for search engines"
          enabled={isSitemapEnabled}
          icon={<Network className="h-5 w-5" />}
          configCount={3}
        />

        <ModuleInfo
          name="Robots.txt"
          description="Control search engine crawling with robots.txt"
          enabled={isRobotsTxtEnabled}
          icon={<Bot className="h-5 w-5" />}
          adminPath="/admin/robots"
          configCount={4}
        />

        <ModuleInfo
          name="Security.txt"
          description="Security policy and contact information"
          enabled={isSecurityTxtEnabled}
          icon={<Shield className="h-5 w-5" />}
          configCount={5}
        />
      </div>
    </div>
  )
}

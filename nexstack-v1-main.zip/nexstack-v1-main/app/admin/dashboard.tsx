import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { getModuleStatus } from "@/lib/module-loader"
import { BarChart, Mail, FileText, History, Share2, Wrench, Bot } from "lucide-react"

export function AdminDashboard() {
  // Get module statuses
  const isBlogEnabled = getModuleStatus("blog")
  const isNewsletterEnabled = getModuleStatus("newsletter")
  const isContactEnabled = getModuleStatus("contact")
  const isSeoEnabled = getModuleStatus("seo")
  const isAnalyticsEnabled = getModuleStatus("analytics")
  const isChangelogEnabled = getModuleStatus("changelog")
  const isColophonEnabled = getModuleStatus("colophon")
  const isSocialMediaEnabled = getModuleStatus("social-media")
  const isMaintenanceModeEnabled = getModuleStatus("maintenance-mode")
  const isSitemapEnabled = getModuleStatus("sitemap")
  const isRobotsTxtEnabled = getModuleStatus("robots-txt")
  const isSecurityTxtEnabled = getModuleStatus("security-txt")

  // Count enabled modules
  const enabledModulesCount = [
    isBlogEnabled,
    isNewsletterEnabled,
    isContactEnabled,
    isSeoEnabled,
    isAnalyticsEnabled,
    isChangelogEnabled,
    isColophonEnabled,
    isSocialMediaEnabled,
    isMaintenanceModeEnabled,
    isSitemapEnabled,
    isRobotsTxtEnabled,
    isSecurityTxtEnabled,
  ].filter(Boolean).length

  // Total modules count
  const totalModulesCount = 12

  return (
    <div className="space-y-8">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Modules</CardTitle>
            <CardDescription>Active module status</CardDescription>
          </CardHeader>
          <CardContent className="pb-2">
            <div className="text-3xl font-bold">
              {enabledModulesCount} / {totalModulesCount}
            </div>
            <div className="text-sm text-muted-foreground">Enabled modules</div>
            <div className="mt-4 h-2 w-full bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-primary rounded-full"
                style={{ width: `${(enabledModulesCount / totalModulesCount) * 100}%` }}
              ></div>
            </div>
          </CardContent>
          <CardFooter>
            <Button asChild variant="outline" size="sm">
              <Link href="/admin/modules">Manage Modules</Link>
            </Button>
          </CardFooter>
        </Card>

        {isAnalyticsEnabled && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Analytics</CardTitle>
              <CardDescription>Website traffic and engagement</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center">
                <BarChart className="h-8 w-8 text-primary mr-2" />
                <div>
                  <div className="text-sm text-muted-foreground">Analytics module is active</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/admin/analytics">View Analytics</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isMaintenanceModeEnabled && (
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>Maintenance Mode</CardTitle>
              <CardDescription>Site availability status</CardDescription>
            </CardHeader>
            <CardContent className="pb-2">
              <div className="flex items-center">
                <Wrench className="h-8 w-8 text-yellow-500 mr-2" />
                <div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Site Online
                  </Badge>
                  <div className="text-sm text-muted-foreground mt-1">Maintenance mode is available</div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" size="sm">
                <Link href="/admin/maintenance">Manage Maintenance</Link>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>

      <h2 className="text-2xl font-bold tracking-tight mt-8 mb-4">Module Management</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isNewsletterEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                <CardTitle>Newsletter</CardTitle>
              </div>
              <CardDescription>Manage your newsletter subscribers</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/newsletter">Manage Newsletter</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isContactEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Mail className="h-5 w-5 text-primary" />
                <CardTitle>Contact</CardTitle>
              </div>
              <CardDescription>Configure contact form settings</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/contact">Manage Contact</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isBlogEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <CardTitle>Blog</CardTitle>
              </div>
              <CardDescription>Manage blog posts and settings</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/blog">Manage Blog</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isChangelogEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <History className="h-5 w-5 text-primary" />
                <CardTitle>Changelog</CardTitle>
              </div>
              <CardDescription>Manage version history</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/changelog">Manage Changelog</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isSocialMediaEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Share2 className="h-5 w-5 text-primary" />
                <CardTitle>Social Media</CardTitle>
              </div>
              <CardDescription>Configure social media accounts</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/social-media">Manage Social Media</Link>
              </Button>
            </CardFooter>
          </Card>
        )}

        {isRobotsTxtEnabled && (
          <Card className="card-hover">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2">
                <Bot className="h-5 w-5 text-primary" />
                <CardTitle>Robots.txt</CardTitle>
              </div>
              <CardDescription>Configure search engine crawling</CardDescription>
            </CardHeader>
            <CardFooter>
              <Button asChild variant="outline" size="sm" className="w-full">
                <Link href="/admin/robots">Manage Robots.txt</Link>
              </Button>
            </CardFooter>
          </Card>
        )}
      </div>
    </div>
  )
}

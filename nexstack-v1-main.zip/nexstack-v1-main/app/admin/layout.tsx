import type React from "react"
import type { Metadata } from "next"
import Link from "next/link"
import { getModuleStatus } from "@/lib/module-loader"
import { PageHeader } from "@/components/page-header"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"

export const metadata: Metadata = {
  title: "Admin Dashboard",
  description: "Manage your website settings and content",
}

interface AdminModule {
  id: string
  name: string
  path: string
  moduleDependency?: string
}

const adminModules: AdminModule[] = [
  { id: "dashboard", name: "Dashboard", path: "/admin" },
  { id: "modules", name: "Modules", path: "/admin/modules" },
  { id: "maintenance", name: "Maintenance Mode", path: "/admin/maintenance", moduleDependency: "maintenance-mode" },
  { id: "robots", name: "Robots.txt", path: "/admin/robots", moduleDependency: "robots-txt" },
  { id: "social-media", name: "Social Media", path: "/admin/social-media", moduleDependency: "social-media" },
  { id: "analytics", name: "Analytics", path: "/admin/analytics", moduleDependency: "analytics" },
]

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  // Filter admin modules based on module status
  const filteredAdminModules = adminModules.filter((module) => {
    if (module.moduleDependency) {
      return getModuleStatus(module.moduleDependency)
    }
    return true
  })

  return (
    <div className="container py-8">
      <PageHeader title="Admin Dashboard" description="Manage your website settings and content" />

      <Tabs defaultValue="dashboard" className="mb-8">
        <TabsList className="w-full justify-start overflow-x-auto">
          {filteredAdminModules.map((module) => (
            <TabsTrigger key={module.id} value={module.id} asChild>
              <Link href={module.path}>{module.name}</Link>
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {children}
    </div>
  )
}

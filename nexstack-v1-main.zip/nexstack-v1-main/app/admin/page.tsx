import { PageHeader } from "@/components/page-header"
import { Breadcrumb } from "@/components/breadcrumb"
import { AdminDashboard } from "./dashboard"

export const metadata = {
  title: "Admin Dashboard",
  description: "Manage your website modules and settings",
}

export default function AdminPage() {
  return (
    <div className="container px-4 md:px-6 py-8">
      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Admin", href: "/admin" },
        ]}
      />
      <PageHeader heading="Admin Dashboard" subheading="Manage your website modules and settings" />
      <div className="mt-8">
        <AdminDashboard />
      </div>
    </div>
  )
}

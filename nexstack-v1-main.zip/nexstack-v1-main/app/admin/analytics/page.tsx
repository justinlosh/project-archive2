import { ModuleRoute, getModuleData, getModuleConfig } from "@/lib/module-loader"
import { PageHeader } from "@/components/page-header"
import { AdminAnalytics } from "@/modules/analytics/admin"

export const metadata = {
  title: "Analytics Configuration | Admin",
  description: "Configure analytics settings for your website",
}

export default async function AdminAnalyticsPage() {
  const analyticsData = await getModuleData("analytics")
  const analyticsConfig = getModuleConfig("analytics")

  return (
    <ModuleRoute moduleName="analytics">
      <div className="container py-12">
        <div className="max-w-4xl mx-auto">
          <PageHeader title="Analytics Configuration" description="Configure analytics settings for your website" />
          <AdminAnalytics config={analyticsConfig} data={analyticsData} />
        </div>
      </div>
    </ModuleRoute>
  )
}

import type { Metadata } from "next"
import ContactAdmin from "@/modules/contact/admin"
import { PageHeader } from "@/components/page-header"
import { Breadcrumb } from "@/components/breadcrumb"

export const metadata: Metadata = {
  title: "Contact Module Settings",
  description: "Configure your contact form and bot protection settings",
}

export default function ContactAdminPage() {
  return (
    <div className="container mx-auto py-6 space-y-6">
      <Breadcrumb
        items={[
          { label: "Home", href: "/" },
          { label: "Admin", href: "/admin" },
          { label: "Contact", href: "/admin/contact" },
        ]}
      />
      <PageHeader heading="Contact Module Settings" text="Configure your contact form and bot protection settings" />
      <ContactAdmin />
    </div>
  )
}

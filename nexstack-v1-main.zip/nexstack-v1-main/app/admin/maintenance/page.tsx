import { ModuleRoute, getModuleStatus } from "@/lib/module-loader"
import { getModuleConfig } from "@/lib/module-system"
import { PageHeader } from "@/components/page-header"
import { AdminMaintenanceMode } from "@/modules/maintenance-mode/admin"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertTriangle } from "lucide-react"

export const metadata = {
  title: "Maintenance Mode Configuration | Admin",
  description: "Configure maintenance mode settings for your website",
}

export default async function AdminMaintenancePage() {
  const isMaintenanceModeEnabled = getModuleStatus("maintenance-mode")
  const maintenanceConfig = getModuleConfig("maintenance-mode")
  const isActive = maintenanceConfig.ENABLED === "true"

  return (
    <ModuleRoute moduleName="maintenance-mode">
      <div className="container py-12">
        <div className="max-w-4xl mx-auto">
          <PageHeader
            title="Maintenance Mode Configuration"
            description="Configure maintenance mode settings for your website"
          />

          {isActive && (
            <Alert variant="destructive" className="mb-6">
              <AlertTriangle className="h-4 w-4" />
              <AlertTitle>Maintenance Mode Active</AlertTitle>
              <AlertDescription>
                Maintenance mode is currently active. All visitors are being redirected to the maintenance page.
              </AlertDescription>
            </Alert>
          )}

          <AdminMaintenanceMode config={maintenanceConfig} />
        </div>
      </div>
    </ModuleRoute>
  )
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Suspense } from "react"
import { ModuleLoader } from "@/lib/module-system"

export default function HomePage() {
  return (
    <div className="container px-4 md:px-6 py-8">
      <div className="flex flex-col items-center justify-center space-y-4 text-center">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Next.js Modular Starter</h1>
          <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
            A modular approach to building Next.js applications
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button asChild>
            <Link href="/docs">Documentation</Link>
          </Button>
          <Button asChild variant="outline">
            <Link href="/admin">Admin Dashboard</Link>
          </Button>
        </div>
      </div>

      <div className="mt-16 grid gap-12">
        <Suspense fallback={<div>Loading blog module...</div>}>
          <ModuleLoader moduleName="blog" fallback={<div>Blog module is not enabled</div>} />
        </Suspense>

        <Suspense fallback={<div>Loading newsletter module...</div>}>
          <ModuleLoader moduleName="newsletter" fallback={<div>Newsletter module is not enabled</div>} />
        </Suspense>
      </div>
    </div>
  )
}

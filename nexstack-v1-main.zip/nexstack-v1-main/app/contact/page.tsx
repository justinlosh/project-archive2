import { ModuleLoader, ModuleRoute, getModuleData } from "@/lib/module-loader"
import { PageHeader } from "@/components/page-header"

export const metadata = {
  title: "Contact Us | Modular Website",
  description: "Get in touch with our team. We'd love to hear from you!",
}

export default async function ContactPage() {
  const contactData = await getModuleData("contact")

  return (
    <ModuleRoute moduleName="contact">
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          <PageHeader title="Contact Us" description="Have questions or feedback? We'd love to hear from you." />

          <ModuleLoader moduleName="contact" />

          {contactData && (
            <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Email</h3>
                <p className="text-muted-foreground">{contactData.contactInfo.email}</p>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Phone</h3>
                <p className="text-muted-foreground">{contactData.contactInfo.phone}</p>
              </div>
              <div className="text-center">
                <h3 className="text-lg font-semibold mb-2">Address</h3>
                <p className="text-muted-foreground">{contactData.contactInfo.address}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </ModuleRoute>
  )
}

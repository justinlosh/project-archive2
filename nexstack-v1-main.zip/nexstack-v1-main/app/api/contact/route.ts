import { type NextRequest, NextResponse } from "next/server"
import { getBotProtectionProvider } from "@/modules/contact/bot-protection"
import { sanitizeInput } from "@/lib/security"
import { getModuleConfig } from "@/lib/module-system"
import { csrf } from "@/lib/csrf"
import { RateLimiter } from "@/lib/rate-limiter"
import { z } from "zod"

// Define validation schema with stricter rules
const contactSchema = z.object({
  name: z.string().min(1).max(100).trim(),
  email: z.string().email().max(254),
  subject: z.string().max(200).optional(),
  message: z.string().min(1).max(5000).trim(),
})

// Create rate limiter (5 requests per minute per IP)
const limiter = new RateLimiter({
  windowMs: 60 * 1000,
  max: 5,
  message: "Too many requests, please try again later.",
  keyGenerator: (req) => {
    const forwarded = req.headers.get("x-forwarded-for")
    const ip = forwarded ? forwarded.split(",")[0].trim() : "127.0.0.1"
    return `contact_form_${ip}`
  },
})

export async function POST(request: NextRequest) {
  try {
    // Check rate limit
    const clientIp = request.headers.get("x-forwarded-for") || "127.0.0.1"
    const rateLimitResult = await limiter.check(clientIp)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { success: false, message: "Too many requests, please try again later." },
        {
          status: 429,
          headers: {
            "Retry-After": Math.ceil((rateLimitResult.reset - Date.now()) / 1000).toString(),
          },
        },
      )
    }

    // Verify CSRF token
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      return NextResponse.json({ success: false, message: "Invalid request token" }, { status: 403 })
    }

    // Get contact module configuration
    const contactConfig = await getModuleConfig("contact")

    // Parse the request body
    const formData = await request.formData()

    // Get bot protection configuration
    const botProtectionConfig = {
      enabled: contactConfig.BOT_PROTECTION_ENABLED === "true",
      provider: contactConfig.BOT_PROTECTION_PROVIDER || "recaptcha",
      siteKey: contactConfig.BOT_PROTECTION_SITE_KEY || "",
      secretKey: contactConfig.BOT_PROTECTION_SECRET_KEY || "",
    }

    // Verify bot protection if enabled
    const botProtectionProvider = getBotProtectionProvider(botProtectionConfig)
    if (botProtectionProvider) {
      const tokenFieldName = botProtectionProvider.getTokenFieldName()
      const token = formData.get(tokenFieldName) as string

      if (!token) {
        return NextResponse.json(
          { success: false, message: "Bot protection verification failed: Missing token" },
          { status: 400 },
        )
      }

      const isValid = await botProtectionProvider.verifyToken(token, botProtectionConfig.secretKey)
      if (!isValid) {
        return NextResponse.json({ success: false, message: "Bot protection verification failed" }, { status: 400 })
      }
    }

    // Extract form fields and sanitize
    const name = sanitizeInput(formData.get("name") as string)
    const email = sanitizeInput(formData.get("email") as string)
    const subject = sanitizeInput(formData.get("subject") as string)
    const message = sanitizeInput(formData.get("message") as string)

    // Validate with schema
    const validationResult = contactSchema.safeParse({
      name,
      email,
      subject: subject || undefined,
      message,
    })

    if (!validationResult.success) {
      return NextResponse.json(
        {
          success: false,
          message: "Invalid input data",
          errors: validationResult.error.flatten(),
        },
        { status: 400 },
      )
    }

    // In a real application, you would send the email here
    // For now, we'll just log the data and return success
    console.log("Contact form submission:", { name, email, subject, message })

    return NextResponse.json({
      success: true,
      message: contactConfig.SUCCESS_MESSAGE || "Thank you for your message. We'll get back to you soon!",
    })
  } catch (error) {
    console.error("Contact form submission error:", error)
    return NextResponse.json({ success: false, message: "An unexpected error occurred" }, { status: 500 })
  }
}

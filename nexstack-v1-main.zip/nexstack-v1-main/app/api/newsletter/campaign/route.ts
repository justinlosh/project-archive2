import { NextResponse } from "next/server"
import { getModuleData } from "@/lib/module-system"
import { logger } from "@/lib/logger"
import { csrf } from "@/lib/csrf"
import { z } from "zod"

// Define validation schema
const campaignSchema = z.object({
  name: z.string().min(3).max(100),
  subject: z.string().min(3).max(150),
  fromName: z.string().min(1).max(50),
  fromEmail: z.string().email(),
  content: z.string().min(10).max(50000),
  listId: z.string().min(1),
})

export async function POST(request: Request) {
  try {
    // Verify CSRF token
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      return NextResponse.json({ success: false, message: "Invalid request token" }, { status: 403 })
    }

    // Here you would implement authentication check for admin access
    // For example:
    // if (!isAdmin(request)) {
    //   return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    // }

    // Check if the newsletter module is enabled
    const newsletterData = await getModuleData("newsletter")
    if (!newsletterData) {
      return NextResponse.json({ success: false, message: "Newsletter module is not enabled" }, { status: 404 })
    }

    // Get the provider
    const provider = await newsletterData.getProvider()
    if (!provider) {
      return NextResponse.json({ success: false, message: "Newsletter provider is not configured" }, { status: 500 })
    }

    // Check if the provider supports campaigns
    if (!provider.createCampaign || !provider.sendCampaign) {
      return NextResponse.json(
        { success: false, message: "This provider does not support campaign management" },
        { status: 400 },
      )
    }

    // Parse and validate the request body
    let body
    try {
      body = await request.json()
    } catch (error) {
      return NextResponse.json({ success: false, message: "Invalid request body" }, { status: 400 })
    }

    const validation = campaignSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: "Invalid campaign data", errors: validation.error.flatten() },
        { status: 400 },
      )
    }

    const { name, subject, fromName, fromEmail, content, listId } = validation.data

    // Rate limit campaign creation - no more than 5 campaigns per hour
    const rateLimiter = require("@/lib/rate-limiter")
    const campaignLimiter = new rateLimiter.RateLimiter({
      windowMs: 60 * 60 * 1000, // 1 hour
      max: 5, // limit each IP to 5 campaigns per hour
    })

    const ip = request.headers.get("x-forwarded-for") || "unknown"
    const rateLimitResult = await campaignLimiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { success: false, message: "Rate limit exceeded. Please try again later." },
        { status: 429, headers: { "Retry-After": Math.ceil((rateLimitResult.reset - Date.now()) / 1000).toString() } },
      )
    }

    try {
      // Create the campaign
      const campaign = await provider.createCampaign({
        name,
        subject,
        fromName,
        fromEmail,
        content,
        listIds: [listId],
      })

      // Send the campaign
      const sendResult = await provider.sendCampaign(campaign.id)

      if (!sendResult.success) {
        return NextResponse.json(
          { success: false, message: sendResult.message || "Failed to send campaign" },
          { status: 500 },
        )
      }

      logger.info("Campaign created and sent successfully", { campaignId: campaign.id })
      return NextResponse.json({
        success: true,
        message: "Campaign created and sent successfully",
        campaignId: campaign.id,
      })
    } catch (error: any) {
      logger.error("Failed to create or send campaign", { error })
      return NextResponse.json(
        {
          success: false,
          message: error.message || "An error occurred while creating or sending the campaign",
        },
        { status: 500 },
      )
    }
  } catch (error: any) {
    logger.error("Failed to create or send newsletter campaign", { error })
    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while creating or sending the campaign",
      },
      { status: 500 },
    )
  }
}

import { NextResponse } from "next/server"
import { logger } from "@/lib/logger"
import fs from "fs"
import path from "path"
import { z } from "zod"
import { csrf } from "@/lib/csrf"

// Define validation schema
const configSchema = z.object({
  provider: z.string(),
  providerConfig: z.record(z.string().optional()).optional(),
  title: z.string().max(100),
  description: z.string().max(500),
  buttonText: z.string().max(50),
  successMessage: z.string().max(200),
  errorMessage: z.string().max(200),
  showPrivacyPolicy: z.boolean(),
  privacyPolicyText: z.string().max(500),
  collectName: z.boolean(),
  nameLabel: z.string().max(50),
  emailLabel: z.string().max(50),
})

export async function POST(request: Request) {
  try {
    // Verify CSRF token
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      return NextResponse.json({ success: false, message: "Invalid request token" }, { status: 403 })
    }

    // In a real application, this would have authentication checks
    // to ensure only admins can update configuration

    // Parse the request body
    let body
    try {
      body = await request.json()
    } catch (error) {
      return NextResponse.json({ success: false, message: "Invalid JSON body" }, { status: 400 })
    }

    // Validate the request body
    const validation = configSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: "Invalid configuration data", errors: validation.error.flatten() },
        { status: 400 },
      )
    }

    const { provider, providerConfig, ...formData } = validation.data

    // Create the environment variables content
    let envContent = `# Newsletter Module Configuration
MODULE_NEWSLETTER=true
MODULE_NEWSLETTER_PROVIDER=${provider}
MODULE_NEWSLETTER_TITLE=${formData.title}
MODULE_NEWSLETTER_DESCRIPTION=${formData.description}
MODULE_NEWSLETTER_BUTTON_TEXT=${formData.buttonText}
MODULE_NEWSLETTER_SUCCESS_MESSAGE=${formData.successMessage}
MODULE_NEWSLETTER_ERROR_MESSAGE=${formData.errorMessage}
MODULE_NEWSLETTER_SHOW_PRIVACY_POLICY=${formData.showPrivacyPolicy}
MODULE_NEWSLETTER_PRIVACY_POLICY_TEXT=${formData.privacyPolicyText}
MODULE_NEWSLETTER_COLLECT_NAME=${formData.collectName}
MODULE_NEWSLETTER_NAME_LABEL=${formData.nameLabel}
MODULE_NEWSLETTER_EMAIL_LABEL=${formData.emailLabel}
`

    // Add provider-specific configuration
    if (provider === "mailchimp" && providerConfig) {
      envContent += `
# Mailchimp Configuration
MODULE_NEWSLETTER_MAILCHIMP_API_KEY=${providerConfig.MAILCHIMP_API_KEY || ""}
MODULE_NEWSLETTER_MAILCHIMP_LIST_ID=${providerConfig.MAILCHIMP_LIST_ID || ""}
`
    } else if (provider === "brevo" && providerConfig) {
      envContent += `
# Brevo Configuration
MODULE_NEWSLETTER_BREVO_API_KEY=${providerConfig.BREVO_API_KEY || ""}
MODULE_NEWSLETTER_BREVO_LIST_ID=${providerConfig.BREVO_LIST_ID || ""}
`
    } else if (provider === "convertkit" && providerConfig) {
      envContent += `
# ConvertKit Configuration
MODULE_NEWSLETTER_CONVERTKIT_API_KEY=${providerConfig.CONVERTKIT_API_KEY || ""}
MODULE_NEWSLETTER_CONVERTKIT_API_SECRET=${providerConfig.CONVERTKIT_API_SECRET || ""}
MODULE_NEWSLETTER_CONVERTKIT_FORM_ID=${providerConfig.CONVERTKIT_FORM_ID || ""}
`
    }

    // Write the environment file
    // In a production environment, this would likely update a database or environment service
    // rather than writing directly to a file
    try {
      const envFilePath = path.join(process.cwd(), "modules", "newsletter", ".env")
      fs.writeFileSync(envFilePath, envContent, { encoding: "utf8", mode: 0o600 }) // Secure file permissions
    } catch (error) {
      logger.error("Failed to write environment file", { error })
      return NextResponse.json({ success: false, message: "Failed to update configuration" }, { status: 500 })
    }

    logger.info("Newsletter configuration updated")
    return NextResponse.json({ success: true })
  } catch (error) {
    logger.error("Failed to update newsletter configuration", { error })
    return NextResponse.json({ success: false, message: "Failed to update configuration" }, { status: 500 })
  }
}

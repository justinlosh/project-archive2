import { NextResponse } from "next/server"
import { getModuleData } from "@/lib/module-system"
import { logger } from "@/lib/logger"
import { csrf } from "@/lib/csrf"

export async function GET(request: Request) {
  try {
    // Verify CSRF token and authentication
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      return NextResponse.json({ success: false, message: "Invalid request token" }, { status: 403 })
    }

    // Here you would implement authentication check for admin access
    // For example:
    // if (!isAdmin(request)) {
    //   return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 401 })
    // }

    // Check if the newsletter module is enabled
    const newsletterData = await getModuleData("newsletter")
    if (!newsletterData) {
      return NextResponse.json({ success: false, message: "Newsletter module is not enabled" }, { status: 404 })
    }

    // Get the provider
    const provider = await newsletterData.getProvider()
    if (!provider) {
      return NextResponse.json({ success: false, message: "Newsletter provider is not configured" }, { status: 500 })
    }

    // Get subscribers with timeout handling
    try {
      const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error("Request timeout")), 15000))
      const subscribersPromise = provider.getSubscribers()
      const subscribers = await Promise.race([subscribersPromise, timeoutPromise])

      return NextResponse.json({
        success: true,
        subscribers,
      })
    } catch (error) {
      logger.error("Failed to fetch subscribers", { error })
      return NextResponse.json(
        { success: false, message: "Failed to fetch subscribers. Please try again." },
        { status: 500 },
      )
    }
  } catch (error) {
    logger.error("Failed to fetch newsletter subscribers", { error })
    return NextResponse.json(
      { success: false, message: "An error occurred while fetching subscribers" },
      { status: 500 },
    )
  }
}

import { NextResponse } from "next/server"
import { getModuleData } from "@/lib/module-system"
import { logger } from "@/lib/logger"
import { csrf } from "@/lib/csrf"
import { z } from "zod"

// Define validation schema
const unsubscribeSchema = z.object({
  email: z.string().email("Invalid email address"),
})

export async function POST(request: Request) {
  try {
    // Verify CSRF token
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      return NextResponse.json({ success: false, message: "Invalid request" }, { status: 403 })
    }

    // Check if the newsletter module is enabled
    const newsletterData = await getModuleData("newsletter")
    if (!newsletterData) {
      return NextResponse.json({ success: false, message: "Newsletter module is not enabled" }, { status: 404 })
    }

    // Get the provider
    const provider = await newsletterData.getProvider()
    if (!provider) {
      return NextResponse.json({ success: false, message: "Newsletter provider is not configured" }, { status: 500 })
    }

    // Parse and validate the request body
    let body
    try {
      body = await request.json()
    } catch (error) {
      return NextResponse.json({ success: false, message: "Invalid request body" }, { status: 400 })
    }

    const validation = unsubscribeSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: "Email is invalid", errors: validation.error.flatten() },
        { status: 400 },
      )
    }

    const { email } = validation.data

    // Unsubscribe the user
    const result = await provider.unsubscribe(email)
    logger.info("User unsubscribed", { email, success: result.success })

    return NextResponse.json(result)
  } catch (error) {
    logger.error("Newsletter unsubscription failed", { error })
    return NextResponse.json(
      { success: false, message: "An error occurred while processing your request" },
      { status: 500 },
    )
  }
}

import { NextResponse } from "next/server"
import { getModuleData } from "@/lib/module-system"
import { logger } from "@/lib/logger"
import { csrf } from "@/lib/csrf"
import { validateEmail } from "@/lib/security"
import { RateLimiter } from "@/lib/rate-limiter"
import { z } from "zod"

// Define validation schema
const subscribeSchema = z.object({
  email: z.string().email("Invalid email address"),
  metadata: z.record(z.string().or(z.number()).or(z.boolean())).optional(),
})

// Create rate limiter (10 requests per hour per IP)
const limiter = new RateLimiter({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 10,
  message: "Too many subscription attempts, please try again later.",
})

export async function POST(request: Request) {
  try {
    // Verify CSRF token
    const csrfError = await csrf.verify(request)
    if (csrfError) {
      logger.warn("CSRF validation failed", { error: csrfError })
      return NextResponse.json({ success: false, message: "Invalid request token" }, { status: 403 })
    }

    // Check if the newsletter module is enabled
    const newsletterData = await getModuleData("newsletter")
    if (!newsletterData) {
      return NextResponse.json({ success: false, message: "Newsletter module is not enabled" }, { status: 404 })
    }

    // Get the provider
    const provider = await newsletterData.getProvider()
    if (!provider) {
      return NextResponse.json({ success: false, message: "Newsletter provider is not configured" }, { status: 500 })
    }

    // Check rate limit
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0] || "unknown"
    const rateLimitResult = await limiter.check(ip)

    if (!rateLimitResult.success) {
      return NextResponse.json(
        { success: false, message: "Too many subscription attempts, please try again later." },
        {
          status: 429,
          headers: {
            "Retry-After": Math.ceil((rateLimitResult.reset - Date.now()) / 1000).toString(),
          },
        },
      )
    }

    // Parse the request body
    let body
    try {
      body = await request.json()
    } catch (error) {
      return NextResponse.json({ success: false, message: "Invalid request body" }, { status: 400 })
    }

    // Validate with zod schema
    const validation = subscribeSchema.safeParse(body)
    if (!validation.success) {
      return NextResponse.json(
        { success: false, message: "Invalid input data", errors: validation.error.flatten() },
        { status: 400 },
      )
    }

    const { email, metadata } = validation.data

    // Use enhanced email validation
    if (!validateEmail(email)) {
      return NextResponse.json({ success: false, message: "Invalid email format" }, { status: 400 })
    }

    // Subscribe the user
    try {
      const result = await provider.subscribe(email, metadata || {})

      if (result.success) {
        logger.info("User subscribed to newsletter", { email })
      } else {
        logger.warn("Newsletter subscription failed", { email, message: result.message })
      }

      return NextResponse.json(result)
    } catch (error) {
      logger.error("Provider subscription error", { error, email })
      return NextResponse.json(
        { success: false, message: "Error connecting to newsletter service. Please try again later." },
        { status: 500 },
      )
    }
  } catch (error) {
    logger.error("Newsletter subscription failed", { error })
    return NextResponse.json(
      { success: false, message: "An error occurred while processing your request" },
      { status: 500 },
    )
  }
}

import { getModuleStatus, getModuleConfig } from "@/lib/module-system"
import { NextResponse } from "next/server"

export async function GET() {
  // Check if robots.txt module is enabled
  const isRobotsTxtEnabled = getModuleStatus("robots-txt")
  if (!isRobotsTxtEnabled) {
    // Return a default robots.txt if the module is disabled
    return new NextResponse("User-agent: *\nAllow: /", {
      headers: {
        "Content-Type": "text/plain",
      },
    })
  }

  // Get robots.txt configuration
  const config = getModuleConfig("robots-txt")
  const allowAll = config.ALLOW_ALL === "true"
  const disallowAll = config.DISALLOW_ALL === "true"
  const sitemapUrl = config.SITEMAP_URL || ""
  const crawlDelay = config.CRAWL_DELAY || ""
  const hostUrl = config.HOST_URL || ""

  // Parse custom rules if provided
  let customRules: Array<{ userAgent: string; allow: string[]; disallow: string[] }> = []
  try {
    if (config.CUSTOM_RULES) {
      customRules = JSON.parse(config.CUSTOM_RULES)
    }
  } catch (error) {
    console.error("Error parsing custom rules:", error)
  }

  // Generate robots.txt content
  let content = ""

  // Check if sitemap module is enabled
  const isSitemapEnabled = getModuleStatus("sitemap")
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.com"

  // Handle disallow all case
  if (disallowAll) {
    content += "User-agent: *\nDisallow: /\n"
  }
  // Handle allow all case
  else if (allowAll && customRules.length === 0) {
    content += "User-agent: *\nAllow: /\n"
  }
  // Handle custom rules
  else if (customRules.length > 0) {
    customRules.forEach((rule) => {
      content += `User-agent: ${rule.userAgent}\n`

      if (rule.allow && rule.allow.length > 0) {
        rule.allow.forEach((path) => {
          content += `Allow: ${path}\n`
        })
      }

      if (rule.disallow && rule.disallow.length > 0) {
        rule.disallow.forEach((path) => {
          content += `Disallow: ${path}\n`
        })
      }

      content += "\n"
    })
  }
  // Default case
  else {
    content += "User-agent: *\nAllow: /\n"
  }

  // Add crawl delay if specified
  if (crawlDelay) {
    content += `Crawl-delay: ${crawlDelay}\n`
  }

  // Add host if specified
  if (hostUrl) {
    content += `Host: ${hostUrl}\n`
  }

  // Add sitemap if available
  if (sitemapUrl) {
    content += `Sitemap: ${sitemapUrl}\n`
  } else if (isSitemapEnabled) {
    content += `Sitemap: ${siteUrl}/sitemap.xml\n`
  }

  // Return the robots.txt content
  return new NextResponse(content, {
    headers: {
      "Content-Type": "text/plain",
    },
  })
}

import { getModuleStatus, getModuleData, getModuleConfig } from "@/lib/module-loader"
import type { MetadataRoute } from "next"

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // Check if sitemap module is enabled
  const isSitemapEnabled = getModuleStatus("sitemap")
  if (!isSitemapEnabled) {
    // Return a minimal sitemap if the module is disabled
    return [
      {
        url: process.env.NEXT_PUBLIC_SITE_URL || "https://example.com",
        lastModified: new Date(),
      },
    ]
  }

  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://example.com"
  const sitemapData = await getModuleData("sitemap")
  const sitemapConfig = getModuleConfig("sitemap")

  // Get default configuration
  const defaultChangeFrequency = (sitemapConfig.DEFAULT_CHANGE_FREQUENCY || "weekly") as
    | "always"
    | "hourly"
    | "daily"
    | "weekly"
    | "monthly"
    | "yearly"
    | "never"
  const defaultPriority = Number.parseFloat(sitemapConfig.DEFAULT_PRIORITY || "0.7")
  const includeLasMod = sitemapConfig.INCLUDE_LASTMOD !== "false"

  // Base pages that always exist
  const routes = [
    {
      url: `${baseUrl}`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "weekly" as const,
      priority: 1,
    },
    {
      url: `${baseUrl}/about`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    },
    {
      url: `${baseUrl}/privacy`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "yearly" as const,
      priority: 0.5,
    },
    {
      url: `${baseUrl}/terms`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "yearly" as const,
      priority: 0.5,
    },
  ]

  // Add changelog page if changelog module is enabled
  const isChangelogEnabled = getModuleStatus("changelog")
  if (isChangelogEnabled) {
    routes.push({
      url: `${baseUrl}/changelog`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "weekly" as const,
      priority: 0.7,
    })
  }

  // Add colophon page if colophon module is enabled
  const isColophonEnabled = getModuleStatus("colophon")
  if (isColophonEnabled) {
    routes.push({
      url: `${baseUrl}/colophon`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "monthly" as const,
      priority: 0.6,
    })
  }

  // Add blog pages if blog module is enabled
  const isBlogEnabled = getModuleStatus("blog")
  if (isBlogEnabled) {
    routes.push({
      url: `${baseUrl}/blog`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "weekly" as const,
      priority: 0.9,
    })

    // Add individual blog posts
    const blogData = await getModuleData("blog")
    if (blogData?.posts) {
      const blogPosts = blogData.posts.map((post: any) => ({
        url: `${baseUrl}/blog/${post.slug}`,
        lastModified: includeLasMod ? new Date(post.date) : undefined,
        changeFrequency: "monthly" as const,
        priority: 0.7,
      }))

      routes.push(...blogPosts)
    }
  }

  // Add contact page if contact module is enabled
  const isContactEnabled = getModuleStatus("contact")
  if (isContactEnabled) {
    routes.push({
      url: `${baseUrl}/contact`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "monthly" as const,
      priority: 0.8,
    })
  }

  // Add docs pages if docs are enabled
  const showDocs = process.env.NEXT_PUBLIC_SHOW_DOCS !== "false"
  if (showDocs) {
    routes.push({
      url: `${baseUrl}/docs`,
      lastModified: includeLasMod ? new Date() : undefined,
      changeFrequency: "weekly" as const,
      priority: 0.8,
    })

    // Add more docs pages here if needed
  }

  // Add additional URLs from the sitemap data
  if (sitemapData?.additionalUrls && Array.isArray(sitemapData.additionalUrls)) {
    const additionalUrls = sitemapData.additionalUrls.map((url: any) => ({
      url: url.url,
      lastModified: includeLasMod ? (url.lastModified ? new Date(url.lastModified) : new Date()) : undefined,
      changeFrequency: (url.changeFrequency || defaultChangeFrequency) as
        | "always"
        | "hourly"
        | "daily"
        | "weekly"
        | "monthly"
        | "yearly"
        | "never",
      priority: url.priority || defaultPriority,
    }))

    routes.push(...additionalUrls)
  }

  // Filter out excluded URLs
  const excludedUrls = sitemapData?.excludedUrls || []
  const filteredRoutes = routes.filter((route) => !excludedUrls.includes(route.url))

  return filteredRoutes
}

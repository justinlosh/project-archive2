import { ModuleRoute, getModuleData } from "@/lib/module-loader"
import { PageHeader } from "@/components/page-header"
import ColophonModule from "@/modules/colophon/component"
import { getModuleConfig } from "@/lib/module-loader"

export const metadata = {
  title: "Colophon | Modular Website",
  description: "Technical details about this website",
}

export default async function ColophonPage() {
  const colophonData = await getModuleData("colophon")
  const colophonConfig = getModuleConfig("colophon")

  return (
    <ModuleRoute moduleName="colophon">
      <div className="container py-12">
        <div className="max-w-4xl mx-auto">
          <PageHeader title="Colophon" description="Technical details about this website" />
          <ColophonModule config={colophonConfig} data={colophonData} />
        </div>
      </div>
    </ModuleRoute>
  )
}

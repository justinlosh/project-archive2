import { ModuleRoute } from "@/lib/module-loader"
import { ModuleLoader } from "@/lib/module-loader"
import { getModuleConfig } from "@/lib/module-system"

export const metadata = {
  title: "Site Under Maintenance",
  description: "We're currently performing scheduled maintenance. Please check back soon.",
}

export default function MaintenancePage() {
  // Get maintenance mode configuration
  const config = getModuleConfig("maintenance-mode")

  // Update metadata based on configuration
  metadata.title = config.TITLE || "Site Under Maintenance"
  metadata.description = config.MESSAGE || "We're currently performing scheduled maintenance. Please check back soon."

  return (
    <ModuleRoute moduleName="maintenance-mode">
      <ModuleLoader moduleName="maintenance-mode" />
    </ModuleRoute>
  )
}

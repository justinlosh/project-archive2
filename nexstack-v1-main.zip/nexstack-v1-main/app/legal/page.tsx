import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/page-header"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { FileText, Shield } from "lucide-react"

export const metadata = {
  title: "Legal Information | Modular Website",
  description: "Legal information, privacy policy, terms of use, and other legal documents.",
}

export default function LegalPage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <PageHeader
          title="Legal Information"
          description="Important legal documents and information about our website and services"
        />

        <div className="grid gap-6 mt-8">
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-primary" />
                <CardTitle>Terms of Use</CardTitle>
              </div>
              <CardDescription>
                Our terms of use outline the rules and guidelines for using our website and services.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                These terms establish the rights and responsibilities of all users accessing or using this website. By
                using our website, you agree to comply with and be bound by these terms.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline">
                <Link href="/legal/terms">Read Terms of Use</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <CardTitle>Privacy Policy</CardTitle>
              </div>
              <CardDescription>
                Our privacy policy explains how we collect, use, and protect your information.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                This policy outlines what personal data we collect, how we use it, and the steps we take to ensure your
                information is handled securely.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline">
                <Link href="/legal/privacy">Read Privacy Policy</Link>
              </Button>
            </CardFooter>
          </Card>

          {/* If the security.txt module is enabled, we can add a link to it here */}
          <Card>
            <CardHeader>
              <div className="flex items-center gap-2">
                <Shield className="h-5 w-5 text-primary" />
                <CardTitle>Security</CardTitle>
              </div>
              <CardDescription>Information for security researchers and our security policies.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We take security seriously. If you've discovered a security vulnerability, please refer to our
                security.txt file for information on how to report it.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline">
                <Link href="/.well-known/security.txt">View Security Information</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/page-header"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export const metadata = {
  title: "Terms of Use | Modular Website",
  description: "Our terms of use outline the rules and guidelines for using our website and services.",
}

export default function TermsOfUsePage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <Button asChild variant="ghost" size="sm" className="mb-8">
          <Link href="/legal" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Legal Information
          </Link>
        </Button>

        <PageHeader title="Terms of Use" description="Last updated: May 4, 2024" />

        <div className="prose dark:prose-invert max-w-none">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Agreement to Terms</CardTitle>
              <CardDescription>Acceptance of these terms</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                These Terms of Use constitute a legally binding agreement made between you and our company, concerning
                your access to and use of our website. By accessing or using the website, you agree to be bound by these
                Terms of Use. If you disagree with any part of these terms, you may not access the website.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Intellectual Property Rights</CardTitle>
              <CardDescription>Ownership of content</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                Unless otherwise indicated, the website and all its content, features, and functionality (including but
                not limited to all information, software, text, displays, images, video, and audio) are owned by us, our
                licensors, or other providers of such material.
              </p>
              <p className="mb-4">
                The website is protected by copyright, trademark, and other intellectual property laws. Our trademarks
                and trade dress may not be used in connection with any product or service without our prior written
                consent.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>User Representations</CardTitle>
              <CardDescription>Your responsibilities</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">By using the website, you represent and warrant that:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>You have the legal capacity to accept these Terms of Use</li>
                <li>You are not a minor in the jurisdiction in which you reside</li>
                <li>You will not access the website through automated or non-human means</li>
                <li>You will not use the website for any illegal or unauthorized purpose</li>
                <li>Your use of the website will not violate any applicable law or regulation</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Prohibited Activities</CardTitle>
              <CardDescription>What you cannot do</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                You may not access or use the website for any purpose other than that for which we make it available.
                The website may not be used in connection with any commercial endeavors except those that are
                specifically endorsed or approved by us.
              </p>
              <p className="mb-4">As a user of the website, you agree not to:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>
                  Systematically retrieve data or other content from the website to create a collection, compilation,
                  database, or directory
                </li>
                <li>
                  Make any unauthorized use of the website, including collecting usernames and/or email addresses of
                  users by electronic or other means
                </li>
                <li>Use the website in a manner inconsistent with any applicable laws or regulations</li>
                <li>Engage in unauthorized framing of or linking to the website</li>
                <li>
                  Upload or transmit viruses, Trojan horses, or other material that interferes with any party's use of
                  the website
                </li>
                <li>
                  Attempt to gain unauthorized access to, interfere with, damage, or disrupt any parts of the website
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>User-Generated Content</CardTitle>
              <CardDescription>Content you submit</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                The website may invite you to chat, contribute to, or participate in blogs, message boards, online
                forums, and other functionality, and may provide you with the opportunity to create, submit, post,
                display, transmit, perform, publish, distribute, or broadcast content and materials to us or on the
                website.
              </p>
              <p className="mb-4">
                Any content you post to the website will be considered non-confidential and non-proprietary. By posting
                any content on the website, you grant us the right and license to use, modify, publicly perform,
                publicly display, reproduce, and distribute such content on and through the website.
              </p>
              <p className="mb-4">
                You represent and warrant that you own or control all rights in and to the content you post, and that
                such content does not violate these Terms of Use.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Limitation of Liability</CardTitle>
              <CardDescription>Our responsibility</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                In no event will we, our affiliates, or their licensors, service providers, employees, agents, officers,
                or directors be liable for damages of any kind, under any legal theory, arising out of or in connection
                with your use, or inability to use, the website, any websites linked to it, any content on the website
                or such other websites.
              </p>
              <p className="mb-4">
                This includes any direct, indirect, special, incidental, consequential, or punitive damages, including
                but not limited to, personal injury, pain and suffering, emotional distress, loss of revenue, loss of
                profits, loss of business or anticipated savings, loss of use, loss of goodwill, loss of data, and
                whether caused by tort (including negligence), breach of contract, or otherwise, even if foreseeable.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Changes to Terms</CardTitle>
              <CardDescription>Updates to this agreement</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                We may revise and update these Terms of Use from time to time in our sole discretion. All changes are
                effective immediately when we post them.
              </p>
              <p className="mb-4">
                Your continued use of the website following the posting of revised Terms of Use means that you accept
                and agree to the changes. You are expected to check this page frequently so you are aware of any
                changes, as they are binding on you.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

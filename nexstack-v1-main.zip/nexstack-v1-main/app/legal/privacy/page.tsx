import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { PageHeader } from "@/components/page-header"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"

export const metadata = {
  title: "Privacy Policy | Modular Website",
  description: "Our privacy policy explains how we collect, use, and protect your information.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="container py-12">
      <div className="max-w-3xl mx-auto">
        <Button asChild variant="ghost" size="sm" className="mb-8">
          <Link href="/legal" className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Legal Information
          </Link>
        </Button>

        <PageHeader title="Privacy Policy" description="Last updated: May 4, 2024" />

        <div className="prose dark:prose-invert max-w-none">
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Introduction</CardTitle>
              <CardDescription>What this policy covers</CardDescription>
            </CardHeader>
            <CardContent>
              <p>
                This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you
                visit our website. Please read this privacy policy carefully. If you do not agree with the terms of this
                privacy policy, please do not access the site.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Information We Collect</CardTitle>
              <CardDescription>Types of data we gather</CardDescription>
            </CardHeader>
            <CardContent>
              <h3 className="text-lg font-medium mb-2">Personal Data</h3>
              <p className="mb-4">
                When you visit our website, we may collect personal information that you voluntarily provide to us, such
                as your name, email address, and any other information you choose to provide when you:
              </p>
              <ul className="list-disc pl-6 mb-4">
                <li>Fill out a form on our website</li>
                <li>Subscribe to our newsletter</li>
                <li>Request information or assistance</li>
                <li>Participate in a survey</li>
              </ul>

              <h3 className="text-lg font-medium mb-2 mt-6">Usage Data</h3>
              <p className="mb-4">
                We may also collect information about how you access and use our website, including:
              </p>
              <ul className="list-disc pl-6 mb-4">
                <li>Your IP address</li>
                <li>Browser type and version</li>
                <li>Pages you visit</li>
                <li>Time and date of your visit</li>
                <li>Time spent on pages</li>
                <li>Other diagnostic data</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>How We Use Your Information</CardTitle>
              <CardDescription>Purposes for collecting your data</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">We may use the information we collect for various purposes, including:</p>
              <ul className="list-disc pl-6 mb-4">
                <li>Providing and maintaining our website</li>
                <li>Improving our website and services</li>
                <li>Analyzing how you use our website</li>
                <li>Developing new products and services</li>
                <li>Communicating with you about updates or changes</li>
                <li>Providing customer support</li>
                <li>Monitoring the usage of our website</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Cookies and Tracking Technologies</CardTitle>
              <CardDescription>How we use cookies</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                We use cookies and similar tracking technologies to track activity on our website and store certain
                information. Cookies are files with a small amount of data which may include an anonymous unique
                identifier.
              </p>
              <p className="mb-4">
                You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However,
                if you do not accept cookies, you may not be able to use some portions of our website.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Data Security</CardTitle>
              <CardDescription>How we protect your information</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                The security of your data is important to us, but remember that no method of transmission over the
                Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable
                means to protect your personal information, we cannot guarantee its absolute security.
              </p>
            </CardContent>
          </Card>

          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Changes to This Privacy Policy</CardTitle>
              <CardDescription>How we'll notify you about updates</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new
                Privacy Policy on this page and updating the "Last updated" date at the top of this page.
              </p>
              <p className="mb-4">
                You are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy
                Policy are effective when they are posted on this page.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Contact Us</CardTitle>
              <CardDescription>How to reach us with questions</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-4">If you have any questions about this Privacy Policy, please contact us:</p>
              <ul className="list-disc pl-6">
                <li>By email: privacy@example.com</li>
                <li>By visiting the contact page on our website</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

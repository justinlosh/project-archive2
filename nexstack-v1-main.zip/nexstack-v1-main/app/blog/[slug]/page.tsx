import { ModuleRoute } from "@/lib/module-loader"
import { getModuleData } from "@/lib/module-loader"
import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import { PageHeader } from "@/components/page-header"

interface BlogPostPageProps {
  params: {
    slug: string
  }
}

export async function generateMetadata({ params }: BlogPostPageProps) {
  const blogData = await getModuleData("blog")
  const post = blogData?.posts?.find((p: any) => p.slug === params.slug)

  if (!post) {
    return {
      title: "Post Not Found",
      description: "The requested blog post could not be found.",
    }
  }

  return {
    title: `${post.title} | Blog`,
    description: post.excerpt,
  }
}

export default async function BlogPostPage({ params }: BlogPostPageProps) {
  const blogData = await getModuleData("blog")
  const post = blogData?.posts?.find((p: any) => p.slug === params.slug)

  if (!post) {
    notFound()
  }

  return (
    <ModuleRoute moduleName="blog">
      <div className="container py-12">
        <div className="max-w-3xl mx-auto">
          <Button asChild variant="ghost" size="sm" className="mb-8">
            <Link href="/blog" className="flex items-center gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Blog
            </Link>
          </Button>

          <article>
            <PageHeader title={post.title} description={`Published on ${new Date(post.date).toLocaleDateString()}`} />

            <div className="prose dark:prose-invert max-w-none">
              <p className="lead text-xl mb-6">{post.excerpt}</p>

              <p>
                This is a sample blog post content. In a real application, this would be the full content of the blog
                post, potentially stored in a database or a CMS and retrieved based on the slug.
              </p>

              <p>
                The modular architecture of this website allows you to easily integrate with various content sources,
                such as a headless CMS, Markdown files, or a database.
              </p>

              <h2>Key Features</h2>

              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl
                nisl aliquam nisl, eu aliquam nisl nisl eu nisl. Sed euismod, nisl vel ultricies lacinia, nisl nisl
                aliquam nisl, eu aliquam nisl nisl eu nisl.
              </p>

              <h2>Getting Started</h2>

              <p>
                Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                pariatur.
              </p>

              <h2>Conclusion</h2>

              <p>
                Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est
                laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque
                laudantium.
              </p>
            </div>
          </article>
        </div>
      </div>
    </ModuleRoute>
  )
}

import { ModuleRoute } from "@/lib/module-loader"
import { getModuleData, getModuleConfig } from "@/lib/module-loader"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import { PageHeader } from "@/components/page-header"

export const metadata = {
  title: "Blog | Modular Website",
  description: "Read our latest articles, tutorials, and updates.",
}

export default async function BlogPage() {
  const config = getModuleConfig("blog")
  const title = config.TITLE || "Blog"
  const description = config.DESCRIPTION || "Latest articles and updates from our team"

  return (
    <ModuleRoute moduleName="blog">
      <div className="container py-12">
        <div className="max-w-3xl mx-auto mb-12">
          <PageHeader title={title} description={description} />
        </div>

        <BlogPosts />
      </div>
    </ModuleRoute>
  )
}

async function BlogPosts() {
  const blogData = await getModuleData("blog")
  const config = getModuleConfig("blog")
  const showAuthor = config.SHOW_AUTHOR === "true"
  const showDate = config.SHOW_DATE === "true"

  if (!blogData || !blogData.posts) {
    return <p>No blog posts found.</p>
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
      {blogData.posts.map((post: any) => (
        <Card key={post.id} className="flex flex-col h-full">
          <CardHeader>
            <CardTitle className="line-clamp-2">{post.title}</CardTitle>
            {showDate && <CardDescription>Published on {new Date(post.date).toLocaleDateString()}</CardDescription>}
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="line-clamp-3">{post.excerpt}</p>
            {showAuthor && <p className="mt-4 text-sm text-muted-foreground">By Author</p>}
          </CardContent>
          <CardFooter>
            <Button asChild variant="ghost" size="sm" className="gap-1">
              <Link href={`/blog/${post.slug}`}>
                Read More
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

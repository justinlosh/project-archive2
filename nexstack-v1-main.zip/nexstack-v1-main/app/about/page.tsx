import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { PageHeader } from "@/components/page-header"

export const metadata = {
  title: "About Us | Modular Website",
  description: "Learn more about our company, mission, and team.",
}

export default function AboutPage() {
  return (
    <div className="container py-12">
      {/* Hero Section */}
      <div className="max-w-3xl mx-auto mb-16">
        <PageHeader
          title="About Us"
          description="We're building the future of modular web development with customizable, feature-rich solutions."
        />
      </div>

      {/* Our Story */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-20">
        <div>
          <h2 className="text-3xl font-bold tracking-tight mb-4">Our Story</h2>
          <p className="text-muted-foreground mb-4">
            Founded in 2023, our company began with a simple mission: to make web development more efficient and
            modular. We recognized that many websites share common features, yet developers often rebuild these
            components from scratch.
          </p>
          <p className="text-muted-foreground mb-4">
            Our team of experienced developers and designers came together to create a modular website platform that
            allows for rapid development without sacrificing quality or customization options.
          </p>
          <p className="text-muted-foreground">
            Today, we're proud to offer a solution that helps businesses and developers launch feature-rich websites in
            a fraction of the time it would traditionally take.
          </p>
        </div>
        <div className="relative h-[300px] md:h-[400px] rounded-lg overflow-hidden">
          <Image src="/placeholder.svg?key=smiwy" alt="Our team collaborating" fill className="object-cover" />
        </div>
      </div>

      {/* Our Mission */}
      <Card className="mb-20 bg-muted/50">
        <CardContent className="p-8 md:p-12">
          <div className="text-center max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold tracking-tight mb-6">Our Mission</h2>
            <p className="text-xl mb-0">
              "To empower developers and businesses with modular, customizable web solutions that reduce development
              time while maintaining the highest standards of quality, performance, and user experience."
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Our Values */}
      <div className="mb-20">
        <h2 className="text-3xl font-bold tracking-tight mb-8 text-center">Our Values</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-6">
            <h3 className="text-xl font-semibold mb-4">Innovation</h3>
            <p className="text-muted-foreground">
              We constantly explore new technologies and approaches to improve our platform and stay ahead of industry
              trends.
            </p>
          </div>
          <div className="text-center p-6">
            <h3 className="text-xl font-semibold mb-4">Quality</h3>
            <p className="text-muted-foreground">
              We're committed to delivering high-quality, well-tested code that performs reliably in any environment.
            </p>
          </div>
          <div className="text-center p-6">
            <h3 className="text-xl font-semibold mb-4">Flexibility</h3>
            <p className="text-muted-foreground">
              We believe in creating solutions that adapt to your needs, not forcing you to adapt to our tools.
            </p>
          </div>
        </div>
      </div>

      {/* Our Team */}
      <div>
        <h2 className="text-3xl font-bold tracking-tight mb-8 text-center">Our Team</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {[
            {
              name: "Alex Johnson",
              role: "Founder & CEO",
              image: "/professional-business-headshot.png",
            },
            {
              name: "Sam Taylor",
              role: "Lead Developer",
              image: "/placeholder.svg?key=v1b9x",
            },
            {
              name: "Jamie Smith",
              role: "UX Designer",
              image: "/designer-headshot.png",
            },
            {
              name: "Morgan Lee",
              role: "Marketing Director",
              image: "/placeholder.svg?key=1b97g",
            },
          ].map((member, index) => (
            <div key={index} className="text-center">
              <div className="relative h-[200px] w-[200px] mx-auto rounded-full overflow-hidden mb-4">
                <Image src={member.image || "/placeholder.svg"} alt={member.name} fill className="object-cover" />
              </div>
              <h3 className="text-xl font-semibold mb-1">{member.name}</h3>
              <p className="text-muted-foreground">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

# Modular Next.js Project

A modular Next.js website project optimized for v0 and Vercel deployment, with environment variable-based feature toggling, dynamic theming, and comprehensive documentation.

## Features

- **Feature Toggling**: Enable or disable features using environment variables
- **Dynamic Theming**: Customize colors, fonts, and other theme settings through environment variables
- **Modular Architecture**: Build self-contained modules with their own components, data, and configuration
- **Latest Technologies**: Next.js App Router, Tailwind CSS, and Shadcn UI
- **Comprehensive Documentation**: Detailed documentation for all aspects of the project
- **Optimized for v0 and Vercel**: Ready to use with v0 and deploy to Vercel
- **Secure Admin Interface**: Multi-layered security for administrative routes
- **SEO Optimization**: Built-in SEO features and structured data support
- **Analytics Integration**: Configurable analytics with privacy controls

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Create a `.env` file based on `.env.example`
4. Copy module-specific `.env` files from each module directory
5. Run the development server: `npm run dev`
6. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

\`\`\`
├── app/                    # Next.js App Router
│   ��── admin/              # Admin routes (protected)
│   ├── api/                # API routes
│   ├── blog/               # Blog module routes
│   ├── contact/            # Contact module routes
│   ├── docs/               # Documentation routes
│   └── ...                 # Other app routes
├── components/             # Shared components
├── lib/                    # Utility functions and shared logic
├── modules/                # Self-contained feature modules
│   ├── analytics/          # Analytics module
│   ├── blog/               # Blog module
│   ├── changelog/          # Changelog module
│   ├── contact/            # Contact module
│   ├── maintenance/        # Maintenance mode module
│   ├── newsletter/         # Newsletter module
│   ├── robots/             # Robots.txt module
│   ├── security/           # Security.txt module
│   ├── seo/                # SEO module
│   ├── sitemap/            # Sitemap module
│   └── admin-security/     # Admin security module
├── public/                 # Static assets
├── styles/                 # Global styles
├── middleware.ts           # Next.js middleware (includes security)
└── ...                     # Configuration files
\`\`\`

## Feature Toggling

Control which features are enabled or disabled using environment variables:

\`\`\`
# Core features
NEXT_PUBLIC_ENABLE_BLOG=true
NEXT_PUBLIC_ENABLE_NEWSLETTER=true
NEXT_PUBLIC_ENABLE_CONTACT=true
NEXT_PUBLIC_ENABLE_DOCS=true

# Additional modules
NEXT_PUBLIC_ENABLE_CHANGELOG=true
NEXT_PUBLIC_ENABLE_SITEMAP=true
NEXT_PUBLIC_ENABLE_SECURITY_TXT=true
NEXT_PUBLIC_ENABLE_ANALYTICS=true
NEXT_PUBLIC_ENABLE_MAINTENANCE_MODE=false
NEXT_PUBLIC_ENABLE_ROBOTS_TXT=true

# Development features
NEXT_PUBLIC_ENABLE_DEVELOPMENT_PAGE=true
\`\`\`

## Dynamic Theming

Customize the look and feel of your application using environment variables:

\`\`\`
# Site information
NEXT_PUBLIC_SITE_TITLE=Modular Next.js
NEXT_PUBLIC_SITE_DESCRIPTION=A modular Next.js website project
NEXT_PUBLIC_SITE_URL=https://example.com
NEXT_PUBLIC_SITE_LANGUAGE=en
NEXT_PUBLIC_GITHUB_URL=https://github.com/username/modular-nextjs
NEXT_PUBLIC_COPYRIGHT_TEXT=© 2023 Your Company

# Theme settings
NEXT_PUBLIC_DEFAULT_THEME=light
NEXT_PUBLIC_PRIMARY_COLOR=#0070f3
NEXT_PUBLIC_SECONDARY_COLOR=#6c757d
NEXT_PUBLIC_ACCENT_COLOR=#f97316
NEXT_PUBLIC_LIGHT_BACKGROUND=#ffffff
NEXT_PUBLIC_LIGHT_TEXT=#000000
NEXT_PUBLIC_DARK_BACKGROUND=#121212
NEXT_PUBLIC_DARK_TEXT=#ffffff

# Fonts
NEXT_PUBLIC_FONT_FAMILY=Inter, sans-serif
NEXT_PUBLIC_HEADING_FONT_FAMILY=Inter, sans-serif

# UI settings
NEXT_PUBLIC_BORDER_RADIUS=0.5rem
\`\`\`

## Modules

### Blog Module

A full-featured blog system with categories, tags, and search functionality.

**Features:**
- Markdown/MDX content support
- Category and tag filtering
- Search functionality
- Featured posts
- Related posts

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_BLOG=true
NEXT_PUBLIC_BLOG_POSTS_PER_PAGE=10
NEXT_PUBLIC_BLOG_SHOW_AUTHOR=true
NEXT_PUBLIC_BLOG_SHOW_DATE=true
\`\`\`

**Usage:**
- Add blog posts in the `modules/blog/content` directory
- Access the blog at `/blog`
- Manage blog settings in the admin interface at `/admin/blog`

### Newsletter Module

Collect and manage newsletter subscriptions with various provider integrations.

**Features:**
- Multiple provider integrations (Mailchimp, ConvertKit, custom API)
- Subscription form with validation
- Double opt-in support
- Subscription management

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_NEWSLETTER=true
NEWSLETTER_PROVIDER=mailchimp
NEWSLETTER_API_KEY=your-api-key
NEWSLETTER_LIST_ID=your-list-id
\`\`\`

**Usage:**
- Add the newsletter component to any page
- Access subscription management at `/newsletter/manage`
- View subscribers in the admin interface at `/admin/newsletter`

### Contact Module

A configurable contact form with spam protection and email notifications.

**Features:**
- Form validation
- CSRF protection
- reCAPTCHA integration
- Email notifications
- Custom form fields

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_CONTACT=true
CONTACT_EMAIL=contact@example.com
CONTACT_FORM_SUBJECTS=General Inquiry,Support,Feedback
RECAPTCHA_SITE_KEY=your-site-key
RECAPTCHA_SECRET_KEY=your-secret-key
\`\`\`

**Usage:**
- Access the contact form at `/contact`
- Configure form fields and validation in `modules/contact/data.ts`
- View submissions in the admin interface at `/admin/contact`

### SEO Module

Comprehensive SEO tools including meta tags, structured data, and social media previews.

**Features:**
- Dynamic meta tags
- Open Graph and Twitter Card support
- JSON-LD structured data
- Canonical URLs
- Sitemap integration

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_SEO=true
NEXT_PUBLIC_DEFAULT_OG_IMAGE=/images/og-image.jpg
NEXT_PUBLIC_TWITTER_HANDLE=@yourusername
\`\`\`

**Usage:**
- Configure default SEO settings in `modules/seo/data.ts`
- Override page-specific SEO in page metadata
- Monitor SEO performance in the admin interface at `/admin/seo`

### Changelog Module

Track and display project changes with versioned changelog entries.

**Features:**
- Versioned changelog entries
- Categorized changes (Added, Changed, Fixed, Removed)
- RSS feed for changes
- Automatic version detection from Git

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_CHANGELOG=true
NEXT_PUBLIC_CHANGELOG_SHOW_DATE=true
\`\`\`

**Usage:**
- Add changelog entries in `modules/changelog/content`
- Access the changelog at `/changelog`
- Manage entries in the admin interface at `/admin/changelog`

### Sitemap Module

Automatically generate XML sitemaps for better search engine indexing.

**Features:**
- Dynamic sitemap generation
- Support for multiple sitemaps
- Customizable change frequency and priority
- Automatic lastmod dates

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_SITEMAP=true
SITEMAP_INCLUDE_IMAGES=true
\`\`\`

**Usage:**
- Access the sitemap at `/sitemap.xml`
- Configure sitemap settings in `modules/sitemap/data.ts`
- View sitemap status in the admin interface at `/admin/sitemap`

### Security.txt Module

Implement the security.txt standard for security vulnerability reporting.

**Features:**
- Compliant with RFC 9116
- Customizable security policy information
- PGP key support
- Automatic expiration date handling

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_SECURITY_TXT=true
SECURITY_CONTACT=security@example.com
SECURITY_EXPIRES_DAYS=365
\`\`\`

**Usage:**
- Access the security.txt file at `/.well-known/security.txt`
- Configure security information in `modules/security/data.ts`
- Update security contacts in the admin interface at `/admin/security`

### Analytics Module

Privacy-focused analytics with support for multiple providers.

**Features:**
- Multiple provider support (Google Analytics, Plausible, Fathom, custom)
- Do Not Track (DNT) respect
- GDPR compliance helpers
- Consent management
- Custom event tracking

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_ANALYTICS=true
MODULE_ANALYTICS_PROVIDER=google
MODULE_ANALYTICS_TRACKING_ID=G-XXXXXXXXXX
MODULE_ANALYTICS_RESPECT_DO_NOT_TRACK=true
MODULE_ANALYTICS_DEBUG_MODE=false
\`\`\`

**Usage:**
- Analytics are automatically included when enabled
- Track custom events using the analytics API
- View analytics data in the admin interface at `/admin/analytics`

### Maintenance Mode Module

Easily enable maintenance mode for your site during updates.

**Features:**
- Customizable maintenance page
- IP allowlist for bypassing maintenance mode
- Scheduled maintenance windows
- API endpoints remain accessible

**Configuration:**
\`\`\`
MAINTENANCE_MODE=false
MAINTENANCE_ALLOWED_IPS=127.0.0.1,::1
MAINTENANCE_END_TIME=2023-12-31T23:59:59Z
\`\`\`

**Usage:**
- Toggle maintenance mode in the admin interface at `/admin/maintenance`
- Customize the maintenance page in `modules/maintenance/component.tsx`
- Schedule maintenance windows in the admin interface

### Robots.txt Module

Generate and manage robots.txt files for search engine crawling control.

**Features:**
- Dynamic robots.txt generation
- Environment-specific configurations
- Sitemap reference
- User-agent specific rules

**Configuration:**
\`\`\`
NEXT_PUBLIC_ENABLE_ROBOTS_TXT=true
ROBOTS_ALLOW_INDEXING=true
\`\`\`

**Usage:**
- Access the robots.txt file at `/robots.txt`
- Configure crawling rules in `modules/robots/data.ts`
- Manage indexing settings in the admin interface at `/admin/robots`

## Admin Security

The project includes a comprehensive security system for protecting administrative routes (`/admin/*`). This system implements multiple layers of protection:

### Password Protection

Basic authentication requiring a username and password.

**Configuration:**
\`\`\`
ADMIN_SECURITY_ENABLED=true
ADMIN_PASSWORD_PROTECTION_ENABLED=true
ADMIN_USERNAME=admin
ADMIN_PASSWORD_HASH=your-generated-hash
ADMIN_PASSWORD_SALT=your-generated-salt
\`\`\`

**Usage:**
- Generate secure credentials using the provided script: `npm run generate-admin-credentials`
- Store the generated hash and salt in your environment variables
- Access admin routes with the configured credentials

### IP Address Restriction

Limit access to specific IP addresses.

**Configuration:**
\`\`\`
ADMIN_IP_RESTRICTION_ENABLED=true
ADMIN_ALLOWED_IPS=127.0.0.1,::1,office-ip-address
ADMIN_ALLOW_LOCALHOST=true
\`\`\`

**Usage:**
- Configure allowed IP addresses in your environment variables
- Update IP addresses in the admin security settings
- Special handling is provided for localhost development

### Environment-Based Restriction

Restrict admin access based on the deployment environment.

**Configuration:**
\`\`\`
ADMIN_ENVIRONMENT_RESTRICTION_ENABLED=true
ADMIN_ALLOWED_ENVIRONMENTS=development,preview
\`\`\`

**Usage:**
- Configure allowed environments in your environment variables
- This prevents access to admin routes in production by default
- Override settings in the admin security interface

### Vercel Edge Config Integration

Use Vercel's Edge Config for dynamic access control without redeployment.

**Configuration:**
\`\`\`
EDGE_CONFIG_ID=your-edge-config-id
\`\`\`

**Usage:**
- Set up a Vercel Edge Config store
- Configure the Edge Config ID in your environment variables
- Manage access control settings dynamically through the Vercel dashboard

## Documentation

Comprehensive documentation is available in the `/docs` directory and on the live site at `/docs`. The documentation covers:

- Getting started guide
- Module documentation
- Configuration options
- Development guidelines
- API reference
- Security considerations
- Deployment instructions

## Development

Run the development server:

\`\`\`
npm run dev
\`\`\`

Visit the development page at [http://localhost:3000/development](http://localhost:3000/development) for more information on how to develop and extend the project.

### Creating New Modules

1. Create a new directory in the `modules` directory
2. Add the required files:
   - `component.tsx`: Main component
   - `data.ts`: Module data and configuration
   - `admin.tsx`: Admin interface component
   - `.env`: Module-specific environment variables
   - `README.md`: Module documentation
3. Register the module in `lib/modules.ts`
4. Add environment variables to `.env.example`
5. Add routes in the `app` directory if needed

## Deployment

Deploy to Vercel:

1. Push your code to a Git repository
2. Import your repository to Vercel
3. Set up your environment variables
4. Deploy your application

### Environment Variables

Make sure to set up all required environment variables in your Vercel project settings. You can use the `.env.example` file as a reference.

### Production Considerations

- Set `ADMIN_ENVIRONMENT_RESTRICTION_ENABLED=true` to restrict admin access in production
- Configure proper security settings for production environments
- Enable maintenance mode during major updates
- Set up proper analytics and monitoring

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a new branch: `git checkout -b feature/your-feature-name`
3. Make your changes
4. Run tests: `npm test`
5. Submit a pull request

## License

MIT

// Mock Next.js navigation functions
jest.mock("next/navigation", () => ({
  notFound: jest.fn(),
}))

// Set up environment variables for testing
process.env.MODULE_BLOG = "true"
process.env.MODULE_NEWSLETTER = "true"
process.env.MODULE_CONTACT = "false"
process.env.MODULE_SEO = "true"

// Mock console.error to avoid cluttering test output
console.error = jest.fn()

"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2, Info } from "lucide-react"

// Import directly from module-system
import type { ModuleMetadata } from "@/lib/module-system"

interface ModuleManagerProps {
  modules: (ModuleMetadata & { name: string })[]
}

export function ModuleManager({ modules }: ModuleManagerProps) {
  const [enabledModules, setEnabledModules] = useState<Record<string, boolean>>({})
  const [saving, setSaving] = useState(false)
  const [saveStatus, setSaveStatus] = useState<"idle" | "success" | "error">("idle")
  const [validationErrors, setValidationErrors] = useState<string[]>([])

  // Initialize state from environment variables on mount only
  useEffect(() => {
    setEnabledModules(
      modules.reduce(
        (acc, module) => {
          const isEnabled = process.env[`MODULE_${module.name.toUpperCase()}`] === "true"
          acc[module.name] = isEnabled
          return acc
        },
        {} as Record<string, boolean>,
      ),
    )
  }, [modules])

  // Toggle module enabled state
  const toggleModule = (moduleName: string) => {
    setEnabledModules((prev) => {
      const newState = { ...prev, [moduleName]: !prev[moduleName] }
      validateModuleConfiguration(newState)
      return newState
    })
  }

  // Validate module configuration
  const validateModuleConfiguration = (state: Record<string, boolean>) => {
    const errors: string[] = []

    // Check for missing dependencies
    for (const module of modules) {
      if (state[module.name]) {
        for (const dependency of module.dependencies) {
          if (!state[dependency]) {
            errors.push(`Module '${module.name}' requires '${dependency}' which is not enabled.`)
          }
        }
      }
    }

    setValidationErrors(errors)
    return errors.length === 0
  }

  // Save module configuration
  const saveConfiguration = async () => {
    if (!validateModuleConfiguration(enabledModules)) {
      return
    }

    setSaving(true)
    setSaveStatus("idle")

    try {
      // In a real application, this would save to the server
      // For now, we'll just simulate a save with a more realistic approach
      const response = await fetch("/api/modules/config", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(enabledModules),
      })

      if (!response.ok) {
        throw new Error("Failed to save configuration")
      }

      // Update local storage for demo purposes
      localStorage.setItem("moduleConfiguration", JSON.stringify(enabledModules))

      setSaveStatus("success")
    } catch (error) {
      console.error("Error saving module configuration:", error)
      setSaveStatus("error")
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="space-y-6">
      {validationErrors.length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Validation Errors</AlertTitle>
          <AlertDescription>
            <ul className="list-disc pl-5 mt-2">
              {validationErrors.map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      {saveStatus === "success" && (
        <Alert variant="default" className="bg-green-50 border-green-200 text-green-800">
          <CheckCircle2 className="h-4 w-4 text-green-600" />
          <AlertTitle>Success</AlertTitle>
          <AlertDescription>
            Module configuration saved successfully. Changes will take effect on the next build.
          </AlertDescription>
        </Alert>
      )}

      {saveStatus === "error" && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Error</AlertTitle>
          <AlertDescription>Failed to save module configuration. Please try again.</AlertDescription>
        </Alert>
      )}

      <Alert>
        <Info className="h-4 w-4" />
        <AlertTitle>Information</AlertTitle>
        <AlertDescription>
          Enabling or disabling modules requires a rebuild of the application. Changes made here will be applied during
          the next build process.
        </AlertDescription>
      </Alert>

      <div className="grid gap-4">
        {modules.map((module) => (
          <Card key={module.name}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    {module.name}
                    {!module.optional && (
                      <Badge variant="secondary" className="ml-2">
                        Required
                      </Badge>
                    )}
                  </CardTitle>
                  <CardDescription>{module.description}</CardDescription>
                </div>
                <Switch
                  checked={!!enabledModules[module.name]}
                  onCheckedChange={() => toggleModule(module.name)}
                  disabled={!module.optional} // Can't disable required modules
                  aria-label={`Toggle ${module.name} module`}
                />
              </div>
            </CardHeader>
            <CardContent>
              {module.dependencies.length > 0 && (
                <div className="text-sm">
                  <span className="font-medium">Dependencies:</span>{" "}
                  {module.dependencies.map((dep, index) => (
                    <span key={dep}>
                      <Badge variant={enabledModules[dep] ? "default" : "destructive"} className="mr-1">
                        {dep}
                      </Badge>
                      {index < module.dependencies.length - 1 ? " " : ""}
                    </span>
                  ))}
                </div>
              )}

              {module.routes.length > 0 && (
                <div className="text-sm mt-2">
                  <span className="font-medium">Routes:</span> {module.routes.join(", ")}
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="flex justify-end">
        <Button onClick={saveConfiguration} disabled={saving || validationErrors.length > 0}>
          {saving ? "Saving..." : "Save Configuration"}
        </Button>
      </div>
    </div>
  )
}

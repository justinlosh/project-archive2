import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { Button } from "@/components/ui/button"
import { getModuleStatus } from "@/lib/module-loader"
import { Menu } from "lucide-react"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { config } from "@/lib/config"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"

// Define navigation items with module dependencies
interface NavItem {
  href: string
  label: string
  moduleDependency?: string
  alwaysShow?: boolean
  children?: NavItem[]
}

// Navigation items configuration
const navItems: NavItem[] = [
  { href: "/", label: "Home", alwaysShow: true },
  {
    href: "#",
    label: "Features",
    alwaysShow: true,
    children: [
      { href: "/blog", label: "Blog", moduleDependency: "blog" },
      { href: "/contact", label: "Contact", moduleDependency: "contact" },
      { href: "/changelog", label: "Changelog", moduleDependency: "changelog" },
      { href: "/colophon", label: "Colophon", moduleDependency: "colophon" },
    ],
  },
  { href: "/docs", label: "Documentation" },
  { href: "/about", label: "About", alwaysShow: true },
  {
    href: "#",
    label: "Resources",
    alwaysShow: true,
    children: [
      { href: "/legal", label: "Legal", alwaysShow: true },
      { href: "/admin", label: "Admin", alwaysShow: true },
    ],
  },
]

export default function Header() {
  const { title: siteTitle } = config.site
  const showDocs = process.env.NEXT_PUBLIC_SHOW_DOCS !== "false"

  // Filter navigation items based on module status
  const filteredNavItems = navItems
    .filter((item) => {
      // Always show items marked as alwaysShow
      if (item.alwaysShow) return true

      // Show docs only if enabled
      if (item.href === "/docs" && !showDocs) return false

      // Check module dependency
      if (item.moduleDependency) {
        return getModuleStatus(item.moduleDependency)
      }

      // Default to showing the item
      return true
    })
    .map((item) => {
      // Filter children if present
      if (item.children) {
        return {
          ...item,
          children: item.children.filter((child) => {
            if (child.alwaysShow) return true
            if (child.moduleDependency) {
              return getModuleStatus(child.moduleDependency)
            }
            return true
          }),
        }
      }
      return item
    })

  return (
    <header className="sticky top-0 z-40 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon" className="mr-2" aria-label="Open menu">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <SheetHeader className="mb-4">
                <SheetTitle>Navigation</SheetTitle>
                <SheetDescription>Explore the features of this modular website</SheetDescription>
              </SheetHeader>
              <nav className="flex flex-col gap-4">
                {filteredNavItems.map((item) =>
                  item.children ? (
                    <div key={item.label} className="space-y-2">
                      <div className="font-medium">{item.label}</div>
                      <div className="pl-4 flex flex-col gap-2">
                        {item.children.map((child) => (
                          <Link
                            key={child.href}
                            href={child.href}
                            className="text-sm transition-colors hover:text-primary"
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <Link
                      key={item.href}
                      href={item.href}
                      className="text-sm font-medium transition-colors hover:text-primary"
                    >
                      {item.label}
                    </Link>
                  ),
                )}
              </nav>
            </SheetContent>
          </Sheet>
          <Link href="/" className="flex items-center space-x-2">
            <span className="font-bold inline-block text-xl">{siteTitle}</span>
          </Link>
        </div>

        <div className="flex items-center gap-6">
          <nav className="hidden md:flex gap-6">
            {filteredNavItems.map((item) =>
              item.children ? (
                <DropdownMenu key={item.label}>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="flex items-center gap-1 h-auto py-1.5 px-2">
                      {item.label}
                      <ChevronDown className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuLabel>{item.label}</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {item.children.map((child) => (
                      <DropdownMenuItem key={child.href} asChild>
                        <Link href={child.href}>{child.label}</Link>
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  key={item.href}
                  href={item.href}
                  className="text-sm font-medium transition-colors hover:text-primary"
                >
                  {item.label}
                </Link>
              ),
            )}
          </nav>

          <div className="flex items-center gap-2">
            <ThemeToggle />
          </div>
        </div>
      </div>
    </header>
  )
}

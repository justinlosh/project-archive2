import Link from "next/link"
import { getModuleStatus } from "@/lib/module-loader"
import { ModuleLoader } from "@/lib/module-loader"
import { config } from "@/lib/config"

// Define footer links with module dependencies
interface FooterLink {
  href: string
  label: string
  moduleDependency?: string
  alwaysShow?: boolean
}

// Footer links configuration
const footerLinks = [
  {
    title: "Pages",
    links: [
      { href: "/", label: "Home", alwaysShow: true },
      { href: "/about", label: "About", alwaysShow: true },
      { href: "/blog", label: "Blog", moduleDependency: "blog" },
      { href: "/contact", label: "Contact", moduleDependency: "contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { href: "/docs", label: "Documentation" },
      { href: "/changelog", label: "Changelog", moduleDependency: "changelog" },
      { href: "/colophon", label: "Colophon", moduleDependency: "colophon" },
      { href: "/sitemap.xml", label: "Sitemap", moduleDependency: "sitemap" },
    ],
  },
  {
    title: "Legal",
    links: [
      { href: "/legal", label: "Legal Information", alwaysShow: true },
      { href: "/legal/privacy", label: "Privacy Policy", alwaysShow: true },
      { href: "/legal/terms", label: "Terms of Service", alwaysShow: true },
    ],
  },
  {
    title: "Admin",
    links: [
      { href: "/admin", label: "Admin Dashboard", alwaysShow: true },
      { href: "/admin/modules", label: "Module Manager", alwaysShow: true },
      { href: "/admin/analytics", label: "Analytics", moduleDependency: "analytics" },
    ],
  },
]

export default function Footer() {
  const { copyrightText } = config.site
  const showDocs = process.env.NEXT_PUBLIC_SHOW_DOCS !== "false"
  const isSocialMediaEnabled = getModuleStatus("social-media")

  // Filter footer links based on module status
  const filteredFooterSections = footerLinks
    .map((section) => {
      return {
        title: section.title,
        links: section.links.filter((link) => {
          // Always show links marked as alwaysShow
          if (link.alwaysShow) return true

          // Show docs only if enabled
          if (link.href === "/docs" && !showDocs) return false

          // Check module dependency
          if (link.moduleDependency) {
            return getModuleStatus(link.moduleDependency)
          }

          // Default to showing the link
          return true
        }),
      }
    })
    .filter((section) => section.links.length > 0)

  return (
    <footer className="border-t py-12 bg-muted/30">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {filteredFooterSections.map((section, index) => (
            <div key={index} className="space-y-3">
              <h4 className="text-sm font-medium">{section.title}</h4>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {isSocialMediaEnabled && (
          <div className="flex justify-center mb-8 border-t border-b py-6 my-6">
            <ModuleLoader moduleName="social-media" />
          </div>
        )}

        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-muted-foreground">
          <p>{copyrightText}</p>
          <p>Built with Next.js and Modular Architecture</p>
        </div>
      </div>
    </footer>
  )
}

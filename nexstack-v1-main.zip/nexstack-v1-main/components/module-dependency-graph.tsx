"use client"

import { useEffect, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import type { ModuleMetadata } from "@/lib/module-system"

interface ModuleDependencyGraphProps {
  modules: (ModuleMetadata & { name: string })[]
  enabledModules: string[]
}

export function ModuleDependencyGraph({ modules, enabledModules }: ModuleDependencyGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Set canvas size
    canvas.width = canvas.offsetWidth
    canvas.height = 500

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw module nodes and connections
    drawModuleGraph(ctx, canvas.width, canvas.height, modules, enabledModules)
  }, [modules, enabledModules])

  // Function to draw the module dependency graph
  const drawModuleGraph = (
    ctx: CanvasRenderingContext2D,
    width: number,
    height: number,
    modules: (ModuleMetadata & { name: string })[],
    enabledModules: string[],
  ) => {
    const nodeRadius = 30
    const nodeSpacing = width / (modules.length + 1)

    // Calculate node positions
    const nodes = modules.map((module, index) => {
      return {
        x: nodeSpacing * (index + 1),
        y: height / 2,
        module,
        isEnabled: enabledModules.includes(module.name),
      }
    })

    // Draw connections first (so they appear behind nodes)
    ctx.lineWidth = 2

    for (const node of nodes) {
      const { module } = node

      for (const dependency of module.dependencies) {
        const dependencyNode = nodes.find((n) => n.module.name === dependency)
        if (dependencyNode) {
          // Draw connection
          ctx.beginPath()
          ctx.moveTo(node.x, node.y)
          ctx.lineTo(dependencyNode.x, dependencyNode.y)

          // Style based on enabled status
          if (node.isEnabled && dependencyNode.isEnabled) {
            ctx.strokeStyle = "#22c55e" // Green for enabled connections
          } else {
            ctx.strokeStyle = "#ef4444" // Red for disabled connections
          }

          ctx.stroke()

          // Draw arrow
          const angle = Math.atan2(dependencyNode.y - node.y, dependencyNode.x - node.x)
          const arrowSize = 10

          ctx.beginPath()
          ctx.moveTo(dependencyNode.x - Math.cos(angle) * nodeRadius, dependencyNode.y - Math.sin(angle) * nodeRadius)
          ctx.lineTo(
            dependencyNode.x - Math.cos(angle) * nodeRadius - Math.cos(angle - Math.PI / 6) * arrowSize,
            dependencyNode.y - Math.sin(angle) * nodeRadius - Math.sin(angle - Math.PI / 6) * arrowSize,
          )
          ctx.lineTo(
            dependencyNode.x - Math.cos(angle) * nodeRadius - Math.cos(angle + Math.PI / 6) * arrowSize,
            dependencyNode.y - Math.sin(angle) * nodeRadius - Math.sin(angle + Math.PI / 6) * arrowSize,
          )
          ctx.closePath()
          ctx.fillStyle = ctx.strokeStyle
          ctx.fill()
        }
      }
    }

    // Draw nodes
    for (const node of nodes) {
      // Draw circle
      ctx.beginPath()
      ctx.arc(node.x, node.y, nodeRadius, 0, Math.PI * 2)

      // Style based on enabled status
      if (node.isEnabled) {
        ctx.fillStyle = "#3b82f6" // Blue for enabled modules
      } else {
        ctx.fillStyle = "#9ca3af" // Gray for disabled modules
      }

      ctx.fill()

      // Draw border
      ctx.strokeStyle = "#ffffff"
      ctx.lineWidth = 2
      ctx.stroke()

      // Draw module name
      ctx.fillStyle = "#ffffff"
      ctx.font = "12px sans-serif"
      ctx.textAlign = "center"
      ctx.textBaseline = "middle"
      ctx.fillText(node.module.name, node.x, node.y)

      // Draw label below
      ctx.fillStyle = "#000000"
      ctx.font = "14px sans-serif"
      ctx.fillText(node.module.name, node.x, node.y + nodeRadius + 20)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Module Dependency Graph</CardTitle>
        <CardDescription>
          Visual representation of module dependencies. Blue nodes are enabled modules, gray nodes are disabled.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <canvas ref={canvasRef} className="w-full border rounded-md" style={{ height: "500px" }} />
      </CardContent>
    </Card>
  )
}

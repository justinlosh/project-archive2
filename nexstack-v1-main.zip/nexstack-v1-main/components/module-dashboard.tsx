import type React from "react"
import Link from "next/link"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ArrowRight, CheckCircle2, ExternalLink } from "lucide-react"
import { getModuleStatus } from "@/lib/module-system"

interface ModuleDashboardProps {
  showAllModules?: boolean
}

interface ModuleInfo {
  id: string
  name: string
  description: string
  icon: React.ReactNode
  path: string
  adminPath?: string
  enabled: boolean
  highlight?: boolean
}

export function ModuleDashboard({ showAllModules = false }: ModuleDashboardProps) {
  // Define all available modules
  const modules: ModuleInfo[] = [
    {
      id: "blog",
      name: "Blog",
      description: "Publish and manage blog posts with categories and tags",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-newspaper"
        >
          <path d="M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-2 2Zm0 0a2 2 0 0 1-2-2v-9c0-1.1.9-2 2-2h2" />
          <path d="M18 14h-8" />
          <path d="M15 18h-5" />
          <path d="M10 6h8v4h-8V6Z" />
        </svg>
      ),
      path: "/blog",
      adminPath: "/admin/blog",
      enabled: getModuleStatus("blog"),
      highlight: true,
    },
    {
      id: "newsletter",
      name: "Newsletter",
      description: "Collect email subscribers and send newsletters",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-mail-plus"
        >
          <path d="M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8" />
          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
          <path d="M19 16v6" />
          <path d="M16 19h6" />
        </svg>
      ),
      path: "/newsletter",
      adminPath: "/admin/newsletter",
      enabled: getModuleStatus("newsletter"),
    },
    {
      id: "contact",
      name: "Contact",
      description: "Contact form with email notifications and spam protection",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-mail"
        >
          <rect width="20" height="16" x="2" y="4" rx="2" />
          <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
        </svg>
      ),
      path: "/contact",
      adminPath: "/admin/contact",
      enabled: getModuleStatus("contact"),
    },
    {
      id: "seo",
      name: "SEO",
      description: "Search engine optimization with meta tags and structured data",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-search"
        >
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.3-4.3" />
        </svg>
      ),
      path: "/docs/modules/seo",
      enabled: getModuleStatus("seo"),
    },
    {
      id: "analytics",
      name: "Analytics",
      description: "Track website traffic and user behavior",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-bar-chart"
        >
          <line x1="12" x2="12" y1="20" y2="10" />
          <line x1="18" x2="18" y1="20" y2="4" />
          <line x1="6" x2="6" y1="20" y2="16" />
        </svg>
      ),
      path: "/admin/analytics",
      enabled: getModuleStatus("analytics"),
    },
    {
      id: "changelog",
      name: "Changelog",
      description: "Display product updates and version history",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-history"
        >
          <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
          <path d="M3 3v5h5" />
          <path d="M12 7v5l4 2" />
        </svg>
      ),
      path: "/changelog",
      enabled: getModuleStatus("changelog"),
    },
    {
      id: "colophon",
      name: "Colophon",
      description: "Technical details about the website",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-info"
        >
          <circle cx="12" cy="12" r="10" />
          <path d="M12 16v-4" />
          <path d="M12 8h.01" />
        </svg>
      ),
      path: "/colophon",
      enabled: getModuleStatus("colophon"),
    },
    {
      id: "social-media",
      name: "Social Media",
      description: "Social media links and sharing functionality",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-share-2"
        >
          <circle cx="18" cy="5" r="3" />
          <circle cx="6" cy="12" r="3" />
          <circle cx="18" cy="19" r="3" />
          <line x1="8.59" x2="15.42" y1="13.51" y2="17.49" />
          <line x1="15.41" x2="8.59" y1="6.51" y2="10.49" />
        </svg>
      ),
      path: "/admin/social-media",
      enabled: getModuleStatus("social-media"),
    },
    {
      id: "maintenance-mode",
      name: "Maintenance Mode",
      description: "Display maintenance page when site is under maintenance",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-wrench"
        >
          <path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z" />
        </svg>
      ),
      path: "/maintenance",
      adminPath: "/admin/maintenance",
      enabled: getModuleStatus("maintenance-mode"),
    },
    {
      id: "sitemap",
      name: "Sitemap",
      description: "Generate XML sitemap for search engines",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-network"
        >
          <rect x="16" y="16" width="6" height="6" rx="1" />
          <rect x="2" y="16" width="6" height="6" rx="1" />
          <rect x="9" y="2" width="6" height="6" rx="1" />
          <path d="M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3" />
          <path d="M12 12V8" />
        </svg>
      ),
      path: "/sitemap.xml",
      enabled: getModuleStatus("sitemap"),
    },
    {
      id: "robots-txt",
      name: "Robots.txt",
      description: "Control search engine crawling with robots.txt",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-bot"
        >
          <path d="M12 8V4H8" />
          <rect width="16" height="12" x="4" y="8" rx="2" />
          <path d="M2 14h2" />
          <path d="M20 14h2" />
          <path d="M15 13v2" />
          <path d="M9 13v2" />
        </svg>
      ),
      path: "/robots.txt",
      adminPath: "/admin/robots",
      enabled: getModuleStatus("robots-txt"),
    },
    {
      id: "security-txt",
      name: "Security.txt",
      description: "Security policy and contact information",
      icon: (
        <svg
          xmlns="http://www.w3.org/2000/svg"
          width="24"
          height="24"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="lucide lucide-shield"
        >
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
        </svg>
      ),
      path: "/.well-known/security.txt",
      enabled: getModuleStatus("security-txt"),
    },
  ]

  // Filter modules based on enabled status if not showing all
  const filteredModules = showAllModules ? modules : modules.filter((module) => module.enabled)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredModules.map((module) => (
          <Card
            key={module.id}
            className={`overflow-hidden ${module.highlight ? "border-primary/50 bg-primary/5" : ""} card-hover`}
          >
            <CardHeader className="pb-2">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <div
                    className={`p-1.5 rounded-md ${module.highlight ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}
                  >
                    {module.icon}
                  </div>
                  <CardTitle className="text-xl">{module.name}</CardTitle>
                </div>
                {module.enabled ? (
                  <Badge
                    variant="outline"
                    className="bg-green-50 text-green-700 border-green-200 dark:bg-green-900/20 dark:text-green-400 dark:border-green-800"
                  >
                    <CheckCircle2 className="mr-1 h-3 w-3" /> Enabled
                  </Badge>
                ) : (
                  <Badge
                    variant="outline"
                    className="bg-gray-50 text-gray-500 border-gray-200 dark:bg-gray-900/20 dark:text-gray-400 dark:border-gray-800"
                  >
                    Disabled
                  </Badge>
                )}
              </div>
              <CardDescription>{module.description}</CardDescription>
            </CardHeader>
            <CardFooter className="pt-2">
              <div className="flex flex-wrap gap-2">
                <Button asChild variant="outline" size="sm">
                  <Link href={module.path} className="flex items-center gap-1">
                    View
                    {module.path.startsWith("http") ? (
                      <ExternalLink className="h-3 w-3" />
                    ) : (
                      <ArrowRight className="h-3 w-3" />
                    )}
                  </Link>
                </Button>
                {module.adminPath && (
                  <Button asChild variant="ghost" size="sm">
                    <Link href={module.adminPath}>Admin</Link>
                  </Button>
                )}
              </div>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

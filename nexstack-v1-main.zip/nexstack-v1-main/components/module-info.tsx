import type React from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Settings, FileText } from "lucide-react"

interface ModuleInfoProps {
  name: string
  description: string
  enabled: boolean
  icon: React.ReactNode
  adminPath?: string
  docsPath?: string
  configCount?: number
}

export function ModuleInfo({ name, description, enabled, icon, adminPath, docsPath, configCount }: ModuleInfoProps) {
  return (
    <Card className={`overflow-hidden ${enabled ? "" : "opacity-70"}`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="rounded-md bg-primary/10 p-1 text-primary">{icon}</div>
            <CardTitle className="text-lg">{name}</CardTitle>
          </div>
          <Badge variant={enabled ? "default" : "outline"}>{enabled ? "Enabled" : "Disabled"}</Badge>
        </div>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="pb-2">
        {configCount && (
          <div className="text-xs text-muted-foreground">
            {configCount} configuration {configCount === 1 ? "option" : "options"}
          </div>
        )}
      </CardContent>
      <CardFooter className="flex gap-2 pt-2">
        {adminPath && enabled && (
          <Button asChild variant="outline" size="sm">
            <Link href={adminPath}>
              <Settings className="mr-1 h-3.5 w-3.5" />
              Manage
            </Link>
          </Button>
        )}
        {docsPath && (
          <Button asChild variant="ghost" size="sm">
            <Link href={docsPath}>
              <FileText className="mr-1 h-3.5 w-3.5" />
              Docs
            </Link>
          </Button>
        )}
      </CardFooter>
    </Card>
  )
}

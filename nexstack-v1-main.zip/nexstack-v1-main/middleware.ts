import { type NextRequest, NextResponse } from "next/server"
import { maintenanceMiddleware } from "./modules/maintenance-mode/middleware"
import { RateLimiter } from "./lib/rate-limiter"
import { adminSecurityMiddleware } from "./middleware/admin-security"

// Create a rate limiter instance
const apiLimiter = new RateLimiter({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
})

export async function middleware(request: NextRequest) {
  // Apply admin security middleware for admin routes
  if (request.nextUrl.pathname.startsWith("/admin")) {
    const securityResponse = await adminSecurityMiddleware(request)
    if (securityResponse.status !== 200) {
      return securityResponse
    }
  }

  // Apply rate limiting to API routes
  if (request.nextUrl.pathname.startsWith("/api/")) {
    const ip = request.ip ?? request.headers.get("x-forwarded-for") ?? "127.0.0.1"
    const { success, limit, remaining, reset } = await apiLimiter.check(ip)

    if (!success) {
      return NextResponse.json(
        { error: "Too many requests, please try again later." },
        {
          status: 429,
          headers: {
            "X-RateLimit-Limit": limit.toString(),
            "X-RateLimit-Remaining": remaining.toString(),
            "X-RateLimit-Reset": reset.toString(),
            "Retry-After": Math.ceil((reset - Date.now()) / 1000).toString(),
          },
        },
      )
    }
  }

  // Apply maintenance mode middleware
  const maintenanceResponse = await maintenanceMiddleware(request)
  if (maintenanceResponse !== NextResponse.next()) {
    return maintenanceResponse
  }

  // Continue with other middleware if needed
  return NextResponse.next()
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|favicon.ico).*)"],
}

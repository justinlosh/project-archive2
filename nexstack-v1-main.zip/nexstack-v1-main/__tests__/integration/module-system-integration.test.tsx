import { render, screen } from "@testing-library/react"
import { ModuleLoader, getEnabledModules, clearModuleCaches, moduleSystem } from "@/lib/module-system"
import fs from "fs"

// Mock fs and path modules
jest.mock("fs", () => ({
  existsSync: jest.fn(),
  readdirSync: jest.fn(),
  statSync: jest.fn(() => ({ isDirectory: () => true })),
  readFileSync: jest.fn(),
}))

jest.mock("path", () => ({
  join: jest.fn((_, ...args) => args.join("/")),
}))

// Mock dynamic imports
jest.mock(
  "@/modules/blog/component",
  () => ({
    __esModule: true,
    default: ({ config }: { config: any }) => (
      <div data-testid="blog-module">Blog Module: {JSON.stringify(config)}</div>
    ),
  }),
  { virtual: true },
)

jest.mock(
  "@/modules/newsletter/component",
  () => ({
    __esModule: true,
    default: ({ config }: { config: any }) => (
      <div data-testid="newsletter-module">Newsletter Module: {JSON.stringify(config)}</div>
    ),
  }),
  { virtual: true },
)

describe("Module System Integration", () => {
  beforeEach(() => {
    jest.clearAllMocks()
    clearModuleCaches()

    // Set up environment variables
    process.env.MODULE_BLOG = "true"
    process.env.MODULE_NEWSLETTER = "true"
    process.env.MODULE_CONTACT = "false"

    // Mock file system
    ;(fs.existsSync as jest.Mock).mockImplementation((filePath) => {
      if (filePath === "modules") return true
      if (filePath === "modules/blog/data.ts") return true
      if (filePath === "modules/newsletter/data.ts") return true
      if (filePath === "modules/contact/data.ts") return true
      return false
    })
    ;(fs.readdirSync as jest.Mock).mockReturnValue(["blog", "newsletter", "contact", "module-manager"])
    ;(fs.readFileSync as jest.Mock).mockImplementation((filePath) => {
      if (filePath.includes("blog")) return "BLOG_API_KEY=test"
      if (filePath.includes("newsletter")) return "NEWSLETTER_API_KEY=test"
      return ""
    })
  })

  it("should load enabled modules correctly", async () => {
    // Test the complete flow from module system to module loader
    const enabledModules = getEnabledModules()
    expect(enabledModules).toContain("blog")
    expect(enabledModules).toContain("newsletter")
    expect(enabledModules).not.toContain("contact")

    // Test loading the blog module
    render(await ModuleLoader({ moduleName: "blog" }))
    expect(screen.getByTestId("blog-module")).toBeInTheDocument()

    // Test loading the newsletter module
    render(await ModuleLoader({ moduleName: "newsletter" }))
    expect(screen.getByTestId("newsletter-module")).toBeInTheDocument()

    // Test loading a disabled module
    const fallback = <div data-testid="fallback">Fallback Content</div>
    render(await ModuleLoader({ moduleName: "contact", fallback }))
    expect(screen.getByTestId("fallback")).toBeInTheDocument()
  })

  it("should validate module configuration correctly", () => {
    // Mock module data with dependencies
    ;(moduleSystem.getModuleData as jest.Mock).mockImplementation((name) => {
      if (name === "blog") {
        return { name: "blog", enabled: true, dependencies: ["newsletter"] }
      }
      if (name === "newsletter") {
        return { name: "newsletter", enabled: true }
      }
      if (name === "contact") {
        return { name: "contact", enabled: false, dependencies: ["blog"] }
      }
      return { name, enabled: false }
    })

    const validation = moduleSystem.validateModuleConfiguration()
    expect(validation.valid).toBe(true)
    expect(validation.errors).toEqual([])

    // Now disable newsletter which is a dependency of blog
    process.env.MODULE_NEWSLETTER = "false"
    const invalidValidation = moduleSystem.validateModuleConfiguration()
    expect(invalidValidation.valid).toBe(false)
    expect(invalidValidation.errors).toContain("Module blog depends on newsletter, but newsletter is not enabled")
  })

  it("should generate consolidated environment variables", () => {
    const env = moduleSystem.generateConsolidatedEnv()

    expect(env).toContain("MODULE_BLOG=true")
    expect(env).toContain("MODULE_NEWSLETTER=true")
    expect(env).toContain("MODULE_CONTACT=false")
    expect(env).toContain("# blog module environment variables")
    expect(env).toContain("BLOG_API_KEY=test")
    expect(env).toContain("# newsletter module environment variables")
    expect(env).toContain("NEWSLETTER_API_KEY=test")
  })
})

import type { ReactElement } from "react"
import { render, type RenderOptions } from "@testing-library/react"

// Custom render function for testing
const customRender = (ui: ReactElement, options?: Omit<RenderOptions, "wrapper">) => render(ui, { ...options })

// Mock module data generator
export function createMockModule(
  name: string,
  options: {
    optional?: boolean
    enabled?: boolean
    dependencies?: string[]
    routes?: string[]
  } = {},
) {
  return {
    name,
    title: name.charAt(0).toUpperCase() + name.slice(1),
    description: `${name} module description`,
    optional: options.optional ?? true,
    dependencies: options.dependencies ?? [],
    routes: options.routes ?? [],
    enabled: options.enabled ?? true,
  }
}

// Mock module config generator
export function createMockConfig(moduleName: string) {
  return {
    [`${moduleName.toUpperCase()}_API_KEY`]: "test-api-key",
    [`${moduleName.toUpperCase()}_ENABLED`]: "true",
  }
}

// Re-export everything from testing-library
export * from "@testing-library/react"

// Override render method
export { customRender as render }

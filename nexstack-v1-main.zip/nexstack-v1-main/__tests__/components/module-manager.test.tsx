import { render, screen, fireEvent, waitFor } from "@testing-library/react"
import { ModuleManager } from "../../components/module-manager"

// Mock environment variables
const originalEnv = process.env

describe("ModuleManager", () => {
  beforeEach(() => {
    jest.resetModules()
    process.env = { ...originalEnv }
    process.env.MODULE_BLOG = "true"
    process.env.MODULE_NEWSLETTER = "true"
    process.env.MODULE_CONTACT = "false"

    // Mock localStorage
    Object.defineProperty(window, "localStorage", {
      value: {
        getItem: jest.fn(),
        setItem: jest.fn(),
      },
      writable: true,
    })
  })

  afterEach(() => {
    process.env = originalEnv
  })

  const mockModules = [
    {
      name: "blog",
      title: "Blog",
      description: "Blog module for content management",
      optional: true,
      dependencies: [],
      routes: ["/blog", "/blog/[slug]"],
    },
    {
      name: "newsletter",
      title: "Newsletter",
      description: "Newsletter subscription module",
      optional: true,
      dependencies: [],
      routes: ["/newsletter"],
    },
    {
      name: "contact",
      title: "Contact",
      description: "Contact form module",
      optional: true,
      dependencies: [],
      routes: ["/contact"],
    },
    {
      name: "seo",
      title: "SEO",
      description: "SEO optimization module",
      optional: false,
      dependencies: [],
      routes: [],
    },
    {
      name: "analytics",
      title: "Analytics",
      description: "Analytics tracking module",
      optional: true,
      dependencies: ["seo"],
      routes: [],
    },
  ]

  it("should render all modules", () => {
    render(<ModuleManager modules={mockModules} />)

    expect(screen.getByText("Blog")).toBeInTheDocument()
    expect(screen.getByText("Newsletter")).toBeInTheDocument()
    expect(screen.getByText("Contact")).toBeInTheDocument()
    expect(screen.getByText("SEO")).toBeInTheDocument()
    expect(screen.getByText("Analytics")).toBeInTheDocument()
  })

  it("should initialize with correct enabled states", () => {
    render(<ModuleManager modules={mockModules} />)

    // Check switches
    const switches = screen.getAllByRole("switch")
    expect(switches[0]).toBeChecked() // blog
    expect(switches[1]).toBeChecked() // newsletter
    expect(switches[2]).not.toBeChecked() // contact
    expect(switches[3]).toBeChecked() // seo (required)
  })

  it("should toggle module state when switch is clicked", () => {
    render(<ModuleManager modules={mockModules} />)

    const blogSwitch = screen.getAllByRole("switch")[0]
    fireEvent.click(blogSwitch)

    expect(blogSwitch).not.toBeChecked()
  })

  it("should disable required module switches", () => {
    render(<ModuleManager modules={mockModules} />)

    const seoSwitch = screen.getAllByRole("switch")[3]
    expect(seoSwitch).toBeDisabled()
  })

  it("should show validation errors for missing dependencies", () => {
    render(<ModuleManager modules={mockModules} />)

    // Enable analytics but disable SEO (which is a dependency)
    const analyticsSwitch = screen.getAllByRole("switch")[4]
    fireEvent.click(analyticsSwitch)

    expect(screen.getByText(/Module 'analytics' requires 'seo'/)).toBeInTheDocument()
  })

  it("should save configuration when save button is clicked", async () => {
    render(<ModuleManager modules={mockModules} />)

    const saveButton = screen.getByText("Save Configuration")
    fireEvent.click(saveButton)

    await waitFor(() => {
      expect(screen.getByText("Module configuration saved successfully")).toBeInTheDocument()
      expect(window.localStorage.setItem).toHaveBeenCalled()
    })
  })

  it("should disable save button when there are validation errors", () => {
    render(<ModuleManager modules={mockModules} />)

    // Enable analytics but disable SEO (which is a dependency)
    const analyticsSwitch = screen.getAllByRole("switch")[4]
    fireEvent.click(analyticsSwitch)

    const saveButton = screen.getByText("Save Configuration")
    expect(saveButton).toBeDisabled()
  })
})

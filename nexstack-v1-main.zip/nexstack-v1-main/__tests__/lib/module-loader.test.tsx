import { render, screen } from "@testing-library/react"
import { ModuleRoute, getModuleStatus, getSafeModuleConfig } from "../../lib/module-loader"
import { isModuleEnabled, getModuleConfig } from "../../lib/module-system"
import { notFound } from "next/navigation"
import { sanitizeConfig } from "../../lib/security"
import { ModuleLoader } from "@/lib/module-system"

// Mock dependencies
jest.mock("../../lib/module-system", () => ({
  isModuleEnabled: jest.fn(),
  getModuleConfig: jest.fn(),
}))

jest.mock("../../lib/security", () => ({
  sanitizeConfig: jest.fn((config) => config),
}))

// Mock dynamic imports
jest.mock(
  "@/modules/blog/component",
  () => ({
    __esModule: true,
    default: ({ config }: { config: any }) => (
      <div data-testid="blog-module">Blog Module: {JSON.stringify(config)}</div>
    ),
  }),
  { virtual: true },
)

describe("Module Loader", () => {
  beforeEach(() => {
    jest.clearAllMocks()
    jest.spyOn(console, "error").mockImplementation(() => {})
  })

  describe("getModuleStatus", () => {
    it("should return false for invalid module names", () => {
      const result = getModuleStatus("invalid-module")

      expect(result).toBe(false)
      expect(console.error).toHaveBeenCalledWith("Invalid module name requested: invalid-module")
    })

    it("should return module enabled status for valid modules", () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(true)

      const result = getModuleStatus("blog")

      expect(result).toBe(true)
      expect(isModuleEnabled).toHaveBeenCalledWith("blog")
    })
  })

  describe("getSafeModuleConfig", () => {
    it("should return empty object for invalid module names", () => {
      const result = getSafeModuleConfig("invalid-module")

      expect(result).toEqual({})
      expect(console.error).toHaveBeenCalledWith("Invalid module config requested: invalid-module")
    })

    it("should return sanitized config for valid modules", () => {
      const mockConfig = { key: "value" }
      ;(getModuleConfig as jest.Mock).mockReturnValueOnce(mockConfig)
      ;(sanitizeConfig as jest.Mock).mockReturnValueOnce({ key: "sanitized" })

      const result = getSafeModuleConfig("blog")

      expect(result).toEqual({ key: "sanitized" })
      expect(getModuleConfig).toHaveBeenCalledWith("blog")
      expect(sanitizeConfig).toHaveBeenCalledWith(mockConfig)
    })
  })

  describe("ModuleLoader", () => {
    it("should return fallback for invalid module names", async () => {
      const fallback = <div>Fallback</div>
      const { container } = render(await ModuleLoader({ moduleName: "invalid-module", fallback }))

      expect(container).toContainHTML("<div>Fallback</div>")
      expect(console.error).toHaveBeenCalledWith("Invalid module requested: invalid-module")
    })

    it("should return fallback for disabled modules", async () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(false)
      const fallback = <div>Fallback</div>

      const { container } = render(await ModuleLoader({ moduleName: "blog", fallback }))

      expect(container).toContainHTML("<div>Fallback</div>")
    })

    it("should render the module component for enabled modules", async () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(true)
      ;(getModuleConfig as jest.Mock).mockReturnValueOnce({ test: "config" })
      ;(sanitizeConfig as jest.Mock).mockReturnValueOnce({ test: "sanitized" })

      render(await ModuleLoader({ moduleName: "blog" }))

      expect(screen.getByTestId("blog-module")).toBeInTheDocument()
      expect(screen.getByTestId("blog-module")).toHaveTextContent('Blog Module: {"test":"sanitized"}')
    })

    it("should handle errors when loading modules", async () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(true)
      // Force an error
      jest.mock(
        "@/modules/newsletter/component",
        () => {
          throw new Error("Failed to load module")
        },
        { virtual: true },
      )

      const fallback = <div>Error Fallback</div>
      const { container } = render(await ModuleLoader({ moduleName: "newsletter", fallback }))

      expect(container).toContainHTML("<div>Error Fallback</div>")
      expect(console.error).toHaveBeenCalled()
    })
  })

  describe("ModuleRoute", () => {
    it("should call notFound for invalid module names", () => {
      ;(notFound as jest.Mock).mockImplementation(() => {
        throw new Error("Not found")
      })
      try {
        render(<ModuleRoute moduleName="invalid-module">Content</ModuleRoute>)
      } catch (e: any) {
        expect(e.message).toBe("Not found")
      }

      expect(console.error).toHaveBeenCalledWith("Invalid module route requested: invalid-module")
    })

    it("should call notFound for disabled modules", () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(false)
      ;(notFound as jest.Mock).mockImplementation(() => {
        throw new Error("Not found")
      })
      try {
        render(<ModuleRoute moduleName="blog">Content</ModuleRoute>)
      } catch (e: any) {
        expect(e.message).toBe("Not found")
      }
    })

    it("should render children for enabled modules", () => {
      ;(isModuleEnabled as jest.Mock).mockReturnValueOnce(true)

      const { container } = render(
        <ModuleRoute moduleName="blog">
          <div>Module Content</div>
        </ModuleRoute>,
      )

      expect(container).toContainHTML("<div>Module Content</div>")
      expect(notFound).not.toHaveBeenCalled()
    })
  })
})

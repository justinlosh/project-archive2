import fs from "fs"
import { isModuleEnabled, getAllModuleNames, getEnabledModules, clearModuleCaches } from "@/lib/module-system"

// Mock fs and path modules
jest.mock("fs", () => ({
  existsSync: jest.fn(),
  readdirSync: jest.fn(),
  statSync: jest.fn(() => ({ isDirectory: () => true })),
  readFileSync: jest.fn(),
}))

jest.mock("path", () => ({
  join: jest.fn((_, ...args) => args.join("/")),
}))

describe("Module System", () => {
  beforeEach(() => {
    jest.clearAllMocks()
    // Reset module cache
    clearModuleCaches()
  })

  describe("getAllModuleNames", () => {
    it("should return an empty array if modules directory does not exist", () => {
      ;(fs.existsSync as jest.Mock).mockReturnValueOnce(false)

      const result = getAllModuleNames()

      expect(result).toEqual([])
      expect(fs.existsSync).toHaveBeenCalledWith("modules")
    })

    it("should return all module names except module-manager", () => {
      ;(fs.existsSync as jest.Mock).mockReturnValueOnce(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog", "newsletter", "module-manager", "contact"])

      const result = getAllModuleNames()

      expect(result).toEqual(["blog", "newsletter", "contact"])
      expect(fs.readdirSync).toHaveBeenCalledWith("modules")
    })
  })

  describe("isModuleEnabled", () => {
    it("should return true for module-manager", () => {
      const result = isModuleEnabled("module-manager")

      expect(result).toBe(true)
    })

    it("should return true for enabled modules", () => {
      const result = isModuleEnabled("blog")

      expect(result).toBe(true)
    })

    it("should return false for disabled modules", () => {
      const result = isModuleEnabled("contact")

      expect(result).toBe(false)
    })
  })

  describe("getEnabledModules", () => {
    it("should return all enabled modules", () => {
      ;(fs.existsSync as jest.Mock).mockReturnValueOnce(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog", "newsletter", "contact", "seo"])

      const result = getEnabledModules()

      expect(result).toEqual(["blog", "newsletter", "seo"])
    })
  })

  describe("getModuleData", () => {
    it("should return cached data if available", () => {
      // Set up cache
      // const mockData = { name: "blog", enabled: true }
      // moduleSystem.getModuleData("blog") // This will cache the data

      // Mock implementation to verify cache is used
      ;(fs.existsSync as jest.Mock).mockReturnValueOnce(false)

      // const result = moduleSystem.getModuleData("blog")

      // expect(result).toEqual({ name: "blog", enabled: true })
    })

    it("should load data from file if not cached", () => {
      ;(fs.existsSync as jest.Mock).mockReturnValueOnce(true)

      // const result = moduleSystem.getModuleData("blog")

      // expect(result).toEqual({ name: "blog", enabled: true })
      expect(fs.existsSync).toHaveBeenCalledWith("modules/blog/data.ts")
    })
  })

  describe("validateModuleConfiguration", () => {
    it("should return valid if no errors", () => {
      // Mock dependencies
      ;(fs.existsSync as jest.Mock).mockReturnValue(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog", "newsletter"])

      // const result = moduleSystem.validateModuleConfiguration()

      // expect(result.valid).toBe(true)
      // expect(result.errors).toEqual([])
    })

    it("should detect missing dependencies", () => {
      // Mock dependencies
      ;(fs.existsSync as jest.Mock).mockReturnValue(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog", "newsletter", "contact"])

      // Mock getModuleData to return dependencies
      // jest.spyOn(moduleSystem, "getModuleData").mockImplementation((name) => {
      //   if (name === "blog") {
      //     return { name: "blog", enabled: true, dependencies: ["contact"] }
      //   }
      //   return { name, enabled: name !== "contact" }
      // })

      // const result = moduleSystem.validateModuleConfiguration()

      // expect(result.valid).toBe(false)
      // expect(result.errors).toContain("Module blog depends on contact, but contact is not enabled")
    })

    it("should detect circular dependencies", () => {
      // Mock dependencies
      ;(fs.existsSync as jest.Mock).mockReturnValue(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog", "newsletter"])

      // Mock getModuleData to return circular dependencies
      // jest.spyOn(moduleSystem, "getModuleData").mockImplementation((name) => {
      //   if (name === "blog") {
      //     return { name: "blog", enabled: true, dependencies: ["newsletter"] }
      //   }
      //   if (name === "newsletter") {
      //     return { name: "newsletter", enabled: true, dependencies: ["blog"] }
      //   }
      //   return { name, enabled: true }
      // })

      // const result = moduleSystem.validateModuleConfiguration()

      // expect(result.valid).toBe(false)
      // expect(result.errors.some((error) => error.includes("Circular dependency"))).toBe(true)
    })
  })

  describe("generateConsolidatedEnv", () => {
    it("should generate consolidated environment variables", () => {
      // Mock environment variables
      process.env.NEXT_PUBLIC_TEST = "test"
      process.env.MODULE_BLOG = "true"
      process.env.PRIVATE_VAR = "private"

      // Mock enabled modules
      ;(fs.existsSync as jest.Mock).mockReturnValue(true)
      ;(fs.readdirSync as jest.Mock).mockReturnValueOnce(["blog"])
      ;(fs.readFileSync as jest.Mock).mockReturnValueOnce("BLOG_API_KEY=test")

      // const result = moduleSystem.generateConsolidatedEnv()

      // expect(result).toContain("NEXT_PUBLIC_TEST=test")
      // expect(result).toContain("MODULE_BLOG=true")
      // expect(result).not.toContain("PRIVATE_VAR=private")
      // expect(result).toContain("# blog module environment variables")
      // expect(result).toContain("BLOG_API_KEY=test")
    })
  })
})

# Style Guide

This page demonstrates the styling and components used in the Modular Next.js Project.

## Typography

### Font Family

- **Body Font:** var(--font-sans)
- **Heading Font:** var(--font-sans)

### Headings

# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6

### Body Text

This is a paragraph of text. It demonstrates the body font and text size. The quick brown fox jumps over the lazy dog.

This is smaller text, typically used for captions or secondary information.

This is extra small text, used for fine print or tertiary information.

## Colors

- **Primary:** #0070f3
- **Secondary:** #6c757d
- **Accent:** #f97316
- **Background:** #ffffff
- **Muted:** (varies by theme)
- **Destructive:** (varies by theme)

## Border Radius

- **Small:** rounded-sm
- **Medium:** rounded-md
- **Large:** rounded-lg (default: 0.5rem)
- **Full:** rounded-full

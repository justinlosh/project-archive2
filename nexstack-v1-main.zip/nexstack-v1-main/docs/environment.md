# Environment Variables

Learn how to configure your application using environment variables.

## Configuration Structure

The project uses a hierarchical approach to environment variables:

- **Main .env file** - Contains global configuration and feature toggles
- **Module-specific .env files** - Contains configuration specific to each module

## Feature Toggles

Control which features are enabled or disabled:

| Variable | Description |
| --- | --- |
| `NEXT_PUBLIC_ENABLE_BLOG` | Enable/disable the blog feature |
| `NEXT_PUBLIC_ENABLE_NEWSLETTER` | Enable/disable the newsletter feature |
| `NEXT_PUBLIC_ENABLE_CONTACT` | Enable/disable the contact form |
| `NEXT_PUBLIC_ENABLE_SEO` | Enable/disable the SEO features |

## Theme Configuration

Customize the look and feel of your application:

| Variable | Description | Default |
| --- | --- | --- |
| `NEXT_PUBLIC_DEFAULT_THEME` | Default theme (light, dark, system) | `light` |
| `NEXT_PUBLIC_PRIMARY_COLOR` | Primary color | `#0070f3` |
| `NEXT_PUBLIC_SECONDARY_COLOR` | Secondary color | `#6c757d` |
| `NEXT_PUBLIC_ACCENT_COLOR` | Accent color | `#f97316` |
| `NEXT_PUBLIC_FONT_FAMILY` | Main font family | `var(--font-sans)` |
| `NEXT_PUBLIC_HEADING_FONT_FAMILY` | Heading font family | `var(--font-sans)` |
| `NEXT_PUBLIC_BORDER_RADIUS` | Border radius for UI elements | `0.5rem` |

## Site Configuration

Configure general site settings:

\`\`\`
# Site Configuration
NEXT_PUBLIC_SITE_TITLE=Modular Next.js
NEXT_PUBLIC_SITE_DESCRIPTION=A modular Next.js website project
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SITE_LANGUAGE=en
NEXT_PUBLIC_SHOW_DOCS=true
NEXT_PUBLIC_GITHUB_URL=https://github.com/yourusername/modular-nextjs
NEXT_PUBLIC_COPYRIGHT_TEXT=© 2024 Modular Next.js. All rights reserved.
NEXT_PUBLIC_HERO_TITLE=Modular Next.js Project
NEXT_PUBLIC_HERO_DESCRIPTION=A modular Next.js website project optimized for v0 and Vercel deployment with environment variable-based feature toggling.
\`\`\`

## Naming Conventions

Environment variables follow these naming conventions:

- `NEXT_PUBLIC_*` - Variables that are accessible on the client side
- `NEXT_PUBLIC_ENABLE_*` - Feature toggle variables (e.g., `NEXT_PUBLIC_ENABLE_BLOG=true`)
- `MODULE_[NAME]_*` - Module-specific configuration variables (e.g., `MODULE_BLOG_TITLE`)

## Accessing Environment Variables

To access environment variables in your code:

\`\`\`tsx
// Server-side (Server Components, API Routes)
const siteTitle = process.env.NEXT_PUBLIC_SITE_TITLE

// Client-side (Client Components)
// Only NEXT_PUBLIC_* variables are available
const siteUrl = process.env.NEXT_PUBLIC_SITE_URL

// Feature visibility
import { isFeatureEnabled } from '@/lib/feature-visibility'
const isBlogEnabled = isFeatureEnabled('blog')

// Theme configuration
import { getThemeConfig } from '@/lib/theme-config'
const themeConfig = getThemeConfig()
const primaryColor = themeConfig.primaryColor

# Introduction

Welcome to the documentation for the Modular Next.js Project.

## Overview

This project is designed to be a modular, scalable Next.js website that can be easily extended with new features. It uses environment variables to toggle modules on and off, making it easy to customize the site without changing code.

## Key Features

- Modular architecture with environment variable-based module toggling
- Comprehensive documentation
- Latest Next.js, Tailwind CSS, and Shadcn UI
- Optimized for v0 and Vercel deployment
- Clean, maintainable code structure
- Module-specific environment variables

## Project Structure

The project follows a standard Next.js App Router structure with some additional directories:

\`\`\`
/app               # Next.js App Router pages and layouts
/components        # Reusable UI components
/lib               # Utility functions and helpers
/modules           # Modular features that can be toggled
  /blog            # Blog module with its own .env file
  /newsletter      # Newsletter module with its own .env file
/docs              # Documentation files
.env               # Main environment variables
.env.example       # Example environment variables

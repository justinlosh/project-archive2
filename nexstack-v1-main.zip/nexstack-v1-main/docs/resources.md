# Project Resources

A curated collection of resources, documentation, and tutorials to help you understand and extend the Modular Next.js project.

## Project Documentation

- [Getting Started](/docs/getting-started) - Installation instructions, environment setup, and basic configuration
- [Module System](/docs/modules) - Learn how the module system works and how to create new modules
- [Environment Variables](/docs/environment) - Detailed guide on using environment variables for configuration
- [Style Guide](/docs/style-guide) - Explore the design system, typography, colors, and UI components
- [Deployment](/docs/deployment) - Learn how to deploy your project to Vercel and other platforms

## Tutorials & Guides

- [Creating a New Module](/docs/modules#creating-a-new-module) - Learn how to create a new module from scratch
- [Customizing the Theme](/docs/style-guide) - Step-by-step guide to customizing the theme and typography
- [Deploying to Vercel](/docs/deployment) - Complete guide to deploying your project to Vercel

## External Resources

- [Next.js Documentation](https://nextjs.org/docs) - The official Next.js documentation
- [Tailwind CSS](https://tailwindcss.com/docs) - Learn how to use Tailwind CSS for styling
- [Shadcn UI](https://ui.shadcn.com) - Documentation for the Shadcn UI components
- [Vercel Platform](https://vercel.com/docs) - Learn how to use Vercel for deployment
- [React Documentation](https://react.dev) - The official React documentation
- [TypeScript Documentation](https://www.typescriptlang.org/docs) - Learn how to use TypeScript

## Community Resources

- [GitHub Repository](https://github.com/yourusername/modular-nextjs) - Source code and issues
- [Next.js Discord](https://discord.gg/nextjs) - Join the Next.js Discord community
- [Vercel Templates](https://vercel.com/templates) - Explore example projects and templates
\`\`\`

Now, let's create a documentation layout and page to render these Markdown files:

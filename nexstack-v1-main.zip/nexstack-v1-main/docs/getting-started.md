# Getting Started

Learn how to set up and run the Modular Next.js Project.

## Prerequisites

- Node.js 18.17 or later
- npm, yarn, or pnpm

## Installation

Clone the repository and install dependencies:

\`\`\`bash
git clone https://github.com/yourusername/modular-nextjs.git
cd modular-nextjs
npm install
\`\`\`

## Environment Setup

Create a `.env` file at the root of your project based on the `.env.example` file:

\`\`\`
# Site Configuration
NEXT_PUBLIC_SITE_TITLE=Modular Next.js
NEXT_PUBLIC_SITE_DESCRIPTION=A modular Next.js website project
NEXT_PUBLIC_SITE_URL=http://localhost:3000
NEXT_PUBLIC_SITE_LANGUAGE=en
NEXT_PUBLIC_DEFAULT_THEME=system
NEXT_PUBLIC_SHOW_DOCS=true
NEXT_PUBLIC_GITHUB_URL=https://github.com/yourusername/modular-nextjs
NEXT_PUBLIC_COPYRIGHT_TEXT=© 2024 Modular Next.js. All rights reserved.

# Module Toggles
MODULE_BLOG=true
MODULE_NEWSLETTER=true
\`\`\`

Also, make sure to copy the module-specific `.env` files from each module directory.

## Development

Run the development server:

\`\`\`bash
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser to see the result.

## Building for Production

Build the application for production:

\`\`\`bash
npm run build
\`\`\`

You can then start the production server:

\`\`\`bash
npm run start
\`\`\`

## Enabling/Disabling Modules

To enable or disable modules, update the module toggle variables in your `.env` file:

\`\`\`
# Enable the blog module
MODULE_BLOG=true

# Disable the newsletter module
MODULE_NEWSLETTER=false
\`\`\`

After changing environment variables, restart the development server for the changes to take effect.

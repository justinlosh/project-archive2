# Modules

Learn how to use and create modules in the Modular Next.js Project.

## What are Modules?

Modules are self-contained features that can be toggled on or off using environment variables. Each module consists of components, data, and potentially routes that are only loaded when the module is enabled.

## Available Modules

- **Blog** - A simple blog module with posts and articles
  - `MODULE_BLOG=true`
- **Newsletter** - A newsletter subscription form
  - `MODULE_NEWSLETTER=true`
- **Contact** - A contact form for user inquiries
  - `MODULE_CONTACT=true`
- **SEO** - Search Engine Optimization features
  - `MODULE_SEO=true`

## Module Structure

Each module follows a standard structure:

\`\`\`
/modules/[module-name]/
  component.tsx    # Main component for the module
  data.ts          # Data for the module (optional)
  .env             # Module-specific environment variables
  README.md        # Documentation for the module
\`\`\`

## Creating a New Module

To create a new module:

1. Create a new directory in the `/modules` directory with your module name
2. Create a `component.tsx` file that exports your module's main component
3. Optionally create a `data.ts` file to export data for your module
4. Create a `.env` file with module-specific environment variables
5. Create a `README.md` file with documentation for your module
6. Add any additional components or utilities specific to your module
7. Add an environment variable to toggle your module (e.g., `MODULE_YOURMODULE=true`)
8. Update the `.env.example` file to include your module's environment variables

## Using Modules

To use a module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with your module name
<ModuleLoader moduleName="blog" />

// You can also provide a fallback component
<ModuleLoader 
  moduleName="newsletter" 
  fallback={<p>Newsletter module is disabled</p>} 
/>
\`\`\`

## Module Routes

To create routes that only work when a module is enabled:

\`\`\`tsx
// Import the ModuleRoute component
import { ModuleRoute } from '@/lib/module-loader'

// Wrap your page component with ModuleRoute
export default function BlogPage() {
  return (
    <ModuleRoute moduleName="blog">
      <div>Your blog page content</div>
    </ModuleRoute>
  )
}
\`\`\`

If the module is disabled, the route will return a 404 page.

## Module Configuration

To access module-specific configuration:

\`\`\`tsx
// Import the getModuleConfig function
import { getModuleConfig } from '@/lib/module-loader'

// Get the module configuration
const config = getModuleConfig('blog')

// Use the configuration values
const title = config.TITLE || 'Default Title'

# Deployment

Learn how to deploy the Modular Next.js Project to Vercel.

## Deploying to Vercel

The easiest way to deploy your Next.js app is to use the Vercel Platform.

1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Import your repository to Vercel
3. Vercel will detect that you're using Next.js and set up the build configuration for you
4. Set up your environment variables in the Vercel dashboard
5. Deploy your application

## Environment Variables

Make sure to set up your environment variables in the Vercel dashboard:

1. Go to your project settings in the Vercel dashboard
2. Navigate to the "Environment Variables" tab
3. Add your environment variables, including module toggles
4. Deploy or redeploy your application

## Custom Domains

To set up a custom domain for your application:

1. Go to your project settings in the Vercel dashboard
2. Navigate to the "Domains" tab
3. Add your custom domain
4. Follow the instructions to configure your DNS settings

## Continuous Deployment

Vercel automatically deploys your application when you push changes to your repository. You can configure deployment settings in the Vercel dashboard.

# Blog Module

Documentation for the Blog module.

## Overview

The Blog module provides a simple blog functionality with posts and articles. It includes a blog listing page and individual post pages.

## Configuration

The Blog module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_BLOG` | Enable/disable the blog module | `false` |
| `MODULE_BLOG_TITLE` | Title for the blog section | `Latest Blog Posts` |
| `MODULE_BLOG_POSTS_TO_SHOW` | Number of posts to show on the homepage | `3` |
| `MODULE_BLOG_SHOW_AUTHOR` | Show author information | `true` |
| `MODULE_BLOG_SHOW_DATE` | Show publication date | `true` |
| `MODULE_BLOG_POSTS_PER_PAGE` | Number of posts per page in the blog listing | `10` |

## Usage

To use the Blog module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the blog module
<ModuleLoader moduleName="blog" />
\`\`\`

## Routes

The Blog module provides the following routes:

- `/blog` - Blog listing page
- `/blog/[slug]` - Individual blog post page

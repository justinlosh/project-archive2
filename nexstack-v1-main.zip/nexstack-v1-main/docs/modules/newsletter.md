# Newsletter Module

Documentation for the Newsletter module.

## Overview

The Newsletter module provides a newsletter subscription form that allows users to subscribe to your newsletter.

## Configuration

The Newsletter module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_NEWSLETTER` | Enable/disable the newsletter module | `false` |
| `MODULE_NEWSLETTER_TITLE` | Title for the newsletter form | `Subscribe to our Newsletter` |
| `MODULE_NEWSLETTER_DESCRIPTION` | Description for the newsletter form | `Get the latest updates delivered to your inbox` |
| `MODULE_NEWSLETTER_BUTTON_TEXT` | Text for the subscribe button | `Subscribe` |
| `MODULE_NEWSLETTER_SUCCESS_MESSAGE` | Message shown after successful subscription | `Thanks for subscribing!` |
| `MODULE_NEWSLETTER_ERROR_MESSAGE` | Message shown if subscription fails | `Something went wrong. Please try again.` |
| `MODULE_NEWSLETTER_SHOW_PRIVACY_POLICY` | Show privacy policy text | `true` |

## Usage

To use the Newsletter module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the newsletter module
<ModuleLoader moduleName="newsletter" />

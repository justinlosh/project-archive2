# Contact Module

Documentation for the Contact module.

## Overview

The Contact module provides a contact form that allows users to send messages to your team. It includes form validation and success/error states.

## Configuration

The Contact module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_CONTACT` | Enable/disable the contact module | `false` |
| `MODULE_CONTACT_TITLE` | Title for the contact form | `Contact Us` |
| `MODULE_CONTACT_DESCRIPTION` | Description for the contact form | `Have questions or feedback? Get in touch with our team.` |
| `MODULE_CONTACT_BUTTON_TEXT` | Text for the submit button | `Send Message` |
| `MODULE_CONTACT_SHOW_SUBJECT` | Show/hide the subject field | `true` |

## Usage

To use the Contact module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the contact module
<ModuleLoader moduleName="contact" />
\`\`\`

## Integration

In a real-world scenario, you would integrate this form with a backend service to handle form submissions. You could:

1. Create a server action to handle form submissions
2. Integrate with an email service like SendGrid or Mailgun
3. Store submissions in a database

For now, the form simulates a submission with a timeout.

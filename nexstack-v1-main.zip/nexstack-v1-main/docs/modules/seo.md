# SEO Module

Documentation for the Search Engine Optimization module.

## Overview

The SEO module provides tools for improving your website's search engine visibility and social media sharing. It includes meta tags, OpenGraph data, structured data, and analytics integration.

## Configuration

The SEO module can be configured using the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| `MODULE_SEO` | Enable/disable the SEO module | `false` |
| `MODULE_SEO_DEFAULT_TITLE` | Default page title | `Modular Next.js Project` |
| `MODULE_SEO_DEFAULT_DESCRIPTION` | Default meta description | `A modular Next.js website project` |
| `MODULE_SEO_ENABLE_GOOGLE_ANALYTICS` | Enable Google Analytics | `false` |
| `MODULE_SEO_ENABLE_STRUCTURED_DATA` | Enable structured data/JSON-LD | `true` |
| `MODULE_SEO_ENABLE_SOCIAL_META` | Enable OpenGraph and Twitter cards | `true` |

## Features

- Meta tags for better search engine visibility
- OpenGraph and Twitter card support for social media sharing
- Structured data/JSON-LD for rich results in search engines
- Google Analytics integration (configurable)
- Canonical URL management

## Usage

To use the SEO module in your application:

\`\`\`tsx
// Import the ModuleLoader component
import { ModuleLoader } from '@/lib/module-loader'

// Use the ModuleLoader component with the SEO module
// This is typically done in your layout or template file
<ModuleLoader moduleName="seo" />
\`\`\`

## Integration with Next.js

In Next.js App Router, you can also use the built-in metadata API in combination with this module:

\`\`\`tsx
// In your layout.tsx or page.tsx
import { getModuleData } from '@/lib/module-loader'

export async function generateMetadata() {
  const seoData = await getModuleData('seo')
  
  return {
    title: seoData?.defaultMetaTags.find(tag => tag.name === 'title')?.content,
    description: seoData?.defaultMetaTags.find(tag => tag.name === 'description')?.content,
    // Add more metadata as needed
  }
}

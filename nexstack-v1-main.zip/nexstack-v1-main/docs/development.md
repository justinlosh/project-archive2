# Development Guidelines

Best practices for developing with the Modular Next.js Project.

## Code Structure

The project follows a modular structure to keep code organized and maintainable. Here are some guidelines for organizing your code:

- Place reusable components in the `/components` directory
- Place utility functions in the `/lib` directory
- Place modular features in the `/modules` directory
- Use the App Router structure for pages and layouts

## Creating New Modules

When creating a new module, follow these steps:

1. Create a new directory in the `/modules` directory
2. Create a `component.tsx` file for the main component
3. Create a `data.ts` file for any data the module needs
4. Add an environment variable to toggle the module
5. Update the documentation to include the new module

## Styling

The project uses Tailwind CSS for styling and Shadcn UI for components. When adding styles, follow these guidelines:

- Use Tailwind utility classes for styling
- Use Shadcn UI components when possible
- Keep styles consistent across the application
- Use the theme variables for colors and spacing

## Testing

The project supports testing with Jest and React Testing Library. When writing tests, follow these guidelines:

- Write tests for all components and utilities
- Use React Testing Library for component tests
- Use Jest for unit tests
- Run tests before committing changes

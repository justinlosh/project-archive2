/** @type {import('next').NextConfig} */
const fs = require("fs")
const path = require("path")
const { execSync } = require("child_process")

// Get version from git or package.json
function getAppVersion() {
  try {
    // Try to get version from git tag
    const gitVersion = execSync('git describe --tags --abbrev=0 2>/dev/null || echo ""').toString().trim()
    if (gitVersion) return gitVersion

    // Fallback to package.json
    const packageJson = JSON.parse(fs.readFileSync("package.json", "utf8"))
    return packageJson.version || "0.0.1"
  } catch (error) {
    console.warn("Could not determine app version:", error.message)
    return "0.0.1"
  }
}

// Log build info for troubleshooting
const buildInfo = {
  version: getAppVersion(),
  timestamp: new Date().toISOString(),
  node: process.version,
  env: process.env.NODE_ENV,
}
console.log("Build info:", buildInfo)

// Load environment variables using Next.js built-in support
// Next.js automatically loads .env, .env.local, .env.development, etc.

// Load module configuration if available
let moduleConfig = { enabled: [], disabled: [] }
try {
  const configPath = path.join(process.cwd(), ".module-config.json")
  if (fs.existsSync(configPath)) {
    moduleConfig = JSON.parse(fs.readFileSync(configPath, "utf8"))
    console.log(
      `Loaded module configuration: ${moduleConfig.enabled.length} enabled, ${moduleConfig.disabled.length} disabled`,
    )
  }
} catch (error) {
  console.error("Error loading module configuration:", error)
}

// Define security headers
const securityHeaders = [
  {
    key: "X-DNS-Prefetch-Control",
    value: "on",
  },
  {
    key: "X-XSS-Protection",
    value: "1; mode=block",
  },
  {
    key: "X-Frame-Options",
    value: "SAMEORIGIN",
  },
  {
    key: "X-Content-Type-Options",
    value: "nosniff",
  },
  {
    key: "Referrer-Policy",
    value: "strict-origin-when-cross-origin",
  },
  {
    key: "Permissions-Policy",
    value: "camera=(), microphone=(), geolocation=(), interest-cohort=()",
  },
  {
    key: "Content-Security-Policy",
    value: `
      default-src 'self';
      script-src 'self' 'unsafe-inline' https://www.googletagmanager.com https://plausible.io https://cdn.usefathom.com;
      style-src 'self' 'unsafe-inline';
      img-src 'self' data: https://v0.blob.com https://www.google-analytics.com;
      font-src 'self' data:;
      connect-src 'self' https://www.google-analytics.com https://plausible.io https://api.usefathom.com;
      frame-ancestors 'self';
      form-action 'self';
      base-uri 'self';
      object-src 'none';
      upgrade-insecure-requests;
    `
      .replace(/\s{2,}/g, " ")
      .trim(),
  },
]

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false, // Hide the X-Powered-By header
  compress: true, // Enable compression
  generateEtags: true, // Generate ETags for caching
  experimental: {
    optimizeCss: true,
    optimizePackageImports: ["lucide-react", "@/components/ui"],
  },
  eslint: {
    ignoreDuringBuilds: process.env.CI === "true", // Only ignore during CI builds
  },
  typescript: {
    ignoreBuildErrors: process.env.CI === "true", // Only ignore during CI builds
  },

  // Configure security headers
  async headers() {
    return [
      {
        source: "/:path*",
        headers: securityHeaders,
      },
    ]
  },

  // Customize build ID for better debugging and deployment tracking
  generateBuildId: async () => {
    return `build_${buildInfo.version}_${Date.now().toString().slice(-6)}`
  },

  // Enable static exports for the docs
  output: process.env.NEXT_PUBLIC_EXPORT === "true" ? "export" : "standalone",

  // Configure image domains for external images
  images: {
    domains: ["images.unsplash.com", "placehold.co", "v0.blob.com"],
    formats: ["image/avif", "image/webp"],
    unoptimized: process.env.NEXT_PUBLIC_EXPORT === "true", // Only use unoptimized for static exports
  },

  // Optimize the build by excluding disabled modules
  webpack: (config, { isServer, webpack }) => {
    if (moduleConfig.disabled.length > 0) {
      // Create a regex pattern for disabled module paths
      const disabledModulePattern = new RegExp(`modules/(${moduleConfig.disabled.join("|")})/`)

      // Add a rule to ignore disabled modules
      config.module.rules.push({
        test: disabledModulePattern,
        use: {
          loader: "null-loader",
        },
      })

      console.log(`Excluded ${moduleConfig.disabled.length} disabled modules from build`)
    }

    // Add build info as a global constant
    config.plugins.push(
      new webpack.DefinePlugin({
        __BUILD_INFO__: JSON.stringify(buildInfo),
      }),
    )

    // Optimize bundle size
    if (!isServer) {
      config.optimization.splitChunks = {
        chunks: "all",
        minSize: 20000,
        maxSize: 90000,
        cacheGroups: {
          vendors: {
            test: /[\\/]node_modules[\\/]/,
            priority: -10,
            reuseExistingChunk: true,
          },
          components: {
            test: /[\\/]components[\\/]/,
            priority: -10,
            reuseExistingChunk: true,
          },
          default: {
            minChunks: 2,
            priority: -20,
            reuseExistingChunk: true,
          },
        },
      }
    }

    return config
  },

  // Handle module-specific redirects if needed
  async redirects() {
    // Redirect requests for disabled module routes to 404
    const redirects = []

    // Check if maintenance mode is enabled
    if (
      process.env.MODULE_MAINTENANCE_MODE_ENABLED === "true" &&
      process.env.MODULE_MAINTENANCE_MODE_REDIRECT_ALL === "true"
    ) {
      // Redirect all non-maintenance pages to maintenance page
      redirects.push({
        source: "/((?!maintenance|_next|api|favicon.ico).*)",
        destination: "/maintenance",
        permanent: false,
      })
    }

    return redirects
  },
}

module.exports = nextConfig

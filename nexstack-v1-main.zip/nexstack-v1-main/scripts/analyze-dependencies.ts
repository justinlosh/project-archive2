import fs from "fs"
import path from "path"
import { getAllModuleNames, getEnabledModules } from "../lib/module-system"

// Function to analyze module dependencies
async function analyzeDependencies() {
  console.log("📊 Analyzing module dependencies...")

  // Get enabled and disabled modules
  const allModules = getAllModuleNames()
  const enabledModules = getEnabledModules()
  const disabledModules = allModules.filter((module) => !enabledModules.includes(module))

  console.log(`✅ Enabled modules (${enabledModules.length}): ${enabledModules.join(", ")}`)
  console.log(`❌ Disabled modules (${disabledModules.length}): ${disabledModules.join(", ")}`)

  // Analyze package.json for unused dependencies
  const packageJsonPath = path.join(process.cwd(), "package.json")
  const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, "utf8"))

  // Get all dependencies
  const allDependencies = {
    ...packageJson.dependencies,
    ...packageJson.devDependencies,
  }

  // Track module-specific dependencies
  const moduleDependencies: Record<string, string[]> = {}

  // Scan each module for dependencies
  for (const moduleName of allModules) {
    const modulePath = path.join(process.cwd(), "modules", moduleName)
    moduleDependencies[moduleName] = []

    // Skip if module directory doesn't exist
    if (!fs.existsSync(modulePath)) continue

    // Scan all files in the module directory
    const files = getAllFiles(modulePath)

    for (const file of files) {
      // Skip non-JS/TS files
      if (![".js", ".jsx", ".ts", ".tsx"].some((ext) => file.endsWith(ext))) continue

      // Read file content
      const content = fs.readFileSync(file, "utf8")

      // Check for import statements
      const importRegex = /import\s+(?:.+\s+from\s+)?['"]([^'"]+)['"]/g
      let match

      while ((match = importRegex.exec(content)) !== null) {
        const importPath = match[1]

        // Skip relative imports and built-in modules
        if (importPath.startsWith(".") || importPath.startsWith("/")) continue

        // Extract package name (handle scoped packages)
        const packageName = importPath.startsWith("@")
          ? importPath.split("/").slice(0, 2).join("/")
          : importPath.split("/")[0]

        // Add to module dependencies if it's in package.json
        if (allDependencies[packageName] && !moduleDependencies[moduleName].includes(packageName)) {
          moduleDependencies[moduleName].push(packageName)
        }
      }
    }
  }

  // Find dependencies that are only used by disabled modules
  const enabledModuleDeps = new Set<string>()
  const disabledModuleDeps = new Set<string>()

  for (const moduleName of enabledModules) {
    moduleDependencies[moduleName].forEach((dep) => enabledModuleDeps.add(dep))
  }

  for (const moduleName of disabledModules) {
    moduleDependencies[moduleName].forEach((dep) => {
      if (!enabledModuleDeps.has(dep)) {
        disabledModuleDeps.add(dep)
      }
    })
  }

  // Output results
  console.log("\n📦 Module-specific dependencies:")
  for (const moduleName of allModules) {
    console.log(`  ${moduleName}: ${moduleDependencies[moduleName].join(", ") || "none"}`)
  }

  console.log("\n🔍 Dependencies only used by disabled modules:")
  if (disabledModuleDeps.size === 0) {
    console.log("  None found")
  } else {
    disabledModuleDeps.forEach((dep) => console.log(`  - ${dep}`))

    // Generate optimization suggestions
    console.log("\n💡 Optimization suggestions:")
    console.log("  You can optimize your deployment by conditionally installing these dependencies:")
    console.log(`  
  if [ "$MODULE_SOME_MODULE" = "true" ]; then
    npm install ${Array.from(disabledModuleDeps).join(" ")}
  fi
    `)
  }

  console.log("\n✅ Dependency analysis complete!")
}

// Helper function to get all files in a directory recursively
function getAllFiles(dirPath: string, arrayOfFiles: string[] = []): string[] {
  const files = fs.readdirSync(dirPath)

  files.forEach((file) => {
    const filePath = path.join(dirPath, file)

    if (fs.statSync(filePath).isDirectory()) {
      arrayOfFiles = getAllFiles(filePath, arrayOfFiles)
    } else {
      arrayOfFiles.push(filePath)
    }
  })

  return arrayOfFiles
}

// Run the analysis
analyzeDependencies().catch((error) => {
  console.error("Error during dependency analysis:", error)
  process.exit(1)
})

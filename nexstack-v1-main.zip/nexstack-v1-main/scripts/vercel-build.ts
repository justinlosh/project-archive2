import fs from "fs"
import path from "path"
import { execSync } from "child_process"
import {
  getAllModuleNames,
  getEnabledModules,
  validateModuleConfiguration,
  generateConsolidatedEnv,
} from "../lib/module-system"

// Load environment variables from .env file if it exists
try {
  const envPath = path.join(process.cwd(), ".env")
  if (fs.existsSync(envPath)) {
    const envConfig = require("dotenv").config({ path: envPath })
    if (envConfig.error) {
      throw envConfig.error
    }
  }
} catch (error) {
  console.warn("Warning: Error loading .env file", error)
}

// Main function to prepare for Vercel deployment
async function vercelBuild() {
  console.log("🚀 Preparing for Vercel deployment...")

  // Validate module configuration
  const validation = validateModuleConfiguration()
  if (!validation.valid) {
    console.error("❌ Module configuration validation failed:")
    validation.errors.forEach((error) => console.error(`  - ${error}`))
    process.exit(1)
  }

  // Get enabled and disabled modules
  const allModules = getAllModuleNames()
  const enabledModules = getEnabledModules()
  const disabledModules = allModules.filter((module) => !enabledModules.includes(module))

  console.log(`✅ Enabled modules (${enabledModules.length}): ${enabledModules.join(", ")}`)
  console.log(`❌ Disabled modules (${disabledModules.length}): ${disabledModules.join(", ")}`)

  // Generate consolidated environment file
  const envContent = generateConsolidatedEnv()
  fs.writeFileSync(path.join(process.cwd(), ".env.production"), envContent)
  console.log("📝 Generated production environment file: .env.production")

  // Create module configuration file for webpack
  const moduleConfig = {
    enabled: enabledModules,
    disabled: disabledModules,
    timestamp: new Date().toISOString(),
  }

  fs.writeFileSync(path.join(process.cwd(), ".module-config.json"), JSON.stringify(moduleConfig, null, 2))

  // Create a build info file for reference
  const buildInfo = {
    timestamp: new Date().toISOString(),
    enabledModules,
    disabledModules,
    environment: process.env.VERCEL_ENV || "unknown",
    commit: process.env.VERCEL_GIT_COMMIT_SHA || "unknown",
    branch: process.env.VERCEL_GIT_COMMIT_REF || "unknown",
  }

  fs.writeFileSync(path.join(process.cwd(), "public", "build-info.json"), JSON.stringify(buildInfo, null, 2))

  console.log("🔍 Running Next.js build...")

  // Run the Next.js build
  try {
    execSync("next build", { stdio: "inherit" })
    console.log("✅ Build completed successfully!")
  } catch (error) {
    console.error("❌ Build failed:", error)
    process.exit(1)
  }
}

// Run the Vercel build
vercelBuild().catch((error) => {
  console.error("Error during Vercel build:", error)
  process.exit(1)
})

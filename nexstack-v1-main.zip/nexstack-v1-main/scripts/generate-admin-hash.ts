import { hashPassword } from "../lib/security"
import * as readline from "readline"

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

rl.question("Enter admin username: ", (username) => {
  rl.question("Enter admin password: ", (password) => {
    const { hash, salt } = hashPassword(password)

    console.log("\n=== Admin Credentials Configuration ===")
    console.log("Add these to your .env file:")
    console.log(`ADMIN_SECURITY_ENABLED=true`)
    console.log(`ADMIN_PASSWORD_PROTECTION_ENABLED=true`)
    console.log(`ADMIN_USERNAME=${username}`)
    console.log(`ADMIN_PASSWORD_HASH=${hash}`)
    console.log(`ADMIN_PASSWORD_SALT=${salt}`)
    console.log("\nFor IP restriction:")
    console.log(`ADMIN_IP_RESTRICTION_ENABLED=true`)
    console.log(`ADMIN_ALLOWED_IPS=127.0.0.1,::1,<your-ip-address>`)
    console.log(`ADMIN_ALLOW_LOCALHOST=true`)
    console.log("\nFor environment restriction:")
    console.log(`ADMIN_ENVIRONMENT_RESTRICTION_ENABLED=true`)
    console.log(`ADMIN_ALLOWED_ENVIRONMENTS=development,preview`)

    rl.close()
  })
})

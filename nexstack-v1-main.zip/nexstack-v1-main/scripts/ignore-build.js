// This script determines whether to skip a build based on which modules are affected
const { execSync } = require("child_process")

// Get the list of files changed since the last build
function getChangedFiles() {
  try {
    // Get the current and previous commit hashes
    const currentCommit = process.env.VERCEL_GIT_COMMIT_SHA
    if (!currentCommit) {
      throw new Error("Missing commit hash")
    }

    // Safely get the last successful commit
    let lastSuccessfulCommit
    try {
      lastSuccessfulCommit = execSync("git rev-parse HEAD~1").toString().trim()
    } catch (error) {
      // If there's an error getting the previous commit, use HEAD
      console.warn("Could not get previous commit, using HEAD")
      lastSuccessfulCommit = "HEAD"
    }

    // Get the list of changed files
    const changedFiles = execSync(`git diff --name-only ${lastSuccessfulCommit} ${currentCommit}`, {
      maxBuffer: 1024 * 1024, // Increase buffer to handle large diffs
    })
      .toString()
      .trim()

    if (!changedFiles) {
      return []
    }

    return changedFiles.split("\n")
  } catch (error) {
    console.error("Error getting changed files:", error)
    // If we can't determine changed files, assume everything changed
    return ["*"]
  }
}

// Check if any module-specific files have changed
function hasModuleChanged(moduleName, changedFiles) {
  if (!moduleName || !Array.isArray(changedFiles)) {
    return false
  }
  return changedFiles.some((file) => file.startsWith(`modules/${moduleName}/`))
}

// Check if any core files have changed
function hasCoreChanged(changedFiles) {
  if (!Array.isArray(changedFiles)) {
    return true
  }

  const corePatterns = [
    "app/",
    "components/",
    "lib/",
    "public/",
    "styles/",
    "next.config.js",
    "package.json",
    "tsconfig.json",
    "tailwind.config.js",
  ]

  return changedFiles.some((file) => corePatterns.some((pattern) => file.startsWith(pattern)))
}

// Main function to determine if build should be skipped
function shouldSkipBuild() {
  // Get environment variables
  const branch = process.env.VERCEL_GIT_COMMIT_REF

  // Never skip builds on main/master branch
  if (branch === "main" || branch === "master") {
    console.log("✅ Building: This is the main branch")
    return false
  }

  // Get changed files
  const changedFiles = getChangedFiles()

  // If no files have changed or we couldn't determine changed files
  if (!changedFiles.length) {
    console.log("✅ Building: Could not determine changed files")
    return false
  }

  // If core files changed, always build
  if (hasCoreChanged(changedFiles)) {
    console.log("✅ Building: Core files have changed")
    return false
  }

  // Get enabled modules from environment variables
  const enabledModules = Object.keys(process.env)
    .filter((key) => key.startsWith("MODULE_") && process.env[key] === "true")
    .map((key) => key.replace("MODULE_", "").toLowerCase())

  // Check if any enabled module has changed
  for (const moduleName of enabledModules) {
    if (hasModuleChanged(moduleName, changedFiles)) {
      console.log(`✅ Building: Module '${moduleName}' has changed`)
      return false
    }
  }

  // If we get here, no enabled modules have changed
  console.log("🛑 Skipping build: No enabled modules have changed")
  return true
}

// Run the check
const skipBuild = shouldSkipBuild()

// Exit with appropriate code (0 = skip, 1 = build)
process.exit(skipBuild ? 0 : 1)

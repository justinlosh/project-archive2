import fs from "fs"
import path from "path"
import {
  getAllModuleNames,
  getEnabledModules,
  validateModuleConfiguration,
  generateConsolidatedEnv,
} from "../lib/module-system"

// Load environment variables from .env file if it exists
try {
  const envPath = path.join(process.cwd(), ".env")
  if (fs.existsSync(envPath)) {
    const envConfig = require("dotenv").config({ path: envPath })
    if (envConfig.error) {
      throw envConfig.error
    }
  }
} catch (error) {
  console.warn("Warning: Error loading .env file", error)
}

// Main function to optimize the build
async function optimizeBuild() {
  console.log("🔍 Analyzing module configuration...")

  // Validate module configuration
  const validation = validateModuleConfiguration()
  if (!validation.valid) {
    console.error("❌ Module configuration validation failed:")
    validation.errors.forEach((error) => console.error(`  - ${error}`))
    process.exit(1)
  }

  // Get enabled and disabled modules
  const allModules = getAllModuleNames()
  const enabledModules = getEnabledModules()
  const disabledModules = allModules.filter((module) => !enabledModules.includes(module))

  console.log(`✅ Enabled modules (${enabledModules.length}): ${enabledModules.join(", ")}`)
  console.log(`❌ Disabled modules (${disabledModules.length}): ${disabledModules.join(", ")}`)

  // Generate consolidated environment file
  const envContent = generateConsolidatedEnv()
  fs.writeFileSync(path.join(process.cwd(), ".env.build"), envContent)
  console.log("📝 Generated consolidated environment file: .env.build")

  // Create a temporary file to indicate which modules are enabled
  const moduleConfig = {
    enabled: enabledModules,
    disabled: disabledModules,
    timestamp: new Date().toISOString(),
  }

  fs.writeFileSync(path.join(process.cwd(), ".module-config.json"), JSON.stringify(moduleConfig, null, 2))

  console.log("🚀 Build optimization complete!")
}

// Run the optimization
optimizeBuild().catch((error) => {
  console.error("Error during build optimization:", error)
  process.exit(1)
})

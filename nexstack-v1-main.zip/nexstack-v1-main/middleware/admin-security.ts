import { type NextRequest, NextResponse } from "next/server"
import { getHash } from "@/lib/security"
import { logger } from "@/lib/logger"

/**
 * Admin security middleware configuration interface
 */
interface AdminSecurityConfig {
  enabled: boolean
  passwordProtection: {
    enabled: boolean
    username: string
    passwordHash: string
  }
  ipRestriction: {
    enabled: boolean
    allowedIps: string[]
    allowLocalhost: boolean
  }
  environmentRestriction: {
    enabled: boolean
    allowedEnvironments: string[]
  }
  rateLimiting: {
    enabled: boolean
    maxRequests: number
    windowMs: number
  }
}

// Cache for rate limiting
const rateLimitCache = new Map<string, { count: number; resetAt: number }>()

/**
 * Load admin security configuration from environment variables
 */
function getAdminSecurityConfig(): AdminSecurityConfig {
  return {
    enabled: process.env.ADMIN_SECURITY_ENABLED !== "false",
    passwordProtection: {
      enabled: process.env.ADMIN_PASSWORD_PROTECTION_ENABLED !== "false",
      username: process.env.ADMIN_USERNAME || "admin",
      passwordHash: process.env.ADMIN_PASSWORD_HASH || "",
    },
    ipRestriction: {
      enabled: process.env.ADMIN_IP_RESTRICTION_ENABLED === "true",
      allowedIps: (process.env.ADMIN_ALLOWED_IPS || "")
        .split(",")
        .map((ip) => ip.trim())
        .filter(Boolean),
      allowLocalhost: process.env.ADMIN_ALLOW_LOCALHOST !== "false",
    },
    environmentRestriction: {
      enabled: process.env.ADMIN_ENVIRONMENT_RESTRICTION_ENABLED === "true",
      allowedEnvironments: (process.env.ADMIN_ALLOWED_ENVIRONMENTS || "development,preview")
        .split(",")
        .map((env) => env.trim()),
    },
    rateLimiting: {
      enabled: process.env.ADMIN_RATE_LIMITING_ENABLED === "true",
      maxRequests: Number.parseInt(process.env.ADMIN_RATE_LIMIT_MAX || "100", 10),
      windowMs: Number.parseInt(process.env.ADMIN_RATE_LIMIT_WINDOW_MS || "3600000", 10), // 1 hour default
    },
  }
}

/**
 * Verify basic authentication credentials
 */
function verifyCredentials(authHeader: string | null, config: AdminSecurityConfig): boolean {
  if (!authHeader || !authHeader.startsWith("Basic ")) {
    return false
  }

  try {
    const base64Credentials = authHeader.split(" ")[1]
    const credentials = atob(base64Credentials)
    const [username, password] = credentials.split(":")

    if (username !== config.passwordProtection.username) {
      logger.warn("Admin login attempt with incorrect username", { username })
      return false
    }

    // If no password hash is configured, deny access
    if (!config.passwordProtection.passwordHash) {
      logger.warn("Admin password hash not configured. Access denied.")
      return false
    }

    // Compare password with stored hash
    const passwordHash = getHash(password)
    const isValid = passwordHash === config.passwordProtection.passwordHash

    if (!isValid) {
      logger.warn("Admin login attempt with incorrect password", { username })
    }

    return isValid
  } catch (error) {
    logger.error("Error verifying admin credentials", { error })
    return false
  }
}

/**
 * Check if the request is coming from an allowed IP
 */
function isAllowedIp(request: NextRequest, config: AdminSecurityConfig): boolean {
  const clientIp = request.ip || request.headers.get("x-forwarded-for")?.split(",")[0].trim() || "127.0.0.1"

  // Allow localhost if configured
  if (
    config.ipRestriction.allowLocalhost &&
    (clientIp === "127.0.0.1" || clientIp === "::1" || clientIp === "localhost")
  ) {
    return true
  }

  const allowed = config.ipRestriction.allowedIps.includes(clientIp)

  if (!allowed) {
    logger.warn("Admin access attempt from unauthorized IP", { ip: clientIp })
  }

  return allowed
}

/**
 * Check if the current environment is allowed
 */
function isAllowedEnvironment(config: AdminSecurityConfig): boolean {
  const environment = process.env.VERCEL_ENV || process.env.NODE_ENV || "development"
  return config.environmentRestriction.allowedEnvironments.includes(environment)
}

/**
 * Check rate limits for a request
 */
function checkRateLimit(request: NextRequest, config: AdminSecurityConfig): { allowed: boolean; resetAfter?: number } {
  if (!config.rateLimiting.enabled) {
    return { allowed: true }
  }

  const clientIp = request.ip || request.headers.get("x-forwarded-for")?.split(",")[0].trim() || "127.0.0.1"

  const now = Date.now()
  let record = rateLimitCache.get(clientIp)

  // Initialize or reset expired record
  if (!record || record.resetAt <= now) {
    record = { count: 0, resetAt: now + config.rateLimiting.windowMs }
    rateLimitCache.set(clientIp, record)
  }

  // Increment counter
  record.count++

  // Clean up old records periodically (every 100 requests)
  if (Math.random() < 0.01) {
    for (const [ip, data] of rateLimitCache.entries()) {
      if (data.resetAt <= now) {
        rateLimitCache.delete(ip)
      }
    }
  }

  const allowed = record.count <= config.rateLimiting.maxRequests
  const resetAfter = Math.ceil((record.resetAt - now) / 1000) // in seconds

  if (!allowed) {
    logger.warn("Rate limit exceeded for admin access", {
      ip: clientIp,
      count: record.count,
      limit: config.rateLimiting.maxRequests,
      resetsIn: resetAfter,
    })
  }

  return { allowed, resetAfter }
}

/**
 * Admin security middleware
 */
export async function adminSecurityMiddleware(request: NextRequest) {
  // Skip security checks for static assets and API routes
  if (
    request.nextUrl.pathname.startsWith("/_next/") ||
    request.nextUrl.pathname.startsWith("/api/") ||
    request.nextUrl.pathname.startsWith("/favicon.ico")
  ) {
    return NextResponse.next()
  }

  // Load security configuration
  const config = getAdminSecurityConfig()

  // Skip if security is disabled
  if (!config.enabled) {
    return NextResponse.next()
  }

  // Environment restriction check
  if (config.environmentRestriction.enabled && !isAllowedEnvironment(config)) {
    logger.warn("Admin access attempt in restricted environment", {
      environment: process.env.VERCEL_ENV || process.env.NODE_ENV || "development",
    })
    return new NextResponse("Admin access not available in this environment", { status: 403 })
  }

  // IP restriction check
  if (config.ipRestriction.enabled && !isAllowedIp(request, config)) {
    return new NextResponse("Access denied: IP not allowed", { status: 403 })
  }

  // Rate limiting check
  const rateLimit = checkRateLimit(request, config)
  if (!rateLimit.allowed) {
    return new NextResponse("Too many requests, please try again later", {
      status: 429,
      headers: {
        "Retry-After": `${rateLimit.resetAfter}`,
        "X-RateLimit-Limit": `${config.rateLimiting.maxRequests}`,
        "X-RateLimit-Reset": `${Math.floor(Date.now() / 1000) + (rateLimit.resetAfter || 0)}`,
      },
    })
  }

  // Password protection check
  if (config.passwordProtection.enabled) {
    const authHeader = request.headers.get("authorization")

    if (!verifyCredentials(authHeader, config)) {
      return new NextResponse("Authentication required", {
        status: 401,
        headers: {
          "WWW-Authenticate": 'Basic realm="Admin Area"',
        },
      })
    }
  }

  // All security checks passed
  return NextResponse.next()
}

import type React from "react"
/**
 * Common types for modules
 */

export interface ModuleConfig {
  [key: string]: string
}

export interface ModuleProps {
  config: ModuleConfig
  data?: any
}

export interface ModuleData {
  title: string
  description: string
  [key: string]: any
}

export interface ModuleLoaderProps {
  moduleName: string
  fallback?: React.ReactNode
}

export interface ModuleRouteProps {
  moduleName: string
  children: React.ReactNode
}

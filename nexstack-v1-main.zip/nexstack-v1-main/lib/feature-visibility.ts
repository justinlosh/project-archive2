import { cache } from "react"

// Create a map to store all feature statuses
const featureStatusCache = new Map<string, boolean>()

// List of known features
const knownFeatures = [
  "blog",
  "newsletter",
  "contact",
  "seo",
  "changelog",
  "sitemap",
  "colophon",
  "security-txt",
  "analytics",
  "maintenance-mode",
  "robots-txt",
  "social-media",
]

// Initialize the cache with all known features
function initializeFeatureCache() {
  for (const feature of knownFeatures) {
    const featureEnvVar = `NEXT_PUBLIC_ENABLE_${feature.toUpperCase()}`
    featureStatusCache.set(feature, process.env[featureEnvVar] === "true")
  }
}

// Initialize on module load
initializeFeatureCache()

// Cache the feature visibility check to avoid unnecessary processing
export const isFeatureEnabled = cache((featureName: string): boolean => {
  // Check if we have the status cached
  if (featureStatusCache.has(featureName)) {
    return featureStatusCache.get(featureName) || false
  }

  // If not in cache, check environment and update cache
  const featureEnvVar = `NEXT_PUBLIC_ENABLE_${featureName.toUpperCase()}`
  const isEnabled = process.env[featureEnvVar] === "true"
  featureStatusCache.set(featureName, isEnabled)

  return isEnabled
})

// Get all enabled features
export function getEnabledFeatures(): string[] {
  return Array.from(featureStatusCache.entries())
    .filter(([_, isEnabled]) => isEnabled)
    .map(([feature]) => feature)
}

/**
 * Centralized configuration service for the application
 * This reduces the need to access process.env directly throughout the codebase
 */

import { logger } from "@/lib/logger"

// Define the configuration schema with types
interface SiteConfig {
  title: string
  description: string
  url: string
  language: string
  showDocs: boolean
  githubUrl: string
  copyrightText: string
}

interface ThemeConfig {
  defaultTheme: "light" | "dark" | "system"
  fontFamily: string
  headingFontFamily: string
  primaryColor: string
  secondaryColor: string
  accentColor: string
  lightBackground: string
  lightText: string
  darkBackground: string
  darkText: string
  borderRadius: string
}

interface AnalyticsConfig {
  provider: string
  trackingId: string
  respectDoNotTrack: boolean
  debugMode: boolean
}

interface AppConfig {
  site: SiteConfig
  theme: ThemeConfig
  analytics: AnalyticsConfig
}

// Helper to parse boolean values from environment variables
function parseBoolean(value: string | undefined, defaultValue: boolean): boolean {
  if (value === undefined) return defaultValue
  return value.toLowerCase() !== "false"
}

// Build the configuration object from environment variables with defaults
export const config: AppConfig = {
  site: {
    title: process.env.NEXT_PUBLIC_SITE_TITLE || "Modular Website",
    description:
      process.env.NEXT_PUBLIC_SITE_DESCRIPTION ||
      "A modular website platform with environment variable-based feature toggling",
    url: process.env.NEXT_PUBLIC_SITE_URL || "https://example.com",
    language: process.env.NEXT_PUBLIC_SITE_LANGUAGE || "en",
    showDocs: parseBoolean(process.env.NEXT_PUBLIC_SHOW_DOCS, true),
    githubUrl: process.env.NEXT_PUBLIC_GITHUB_URL || "https://github.com/yourusername/modular-nextjs",
    copyrightText:
      process.env.NEXT_PUBLIC_COPYRIGHT_TEXT || `© ${new Date().getFullYear()} Modular Website. All rights reserved.`,
  },
  theme: {
    defaultTheme: (process.env.NEXT_PUBLIC_DEFAULT_THEME || "light") as "light" | "dark" | "system",
    fontFamily: process.env.NEXT_PUBLIC_FONT_FAMILY || "var(--font-sans)",
    headingFontFamily: process.env.NEXT_PUBLIC_HEADING_FONT_FAMILY || "var(--font-sans)",
    primaryColor: process.env.NEXT_PUBLIC_PRIMARY_COLOR || "#0070f3",
    secondaryColor: process.env.NEXT_PUBLIC_SECONDARY_COLOR || "#6c757d",
    accentColor: process.env.NEXT_PUBLIC_ACCENT_COLOR || "#f97316",
    lightBackground: process.env.NEXT_PUBLIC_LIGHT_BACKGROUND || "#ffffff",
    lightText: process.env.NEXT_PUBLIC_LIGHT_TEXT || "#1a1a1a",
    darkBackground: process.env.NEXT_PUBLIC_DARK_BACKGROUND || "#121212",
    darkText: process.env.NEXT_PUBLIC_DARK_TEXT || "#f8f9fa",
    borderRadius: process.env.NEXT_PUBLIC_BORDER_RADIUS || "0.5rem",
  },
  analytics: {
    provider: process.env.MODULE_ANALYTICS_PROVIDER || "google-analytics",
    trackingId: process.env.MODULE_ANALYTICS_TRACKING_ID || "",
    respectDoNotTrack: parseBoolean(process.env.MODULE_ANALYTICS_RESPECT_DO_NOT_TRACK, true),
    debugMode: parseBoolean(process.env.MODULE_ANALYTICS_DEBUG_MODE, false),
  },
}

/**
 * Get a specific configuration value
 * @param path Dot notation path to the configuration value (e.g., "site.title")
 * @param defaultValue Default value if the configuration value doesn't exist
 * @returns The configuration value or the default value
 */
export function getConfig<T>(path: string, defaultValue: T): T {
  try {
    const parts = path.split(".")
    let current: any = config

    for (const part of parts) {
      if (current === undefined || current === null || typeof current !== "object") {
        return defaultValue
      }
      current = current[part]
    }

    return current !== undefined ? current : defaultValue
  } catch (error) {
    logger.error(`Error retrieving config value for path: ${path}`, { error })
    return defaultValue
  }
}

/**
 * Update a configuration value at runtime (client-side only)
 * Useful for settings that can be changed by the user
 * Note: This will not persist across page loads
 *
 * @param path Dot notation path to the configuration value
 * @param value New value to set
 * @returns Whether the update was successful
 */
export function updateConfig<T>(path: string, value: T): boolean {
  try {
    const parts = path.split(".")
    const lastPart = parts.pop()

    if (!lastPart) {
      return false
    }

    let current: any = config

    // Navigate to the parent object
    for (const part of parts) {
      if (current[part] === undefined) {
        current[part] = {}
      }
      current = current[part]
    }

    // Update the value
    current[lastPart] = value
    return true
  } catch (error) {
    logger.error(`Error updating config value for path: ${path}`, { error })
    return false
  }
}

// Export the typed config
export default config

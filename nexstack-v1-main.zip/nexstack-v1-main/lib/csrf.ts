/**
 * CSRF protection utilities
 */
import type { NextRequest } from "next/server"
import { cookies } from "next/headers"
import crypto from "crypto"

// CSRF token configuration
const CSRF_SECRET = process.env.CSRF_SECRET || "default-csrf-secret-change-in-production"
const CSRF_COOKIE_NAME = "csrf-token"
const CSRF_HEADER_NAME = "X-CSRF-Token"
const CSRF_TOKEN_EXPIRY = 24 * 60 * 60 * 1000 // 24 hours

/**
 * Generates a CSRF token
 * @returns The generated CSRF token
 */
export function generateCsrfToken(): string {
  const timestamp = Date.now().toString()
  const randomBytes = crypto.randomBytes(16).toString("hex")
  const payload = `${timestamp}.${randomBytes}`

  // Create HMAC signature
  const signature = crypto.createHmac("sha256", CSRF_SECRET).update(payload).digest("hex")

  return `${payload}.${signature}`
}

/**
 * Validates a CSRF token
 * @param token The token to validate
 * @returns True if the token is valid, false otherwise
 */
export function validateCsrfToken(token: string): boolean {
  try {
    const [timestamp, randomBytes, signature] = token.split(".")

    // Check if all parts exist
    if (!timestamp || !randomBytes || !signature) {
      return false
    }

    // Check token expiry
    const tokenTime = Number.parseInt(timestamp, 10)
    if (isNaN(tokenTime) || Date.now() - tokenTime > CSRF_TOKEN_EXPIRY) {
      return false
    }

    // Verify signature
    const payload = `${timestamp}.${randomBytes}`
    const expectedSignature = crypto.createHmac("sha256", CSRF_SECRET).update(payload).digest("hex")

    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
  } catch (error) {
    console.error("CSRF token validation error:", error)
    return false
  }
}

/**
 * CSRF protection middleware
 */
export const csrf = {
  /**
   * Sets a CSRF token in cookies
   */
  setToken: () => {
    const token = generateCsrfToken()
    cookies().set({
      name: CSRF_COOKIE_NAME,
      value: token,
      httpOnly: true,
      sameSite: "strict",
      secure: process.env.NODE_ENV === "production",
      path: "/",
    })
    return token
  },

  /**
   * Verifies a CSRF token from a request
   * @param request The request to verify
   * @returns Error message if invalid, null if valid
   */
  verify: async (request: Request | NextRequest): Promise<string | null> => {
    try {
      // Get the token from the request header
      const token = request.headers.get(CSRF_HEADER_NAME)

      // Get the token from cookies
      const cookieToken = cookies().get(CSRF_COOKIE_NAME)?.value

      // Check if tokens exist
      if (!token || !cookieToken) {
        return "CSRF token missing"
      }

      // Check if tokens match
      if (token !== cookieToken) {
        return "CSRF token mismatch"
      }

      // Validate the token
      if (!validateCsrfToken(token)) {
        return "Invalid CSRF token"
      }

      return null
    } catch (error) {
      console.error("CSRF verification error:", error)
      return "CSRF verification failed"
    }
  },
}

/**
 * Error handling utilities for the application
 *
 * This module provides consistent error handling patterns for the application,
 * including logging, fallbacks, and API error responses.
 */

import { logger } from "@/lib/logger"

/**
 * Custom error classes for specific error types
 */
export class ValidationError extends Error {
  constructor(
    message: string,
    public details?: any,
  ) {
    super(message)
    this.name = "ValidationError"
  }
}

export class AuthError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "AuthError"
  }
}

export class NotFoundError extends Error {
  constructor(message: string) {
    super(message)
    this.name = "NotFoundError"
  }
}

/**
 * Error handler type for consistent error handling
 */
export type ErrorHandler = (error: unknown, context?: Record<string, any>) => void

/**
 * Default error handler that logs errors
 */
export const defaultErrorHandler: ErrorHandler = (error, context) => {
  // Extract meaningful error information
  const errorMessage = error instanceof Error ? error.message : String(error)
  const errorName = error instanceof Error ? error.name : "Unknown Error"
  const errorStack = error instanceof Error ? error.stack : undefined

  // Log with appropriate level based on error type
  if (error instanceof ValidationError) {
    logger.warn(`${errorName}: ${errorMessage}`, {
      ...context,
      details: (error as ValidationError).details,
      stack: errorStack,
    })
  } else if (error instanceof NotFoundError) {
    logger.info(`${errorName}: ${errorMessage}`, {
      ...context,
      stack: errorStack,
    })
  } else {
    logger.error(`${errorName}: ${errorMessage}`, {
      ...context,
      stack: errorStack,
    })
  }
}

/**
 * Safely executes a function and returns a fallback value if it fails
 * @param fn Function to execute
 * @param fallbackValue Fallback value to return if the function fails
 * @param errorHandler Optional custom error handler
 * @returns The result of the function or the fallback value
 */
export async function safelyExecute<T>(
  fn: () => Promise<T>,
  fallbackValue: T,
  errorHandler: ErrorHandler = defaultErrorHandler,
): Promise<T> {
  try {
    return await fn()
  } catch (error) {
    errorHandler(error, { functionName: fn.name })
    return fallbackValue
  }
}

/**
 * Safely executes a synchronous function and returns a fallback value if it fails
 * @param fn Function to execute
 * @param fallbackValue Fallback value to return if the function fails
 * @param errorHandler Optional custom error handler
 * @returns The result of the function or the fallback value
 */
export function safelyExecuteSync<T>(
  fn: () => T,
  fallbackValue: T,
  errorHandler: ErrorHandler = defaultErrorHandler,
): T {
  try {
    return fn()
  } catch (error) {
    errorHandler(error, { functionName: fn.name })
    return fallbackValue
  }
}

/**
 * Creates a wrapped function with error handling
 * @param fn Function to wrap with error handling
 * @param errorHandler Optional custom error handler
 * @returns Wrapped function that handles errors
 */
export function withErrorHandling<T extends (...args: any[]) => Promise<any>>(
  fn: T,
  errorHandler: ErrorHandler = defaultErrorHandler,
): (...args: Parameters<T>) => Promise<ReturnType<T> | undefined> {
  return async (...args: Parameters<T>): Promise<ReturnType<T> | undefined> => {
    try {
      return await fn(...args)
    } catch (error) {
      // Mask sensitive arguments in logs
      const safeArgs = args.map((arg) =>
        typeof arg === "object" && arg !== null
          ? Object.fromEntries(
              Object.entries(arg).map(([k, v]) => (/pass|token|key|secret|auth/i.test(k) ? [k, "[REDACTED]"] : [k, v])),
            )
          : arg,
      )

      errorHandler(error, {
        functionName: fn.name,
        arguments: safeArgs,
      })
      return undefined
    }
  }
}

/**
 * Standardized API error response interface
 */
export interface ApiErrorResponse {
  success: false
  code: string
  message: string
  details?: any
}

/**
 * Standardized API error handling
 * @param error The error to handle
 * @param errorHandler Optional custom error handler
 * @returns Standardized error response
 */
export function handleApiError(error: unknown, errorHandler: ErrorHandler = defaultErrorHandler): Response {
  errorHandler(error, { context: "API" })

  // Determine error type and return appropriate response
  if (error instanceof ValidationError) {
    return Response.json(
      {
        success: false,
        code: "VALIDATION_ERROR",
        message: "Invalid input data",
        details: error.details,
      } as ApiErrorResponse,
      { status: 400 },
    )
  }

  if (error instanceof AuthError) {
    return Response.json(
      {
        success: false,
        code: "AUTH_ERROR",
        message: "Authentication required",
      } as ApiErrorResponse,
      { status: 401 },
    )
  }

  if (error instanceof NotFoundError) {
    return Response.json(
      {
        success: false,
        code: "NOT_FOUND",
        message: "Resource not found",
      } as ApiErrorResponse,
      { status: 404 },
    )
  }

  // Default case - don't expose internal error details
  return Response.json(
    {
      success: false,
      code: "INTERNAL_ERROR",
      message: "An unexpected error occurred",
    } as ApiErrorResponse,
    { status: 500 },
  )
}

/**
 * Wrapper for API handlers to standardize error handling
 * @param handler API route handler function
 * @returns Wrapped handler with standardized error handling
 */
export function withApiErrorHandling<T extends (...args: any[]) => Promise<Response>>(
  handler: T,
): (...args: Parameters<T>) => Promise<Response> {
  return async (...args: Parameters<T>): Promise<Response> => {
    try {
      return await handler(...args)
    } catch (error) {
      return handleApiError(error)
    }
  }
}

/**
 * Create a validation function that throws a ValidationError on failure
 * @param validator Function that returns true if validation passes
 * @param errorMessage Message to include in the ValidationError
 * @returns Function that throws a ValidationError if validation fails
 */
export function createValidator<T>(validator: (value: T) => boolean, errorMessage: string): (value: T) => void {
  return (value: T) => {
    if (!validator(value)) {
      throw new ValidationError(errorMessage)
    }
  }
}

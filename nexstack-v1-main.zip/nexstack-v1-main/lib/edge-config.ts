import { createClient } from "@vercel/edge-config"

// Create an Edge Config client
export const edgeConfig = createClient(process.env.EDGE_CONFIG_ID || "")

/**
 * Check if an IP address is allowed to access the admin area
 * @param ip The IP address to check
 * @returns True if the IP is allowed, false otherwise
 */
export async function isAllowedIpFromEdgeConfig(ip: string): Promise<boolean> {
  try {
    if (!process.env.EDGE_CONFIG_ID) {
      // If Edge Config is not configured, fall back to environment variables
      return true
    }

    const allowedIps = (await edgeConfig.get("adminAllowedIps")) as string[]
    if (!allowedIps || !Array.isArray(allowedIps)) {
      return false
    }

    return allowedIps.includes(ip)
  } catch (error) {
    console.error("Error checking IP in Edge Config:", error)
    // In case of error, deny access
    return false
  }
}

/**
 * Check if a user has admin access
 * @param username The username to check
 * @param passwordHash The password hash to check
 * @returns True if the user has admin access, false otherwise
 */
export async function verifyAdminCredentialsFromEdgeConfig(username: string, passwordHash: string): Promise<boolean> {
  try {
    if (!process.env.EDGE_CONFIG_ID) {
      // If Edge Config is not configured, fall back to environment variables
      return true
    }

    const adminUsers = (await edgeConfig.get("adminUsers")) as Record<string, string>
    if (!adminUsers || typeof adminUsers !== "object") {
      return false
    }

    return adminUsers[username] === passwordHash
  } catch (error) {
    console.error("Error verifying admin credentials in Edge Config:", error)
    // In case of error, deny access
    return false
  }
}

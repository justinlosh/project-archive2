/**
 * Enhanced caching utilities for the application
 */

import { logger } from "@/lib/logger"

type CacheEntry<T> = {
  data: T
  timestamp: number
  ttl: number
  tags?: string[]
}

/**
 * A versatile caching system with key/value storage, TTL, and tag-based invalidation
 */
class ModuleCache {
  private cache = new Map<string, CacheEntry<any>>()
  private pendingPromises = new Map<string, Promise<any>>()
  private readonly DEFAULT_TTL = 60000 // 1 minute default TTL
  private readonly CACHE_SIZE_LIMIT = 100 // Maximum number of items in the cache
  private tagIndex = new Map<string, Set<string>>() // Maps tags to sets of keys

  // Automatic cleanup interval
  private cleanupInterval: NodeJS.Timeout | null = null

  constructor() {
    // Set up cleanup interval if we're in a browser or Node.js environment
    if (typeof setInterval !== "undefined") {
      this.cleanupInterval = setInterval(() => this.cleanup(), 60000) // Run cleanup every minute
    }
  }

  /**
   * Get a value from the cache
   * @param key Cache key
   * @param ttl Override TTL for this specific retrieval
   * @returns The cached value or undefined if not found or expired
   */
  get<T>(key: string, ttl = this.DEFAULT_TTL): T | undefined {
    const entry = this.cache.get(key)

    if (!entry) {
      return undefined
    }

    // Use the minimum of the specified TTL and the entry's TTL
    const effectiveTtl = Math.min(ttl, entry.ttl)

    // Check if the entry has expired
    if (Date.now() - entry.timestamp > effectiveTtl) {
      this.delete(key)
      return undefined
    }

    return entry.data
  }

  /**
   * Set a value in the cache
   * @param key Cache key
   * @param data Data to cache
   * @param ttl TTL in milliseconds
   * @param tags Optional tags for grouped invalidation
   */
  set<T>(key: string, data: T, ttl = this.DEFAULT_TTL, tags?: string[]): void {
    // Enforce cache size limit
    if (this.cache.size >= this.CACHE_SIZE_LIMIT && !this.cache.has(key)) {
      // Remove oldest entry if at capacity
      const oldestKey = this.findOldestEntry()
      if (oldestKey) {
        this.delete(oldestKey)
      }
    }

    // Store the entry
    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl,
      tags,
    })

    // Index the entry by tags if provided
    if (tags && tags.length > 0) {
      tags.forEach((tag) => {
        if (!this.tagIndex.has(tag)) {
          this.tagIndex.set(tag, new Set<string>())
        }
        this.tagIndex.get(tag)?.add(key)
      })
    }
  }

  /**
   * Delete a value from the cache
   * @param key Cache key
   */
  delete(key: string): void {
    const entry = this.cache.get(key)

    // Remove from tag index if the entry has tags
    if (entry?.tags) {
      entry.tags.forEach((tag) => {
        const taggedKeys = this.tagIndex.get(tag)
        if (taggedKeys) {
          taggedKeys.delete(key)
          // Clean up empty tag sets
          if (taggedKeys.size === 0) {
            this.tagIndex.delete(tag)
          }
        }
      })
    }

    this.cache.delete(key)
    this.pendingPromises.delete(key)
  }

  /**
   * Invalidate all entries with a specific tag
   * @param tag Tag to invalidate
   * @returns Number of invalidated entries
   */
  invalidateByTag(tag: string): number {
    const taggedKeys = this.tagIndex.get(tag)
    if (!taggedKeys) {
      return 0
    }

    let count = 0
    for (const key of taggedKeys) {
      this.delete(key)
      count++
    }

    // Clean up the tag index
    this.tagIndex.delete(tag)

    return count
  }

  /**
   * Clear the entire cache
   */
  clear(): void {
    this.cache.clear()
    this.pendingPromises.clear()
    this.tagIndex.clear()
  }

  /**
   * Get or set a value in the cache with request deduplication
   * @param key Cache key
   * @param factory Factory function to create the value if not in cache
   * @param ttl Time to live in milliseconds
   * @param tags Optional tags for grouped invalidation
   * @returns The cached or newly created value
   */
  async getOrSet<T>(key: string, factory: () => Promise<T>, ttl = this.DEFAULT_TTL, tags?: string[]): Promise<T> {
    // Check if value is in cache and not expired
    const cachedValue = this.get<T>(key, ttl)
    if (cachedValue !== undefined) {
      return cachedValue
    }

    // Check if there's already a pending promise for this key
    if (this.pendingPromises.has(key)) {
      return this.pendingPromises.get(key) as Promise<T>
    }

    // Add timeout to the factory function
    const timeoutPromise = new Promise<T>((_, reject) => {
      setTimeout(() => reject(new Error(`Cache factory timeout for key: ${key}`)), 10000) // 10 second timeout
    })

    // Create and store the promise
    const promise = Promise.race([
      factory().then((value) => {
        this.set(key, value, ttl, tags)
        this.pendingPromises.delete(key)
        return value
      }),
      timeoutPromise,
    ]).catch((error) => {
      this.pendingPromises.delete(key)
      logger.error(`Cache factory error for key: ${key}`, { error })
      throw error
    })

    this.pendingPromises.set(key, promise)
    return promise
  }

  /**
   * Get stats about the cache
   */
  getStats() {
    const now = Date.now()
    let activeEntries = 0
    let expiredEntries = 0

    for (const [, entry] of this.cache.entries()) {
      if (now - entry.timestamp <= entry.ttl) {
        activeEntries++
      } else {
        expiredEntries++
      }
    }

    return {
      totalEntries: this.cache.size,
      activeEntries,
      expiredEntries,
      pendingPromises: this.pendingPromises.size,
      tags: this.tagIndex.size,
    }
  }

  /**
   * Clean up expired entries
   */
  private cleanup(): void {
    const now = Date.now()

    // Remove expired entries
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.delete(key)
      }
    }

    // Ensure cache doesn't exceed size limit
    while (this.cache.size > this.CACHE_SIZE_LIMIT) {
      const oldestKey = this.findOldestEntry()
      if (oldestKey) {
        this.delete(oldestKey)
      } else {
        break
      }
    }
  }

  /**
   * Find the oldest entry in the cache
   */
  private findOldestEntry(): string | null {
    let oldestKey: string | null = null
    let oldestTime = Date.now()

    for (const [key, entry] of this.cache.entries()) {
      if (entry.timestamp < oldestTime) {
        oldestTime = entry.timestamp
        oldestKey = key
      }
    }

    return oldestKey
  }

  /**
   * Stop the cleanup interval
   */
  stopCleanup(): void {
    if (this.cleanupInterval && typeof clearInterval !== "undefined") {
      clearInterval(this.cleanupInterval)
      this.cleanupInterval = null
    }
  }
}

// Export a singleton instance
export const moduleCache = new ModuleCache()

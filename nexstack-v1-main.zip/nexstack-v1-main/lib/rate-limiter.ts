/**
 * Rate limiting utility for API routes
 */

import { logger } from "@/lib/logger"

interface RateLimiterOptions {
  windowMs: number // Time window in milliseconds
  max: number // Maximum number of requests per window
  message?: string // Error message
  statusCode?: number // HTTP status code for rate limit exceeded
  keyGenerator?: (req: Request) => string // Function to generate keys
  skipSuccessfulRequests?: boolean // Whether to skip counting successful requests
  headers?: boolean // Whether to include rate limit headers in responses
}

interface RateLimitResult {
  success: boolean // Whether the request is allowed
  limit: number // The rate limit
  remaining: number // Remaining requests in the window
  reset: number // Time when the rate limit resets (timestamp)
  key: string // The key used for rate limiting
}

/**
 * Rate limiting implementation for API routes
 * Limits the number of requests based on various criteria
 */
export class RateLimiter {
  private windowMs: number
  private max: number
  private message: string
  private statusCode: number
  private keyGenerator: (req: Request) => string
  private skipSuccessfulRequests: boolean
  private includeHeaders: boolean
  private store = new Map<string, { count: number; resetTime: number }>()
  private cleanupInterval: NodeJS.Timeout | null = null

  /**
   * Create a new rate limiter
   * @param options Rate limiter options
   */
  constructor(options: RateLimiterOptions) {
    this.windowMs = options.windowMs || 60 * 1000 // Default: 1 minute
    this.max = options.max || 100 // Default: 100 requests per window
    this.message = options.message || "Too many requests, please try again later."
    this.statusCode = options.statusCode || 429 // Default: 429 Too Many Requests
    this.skipSuccessfulRequests = options.skipSuccessfulRequests || false
    this.includeHeaders = options.headers !== false // Default: true

    this.keyGenerator =
      options.keyGenerator ||
      ((req) => {
        // Default key generator uses IP or a fallback
        const forwarded = req.headers.get("x-forwarded-for")
        const ip = forwarded ? forwarded.split(",")[0].trim() : "127.0.0.1"
        return ip
      })

    this.store = new Map()

    // Set up cleanup interval to prevent memory leaks
    if (typeof setInterval !== "undefined") {
      this.cleanupInterval = setInterval(() => this.cleanup(), Math.min(this.windowMs, 60000)) // Run cleanup at least every minute
    }
  }

  /**
   * Check if a request is allowed
   * @param req The request to check
   * @returns Result of the rate limit check
   */
  async check(req: Request): Promise<RateLimitResult> {
    const key = this.keyGenerator(req)
    const now = Date.now()

    // Get or create entry
    let entry = this.store.get(key)

    if (!entry || entry.resetTime <= now) {
      // Create new entry if none exists or if the window has expired
      entry = { count: 0, resetTime: now + this.windowMs }
      this.store.set(key, entry)
    }

    // Increment count
    entry.count++

    // Check if over limit
    const remaining = Math.max(0, this.max - entry.count)
    const success = entry.count <= this.max

    if (!success) {
      logger.warn("Rate limit exceeded", {
        key,
        count: entry.count,
        limit: this.max,
        url: req.url,
        method: req.method,
      })
    }

    return {
      success,
      limit: this.max,
      remaining,
      reset: entry.resetTime,
      key,
    }
  }

  /**
   * Create a Response object for a rate-limited request
   * @param result Rate limit check result
   * @returns Response object
   */
  createLimitedResponse(result: RateLimitResult): Response {
    const headers: HeadersInit = {}

    if (this.includeHeaders) {
      headers["Retry-After"] = Math.ceil((result.reset - Date.now()) / 1000).toString()
      headers["X-RateLimit-Limit"] = this.max.toString()
      headers["X-RateLimit-Remaining"] = result.remaining.toString()
      headers["X-RateLimit-Reset"] = Math.ceil(result.reset / 1000).toString()
    }

    return new Response(this.message, {
      status: this.statusCode,
      headers,
    })
  }

  /**
   * Apply rate limiting to a handler function
   * @param handler The handler function to apply rate limiting to
   * @returns A wrapped handler function with rate limiting
   */
  middleware(handler: (req: Request) => Promise<Response>): (req: Request) => Promise<Response> {
    return async (req: Request) => {
      const result = await this.check(req)

      if (!result.success) {
        return this.createLimitedResponse(result)
      }

      // Process the request
      const response = await handler(req)

      // Add rate limit headers to the response if enabled
      if (this.includeHeaders) {
        const headers = new Headers(response.headers)
        headers.set("X-RateLimit-Limit", this.max.toString())
        headers.set("X-RateLimit-Remaining", result.remaining.toString())
        headers.set("X-RateLimit-Reset", Math.ceil(result.reset / 1000).toString())

        return new Response(response.body, {
          status: response.status,
          statusText: response.statusText,
          headers,
        })
      }

      // If successful requests should be skipped, decrement the counter
      if (this.skipSuccessfulRequests && response.status >= 200 && response.status < 400) {
        const entry = this.store.get(result.key)
        if (entry && entry.count > 0) {
          entry.count--
        }
      }

      return response
    }
  }

  /**
   * Clean up expired entries
   */
  private cleanup() {
    const now = Date.now()

    for (const [key, entry] of this.store.entries()) {
      if (entry.resetTime <= now) {
        this.store.delete(key)
      }
    }

    // Log cleanup stats if there are many entries
    if (this.store.size > 1000) {
      logger.info("Rate limiter store cleanup", { storeSize: this.store.size })
    }
  }

  /**
   * Clear the interval and store
   */
  public clear() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval)
      this.cleanupInterval = null
    }
    this.store.clear()
  }
}

/**
 * Create a global rate limiter instance with default settings
 */
export const globalRateLimiter = new RateLimiter({
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  message: "Too many requests from this IP, please try again later.",
  headers: true,
})

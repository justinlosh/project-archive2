import fs from "fs"
import path from "path"
import { remark } from "remark"
import html from "remark-html"
import prism from "remark-prism"

export async function getMarkdownContent(filePath: string) {
  try {
    const fullPath = path.join(process.cwd(), filePath)
    const fileContents = fs.readFileSync(fullPath, "utf8")

    // Use remark to convert markdown into HTML string
    const processedContent = await remark().use(html, { sanitize: false }).use(prism).process(fileContents)

    const contentHtml = processedContent.toString()

    return contentHtml
  } catch (error) {
    console.error(`Error reading markdown file: ${filePath}`, error)
    return "<p>Documentation content not found.</p>"
  }
}

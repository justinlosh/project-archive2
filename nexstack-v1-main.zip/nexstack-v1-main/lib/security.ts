/**
 * Security utilities for the application
 *
 * This module provides functions for securing the application against common
 * web vulnerabilities, handling sensitive data, and validating user input.
 */

import crypto from "crypto"
import { logger } from "@/lib/logger"

// Import DOMPurify only in browser context
let DOMPurify: any = null
if (typeof window !== "undefined") {
  import("dompurify").then((module) => {
    DOMPurify = module.default
  })
}

/**
 * Generate a secure hash of a string using SHA-256
 * @param input - The string to hash
 * @returns The hashed string
 */
export function getHash(input: string): string {
  return crypto.createHash("sha256").update(input).digest("hex")
}

/**
 * Hash a password with a salt using PBKDF2
 * @param password - The password to hash
 * @param salt - Optional salt (will be generated if not provided)
 * @returns Object containing the hash and salt
 */
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  // Generate a random salt if not provided
  const useSalt = salt || crypto.randomBytes(16).toString("hex")

  // Use PBKDF2 with 100,000 iterations for secure password hashing
  const hash = crypto.pbkdf2Sync(password, useSalt, 100000, 64, "sha512").toString("hex")

  return { hash, salt: useSalt }
}

/**
 * Verify a password against a stored hash
 * @param password - The password to verify
 * @param storedHash - The stored hash
 * @param salt - The salt used for hashing
 * @returns Whether the password is correct
 */
export function verifyPassword(password: string, storedHash: string, salt: string): boolean {
  const { hash } = hashPassword(password, salt)
  return hash === storedHash
}

/**
 * Securely store sensitive data with encryption
 * @param key - The key to store the data under
 * @param data - The data to store
 * @param encryptionKey - Optional encryption key (uses env variable if not provided)
 * @returns Whether the operation was successful
 */
export function secureStore(key: string, data: string, encryptionKey?: string): boolean {
  try {
    // Use provided key or fallback to environment variable
    const secretKey = encryptionKey || process.env.ENCRYPTION_KEY || "default-secure-key-change-in-production"

    // Generate initialization vector
    const iv = crypto.randomBytes(16)

    // Create cipher
    const cipher = crypto.createCipheriv(
      "aes-256-gcm",
      crypto.createHash("sha256").update(secretKey).digest().slice(0, 32),
      iv,
    )

    // Encrypt the data
    let encrypted = cipher.update(data, "utf8", "hex")
    encrypted += cipher.final("hex")

    // Get authentication tag
    const authTag = cipher.getAuthTag().toString("hex")

    // Store in a secure storage (using localStorage for demo, use a more secure method in production)
    if (typeof window !== "undefined") {
      const secureData = JSON.stringify({
        iv: iv.toString("hex"),
        data: encrypted,
        authTag,
      })
      localStorage.setItem(`secure_${key}`, secureData)
    } else {
      // For server-side, you would use a secure database or other storage
      logger.info(`Server-side secure storage for ${key} would be implemented here`)
    }

    return true
  } catch (error) {
    logger.error("Error in secureStore:", error)
    return false
  }
}

/**
 * Securely retrieve stored sensitive data
 * @param key - The key the data was stored under
 * @param encryptionKey - Optional encryption key (uses env variable if not provided)
 * @returns The decrypted data or null if retrieval failed
 */
export function secureRetrieve(key: string, encryptionKey?: string): string | null {
  try {
    // Use provided key or fallback to environment variable
    const secretKey = encryptionKey || process.env.ENCRYPTION_KEY || "default-secure-key-change-in-production"

    let secureData: { iv: string; data: string; authTag: string } | null = null

    // Retrieve from storage
    if (typeof window !== "undefined") {
      const storedData = localStorage.getItem(`secure_${key}`)
      if (!storedData) return null
      secureData = JSON.parse(storedData)
    } else {
      // For server-side, you would retrieve from a secure database or other storage
      logger.info(`Server-side secure retrieval for ${key} would be implemented here`)
      return null
    }

    if (!secureData) return null

    // Convert hex strings back to buffers
    const iv = Buffer.from(secureData.iv, "hex")
    const authTag = Buffer.from(secureData.authTag, "hex")

    // Create decipher
    const decipher = crypto.createDecipheriv(
      "aes-256-gcm",
      crypto.createHash("sha256").update(secretKey).digest().slice(0, 32),
      iv,
    )

    // Set auth tag
    decipher.setAuthTag(authTag)

    // Decrypt the data
    let decrypted = decipher.update(secureData.data, "hex", "utf8")
    decrypted += decipher.final("utf8")

    return decrypted
  } catch (error) {
    logger.error("Error in secureRetrieve:", error)
    return null
  }
}

/**
 * Sanitize module configuration to remove sensitive data
 * This prevents exposing sensitive environment variables to the client
 * @param config - The configuration object to sanitize
 * @returns A sanitized copy of the configuration
 */
export function sanitizeConfig(config: Record<string, string>): Record<string, string> {
  const safeConfig: Record<string, string> = {}

  // Sensitive key patterns to filter out
  const sensitivePatterns = [/key/i, /secret/i, /password/i, /token/i, /private/i, /auth/i, /credential/i]

  // Copy only non-sensitive keys
  Object.entries(config).forEach(([key, value]) => {
    // Skip keys that might contain sensitive information
    const isSensitive = sensitivePatterns.some((pattern) => pattern.test(key))
    if (!isSensitive) {
      safeConfig[key] = value
    } else {
      // Instead of skipping entirely, add a placeholder to indicate a value exists
      safeConfig[key] = "[REDACTED]"
      logger.debug(`Redacted sensitive configuration key: ${key}`)
    }
  })

  return safeConfig
}

/**
 * Validate email format
 * @param email - The email to validate
 * @returns Whether the email is valid
 */
export function validateEmail(email: string): boolean {
  // RFC 5322 compliant email regex
  const emailRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/
  return emailRegex.test(email)
}

/**
 * Sanitizes user input to prevent XSS attacks using DOMPurify
 * @param input - The user input to sanitize
 * @returns Sanitized input string
 */
export function sanitizeInput(input: string): string {
  if (typeof input !== "string") {
    return ""
  }

  // Use DOMPurify in browser environments
  if (typeof window !== "undefined" && DOMPurify) {
    return DOMPurify.sanitize(input, {
      ALLOWED_TAGS: [], // Only allow text, no HTML
      ALLOWED_ATTR: [], // No attributes
    })
  }

  // Basic sanitization for server-side contexts
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;")
}

/**
 * Safely merges objects without risking prototype pollution
 * @param objects - Objects to merge
 * @returns A new merged object
 */
export function safeMerge(...objects: Record<string, any>[]): Record<string, any> {
  // Create a new object with no prototype
  const result = Object.create(null)

  for (const obj of objects) {
    if (obj && typeof obj === "object") {
      // Only copy own properties
      for (const key of Object.keys(obj)) {
        // Avoid __proto__, constructor, etc.
        if (key !== "__proto__" && key !== "constructor" && key !== "prototype") {
          result[key] = obj[key]
        }
      }
    }
  }

  return result
}

/**
 * Generate a CSRF token
 * @param secret - The secret to use for generating the token
 * @returns A CSRF token
 */
export function generateCsrfToken(secret: string): string {
  const timestamp = Date.now().toString()
  const randomString = crypto.randomBytes(16).toString("hex")
  const payload = `${timestamp}:${randomString}`
  const hmac = crypto.createHmac("sha256", secret)
  const signature = hmac.update(payload).digest("hex")

  return `${payload}:${signature}`
}

/**
 * Verify a CSRF token
 * @param token - The token to verify
 * @param secret - The secret used to generate the token
 * @param maxAge - The maximum age of the token in milliseconds (default: 1 hour)
 * @returns Whether the token is valid
 */
export function verifyCsrfToken(token: string, secret: string, maxAge = 3600000): boolean {
  try {
    const [timestamp, randomString, signature] = token.split(":")
    const payload = `${timestamp}:${randomString}`

    // Verify timestamp is not too old
    const tokenAge = Date.now() - Number.parseInt(timestamp, 10)
    if (tokenAge > maxAge) {
      return false
    }

    // Verify signature
    const hmac = crypto.createHmac("sha256", secret)
    const expectedSignature = hmac.update(payload).digest("hex")

    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature))
  } catch (error) {
    logger.error("CSRF token verification failed", { error })
    return false
  }
}

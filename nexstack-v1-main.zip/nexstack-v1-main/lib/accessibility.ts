/**
 * Accessibility utilities for the application
 */

/**
 * Generates a unique ID for accessibility purposes
 * @param prefix Prefix for the ID
 * @returns A unique ID
 */
export function generateId(prefix = "id"): string {
  return `${prefix}-${Math.random().toString(36).substring(2, 9)}`
}

/**
 * Creates props for an accessible accordion
 * @param id Base ID for the accordion
 * @returns Props for the accordion
 */
export function createAccordionA11yProps(id: string) {
  return {
    button: (index: number) => ({
      id: `${id}-header-${index}`,
      "aria-controls": `${id}-panel-${index}`,
    }),
    panel: (index: number) => ({
      id: `${id}-panel-${index}`,
      "aria-labelledby": `${id}-header-${index}`,
    }),
  }
}

/**
 * Creates props for an accessible dialog
 * @param id Base ID for the dialog
 * @returns Props for the dialog
 */
export function createDialogA11yProps(id: string) {
  return {
    dialog: {
      id: `${id}-dialog`,
      "aria-labelledby": `${id}-title`,
      "aria-describedby": `${id}-description`,
    },
    title: {
      id: `${id}-title`,
    },
    description: {
      id: `${id}-description`,
    },
  }
}

/**
 * Create accessibility props for form fields
 * This helps ensure proper accessibility for form fields
 */
export function createFormFieldA11yProps(id: string, hasError = false) {
  return {
    label: {
      htmlFor: id,
      id: `${id}-label`,
    },
    input: {
      id,
      "aria-labelledby": `${id}-label`,
      "aria-invalid": hasError,
      "aria-describedby": hasError ? `${id}-error` : undefined,
    },
    error: {
      id: `${id}-error`,
      role: "alert",
    },
  }
}

import { validModules } from "./module-config"
import { getModuleStatus } from "./module-status"

// Get module data (metadata, not the component)
export async function getModuleData(moduleName: string): Promise<any> {
  // Security check - only allow known modules
  if (!validModules.includes(moduleName)) {
    console.error(`Invalid module data requested: ${moduleName}`)
    return null
  }

  try {
    // Dynamic import with error handling
    const module = await import(`@/modules/${moduleName}/data`)
    return module.default || module
  } catch (error) {
    console.error(`Failed to load module data for ${moduleName}:`, error)
    return { name: moduleName, enabled: getModuleStatus(moduleName) }
  }
}

/**
 * Consolidated Module System
 *
 * This file contains all module-related functionality in one place to avoid import issues.
 */

import React from "react";
import { notFound } from "next/navigation";
import { logger } from "@/lib/logger";
import { moduleCache } from "@/lib/cache";

// Type definitions
export interface ModuleMetadata {
  name: string;
  description: string;
  enabled: boolean;
  optional: boolean;
  dependencies: string[];
  routes: string[];
}

// List of valid modules for security
export const validModules = [
  "blog",
  "newsletter",
  "contact",
  "seo",
  "changelog",
  "sitemap",
  "colophon",
  "security-txt",
  "analytics",
  "maintenance-mode",
  "robots-txt",
  "social-media",
  "admin-security",
];

// Module component cache
const moduleComponentCache: Record<string, any> = {};
const moduleDataCache: Record<string, any> = {};

/**
 * Check if a module is enabled based on environment variables
 */
export function isModuleEnabled(moduleName: string): boolean {
  // Special case for module-manager which is always enabled
  if (moduleName === "module-manager") {
    return true;
  }

  if (!validModules.includes(moduleName)) {
    logger.warn(`Invalid module requested: ${moduleName}`);
    return false;
  }

  const envVarName = `MODULE_${moduleName.replace(/-/g, "_").toUpperCase()}`;
  const envValue = process.env[envVarName];

  return envValue === "true" || envValue === "1" || envValue === "yes";
}

/**
 * Get module status - whether it's enabled or not
 */
export function getModuleStatus(moduleName: string): boolean {
  return isModuleEnabled(moduleName);
}

/**
 * Get all enabled modules
 */
export function getEnabledModules(): string[] {
  return validModules.filter(isModuleEnabled);
}

/**
 * Get all disabled modules
 */
export function getDisabledModules(): string[] {
  return validModules.filter((name) => !isModuleEnabled(name));
}

/**
 * Get module configuration from environment variables
 */
export function getModuleConfig(moduleName: string): Record<string, string> {
  if (!validModules.includes(moduleName)) {
    logger.warn(`Invalid module config requested: ${moduleName}`);
    return {};
  }

  const config: Record<string, string> = {};
  const prefix = `MODULE_${moduleName.replace(/-/g, "_").toUpperCase()}_`;

  if (typeof process !== "undefined" && process.env) {
    Object.entries(process.env).forEach(([key, value]) => {
      if (key.startsWith(prefix) && value !== undefined) {
        const configKey = key.replace(prefix, "");
        config[configKey] = value;
      }
    });
  }

  return config;
}

/**
 * Update module configuration
 * @param moduleName The module name to update configuration for
 * @param config The new configuration values
 * @returns Boolean indicating success
 */
export async function updateModuleConfig(moduleName: string, config: Record<string, string>): Promise<boolean> {
  if (!validModules.includes(moduleName)) {
    logger.warn(`Invalid module config update requested: ${moduleName}`);
    return false;
  }

  try {
    // In a real implementation, this would update environment variables
    // or a database. For now, we'll just log the update.
    logger.info(`Updating config for module ${moduleName}:`, config);

    // Invalidate any cached data for this module
    invalidateModuleCache(moduleName);

    // Return success
    return true;
  } catch (error) {
    logger.error(`Failed to update config for module ${moduleName}:`, error as Error);
    return false;
  }
}

/**
 * Get sanitized module configuration safe for client exposure
 */
export function getSafeModuleConfig(moduleName: string): Record<string, string> {
  // For security, we only return non-sensitive config values
  const config = getModuleConfig(moduleName);

  // Filter out any keys that might contain sensitive information
  const sensitiveKeywords = ["password", "secret", "key", "token", "auth"];

  return Object.fromEntries(
    Object.entries(config).filter(([key]) => !sensitiveKeywords.some((keyword) => key.toLowerCase().includes(keyword))),
  );
}

/**
 * Validate module configuration for dependencies
 */
export function validateModuleConfiguration(): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const enabledModules = getEnabledModules();

  // Check for missing dependencies
  for (const moduleName of enabledModules) {
    const moduleData = moduleDataCache[moduleName];
    if (moduleData && moduleData.dependencies) {
      for (const dependency of moduleData.dependencies) {
        if (!isModuleEnabled(dependency)) {
          errors.push(`Module ${moduleName} depends on ${dependency}, but ${dependency} is not enabled`);
        }
      }
    }
  }

  // Check for circular dependencies
  const dependencyGraph: Record<string, string[]> = {};
  for (const moduleName of enabledModules) {
    const moduleData = moduleDataCache[moduleName];
    if (moduleData && moduleData.dependencies) {
      dependencyGraph[moduleName] = moduleData.dependencies;
    } else {
      dependencyGraph[moduleName] = [];
    }
  }

  const visited = new Set<string>();
  const recursionStack = new Set<string>();

  function detectCycle(node: string): boolean {
    if (!visited.has(node)) {
      visited.add(node);
      recursionStack.add(node);

      const dependencies = dependencyGraph[node] || [];
      for (const dependency of dependencies) {
        if (!visited.has(dependency) && detectCycle(dependency)) {
          return true;
        } else if (recursionStack.has(dependency)) {
          errors.push(`Circular dependency detected: ${node} -> ${dependency}`);
          return true;
        }
      }
    }

    recursionStack.delete(node);
    return false;
  }

  for (const moduleName of enabledModules) {
    if (!visited.has(moduleName)) {
      detectCycle(moduleName);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

/**
 * Clear all module caches
 */
export function clearModuleCaches(): void {
  Object.keys(moduleComponentCache).forEach((key) => {
    delete moduleComponentCache[key];
  });

  Object.keys(moduleDataCache).forEach((key) => {
    delete moduleDataCache[key];
  });
}

/**
 * React component to load and render a module
 */
export async function ModuleLoader({
  moduleName,
  fallback = null,
  props = {},
}: {
  moduleName: string;
  fallback?: React.ReactNode;
  props?: Record<string, any>;
}): Promise<React.ReactNode> {
  const isEnabled = getModuleStatus(moduleName);

  if (!isEnabled) {
    return fallback;
  }

  try {
    if (!moduleComponentCache[moduleName]) {
      const moduleImport = await import(`@/modules/${moduleName}/component`);
      moduleComponentCache[moduleName] = moduleImport.default || moduleImport;
    }

    const ModuleComponent = moduleComponentCache[moduleName] as React.ComponentType<any>;
    const moduleConfig = getSafeModuleConfig(moduleName);

    return React.createElement(ModuleComponent, { config: moduleConfig, ...props });
  } catch (error) {
    logger.error(`Failed to load module: ${moduleName}`, error as Error);
    return fallback;
  }
}

/**
 * React component to handle module routes
 */
export function ModuleRoute({
  moduleName,
  children,
}: {
  moduleName: string;
  children: React.ReactNode;
}): React.ReactElement {
  const isEnabled = getModuleStatus(moduleName);

  if (!isEnabled) {
    notFound();
  }

  return React.createElement(React.Fragment, null, children);
}

/**
 * Invalidate module cache for a specific module
 * @param moduleName The module name to invalidate cache for
 */
export function invalidateModuleCache(moduleName: string): void {
  if (!validModules.includes(moduleName)) {
    logger.warn(`Invalid module cache invalidation requested: ${moduleName}`);
    return;
  }

  // Invalidate all module-related cache entries
  moduleCache.invalidateByTag(`module-${moduleName}`);

  // Clear component cache for this module
  Object.keys(moduleComponentCache).forEach((key) => {
    if (key.startsWith(`${moduleName}-`)) {
      delete moduleComponentCache[key];
    }
  });

  logger.info(`Cache invalidated for module: ${moduleName}`);
}

/**
 * Module system object that encapsulates all module-related functionality
 * This is exported as a named export to satisfy the deployment requirements
 */
export const moduleSystem = {
  isModuleEnabled,
  getModuleStatus,
  getEnabledModules,
  getDisabledModules,
  getModuleConfig,
  getSafeModuleConfig,
  validateModuleConfiguration,
  clearModuleCaches,
  ModuleLoader,
  ModuleRoute,
  invalidateModuleCache,
  updateModuleConfig,
};

import { config } from "@/lib/config"

// Get theme configuration from centralized config
export function getThemeConfig() {
  return {
    // Default theme (light, dark, system)
    defaultTheme: config.theme.defaultTheme,

    // Font configuration - using Next.js default font system
    fontFamily: config.theme.fontFamily,
    headingFontFamily: config.theme.headingFontFamily,

    // Color scheme
    primaryColor: config.theme.primaryColor,
    secondaryColor: config.theme.secondaryColor,
    accentColor: config.theme.accentColor,

    // Light mode colors
    lightBackground: config.theme.lightBackground,
    lightText: config.theme.lightText,

    // Dark mode colors
    darkBackground: config.theme.darkBackground,
    darkText: config.theme.darkText,

    // Border radius
    borderRadius: config.theme.borderRadius,
  }
}

import { isModuleEnabled } from "./module-system"
import { validModules } from "./module-config"

// Cache the module status check to avoid unnecessary processing
export function getModuleStatus(moduleName: string): boolean {
  // Security check - only allow known modules
  if (!validModules.includes(moduleName)) {
    console.error(`Invalid module name requested: ${moduleName}`)
    return false
  }

  return isModuleEnabled(moduleName)
}

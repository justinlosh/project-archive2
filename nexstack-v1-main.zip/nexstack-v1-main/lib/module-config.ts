import { sanitizeConfig } from "@/lib/security"

// List of valid modules for security
export const validModules = [
  "blog",
  "newsletter",
  "contact",
  "seo",
  "changelog",
  "sitemap",
  "colophon",
  "security-txt",
  "analytics",
  "maintenance-mode",
  "robots-txt",
  "social-media",
]

// Get module configuration from environment variables
export function getModuleConfig(moduleName: string): Record<string, string> {
  // Security check - only allow known modules
  if (!validModules.includes(moduleName)) {
    console.error(`Invalid module config requested: ${moduleName}`)
    return {}
  }

  const config: Record<string, string> = {}
  const prefix = `MODULE_${moduleName.replace(/-/g, "_").toUpperCase()}_`

  // Get all environment variables with the module prefix
  if (typeof process !== "undefined" && process.env) {
    Object.entries(process.env).forEach(([key, value]) => {
      if (key.startsWith(prefix) && value !== undefined) {
        // Remove the prefix to get the config key
        const configKey = key.replace(prefix, "")
        config[configKey] = value
      }
    })
  }

  return sanitizeConfig(config)
}

// Get sanitized module configuration safe for client exposure
export function getSafeModuleConfig(moduleName: string): Record<string, string> {
  // Security check - only allow known modules
  if (!validModules.includes(moduleName)) {
    console.error(`Invalid module config requested: ${moduleName}`)
    return {}
  }

  return getModuleConfig(moduleName)
}

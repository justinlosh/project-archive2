import fs from "fs"
import path from "path"
import { remark } from "remark"
import html from "remark-html"
import prism from "remark-prism"
import { safelyExecute } from "@/lib/error-utils"

// Create a reusable processor
const processor = remark().use(html, { sanitize: false }).use(prism)

/**
 * Converts markdown to HTML
 * @param markdown Markdown content
 * @returns HTML content
 */
export async function markdownToHtml(markdown: string): Promise<string> {
  const result = await processor.process(markdown)
  return result.toString()
}

/**
 * Reads a markdown file and converts it to HTML
 * @param filePath Path to the markdown file
 * @returns HTML content
 */
export async function getMarkdownContent(filePath: string): Promise<string> {
  return await safelyExecute(async () => {
    const fullPath = path.join(process.cwd(), filePath)
    const fileContents = fs.readFileSync(fullPath, "utf8")
    return await markdownToHtml(fileContents)
  }, "<p>Documentation content not found.</p>")
}

/**
 * Reads a markdown file and returns its raw content
 * @param filePath Path to the markdown file
 * @returns Raw markdown content
 */
export async function getRawMarkdownContent(filePath: string): Promise<string> {
  return await safelyExecute(async () => {
    const fullPath = path.join(process.cwd(), filePath)
    return fs.readFileSync(fullPath, "utf8")
  }, "# Content Not Found\n\nThe requested content could not be found.")
}

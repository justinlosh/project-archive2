# Base Command Meta Theme
This theme was created for usage on [meta.basecmd.com](https://meta.basecmd.com), which is powered by [Discourse](https://discourse.org).

## Structure
_The following structure is utilized in this repo._

### Assets
_```assets``` contains exported assets utilized in the theme._

### Theme
_```theme``` contains the core Discourse theme package._

### Components
_```components``` contains exported Discourse theme components, some which contain setting configurations._
* **Discourse Category Icons**: [components/discourse-category-icons](https://github.com/justinlosh/basecmd-meta-theme/tree/main/components/discourse-category-icons)
  * Source: [discourse/discourse-category-icons](https://github.com/discourse/discourse-category-icons)
  * License: [MIT License](https://github.com/discourse/discourse-category-icons?tab=MIT-1-ov-file#)

import "./styles/main.scss"
import { initApp } from "@modules/app"

// Initialize the application
document.addEventListener("DOMContentLoaded", () => {
  initApp()
})

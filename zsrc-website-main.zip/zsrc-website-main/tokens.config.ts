import { defineTheme } from 'pinceau'

export default defineTheme({
})

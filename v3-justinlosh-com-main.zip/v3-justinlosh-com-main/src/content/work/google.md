---
company: "Google"
role: "Staff Software Engineer"
dateStart: "11/27/2022"
dateEnd: "Current"
---

Sit amet consectetur adipisicing elit. Iure illo neque tempora, voluptatem est quaerat voluptas praesentium ipsa dolorem dignissimos nulla ratione distinctio quae maiores eligendi nostrum? Quibusdam, debitis voluptatum, lorem ipsum dolor.
---
title: "Draft example"
description: "Setting draft flag to true to hide this post."
date: "12/31/2022"
draft: false
---

This post is to demonstrate the year sorting capabilities.

If you are seeing this post, edit `src/content/08-draft-example` and enter `draft: true` in the metadata.


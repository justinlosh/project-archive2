<script lang="ts" setup>

</script>

<template>
  <div class="h-screen flex items-center justify-center">
    <slot />
  </div>
</template>

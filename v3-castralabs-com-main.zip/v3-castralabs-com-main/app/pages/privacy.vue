<script lang="ts" setup>
const title = 'Privacy Policy'

useSeoMeta({
  title,
})
</script>

<template>
  <UContainer>
    <UPage>
      <UPageHeader
        :title
      />

      <!-- Use a UPageBody to build the user dashboard -->
    </UPage>
  </UContainer>
</template>

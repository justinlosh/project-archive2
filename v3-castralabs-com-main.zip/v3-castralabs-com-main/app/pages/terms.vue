<script lang="ts" setup>
const title = 'Terms of Service'

useSeoMeta({
  title,
})
</script>

<template>
  <UContainer>
    <UPage>
      <UPageHeader
        :title
      />

      <!-- Use a UPageBody to build the user dashboard -->
    </UPage>
  </UContainer>
</template>

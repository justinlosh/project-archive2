<script lang="ts" setup>

</script>

<template>
  <h2 class="text-xl font-semibold text-red-900 dark:text-white">
    <slot />
  </h2>
</template>

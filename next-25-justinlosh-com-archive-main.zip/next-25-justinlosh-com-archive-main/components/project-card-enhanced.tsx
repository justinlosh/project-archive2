import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, LinkIcon } from "lucide-react"
import { cn } from "@/lib/utils"

interface ProjectCardEnhancedProps {
  project: {
    id: number
    title: string
    description: string
    image?: string
    link?: string
    github?: string
    category?: string
    tags?: string[]
    isFeatured?: boolean
  }
  featured?: boolean
  className?: string
}

export function ProjectCardEnhanced({ project, featured = false, className }: ProjectCardEnhancedProps) {
  return (
    <div className={cn("rounded-lg border overflow-hidden bg-card", featured && "border-primary/50", className)}>
      <div className="flex flex-col md:flex-row">
        {project.image && (
          <div className="md:w-1/3 lg:w-1/4 p-6 flex items-center justify-center bg-muted/30">
            <div className="relative w-full aspect-square max-w-[200px]">
              <Image
                src={project.image || "/placeholder.svg?height=200&width=200"}
                alt={`${project.title} preview`}
                fill
                className="object-contain"
                sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                priority={featured}
              />
            </div>
          </div>
        )}
        <div className={cn("flex-1 p-6", !project.image && "md:w-full")}>
          <div className="mb-4">
            {featured && (
              <Badge className="mb-2 bg-primary/10 text-primary hover:bg-primary/20 border-0">Featured Project</Badge>
            )}
            <h3 className="text-2xl font-bold">{project.title}</h3>
            <p className="mt-2 text-muted-foreground">{project.description}</p>
          </div>

          {project.tags && project.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-6">
              {project.tags.map((tag) => (
                <Badge key={tag} variant="secondary" className="font-normal">
                  {tag}
                </Badge>
              ))}
            </div>
          )}

          <div className="flex flex-wrap gap-3 mt-auto">
            {project.github && (
              <Button variant="outline" size="sm" asChild>
                <a href={project.github} target="_blank" rel="noopener noreferrer" className="inline-flex items-center">
                  <Github className="mr-2 h-4 w-4" />
                  GitHub
                </a>
              </Button>
            )}
            {project.link && (
              <Button variant="outline" size="sm" asChild>
                <a href={project.link} target="_blank" rel="noopener noreferrer" className="inline-flex items-center">
                  <LinkIcon className="mr-2 h-4 w-4" />
                  View Project
                </a>
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { usePathname } from "next/navigation"

const footerLinks = [
  { href: "/colophon", label: "Colophon" },
  { href: "/security", label: "Security" },
  { href: "/privacy", label: "Privacy" },
  { href: "/disclaimer", label: "Disclaimer" },
  { href: "/verify", label: "Verify" },
  { href: "/contact", label: "Contact" },
]

export function FooterNav() {
  const pathname = usePathname()

  return (
    <nav className="flex flex-wrap gap-4 sm:gap-6">
      {footerLinks.map((link) => (
        <Link
          key={link.href}
          href={link.href}
          className={cn(
            "text-sm transition-colors hover:text-primary",
            pathname === link.href ? "text-foreground" : "text-muted-foreground",
          )}
        >
          {link.label}
        </Link>
      ))}
    </nav>
  )
}

"use client"

import { useState } from "react"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { formatDate } from "@/lib/utils"
import type { Note } from "@/types"

interface NotesListClientProps {
  initialNotes: Note[]
}

export function NotesListClient({ initialNotes }: NotesListClientProps) {
  const [notes] = useState<Note[]>(initialNotes)

  if (!notes.length) {
    return (
      <div className="text-center py-10">
        <p className="text-muted-foreground">No notes found.</p>
      </div>
    )
  }

  return (
    <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
      {notes.map((note) => (
        <Link key={note.slug} href={`/notes/${note.slug}`} className="group">
          <Card className="h-full transition-colors hover:border-primary/50">
            <CardHeader className="pb-3">
              <CardTitle className="line-clamp-2 text-lg font-semibold">{note.title}</CardTitle>
              <CardDescription className="line-clamp-1">{formatDate(note.date)}</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="line-clamp-3 text-sm text-muted-foreground">{note.excerpt}</p>
            </CardContent>
            <CardFooter>
              {note.category && (
                <Badge variant="secondary" className="text-xs">
                  {note.category}
                </Badge>
              )}
            </CardFooter>
          </Card>
        </Link>
      ))}
    </div>
  )
}

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface YearArchiveNavProps {
  currentYear: string
  availableYears: string[]
  className?: string
}

export function YearArchiveNav({ currentYear, availableYears, className }: YearArchiveNavProps) {
  if (!availableYears.length) {
    return null
  }

  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      <Button variant={!currentYear ? "default" : "outline"} size="sm" asChild>
        <Link href="/notes">All Years</Link>
      </Button>

      {availableYears.map((year) => (
        <Button key={year} variant={year === currentYear ? "default" : "outline"} size="sm" asChild>
          <Link href={`/notes/${year}`}>{year}</Link>
        </Button>
      ))}
    </div>
  )
}

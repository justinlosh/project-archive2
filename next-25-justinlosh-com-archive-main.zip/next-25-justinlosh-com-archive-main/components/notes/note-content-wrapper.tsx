"use client"

import dynamic from "next/dynamic"

// Import with no SSR to avoid hydration issues
const NoteContent = dynamic(() => import("./note-content").then((mod) => mod.NoteContent), {
  ssr: false,
  loading: () => (
    <div className="prose dark:prose-invert max-w-none min-h-[300px] animate-pulse bg-muted/20 rounded-md" />
  ),
})

interface NoteContentWrapperProps {
  content: string | null | undefined
}

export function NoteContentWrapper({ content }: NoteContentWrapperProps) {
  return <NoteContent content={content} />
}

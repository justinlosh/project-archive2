"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { formatDate } from "@/lib/utils"
import type { Note } from "@/types"
import { ArrowRight, Calendar } from "lucide-react"
import { useState, useCallback, useEffect, useRef } from "react"

export type PostListVariant = "compact" | "grid" | "magazine" | "simple"

interface PostListProps {
  posts: Note[]
  basePath?: string
  className?: string
  variant?: PostListVariant
  showViewAll?: boolean
  viewAllHref?: string
}

export function PostList({
  posts = [],
  basePath = "notes",
  className,
  variant = "compact",
  showViewAll = false,
  viewAllHref,
}: PostListProps) {
  const [hoveredId, setHoveredId] = useState<number | string | null>(null)
  const [mounted, setMounted] = useState(false)
  const postsRef = useRef(posts)

  useEffect(() => {
    setMounted(true)

    // Update ref if props change
    if (posts !== postsRef.current) {
      postsRef.current = posts
    }

    return () => setMounted(false)
  }, [posts])

  const handleMouseEnter = useCallback((id: number | string) => {
    setHoveredId(id)
  }, [])

  const handleMouseLeave = useCallback(() => {
    setHoveredId(null)
  }, [])

  // Ensure posts is an array
  const safePosts = Array.isArray(postsRef.current) ? postsRef.current : []

  if (!mounted) {
    return <div className="py-6 text-center text-muted-foreground">Loading posts...</div>
  }

  if (safePosts.length === 0) {
    return <div className="py-6 text-center text-muted-foreground">No notes available.</div>
  }

  // Extract year from slug for display
  const getYearFromSlug = (slug: string): string => {
    const parts = slug.split("/")
    return parts[0] || ""
  }

  // Simple variant (used on homepage)
  if (variant === "simple") {
    return (
      <div className={cn("divide-y divide-border", className)}>
        {safePosts.map((post) => (
          <article
            key={post.id}
            className="py-4 first:pt-0 last:pb-0"
            onMouseEnter={() => handleMouseEnter(post.id)}
            onMouseLeave={handleMouseLeave}
          >
            <Link
              href={`/${basePath}/${post.slug}`}
              className="flex items-center justify-between px-1 rounded-lg transition-colors"
              aria-labelledby={`post-title-${post.id}`}
            >
              <div className="flex-1 min-w-0 pr-4">
                <h4 id={`post-title-${post.id}`} className="text-lg font-medium truncate">
                  {post.title}
                </h4>
              </div>
              <div className="flex items-center gap-3">
                <time
                  className="text-sm text-muted-foreground tabular-nums shrink-0"
                  dateTime={new Date(post.date).toISOString()}
                >
                  {formatDate(post.date)}
                </time>
                <ArrowRight
                  className={cn(
                    "h-4 w-4 text-muted-foreground transition-transform",
                    hoveredId === post.id ? "transform translate-x-1 text-primary" : "",
                  )}
                  aria-hidden="true"
                />
              </div>
            </Link>
          </article>
        ))}
      </div>
    )
  }

  // Default compact variant
  return (
    <div className={cn("space-y-1", className)}>
      {safePosts.map((post) => {
        const year = getYearFromSlug(post.slug)

        return (
          <article key={post.id} className="group">
            <Link
              href={`/${basePath}/${post.slug}`}
              className="flex items-center justify-between py-3 px-4 -mx-4 rounded-lg hover:bg-muted/50 transition-colors relative overflow-hidden"
              aria-labelledby={`post-title-${post.id}`}
            >
              <div className="flex-1 min-w-0 pr-4">
                <h3
                  id={`post-title-${post.id}`}
                  className="text-lg font-medium group-hover:text-primary transition-colors truncate"
                >
                  {post.title}
                </h3>
                <div className="flex items-center text-sm text-muted-foreground mt-1">
                  <Calendar className="mr-1 h-3.5 w-3.5" />
                  <time dateTime={new Date(post.date).toISOString()}>{formatDate(post.date)}</time>
                  {year && (
                    <>
                      <span className="mx-2">•</span>
                      <span>{year}</span>
                    </>
                  )}
                </div>
              </div>
            </Link>
          </article>
        )
      })}
    </div>
  )
}

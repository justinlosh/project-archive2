"use client"

import { useEffect, useState } from "react"
import { sanitizeText } from "@/lib/utils/sanitize"
import { useTheme } from "next-themes"

interface NoteContentProps {
  content: string | null | undefined
}

export function NoteContent({ content }: NoteContentProps) {
  const [sanitizedContent, setSanitizedContent] = useState("")
  const [mounted, setMounted] = useState(false)
  const { resolvedTheme } = useTheme()

  // Process content only on the client side
  useEffect(() => {
    setMounted(true)
    setSanitizedContent(sanitizeText(content))

    return () => setMounted(false)
  }, [content])

  // Re-process content when theme changes to handle any theme-specific styling
  useEffect(() => {
    if (mounted) {
      setSanitizedContent(sanitizeText(content))
    }
  }, [content, resolvedTheme, mounted])

  if (!mounted) {
    return <div className="prose dark:prose-invert max-w-none min-h-[200px]" />
  }

  return <div className="prose dark:prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: sanitizedContent }} />
}

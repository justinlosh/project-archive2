"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { useEffect, useState } from "react"

interface YearFilterProps {
  years: string[]
  className?: string
}

export function YearFilter({ years, className }: YearFilterProps) {
  const pathname = usePathname()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  if (!mounted) {
    return (
      <div className={cn("flex flex-wrap gap-2", className)}>
        {years.map((_, i) => (
          <div key={i} className="h-9 w-16 bg-muted rounded-md animate-pulse" />
        ))}
      </div>
    )
  }

  if (!years.length) {
    return null
  }

  // Determine if we're on a year page
  const isYearPage = pathname.match(/^\/notes\/(\d{4})$/)
  const currentYear = isYearPage ? pathname.split("/").pop() : ""

  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      <Button variant={!currentYear ? "default" : "outline"} size="sm" asChild>
        <Link href="/notes">All</Link>
      </Button>

      {years.map((year) => (
        <Button key={year} variant={year === currentYear ? "default" : "outline"} size="sm" asChild>
          <Link href={`/notes/${year}`}>{year}</Link>
        </Button>
      ))}
    </div>
  )
}

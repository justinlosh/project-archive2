"use client"

import { Button } from "@/components/ui/button"
import { Share2 } from "lucide-react"
import { useState, useCallback, useEffect, useRef } from "react"
import { toast } from "@/components/ui/use-toast"

interface ShareButtonProps {
  title: string
  url: string
}

export function ShareButton({ title, url }: ShareButtonProps) {
  const [isSharing, setIsSharing] = useState(false)
  const [mounted, setMounted] = useState(false)
  const isMountedRef = useRef(false)

  useEffect(() => {
    setMounted(true)
    isMountedRef.current = true
    return () => {
      setMounted(false)
      isMountedRef.current = false
    }
  }, [])

  const handleShare = useCallback(async () => {
    if (isSharing || !mounted) return

    setIsSharing(true)

    try {
      if (typeof navigator !== "undefined" && navigator.share) {
        await navigator.share({
          title,
          url,
        })
      } else if (typeof navigator !== "undefined" && navigator.clipboard) {
        await navigator.clipboard.writeText(url)

        // Check if component is still mounted before updating state
        if (isMountedRef.current) {
          toast({
            title: "Link copied",
            description: "The link has been copied to your clipboard.",
          })
        }
      } else {
        // Fallback for environments without clipboard API
        const textarea = document.createElement("textarea")
        textarea.value = url
        textarea.style.position = "fixed"
        document.body.appendChild(textarea)
        textarea.focus()
        textarea.select()
        document.execCommand("copy")
        document.body.removeChild(textarea)

        // Check if component is still mounted before updating state
        if (isMountedRef.current) {
          toast({
            title: "Link copied",
            description: "The link has been copied to your clipboard.",
          })
        }
      }
    } catch (error) {
      console.error("Error sharing:", error)

      // Check if component is still mounted before updating state
      if (isMountedRef.current) {
        toast({
          title: "Sharing failed",
          description: "Could not share or copy the link.",
          variant: "destructive",
        })
      }
    } finally {
      // Check if component is still mounted before updating state
      if (isMountedRef.current) {
        setIsSharing(false)
      }
    }
  }, [isSharing, title, url, mounted])

  if (!mounted) {
    return (
      <Button variant="outline" size="sm" className="gap-2 w-full sm:w-auto" disabled>
        <Share2 className="h-4 w-4" />
        Share this note
      </Button>
    )
  }

  return (
    <Button variant="outline" size="sm" className="gap-2 w-full sm:w-auto" onClick={handleShare} disabled={isSharing}>
      <Share2 className="h-4 w-4" />
      {isSharing ? "Sharing..." : "Share this note"}
    </Button>
  )
}

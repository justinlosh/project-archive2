"use client"

import dynamic from "next/dynamic"
import { Button } from "@/components/ui/button"
import { Share2 } from "lucide-react"

// Import with no SSR to avoid hydration issues
const ShareButton = dynamic(() => import("./share-button").then((mod) => mod.ShareButton), {
  ssr: false,
  loading: () => (
    <Button variant="outline" size="sm" className="gap-2 w-full sm:w-auto" disabled>
      <Share2 className="h-4 w-4" />
      Share this note
    </Button>
  ),
})

interface ShareButtonWrapperProps {
  title: string
  url: string
}

export function ShareButtonWrapper({ title, url }: ShareButtonWrapperProps) {
  return <ShareButton title={title} url={url} />
}

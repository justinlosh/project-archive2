"use client"

import Link from "next/link"
import { ChevronRight, Home } from "lucide-react"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"

interface NoteBreadcrumbProps {
  slug: string
  title: string
  className?: string
}

export function NoteBreadcrumb({ slug, title, className }: NoteBreadcrumbProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  if (!mounted) {
    return <div className={cn("h-6 animate-pulse bg-muted rounded w-full max-w-md", className)} />
  }

  // Extract year from slug
  const slugParts = slug.split("/")
  const year = slugParts[0]

  return (
    <nav aria-label="Breadcrumb" className={cn("text-sm text-muted-foreground", className)}>
      <ol className="flex items-center flex-wrap">
        <li className="flex items-center">
          <Link href="/" className="flex items-center hover:text-foreground">
            <Home className="h-3.5 w-3.5" />
            <span className="sr-only">Home</span>
          </Link>
          <ChevronRight className="h-4 w-4 mx-1" aria-hidden="true" />
        </li>
        <li className="flex items-center">
          <Link href="/notes" className="hover:text-foreground">
            Notes
          </Link>
          <ChevronRight className="h-4 w-4 mx-1" aria-hidden="true" />
        </li>
        {year && (
          <li className="flex items-center">
            <Link href={`/notes/${year}`} className="hover:text-foreground">
              {year}
            </Link>
            <ChevronRight className="h-4 w-4 mx-1" aria-hidden="true" />
          </li>
        )}
        <li className="truncate max-w-[200px] sm:max-w-xs">
          <span className="text-foreground" aria-current="page">
            {title}
          </span>
        </li>
      </ol>
    </nav>
  )
}

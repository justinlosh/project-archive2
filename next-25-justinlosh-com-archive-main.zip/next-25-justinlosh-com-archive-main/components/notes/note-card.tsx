import Link from "next/link"
import Image from "next/image"
import { format } from "date-fns"
import { Calendar } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Note } from "@/types"

interface NoteCardProps {
  note: Note
  className?: string
}

export function NoteCard({ note, className }: NoteCardProps) {
  const formattedDate = format(new Date(note.date), "MMMM d, yyyy")

  return (
    <article className={cn("group relative rounded-lg border p-5 transition-all hover:shadow-md", className)}>
      <div className="flex flex-col md:flex-row gap-6">
        {note.image && (
          <div className="relative w-full md:w-1/3 h-[200px] rounded-md overflow-hidden">
            <Image
              src={note.image || "/placeholder.svg"}
              alt={note.title}
              fill
              className="object-cover transition-transform duration-300 group-hover:scale-105"
              sizes="(max-width: 768px) 100vw, 300px"
            />
          </div>
        )}

        <div className={cn("flex flex-col", note.image ? "md:w-2/3" : "w-full")}>
          <div className="flex items-center text-sm text-muted-foreground mb-2">
            <Calendar className="mr-1 h-3 w-3" />
            <time dateTime={note.date}>{formattedDate}</time>
            {note.category && (
              <>
                <span className="mx-2">•</span>
                <span>{note.category}</span>
              </>
            )}
          </div>

          <h2 className="text-2xl font-semibold tracking-tight group-hover:text-primary transition-colors mb-2">
            <Link href={`/notes/${note.slug}`} className="after:absolute after:inset-0">
              {note.title}
            </Link>
          </h2>

          {note.excerpt && <p className="text-muted-foreground line-clamp-2 mb-2">{note.excerpt}</p>}

          {note.author && <div className="mt-auto pt-2 text-sm font-medium">By {note.author}</div>}
        </div>
      </div>
    </article>
  )
}

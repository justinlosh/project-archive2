import { env } from "@/lib/env"

interface WebsiteJSONLDProps {
  url?: string
  name?: string
  description?: string
}

export function WebsiteJSONLD({
  url = env.SITE_URL,
  name = env.SITE_NAME,
  description = env.SITE_DESCRIPTION,
}: WebsiteJSONLDProps) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    url,
    name,
    description,
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
}

interface BlogPostJSONLDProps {
  url: string
  title: string
  description: string
  datePublished: string
  dateModified?: string
  authorName?: string
  imageUrl?: string
}

export function BlogPostJSONLD({
  url,
  title,
  description,
  datePublished,
  dateModified,
  authorName = env.AUTHOR_NAME,
  imageUrl,
}: BlogPostJSONLDProps) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": url,
    },
    headline: title,
    description,
    author: {
      "@type": "Person",
      name: authorName,
    },
    datePublished,
    dateModified: dateModified || datePublished,
    publisher: {
      "@type": "Person",
      name: authorName,
    },
    ...(imageUrl && {
      image: {
        "@type": "ImageObject",
        url: imageUrl,
      },
    }),
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
}

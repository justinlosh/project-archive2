import Head from "next/head"
import { env } from "@/lib/env"

interface SEOProps {
  title?: string
  description?: string
  keywords?: string
  ogImage?: string
  ogType?: "website" | "article"
  canonicalUrl?: string
  noIndex?: boolean
}

export function SEO({
  title,
  description = env.SITE_DESCRIPTION,
  keywords = env.DEFAULT_KEYWORDS,
  ogImage,
  ogType = "website",
  canonicalUrl,
  noIndex = false,
}: SEOProps) {
  const pageTitle = title ? title + " | " + env.SITE_NAME : env.SITE_NAME

  const pageUrl = canonicalUrl || env.SITE_URL
  const imageUrl = ogImage ? `${env.SITE_URL}${ogImage}` : `${env.SITE_URL}/og-image.jpg`

  return (
    <Head>
      {/* Basic metadata */}
      <title>{pageTitle}</title>
      <meta name="description" content={description} />
      <meta name="keywords" content={keywords} />

      {/* Canonical URL */}
      <link rel="canonical" href={pageUrl} />

      {/* Open Graph */}
      <meta property="og:title" content={pageTitle} />
      <meta property="og:description" content={description} />
      <meta property="og:url" content={pageUrl} />
      <meta property="og:image" content={imageUrl} />
      <meta property="og:type" content={ogType} />
      <meta property="og:site_name" content={env.SITE_NAME} />

      {/* Twitter */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:site" content={env.TWITTER_HANDLE} />
      <meta name="twitter:title" content={pageTitle} />
      <meta name="twitter:description" content={description} />
      <meta name="twitter:image" content={imageUrl} />

      {/* No index if specified */}
      {noIndex && <meta name="robots" content="noindex, nofollow" />}
    </Head>
  )
}

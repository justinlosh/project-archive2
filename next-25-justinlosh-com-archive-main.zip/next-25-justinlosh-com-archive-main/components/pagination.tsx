import { Button } from "@/components/ui/button"
import Link from "next/link"
import { cn } from "@/lib/utils"

interface PaginationProps {
  currentPage: number
  totalPages: number
  basePath: string
  className?: string
}

export function Pagination({ currentPage, totalPages, basePath, className }: PaginationProps) {
  const hasPrevious = currentPage > 1
  const hasNext = currentPage < totalPages

  return (
    <div className={cn("flex justify-center gap-2", className)}>
      <Button variant="outline" disabled={!hasPrevious} asChild={hasPrevious}>
        {hasPrevious ? <Link href={`${basePath}/${currentPage - 1}`}>Previous</Link> : <span>Previous</span>}
      </Button>
      <Button variant="outline" disabled={!hasNext} asChild={hasNext}>
        {hasNext ? <Link href={`${basePath}/${currentPage + 1}`}>Next</Link> : <span>Next</span>}
      </Button>
    </div>
  )
}

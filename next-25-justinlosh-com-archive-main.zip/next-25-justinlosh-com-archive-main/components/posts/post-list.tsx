"use client"

import Link from "next/link"
import { cn } from "@/lib/utils"
import { formatDate } from "@/lib/utils"
import { ArrowRight, Calendar } from "lucide-react"
import { useState, useCallback } from "react"

export type PostListVariant = "compact" | "grid" | "magazine" | "simple"

interface Post {
  id: string | number
  title: string
  date: string
  excerpt?: string
}

interface PostListProps {
  posts: Post[]
  basePath?: string
  className?: string
  variant?: PostListVariant
  showViewAll?: boolean
  viewAllHref?: string
}

export function PostList({
  posts,
  basePath = "notes",
  className,
  variant = "compact",
  showViewAll = false,
  viewAllHref,
}: PostListProps) {
  const [hoveredId, setHoveredId] = useState<number | string | null>(null)

  const handleMouseEnter = useCallback((id: number | string) => {
    setHoveredId(id)
  }, [])

  const handleMouseLeave = useCallback(() => {
    setHoveredId(null)
  }, [])

  if (!posts.length) {
    return <div className="py-6 text-center text-muted-foreground">No posts available.</div>
  }

  // Simple variant (used on homepage)
  if (variant === "simple") {
    return (
      <div className={cn("divide-y divide-border", className)}>
        {posts.map((post) => (
          <article
            key={post.id}
            className="py-4 first:pt-0 last:pb-0"
            onMouseEnter={() => handleMouseEnter(post.id)}
            onMouseLeave={handleMouseLeave}
          >
            <Link
              href={`/${basePath}/${post.id}`}
              className="flex items-center justify-between px-1 rounded-lg transition-colors"
              aria-labelledby={`post-title-${post.id}`}
            >
              <div className="flex-1 min-w-0 pr-4">
                <h3 id={`post-title-${post.id}`} className="text-lg font-medium truncate">
                  {post.title}
                </h3>
              </div>
              <div className="flex items-center gap-3">
                <time
                  className="text-sm text-muted-foreground tabular-nums shrink-0"
                  dateTime={new Date(post.date).toISOString()}
                >
                  {formatDate(post.date)}
                </time>
                <ArrowRight
                  className={cn(
                    "h-4 w-4 text-muted-foreground transition-transform",
                    hoveredId === post.id ? "transform translate-x-1 text-primary" : "",
                  )}
                  aria-hidden="true"
                />
              </div>
            </Link>
          </article>
        ))}
      </div>
    )
  }

  // Compact variant
  if (variant === "compact") {
    return (
      <div className={cn("space-y-1", className)}>
        {posts.map((post) => (
          <article key={post.id} className="group">
            <Link
              href={`/${basePath}/${post.id}`}
              className="flex items-center justify-between py-3 px-4 -mx-4 rounded-lg hover:bg-muted/50 transition-colors relative overflow-hidden"
              aria-labelledby={`post-title-${post.id}`}
            >
              <div className="flex-1 min-w-0 pr-4">
                <h3
                  id={`post-title-${post.id}`}
                  className="text-lg font-medium group-hover:text-primary transition-colors truncate"
                >
                  {post.title}
                </h3>
              </div>
              <time
                className="text-sm text-muted-foreground tabular-nums shrink-0"
                dateTime={new Date(post.date).toISOString()}
              >
                {formatDate(post.date)}
              </time>
              <div
                className="absolute left-0 w-1 h-0 bg-primary transition-all duration-200 group-hover:h-full"
                aria-hidden="true"
              />
            </Link>
          </article>
        ))}
      </div>
    )
  }

  // Magazine variant
  if (variant === "magazine") {
    return (
      <div className={cn("space-y-8", className)}>
        {posts.map((post) => (
          <article key={post.id} className="group">
            <Link href={`/${basePath}/${post.id}`} className="block space-y-3">
              <div className="flex items-center text-sm text-muted-foreground">
                <Calendar className="mr-1 h-3 w-3" />
                <time dateTime={new Date(post.date).toISOString()}>{formatDate(post.date)}</time>
              </div>

              <h3 className="text-2xl font-semibold tracking-tight group-hover:text-primary transition-colors">
                {post.title}
              </h3>

              {post.excerpt && <p className="text-muted-foreground">{post.excerpt}</p>}

              <div className="flex items-center text-sm font-medium text-primary">
                Read more
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                  className="ml-1 h-4 w-4 transition-transform group-hover:translate-x-1"
                >
                  <path
                    fillRule="evenodd"
                    d="M3 10a.75.75 0 01.75-.75h10.638L10.23 5.29a.75.75 0 111.04-1.08l5.5 5.25a.75.75 0 010 1.08l-5.5 5.25a.75.75 0 11-1.04-1.08l4.158-3.96H3.75A.75.75 0 013 10z"
                    clipRule="evenodd"
                  />
                </svg>
              </div>
            </Link>
          </article>
        ))}
      </div>
    )
  }

  // Grid variant (default to this if no valid variant is provided)
  return (
    <div className={cn("grid gap-4 md:grid-cols-2", className)}>
      {posts.map((post) => (
        <article
          key={post.id}
          className="group relative overflow-hidden rounded-lg border bg-background p-5 transition-all hover:shadow-md"
        >
          <Link href={`/${basePath}/${post.id}`} className="absolute inset-0 z-10">
            <span className="sr-only">View {post.title}</span>
          </Link>

          <div className="flex flex-col space-y-2">
            <h3 className="text-xl font-semibold tracking-tight group-hover:text-primary transition-colors">
              {post.title}
            </h3>

            {post.excerpt && <p className="text-muted-foreground line-clamp-2">{post.excerpt}</p>}

            <div className="flex items-center text-sm text-muted-foreground">
              <Calendar className="mr-1 h-3 w-3" />
              <time dateTime={new Date(post.date).toISOString()}>{formatDate(post.date)}</time>
            </div>
          </div>
        </article>
      ))}
    </div>
  )
}

"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { BlueskyIcon, MastodonIcon, GithubIcon, BookIcon } from "@/components/ui/social-icons"

interface FilterOption {
  id: string
  label: string
  icon: React.ReactNode
}

interface FeedFilterProps {
  onFilterChange: (filters: string[]) => void
  className?: string
  activeFilters?: string[]
  availableFilters?: FilterOption[]
  compact?: boolean // Add compact prop
}

// Define available filters with icons
const availableFilters: FilterOption[] = [
  { id: "github", label: "GitHub", icon: <GithubIcon className="mr-2" /> },
  { id: "reading", label: "Reading", icon: <BookIcon className="mr-2" /> },
  { id: "bluesky", label: "Bluesky", icon: <BlueskyIcon className="mr-2" /> },
  { id: "mastodon", label: "Mastodon", icon: <MastodonIcon className="mr-2" /> },
]

export function FeedFilter({
  onFilterChange,
  className,
  activeFilters: externalActiveFilters,
  availableFilters: externalFilters,
  compact, // Destructure compact prop
}: FeedFilterProps) {
  // Use provided filters or default ones
  const filters = externalFilters || availableFilters

  const [activeFilters, setActiveFilters] = useState<string[]>(externalActiveFilters || filters.map((f) => f.id))

  // Update internal state when external state changes
  useEffect(() => {
    if (externalActiveFilters) {
      setActiveFilters(externalActiveFilters)
    }
  }, [externalActiveFilters])

  // Notify parent component when filters change
  useEffect(() => {
    onFilterChange(activeFilters)
  }, [activeFilters, onFilterChange])

  // Toggle a filter
  const toggleFilter = (filterId: string) => {
    setActiveFilters((prev) => {
      if (prev.includes(filterId)) {
        // Remove filter if it's the only one active, don't allow empty filters
        if (prev.length === 1) return prev
        return prev.filter((id) => id !== filterId)
      } else {
        return [...prev, filterId]
      }
    })
  }

  return (
    <div className={cn("flex flex-wrap gap-2", className)}>
      {filters.map((filter) => (
        <Button
          key={filter.id}
          variant={activeFilters.includes(filter.id) ? "default" : "outline"}
          size={compact ? "xs" : "sm"} // Adjust size based on compact prop
          onClick={() => toggleFilter(filter.id)}
          className={cn("flex items-center", compact ? "px-2 py-1 text-xs" : "px-3 py-2")} // Adjust padding and text size
        >
          {filter.icon}
          <span>{filter.label}</span>
        </Button>
      ))}
    </div>
  )
}

import { FeedItem, type FeedItemProps } from "./feed-item"
import { Github } from "lucide-react"
import Image from "next/image"
import { ActionIndicator } from "./action-indicator"

interface GitHubCommit {
  repo: string
  message: string
  branch?: string
  sha?: string
  username?: string
  avatarUrl?: string
  eventType?: string
}

interface GitHubItemProps extends Omit<FeedItemProps, "source" | "children"> {
  commit: GitHubCommit
}

export function GitHubItem({ commit, ...props }: GitHubItemProps) {
  // Determine the action based on the event type or other properties
  const getActionText = () => {
    if (!commit.eventType) return "Activity on GitHub"

    switch (commit.eventType) {
      case "PushEvent":
        return "Pushed to repository"
      case "CreateEvent":
        return commit.branch ? `Created branch ${commit.branch}` : "Created repository"
      case "PullRequestEvent":
        return "Opened pull request"
      case "IssuesEvent":
        return "Opened issue"
      case "IssueCommentEvent":
        return "Commented on issue"
      case "WatchEvent":
        return "Starred repository"
      case "ForkEvent":
        return "Forked repository"
      default:
        return "Activity on GitHub"
    }
  }

  return (
    <FeedItem source="github" {...props}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">
          {commit.avatarUrl ? (
            <div className="relative h-8 w-8 rounded-full overflow-hidden">
              <Image
                src={commit.avatarUrl || "/placeholder.svg"}
                alt={`${commit.username || "User"}'s avatar`}
                width={32}
                height={32}
                className="object-cover"
              />
            </div>
          ) : (
            <div className="bg-[#24292e] text-white p-1.5 rounded-md">
              <Github className="h-4 w-4" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <ActionIndicator action={getActionText()} source="github" />
          </div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-medium text-sm truncate">{commit.repo}</span>
            {commit.branch && <span className="px-1.5 py-0.5 bg-muted text-xs rounded-full">{commit.branch}</span>}
          </div>
          <p className="text-sm break-words">{commit.message}</p>
          {commit.sha && (
            <div className="mt-1.5">
              <code className="text-xs bg-muted px-1.5 py-0.5 rounded font-mono">{commit.sha.substring(0, 7)}</code>
            </div>
          )}
        </div>
      </div>
    </FeedItem>
  )
}

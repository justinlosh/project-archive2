"use client"

import { FeedItem, type FeedItemProps } from "./feed-item"
import { BookOpen } from "lucide-react"
import Image from "next/image"
import { useState } from "react"
import { StarRating } from "@/components/ui/star-rating"
import { ActionIndicator } from "./action-indicator"

interface Book {
  title: string
  author: string
  coverUrl?: string
  summary?: string
  status: "reading" | "read" | "to-read"
  rating?: number
  review?: string
  progress?: number
  hasRating?: boolean
}

interface ReadingItemProps extends Omit<FeedItemProps, "source" | "children"> {
  book: Book
}

export function ReadingItem({ book, ...props }: ReadingItemProps) {
  const [imageError, setImageError] = useState(false)

  // Get status text based on book status
  const getStatusText = (status: Book["status"]) => {
    switch (status) {
      case "reading":
        return "Currently reading"
      case "read":
        return "Finished reading"
      case "to-read":
        return "Added to reading list"
      default:
        return "Updated book"
    }
  }

  return (
    <FeedItem source="reading" {...props}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">
          {book.coverUrl && !imageError ? (
            <div className="relative h-12 w-8 flex-shrink-0 overflow-hidden rounded shadow-sm">
              <Image
                src={book.coverUrl || "/placeholder.svg"}
                alt={`Cover of ${book.title} by ${book.author}`}
                width={32}
                height={48}
                className="object-cover"
                onError={() => setImageError(true)}
              />
            </div>
          ) : (
            <div className="bg-[#553b08] text-white p-1.5 rounded-md">
              <BookOpen className="h-4 w-4" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <ActionIndicator action={getStatusText(book.status)} source="reading" />
          </div>
          <h3 className="font-medium text-sm line-clamp-1">{book.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-1">by {book.author}</p>

          {/* Rating display */}
          {book.rating !== undefined && (
            <div className="mt-1">
              <StarRating rating={book.rating} size="sm" showEmpty={true} />
            </div>
          )}

          {book.progress !== undefined && book.status === "reading" && (
            <div className="mt-2 w-full">
              <div className="h-1.5 w-full bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${book.progress}%` }}
                  aria-label={`${book.progress}% complete`}
                />
              </div>
              <p className="text-xs text-muted-foreground mt-1">{book.progress}% complete</p>
            </div>
          )}
        </div>
      </div>
    </FeedItem>
  )
}

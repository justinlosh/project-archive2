"use client"

import { Skeleton } from "@/components/ui/skeleton"
import { AlertCircle, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"
import { formatDistanceToNow } from "date-fns"

// Define the FeedItemType for different types of feed items
export type FeedItemType = {
  type: string
  id: string
  timestamp: Date
  url: string
} & (
  | {
      type: "github"
      github: {
        username: string
        avatarUrl: string
        repoName: string
        eventType: string
        title: string
        description: string
        url: string
      }
    }
  | {
      type: "social"
      post: {
        username: string
        displayName: string
        content: string
        avatarUrl: string
        platform: "twitter" | "mastodon" | "bluesky"
        likes?: number
        reposts?: number
        replies?: number
        hasMedia: boolean
      }
    }
  | {
      type: "reading"
      book: {
        title: string
        author: string
        coverUrl: string
        summary: string
        status: "reading" | "read" | "to-read"
        rating?: number
        progress?: number
      }
    }
  | {
      type: "lastfm"
      track: {
        title: string
        artist: string
        album: string
        albumArt: string
      }
    }
)

interface FeedProps {
  items: FeedItemType[]
  isLoading: boolean
  error: string | null
  onRetry?: () => void
}

export function Feed({ items, isLoading, error, onRetry }: FeedProps) {
  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="flex items-start space-x-4 p-4 border rounded-lg">
            <Skeleton className="h-10 w-10 rounded-full" />
            <div className="space-y-2 flex-1">
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-4 w-full" />
              <Skeleton className="h-4 w-3/4" />
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center border rounded-lg">
        <AlertCircle className="h-8 w-8 text-destructive mb-2" />
        <h3 className="text-lg font-medium">Failed to load feed</h3>
        <p className="text-sm text-muted-foreground mb-4">{error}</p>
        {onRetry && (
          <Button variant="outline" size="sm" onClick={onRetry}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Try again
          </Button>
        )}
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-8 text-center border rounded-lg">
        <p className="text-muted-foreground">No activity to display.</p>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      {items.map((item) => (
        <div key={item.id} className="p-4 border rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <div className="font-medium">
              {item.type === "github" && `GitHub: ${item.github.title}`}
              {item.type === "social" && `${item.post.platform}: ${item.post.displayName}`}
              {item.type === "reading" && `Reading: ${item.book.title}`}
              {item.type === "lastfm" && `Listening: ${item.track.title}`}
            </div>
            <div className="text-xs text-muted-foreground">
              {formatDistanceToNow(item.timestamp, { addSuffix: true })}
            </div>
          </div>
          <p className="text-sm text-muted-foreground">
            {item.type === "github" && item.github.description}
            {item.type === "social" && item.post.content}
            {item.type === "reading" && item.book.summary}
            {item.type === "lastfm" && `${item.track.artist} - ${item.track.album}`}
          </p>
        </div>
      ))}
    </div>
  )
}

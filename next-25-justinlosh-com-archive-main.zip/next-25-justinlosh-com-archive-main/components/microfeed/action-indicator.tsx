import { cn } from "@/lib/utils"

interface ActionIndicatorProps {
  action: string
  source: "github" | "bluesky" | "mastodon" | "reading" | "lastfm"
  className?: string
}

export function ActionIndicator({ action, source, className }: ActionIndicatorProps) {
  // Source-specific color schemes
  const colorSchemes = {
    github: "bg-[#24292e]/10 text-[#24292e] dark:bg-[#24292e]/20 dark:text-gray-200",
    bluesky: "bg-[#0085ff]/10 text-[#0085ff] dark:bg-[#0085ff]/20 dark:text-[#0085ff]",
    mastodon: "bg-[#6364FF]/10 text-[#6364FF] dark:bg-[#6364FF]/20 dark:text-[#6364FF]",
    reading: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
    lastfm: "bg-[#d51007]/10 text-[#d51007] dark:bg-[#d51007]/20 dark:text-[#d51007]",
  }

  return (
    <span
      className={cn(
        "px-1.5 py-0.5 text-xs rounded-full font-medium inline-flex items-center action-indicator",
        colorSchemes[source],
        className,
      )}
    >
      {action}
    </span>
  )
}

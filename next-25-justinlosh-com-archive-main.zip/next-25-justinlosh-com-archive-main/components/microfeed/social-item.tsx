import { FeedItem, type FeedItemProps } from "./feed-item"
import { MessageSquare } from "lucide-react"
import Image from "next/image"
import { BlueskyIcon, MastodonIcon } from "@/components/ui/social-icons"
import { ActionIndicator } from "./action-indicator"

interface SocialPost {
  username: string
  displayName?: string
  content: string
  avatarUrl?: string
  platform: "bluesky" | "mastodon"
  stats?: {
    likes?: number
    reposts?: number
    replies?: number
  }
  action?: string
}

interface SocialItemProps extends Omit<FeedItemProps, "source" | "children"> {
  post: SocialPost
}

export function SocialItem({ post, ...props }: SocialItemProps) {
  // Set source based on platform
  const source = post.platform as FeedItemProps["source"]

  // Platform-specific styling
  const platformColors = {
    bluesky: "bg-[#0085ff]",
    mastodon: "bg-[#6364FF]",
  }

  // Platform-specific icons
  const platformIcons = {
    bluesky: <BlueskyIcon className="h-4 w-4" />,
    mastodon: <MastodonIcon className="h-4 w-4" />,
  }

  // Determine action text based on platform and content
  const getActionText = () => {
    if (post.action) return post.action

    // Default actions based on platform
    const platformActions = {
      bluesky: "Posted on Bluesky",
      mastodon: "Posted on Mastodon",
    }

    return platformActions[post.platform]
  }

  return (
    <FeedItem source={source} {...props}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">
          {post.avatarUrl ? (
            <div className="relative h-8 w-8 rounded-full overflow-hidden">
              <Image
                src={post.avatarUrl || "/placeholder.svg"}
                alt={post.displayName || post.username}
                width={32}
                height={32}
                className="object-cover"
              />
            </div>
          ) : (
            <div className={`${platformColors[post.platform]} text-white p-1.5 rounded-md`}>
              {platformIcons[post.platform] || <MessageSquare className="h-4 w-4" />}
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <ActionIndicator action={getActionText()} source={post.platform} />
          </div>
          <div className="flex items-baseline gap-1.5 mb-1">
            {post.displayName && <span className="font-medium text-sm truncate">{post.displayName}</span>}
            <span className="text-xs text-muted-foreground truncate">@{post.username}</span>
          </div>
          <div className="text-sm break-words whitespace-pre-wrap">{post.content}</div>

          {post.stats && (
            <div className="flex gap-3 mt-2 text-xs text-muted-foreground">
              {post.stats.replies !== undefined && (
                <span className="flex items-center gap-1">
                  <MessageSquare className="h-3 w-3" />
                  {post.stats.replies}
                </span>
              )}
              {/* Could add more stats icons here */}
            </div>
          )}
        </div>
      </div>
    </FeedItem>
  )
}

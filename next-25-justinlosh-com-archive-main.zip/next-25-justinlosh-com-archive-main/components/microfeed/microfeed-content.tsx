"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Github, Music, BookOpen, ExternalLink, GitCommit, Star, GitFork } from "lucide-react"
import { BlueskyIcon } from "@/components/ui/social-icons"
import { format } from "date-fns"

interface FeedItem {
  id: string
  platform: string
  type: string
  title: string
  description?: string
  url?: string
  timestamp: string
  metadata?: Record<string, any>
}

interface MicrofeedContentProps {
  activeFilters: string[]
}

// Sample data - in a real app, this would come from APIs
const sampleFeedData: FeedItem[] = [
  {
    id: "1",
    platform: "github",
    type: "commit",
    title: "Fix responsive design issues on mobile",
    description: "Updated CSS grid layouts and improved mobile navigation",
    url: "https://github.com/justinlosh/project/commit/abc123",
    timestamp: "2024-01-15T10:30:00Z",
    metadata: { repo: "justinlosh/portfolio", additions: 45, deletions: 12 },
  },
  {
    id: "2",
    platform: "reading",
    type: "book",
    title: "Currently Reading: Clean Architecture",
    description: "By Robert C. Martin - Exploring software architecture principles",
    url: "https://goodreads.com/book/123",
    timestamp: "2024-01-14T15:20:00Z",
    metadata: { author: "Robert C. Martin", progress: "65%" },
  },
  {
    id: "3",
    platform: "bluesky",
    type: "post",
    title: "Just shipped a new feature!",
    description:
      "Excited to share the latest updates to our design system. The new components are much more accessible and performant.",
    url: "https://bsky.app/profile/justinlosh.com/post/123",
    timestamp: "2024-01-14T09:15:00Z",
    metadata: { likes: 12, reposts: 3 },
  },
  {
    id: "4",
    platform: "lastfm",
    type: "track",
    title: "Now Playing: Bohemian Rhapsody",
    description: "Queen - A Night at the Opera",
    url: "https://last.fm/music/Queen/_/Bohemian+Rhapsody",
    timestamp: "2024-01-13T20:45:00Z",
    metadata: { artist: "Queen", album: "A Night at the Opera", playcount: 47 },
  },
  {
    id: "5",
    platform: "github",
    type: "star",
    title: "Starred shadcn/ui",
    description: "Beautifully designed components built with Radix UI and Tailwind CSS",
    url: "https://github.com/shadcn/ui",
    timestamp: "2024-01-13T14:30:00Z",
    metadata: { repo: "shadcn/ui", stars: 45000 },
  },
]

const platformIcons = {
  github: Github,
  reading: BookOpen,
  bluesky: BlueskyIcon,
  lastfm: Music,
}

const typeIcons = {
  commit: GitCommit,
  star: Star,
  fork: GitFork,
  post: ExternalLink,
  book: BookOpen,
  track: Music,
}

export function MicrofeedContent({ activeFilters }: MicrofeedContentProps) {
  const [feedItems, setFeedItems] = useState<FeedItem[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate API call
    const loadFeedData = async () => {
      setIsLoading(true)
      await new Promise((resolve) => setTimeout(resolve, 1000)) // Simulate loading

      const filteredData = sampleFeedData.filter((item) => activeFilters.includes(item.platform))

      setFeedItems(filteredData)
      setIsLoading(false)
    }

    loadFeedData()
  }, [activeFilters])

  if (isLoading) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 5 }).map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="space-y-3">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-3 bg-muted rounded w-1/2"></div>
                <div className="h-3 bg-muted rounded w-full"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (feedItems.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <p className="text-muted-foreground">No activity found for the selected filters.</p>
          <p className="text-sm text-muted-foreground mt-2">Try enabling more platforms to see content.</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {feedItems.map((item) => {
        const PlatformIcon = platformIcons[item.platform as keyof typeof platformIcons]
        const TypeIcon = typeIcons[item.type as keyof typeof typeIcons] || ExternalLink

        return (
          <Card key={item.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                    <PlatformIcon className="h-5 w-5" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-2">
                    <TypeIcon className="h-4 w-4 text-muted-foreground" />
                    <Badge variant="outline" className="text-xs capitalize">
                      {item.platform}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {format(new Date(item.timestamp), "MMM d, h:mm a")}
                    </span>
                  </div>

                  <h3 className="font-semibold text-sm mb-1">{item.title}</h3>

                  {item.description && (
                    <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{item.description}</p>
                  )}

                  {item.metadata && (
                    <div className="flex flex-wrap gap-2 mb-3">
                      {Object.entries(item.metadata).map(([key, value]) => (
                        <Badge key={key} variant="secondary" className="text-xs">
                          {key}: {value}
                        </Badge>
                      ))}
                    </div>
                  )}

                  {item.url && (
                    <Button variant="outline" size="sm" asChild>
                      <a href={item.url} target="_blank" rel="noopener noreferrer" className="gap-1">
                        View
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

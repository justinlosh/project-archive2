"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Music, BookOpen, Filter } from "lucide-react"
import { BlueskyIcon } from "@/components/ui/social-icons"
import { cn } from "@/lib/utils"

interface MicrofeedSidebarProps {
  activeFilters: string[]
  onFilterChange: (filters: string[]) => void
}

const filterOptions = [
  {
    id: "github",
    label: "GitHub",
    icon: Github,
    color: "hover:text-gray-900 dark:hover:text-gray-100",
    count: 12,
  },
  {
    id: "reading",
    label: "Reading",
    icon: BookOpen,
    color: "hover:text-amber-600",
    count: 3,
  },
  {
    id: "bluesky",
    label: "Bluesky",
    icon: BlueskyIcon,
    color: "hover:text-blue-500",
    count: 8,
  },
  {
    id: "lastfm",
    label: "Last.fm",
    icon: Music,
    color: "hover:text-red-500",
    count: 15,
  },
]

const socialLinks = [
  {
    platform: "GitHub",
    url: "https://github.com/justinlosh",
    icon: Github,
    color: "hover:text-gray-900 dark:hover:text-gray-100",
    username: "@justinlosh",
  },
  {
    platform: "Bluesky",
    url: "https://bsky.app/profile/justinlosh.com",
    icon: BlueskyIcon,
    color: "hover:text-blue-500",
    username: "@justinlosh.com",
  },
  {
    platform: "Last.fm",
    url: "https://last.fm/user/justinlosh",
    icon: Music,
    color: "hover:text-red-500",
    username: "@justinlosh",
  },
  {
    platform: "Goodreads",
    url: "https://goodreads.com/justinlosh",
    icon: BookOpen,
    color: "hover:text-amber-600",
    username: "@justinlosh",
  },
]

export function MicrofeedSidebar({ activeFilters, onFilterChange }: MicrofeedSidebarProps) {
  const handleFilterToggle = (filterId: string) => {
    const newFilters = activeFilters.includes(filterId)
      ? activeFilters.filter((f) => f !== filterId)
      : [...activeFilters, filterId]

    // Prevent removing all filters
    if (newFilters.length > 0) {
      onFilterChange(newFilters)
    }
  }

  return (
    <div className="space-y-6">
      {/* Filter Options Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filter Content
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {filterOptions.map((option) => {
            const Icon = option.icon
            const isActive = activeFilters.includes(option.id)

            return (
              <Button
                key={option.id}
                variant={isActive ? "default" : "outline"}
                size="sm"
                onClick={() => handleFilterToggle(option.id)}
                className={cn("w-full justify-between", !isActive && option.color)}
              >
                <div className="flex items-center gap-2">
                  <Icon className="h-4 w-4" />
                  {option.label}
                </div>
                <Badge variant={isActive ? "secondary" : "outline"} className="text-xs">
                  {option.count}
                </Badge>
              </Button>
            )
          })}
        </CardContent>
      </Card>

      {/* Social Links Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center gap-2">
            <ExternalLink className="h-4 w-4" />
            My Profiles
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {socialLinks.map((link) => {
            const Icon = link.icon

            return (
              <Button
                key={link.platform}
                variant="ghost"
                size="sm"
                asChild
                className={cn("w-full justify-start p-3 h-auto", link.color)}
              >
                <a
                  href={link.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between w-full"
                >
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    <div className="text-left">
                      <div className="font-medium">{link.platform}</div>
                      <div className="text-xs text-muted-foreground">{link.username}</div>
                    </div>
                  </div>
                  <ExternalLink className="h-3 w-3 opacity-50" />
                </a>
              </Button>
            )
          })}
        </CardContent>
      </Card>
    </div>
  )
}

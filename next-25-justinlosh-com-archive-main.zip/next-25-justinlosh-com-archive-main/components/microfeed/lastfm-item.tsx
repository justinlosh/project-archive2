import type React from "react"
import { FeedItem, type FeedItemProps } from "./feed-item"
import { Music } from "lucide-react"
import Image from "next/image"
import { ActionIndicator } from "./action-indicator"

interface Track {
  title: string
  artist: string
  album?: string
  albumArt?: string
  action?: string
}

interface LastFmItemProps extends Omit<FeedItemProps, "source" | "children"> {
  track: Track
}

export function LastFmItem({ track, ...props }: LastFmItemProps) {
  // Handle image loading errors
  const handleImageError = (event: React.SyntheticEvent<HTMLImageElement, Event>) => {
    event.currentTarget.src = "/placeholder.svg?height=100&width=100&text=Music"
  }

  // Determine action text
  const getActionText = () => {
    if (track.action) return track.action
    return "Listened to track"
  }

  return (
    <FeedItem source="lastfm" {...props}>
      <div className="flex gap-3">
        <div className="flex-shrink-0 mt-1">
          {track.albumArt ? (
            <div className="relative h-8 w-8 flex-shrink-0 overflow-hidden rounded">
              <Image
                src={track.albumArt || "/placeholder.svg"}
                alt={track.album || `${track.title} by ${track.artist}`}
                width={32}
                height={32}
                className="object-cover"
                onError={handleImageError}
              />
            </div>
          ) : (
            <div className="bg-[#d51007] text-white p-1.5 rounded-md">
              <Music className="h-4 w-4" />
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-2">
            <ActionIndicator action={getActionText()} source="lastfm" />
          </div>
          <p className="font-medium text-sm line-clamp-1">{track.title}</p>
          <p className="text-sm text-muted-foreground line-clamp-1">{track.artist}</p>
          {track.album && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{track.album}</p>}
        </div>
      </div>
    </FeedItem>
  )
}

import type React from "react"
import { MicrofeedItem } from "./microfeed-item"

interface MicrofeedSectionProps {
  items: any[] // Replace 'any' with a more specific type if possible
}

export const MicrofeedSection: React.FC<MicrofeedSectionProps> = ({ items }) => {
  return (
    <div className="microfeed-section">
      {items.map((item) => (
        <MicrofeedItem key={item.id} item={item} />
      ))}
    </div>
  )
}

import type React from "react"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { formatDistanceToNow } from "date-fns"
import { cn } from "@/lib/utils"
import Link from "next/link"
import { ExternalLink } from "lucide-react"

export type FeedSource = "github" | "lastfm" | "bluesky" | "mastodon" | "reading" | "other"

export interface FeedItemProps {
  id: string
  source: FeedSource
  timestamp: Date
  url?: string
  className?: string
  children: React.ReactNode
}

export function FeedItem({ id, source, timestamp, url, className, children }: FeedItemProps) {
  const timeAgo = formatDistanceToNow(timestamp, { addSuffix: true })

  return (
    <Card className={cn("overflow-hidden", className)}>
      <CardContent className="p-4">{children}</CardContent>
      <CardFooter className="px-4 py-2 bg-muted/30 flex justify-between items-center text-xs text-muted-foreground">
        <span>{timeAgo}</span>
        {url && (
          <Link
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 hover:text-primary transition-colors"
            aria-label={`View original ${source} post`}
          >
            <span>View</span>
            <ExternalLink className="h-3 w-3" />
          </Link>
        )}
      </CardFooter>
    </Card>
  )
}

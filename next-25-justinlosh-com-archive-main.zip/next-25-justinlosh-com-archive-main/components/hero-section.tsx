import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowRight, Download } from "lucide-react"

interface HeroSectionProps {
  title: string
  description: string
}

export function HeroSection({ title, description }: HeroSectionProps) {
  return (
    <section className="py-12 md:py-16 lg:py-20 flex flex-col items-center space-y-4 text-center">
      <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">{title}</h1>
      <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl leading-relaxed">{description}</p>
      <div className="flex flex-col sm:flex-row gap-4 mt-8">
        <Button asChild size="lg">
          <Link href="/projects" className="flex items-center">
            View Projects
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
        <Button variant="outline" asChild size="lg">
          <Link href="/contact" className="flex items-center">
            Get in Touch
            <Download className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      </div>
    </section>
  )
}

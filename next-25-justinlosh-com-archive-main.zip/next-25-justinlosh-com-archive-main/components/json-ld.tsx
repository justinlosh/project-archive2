import { SITE_NAME, SITE_DESCRIPTION, SITE_URL } from "@/lib/constants"

export function WebsiteJSONLD() {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: SITE_NAME,
    description: SITE_DESCRIPTION,
    url: SITE_URL,
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
}

interface BlogPostJSONLDProps {
  url: string
  title: string
  description: string
  datePublished: string
  dateModified?: string
  authorName?: string
  imageUrl?: string
}

export function BlogPostJSONLD({
  url,
  title,
  description,
  datePublished,
  dateModified,
  authorName,
  imageUrl,
}: BlogPostJSONLDProps) {
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    mainEntityOfPage: {
      "@type": "WebPage",
      "@id": url,
    },
    headline: title,
    description,
    author: {
      "@type": "Person",
      name: authorName,
      url: SITE_URL,
    },
    datePublished,
    dateModified: dateModified || datePublished,
    publisher: {
      "@type": "Person",
      name: authorName,
      url: SITE_URL,
    },
    ...(imageUrl && {
      image: {
        "@type": "ImageObject",
        url: imageUrl,
        width: 1200,
        height: 630,
      },
    }),
  }

  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
}

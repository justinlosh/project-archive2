import { Button } from "@/components/ui/button"
import { Github, LinkIcon } from "lucide-react"
import Image from "next/image"
import type { Project } from "@/types"
import { cn } from "@/lib/utils"

interface ProjectCardSimpleProps {
  project: Project
  className?: string
}

export function ProjectCardSimple({ project, className }: ProjectCardSimpleProps) {
  // Safely access project properties with fallbacks
  const {
    title = "Untitled Project",
    description = "",
    tags = [],
    github,
    link,
    image,
    isFeatured = false,
  } = project || {}

  return (
    <div className={cn("border rounded-lg overflow-hidden bg-card h-full flex flex-col", className)}>
      <div className="flex">
        <div className="relative shrink-0 w-24 h-24 bg-muted">
          <Image
            src={image || "/placeholder.svg?height=100&width=100"}
            alt={`${title} preview`}
            width={100}
            height={100}
            className="object-cover h-full"
            priority={isFeatured}
            loading={isFeatured ? "eager" : "lazy"}
          />
        </div>
        <div className="flex-1 min-w-0 p-4">
          <div>
            {isFeatured && (
              <div className="mb-1">
                <span className="text-xs font-medium px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                  Featured
                </span>
              </div>
            )}
            <h3 className="text-lg font-semibold truncate">{title}</h3>
          </div>
        </div>
      </div>

      <div className="p-4 pt-0 flex-1 flex flex-col">
        <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{description}</p>

        <div className="flex flex-wrap gap-1 mb-3">
          {tags.slice(0, 3).map((tag) => (
            <span key={tag} className="px-1.5 py-0.5 bg-muted text-muted-foreground rounded-md text-xs">
              {tag}
            </span>
          ))}
          {tags.length > 3 && (
            <span className="px-1.5 py-0.5 bg-muted text-muted-foreground rounded-md text-xs">+{tags.length - 3}</span>
          )}
        </div>

        <div className="flex gap-2 mt-auto">
          {github && (
            <Button variant="outline" size="sm" asChild>
              <a
                href={github}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center"
                aria-label={`View ${title} on GitHub`}
              >
                <Github className="h-3 w-3 mr-1" />
                <span>GitHub</span>
              </a>
            </Button>
          )}
          {link && (
            <Button variant="outline" size="sm" asChild>
              <a
                href={link}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center"
                aria-label={`Visit ${title} website`}
              >
                <LinkIcon className="h-3 w-3 mr-1" />
                <span>Visit</span>
              </a>
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}

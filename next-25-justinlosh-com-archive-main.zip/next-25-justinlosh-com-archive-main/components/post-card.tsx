import Link from "next/link"
import { formatDate } from "@/lib/utils"
import type { Post } from "@/types"
import { Calendar } from "lucide-react"
import { cn } from "@/lib/utils"

interface PostCardProps {
  post: Post
  basePath?: string
  className?: string
}

export function PostCard({ post, basePath = "posts", className }: PostCardProps) {
  return (
    <article
      className={cn(
        "group relative overflow-hidden rounded-lg border bg-background p-5 transition-all hover:shadow-md",
        className,
      )}
    >
      <Link href={`/${basePath}/${post.id}`} className="absolute inset-0 z-10">
        <span className="sr-only">View {post.title}</span>
      </Link>

      <div className="flex flex-col space-y-2">
        <h3 className="text-xl font-semibold tracking-tight group-hover:text-primary transition-colors">
          {post.title}
        </h3>

        {post.excerpt && <p className="text-muted-foreground line-clamp-2">{post.excerpt}</p>}

        <div className="flex items-center text-sm text-muted-foreground">
          <Calendar className="mr-1 h-3 w-3" />
          <time dateTime={new Date(post.date).toISOString()}>{formatDate(post.date)}</time>
        </div>
      </div>
    </article>
  )
}

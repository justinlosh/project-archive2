"use client"

import type * as React from "react"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"

export interface ProvidersProps {
  children: React.ReactNode
  defaultTheme?: string
  storageKey?: string
}

export function Providers({ children, defaultTheme = "light", storageKey = "justin-losh-theme" }: ProvidersProps) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme={defaultTheme}
      enableSystem={true}
      storageKey={storageKey}
      disableTransitionOnChange
    >
      {children}
      <Toaster />
    </ThemeProvider>
  )
}

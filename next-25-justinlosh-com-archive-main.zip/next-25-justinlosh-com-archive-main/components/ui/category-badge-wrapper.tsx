"use client"

import dynamic from "next/dynamic"
import { Skeleton } from "@/components/ui/skeleton"

// Import with no SSR to avoid hydration issues
const CategoryBadge = dynamic(() => import("./category-badge").then((mod) => mod.CategoryBadge), {
  ssr: false,
  loading: () => <Skeleton className="h-5 w-20 rounded-full" />,
})

interface CategoryBadgeWrapperProps {
  category: string
  useColorMapping?: boolean
}

export function CategoryBadgeWrapper({ category, useColorMapping = true }: CategoryBadgeWrapperProps) {
  return <CategoryBadge category={category} useColorMapping={useColorMapping} />
}

import { Star } from "lucide-react"
import { cn } from "@/lib/utils"

interface StarRatingProps {
  rating?: number
  size?: "sm" | "md" | "lg"
  showEmpty?: boolean
  className?: string
}

export function StarRating({ rating, size = "md", showEmpty = false, className }: StarRatingProps) {
  // Size classes for the stars
  const sizeClasses = {
    sm: "h-3 w-3",
    md: "h-4 w-4",
    lg: "h-5 w-5",
  }

  // Text size classes
  const textSizeClasses = {
    sm: "text-xs",
    md: "text-sm",
    lg: "text-base",
  }

  // If no rating and we don't want to show empty state, return null
  if (rating === undefined && !showEmpty) {
    return null
  }

  // If no rating but we want to show empty state
  if (rating === undefined) {
    return (
      <div className={cn("flex items-center", className)}>
        <span className={cn("text-muted-foreground", textSizeClasses[size])}>No rating</span>
      </div>
    )
  }

  // Ensure rating is between 0 and 5
  const normalizedRating = Math.max(0, Math.min(5, rating))

  // Create an array of 5 stars
  const stars = Array.from({ length: 5 }, (_, i) => {
    // Determine if this star should be filled, half-filled, or empty
    const isFilled = i < Math.floor(normalizedRating)
    const isHalfFilled = i === Math.floor(normalizedRating) && normalizedRating % 1 >= 0.5

    return (
      <Star
        key={i}
        className={cn(
          sizeClasses[size],
          isFilled
            ? "text-amber-500 fill-amber-500"
            : isHalfFilled
              ? "text-amber-500 fill-amber-500/50"
              : "text-muted stroke-muted-foreground fill-transparent",
        )}
        aria-hidden="true"
      />
    )
  })

  return (
    <div className={cn("flex items-center gap-1", className)} aria-label={`${normalizedRating} out of 5 stars`}>
      <div className="flex">{stars}</div>
    </div>
  )
}

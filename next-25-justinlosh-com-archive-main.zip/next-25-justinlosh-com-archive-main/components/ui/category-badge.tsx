"use client"

import type React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"
import { useEffect, useState } from "react"

// Define category colors based on category name
const categoryColors: Record<string, string> = {
  // Note categories
  Development: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
  Design: "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-300",
  Technology: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-300",
  Tutorial: "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300",
  Opinion: "bg-rose-100 text-rose-800 dark:bg-rose-900/30 dark:text-rose-300",

  // Project categories
  Project: "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-300",
  "Open Source": "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-300",
  Contribution: "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300",

  // Default color for any other category
  default: "bg-gray-100 text-gray-800 dark:bg-gray-800/50 dark:text-gray-300",
}

const categoryBadgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium transition-colors hover:bg-opacity-80",
  {
    variants: {
      variant: {
        default: "bg-primary/10 text-primary hover:bg-primary/20",
        outline: "border border-primary/20 text-primary",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  },
)

export interface CategoryBadgeProps
  extends React.HTMLAttributes<HTMLSpanElement>,
    VariantProps<typeof categoryBadgeVariants> {
  category: string
  useColorMapping?: boolean
}

export function CategoryBadge({
  category = "",
  className,
  variant,
  useColorMapping = true,
  ...props
}: CategoryBadgeProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  // Use a safe default during SSR
  const colorClass =
    mounted && useColorMapping ? categoryColors[category] || categoryColors.default : "bg-muted text-muted-foreground"

  return (
    <span className={cn(categoryBadgeVariants({ variant }), colorClass, className)} {...props}>
      {category}
    </span>
  )
}

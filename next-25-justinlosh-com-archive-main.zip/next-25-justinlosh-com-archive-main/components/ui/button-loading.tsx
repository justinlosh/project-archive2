"use client"

import { Button, type ButtonProps } from "@/components/ui/button"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { cn } from "@/lib/utils"
import { forwardRef } from "react"

interface ButtonLoadingProps extends ButtonProps {
  isLoading?: boolean
  loadingText?: string
}

const ButtonLoading = forwardRef<HTMLButtonElement, ButtonLoadingProps>(
  ({ children, isLoading, loadingText, className, disabled, ...props }, ref) => {
    return (
      <Button ref={ref} disabled={disabled || isLoading} className={cn(className)} aria-busy={isLoading} {...props}>
        {isLoading ? (
          <>
            <LoadingSpinner size="sm" className="mr-2" aria-hidden="true" />
            <span>{loadingText || children}</span>
          </>
        ) : (
          children
        )}
      </Button>
    )
  },
)
ButtonLoading.displayName = "ButtonLoading"

export { ButtonLoading }

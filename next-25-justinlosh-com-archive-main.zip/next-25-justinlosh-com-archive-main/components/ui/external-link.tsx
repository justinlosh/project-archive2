import type React from "react"
import { cn } from "@/lib/utils"
import { ExternalLinkIcon } from "lucide-react"

interface ExternalLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  showIcon?: boolean
}

export function ExternalLink({ href, children, className, showIcon = false, ...props }: ExternalLinkProps) {
  return (
    <a
      href={href}
      className={cn("inline-flex items-center gap-1", className)}
      target="_blank"
      rel="noopener noreferrer"
      {...props}
    >
      {children}
      {showIcon && <ExternalLinkIcon className="h-3.5 w-3.5" />}
    </a>
  )
}

import { Calendar } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface LastUpdatedProps {
  date: string
  className?: string
}

export function LastUpdated({ date, className = "" }: LastUpdatedProps) {
  const formattedDate = new Date(date).toLocaleDateString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  })

  return (
    <div className={`flex justify-end ${className}`}>
      <Badge variant="outline" className="gap-1.5 text-xs text-muted-foreground">
        <Calendar className="h-3 w-3" />
        Last Updated: {formattedDate}
      </Badge>
    </div>
  )
}

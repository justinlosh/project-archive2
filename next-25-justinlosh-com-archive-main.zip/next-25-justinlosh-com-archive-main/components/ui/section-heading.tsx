import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

interface SectionHeadingProps {
  title: string
  description?: string
  link?: string
  linkText?: string
}

export function SectionHeading({ title, description, link, linkText }: SectionHeadingProps) {
  return (
    <div className="flex items-center justify-between mb-8">
      <div>
        <h2 className="text-2xl md:text-3xl font-bold tracking-tight">{title}</h2>
        {description && <p className="text-muted-foreground mt-2">{description}</p>}
      </div>
      {link && linkText && (
        <Button variant="outline" asChild>
          <Link href={link} className="flex items-center">
            {linkText}
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </Button>
      )}
    </div>
  )
}

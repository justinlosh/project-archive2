"use client"

import { useEffect, useRef, useState } from "react"
import { turnstileConfig } from "@/lib/config/turnstile"

interface TurnstileProps {
  onVerify: (token: string) => void
  onError?: () => void
  onExpire?: () => void
  className?: string
  id?: string
}

export function Turnstile({ onVerify, onError, onExpire, className = "", id = "cf-turnstile" }: TurnstileProps) {
  const [loaded, setLoaded] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const widgetIdRef = useRef<string | null>(null)

  useEffect(() => {
    // Skip if Turnstile is disabled
    if (!turnstileConfig.enabled) {
      return
    }

    // Load the Turnstile script if it hasn't been loaded yet
    if (!window.turnstile) {
      const script = document.createElement("script")
      script.src = "https://challenges.cloudflare.com/turnstile/v0/api.js"
      script.async = true
      script.defer = true
      script.onload = () => setLoaded(true)
      document.head.appendChild(script)
      return () => {
        document.head.removeChild(script)
      }
    } else {
      setLoaded(true)
    }
  }, [])

  useEffect(() => {
    // Skip if Turnstile is disabled or not loaded
    if (!turnstileConfig.enabled || !loaded || !containerRef.current || !window.turnstile) {
      return
    }

    // Reset any existing widget
    if (widgetIdRef.current) {
      window.turnstile.reset(widgetIdRef.current)
    }

    // Render the widget
    widgetIdRef.current = window.turnstile.render(containerRef.current, {
      sitekey: turnstileConfig.siteKey,
      callback: onVerify,
      "error-callback": onError,
      "expired-callback": onExpire,
      theme: "auto",
      // Use testing mode if configured
      action: turnstileConfig.testMode ? "test-mode" : "contact-form",
    })

    // Clean up the widget when the component unmounts
    return () => {
      if (widgetIdRef.current) {
        window.turnstile.remove(widgetIdRef.current)
      }
    }
  }, [loaded, onVerify, onError, onExpire])

  // If Turnstile is disabled, render nothing
  if (!turnstileConfig.enabled) {
    return null
  }

  return <div id={id} ref={containerRef} className={className} />
}

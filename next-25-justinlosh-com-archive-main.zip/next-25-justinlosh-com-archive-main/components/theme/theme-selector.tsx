"use client"

import * as React from "react"
import { Check, Palette } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useTheme } from "next-themes"

const themes = [
  // Light themes
  {
    value: "light",
    label: "Light",
    group: "light",
  },
  {
    value: "theme-blue",
    label: "Blue",
    group: "light",
  },
  {
    value: "theme-purple",
    label: "Purple",
    group: "light",
  },
  {
    value: "theme-green",
    label: "Green",
    group: "light",
  },
  {
    value: "theme-amber",
    label: "Amber",
    group: "light",
  },
  // Dark themes
  {
    value: "dark",
    label: "Dark",
    group: "dark",
  },
  {
    value: "theme-blue-dark",
    label: "Blue Dark",
    group: "dark",
  },
  {
    value: "theme-purple-dark",
    label: "Purple Dark",
    group: "dark",
  },
  {
    value: "theme-green-dark",
    label: "Green Dark",
    group: "dark",
  },
  {
    value: "theme-amber-dark",
    label: "Amber Dark",
    group: "dark",
  },
]

export function ThemeSelector() {
  const { resolvedTheme, theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)
  const themeRef = React.useRef(theme)

  // Ensure component is mounted to avoid hydration mismatch
  React.useEffect(() => {
    setMounted(true)

    // Update ref when theme changes
    themeRef.current = theme

    return () => setMounted(false)
  }, [theme])

  // Create a stable callback for theme changing
  const handleThemeChange = React.useCallback(
    (themeValue: string) => {
      if (mounted && themeValue !== themeRef.current) {
        setTheme(themeValue)
      }
    },
    [mounted, setTheme],
  )

  if (!mounted) {
    return (
      <Button variant="ghost" size="icon" disabled>
        <Palette className="h-5 w-5" />
        <span className="sr-only">Select theme</span>
      </Button>
    )
  }

  const lightThemes = themes.filter((t) => t.group === "light")
  const darkThemes = themes.filter((t) => t.group === "dark")

  // Use the actual theme value for comparison, not resolvedTheme
  const currentTheme = theme || "system"

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Select a theme">
          <Palette className="h-5 w-5" />
          <span className="sr-only">Select theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {lightThemes.map((themeOption) => (
          <DropdownMenuItem
            key={themeOption.value}
            onClick={() => handleThemeChange(themeOption.value)}
            className={cn("flex items-center gap-2", currentTheme === themeOption.value && "bg-accent")}
          >
            {themeOption.label}
            {currentTheme === themeOption.value && <Check className="h-4 w-4 ml-auto" />}
          </DropdownMenuItem>
        ))}

        <DropdownMenuSeparator />

        {darkThemes.map((themeOption) => (
          <DropdownMenuItem
            key={themeOption.value}
            onClick={() => handleThemeChange(themeOption.value)}
            className={cn("flex items-center gap-2", currentTheme === themeOption.value && "bg-accent")}
          >
            {themeOption.label}
            {currentTheme === themeOption.value && <Check className="h-4 w-4 ml-auto" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

"use client"

import { useEffect } from "react"
import { logError } from "@/lib/utils/error-logger"

export function ClientErrorHandler() {
  useEffect(() => {
    // Handler for unhandled promise rejections
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      event.preventDefault()
      logError("Unhandled promise rejection", event.reason, {
        type: "unhandledRejection",
      })
    }

    // Handler for uncaught errors
    const handleError = (event: ErrorEvent) => {
      event.preventDefault()
      logError("Uncaught error", event.error || new Error(event.message), {
        type: "uncaughtError",
        filename: event.filename,
        lineno: event.lineno,
        colno: event.colno,
      })
    }

    // Add event listeners
    window.addEventListener("unhandledrejection", handleUnhandledRejection)
    window.addEventListener("error", handleError)

    // Remove event listeners on cleanup
    return () => {
      window.removeEventListener("unhandledrejection", handleUnhandledRejection)
      window.removeEventListener("error", handleError)
    }
  }, [])

  return null
}

"use client"

import { ThemeProvider as NextThemesProvider } from "next-themes"
import type { ThemeProviderProps } from "next-themes"

export function ThemeProvider({ children, ...props }: ThemeProviderProps) {
  // Simple wrapper around NextThemesProvider to ensure we only have one instance
  return <NextThemesProvider {...props}>{children}</NextThemesProvider>
}

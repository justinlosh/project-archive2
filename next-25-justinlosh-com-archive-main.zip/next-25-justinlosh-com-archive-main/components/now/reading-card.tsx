"use client"

import { BookOpen, ExternalLink } from "lucide-react"
import { NowCard } from "./now-card"
import { useEffect, useState } from "react"
import { getReadingData, getGoodreadsProfileUrl, getGoodreadsShelfUrl } from "@/lib/services/reading-service"
import type { ReadingItem } from "@/types/reading"
import Image from "next/image"
import { StarRating } from "@/components/ui/star-rating"
import { Button } from "@/components/ui/button"

interface ReadingCardProps {
  className?: string
}

export function ReadingCard({ className }: ReadingCardProps) {
  const [books, setBooks] = useState<ReadingItem[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastUpdated, setLastUpdated] = useState<string>(new Date().toISOString())

  useEffect(() => {
    const fetchBooks = async () => {
      setIsLoading(true)
      try {
        // Only fetch currently reading books
        const response = await getReadingData(3, "reading")
        if (response.success && response.items.length > 0) {
          setBooks(response.items)
          setLastUpdated(new Date().toISOString())
        } else {
          setError(response.error || "No books currently being read")
        }
      } catch (error) {
        console.error("Error fetching reading data:", error)
        setError("Failed to fetch reading data")
      } finally {
        setIsLoading(false)
      }
    }

    fetchBooks()
  }, [])

  // Format the date to a readable string
  const formatLastUpdated = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleString()
    } catch (error) {
      console.error("Error formatting date:", error)
      return "Unknown"
    }
  }

  return (
    <NowCard
      title="Reading"
      icon={BookOpen}
      className={className}
      action={
        <a
          href={getGoodreadsShelfUrl("reading")}
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-muted-foreground hover:text-primary transition-colors"
        >
          View on Goodreads
        </a>
      }
    >
      {isLoading ? (
        <div className="space-y-4 animate-pulse">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex gap-3">
              <div className="h-24 w-16 bg-muted rounded"></div>
              <div className="flex-1">
                <div className="h-5 bg-muted rounded w-3/4 mb-1"></div>
                <div className="h-4 bg-muted rounded w-1/2 mb-2"></div>
                <div className="flex items-center gap-2">
                  <div className="h-2 bg-muted rounded-full w-24"></div>
                  <div className="h-4 bg-muted rounded w-8"></div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="text-sm text-muted-foreground py-4">{error}</div>
      ) : books.length === 0 ? (
        <div className="text-sm text-muted-foreground py-4">No books currently being read. Check back later!</div>
      ) : (
        <ul className="space-y-4">
          {books.map((book) => (
            <li key={book.id} className="flex gap-3">
              <a
                href={book.goodreadsUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="relative block h-24 w-16 flex-shrink-0 overflow-hidden rounded shadow"
              >
                <Image
                  src={book.coverUrl || `/placeholder.svg?height=300&width=200&text=${encodeURIComponent(book.title)}`}
                  alt={`Cover of ${book.title}`}
                  fill
                  className="object-cover"
                  sizes="64px"
                  onError={(e) => {
                    // Fallback if image fails to load
                    const target = e.target as HTMLImageElement
                    target.src = `/placeholder.svg?height=300&width=200&text=${encodeURIComponent(book.title)}`
                  }}
                />
              </a>
              <div className="flex-1">
                <a
                  href={book.goodreadsUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-medium hover:text-primary transition-colors"
                >
                  {book.title}
                </a>
                <div className="text-sm text-muted-foreground">by {book.author}</div>

                {/* Rating display */}
                <div className="mt-1">
                  <StarRating rating={book.rating} size="sm" showEmpty={true} />
                </div>

                {/* Progress bar */}
                <div className="mt-2 flex items-center gap-2">
                  <div className="h-2 w-full max-w-24 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-primary rounded-full"
                      style={{ width: `${book.progress || 0}%` }}
                      aria-hidden="true"
                    />
                  </div>
                  <span className="text-xs text-muted-foreground">{book.progress || 0}%</span>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}

      {/* Add Goodreads profile button and last updated timestamp */}
      <div className="pt-4 mt-2">
        <Button variant="outline" size="sm" className="w-full" asChild>
          <a
            href={getGoodreadsProfileUrl()}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1"
          >
            <span>View Goodreads Profile</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </Button>
        <p className="text-xs text-muted-foreground text-center mt-2">Last updated: {formatLastUpdated(lastUpdated)}</p>
      </div>
    </NowCard>
  )
}

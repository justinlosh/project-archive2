import { Lightbulb } from "lucide-react"
import { NowCard } from "./now-card"
import { Badge } from "@/components/ui/badge"

interface LearningItem {
  topic: string
  resources?: string[]
  tags?: string[]
}

interface LearningCardProps {
  items: LearningItem[]
  className?: string
}

export function LearningCard({ items, className }: LearningCardProps) {
  return (
    <NowCard title="Learning" icon={Lightbulb} className={className}>
      <ul className="space-y-4">
        {items.map((item, index) => (
          <li key={index} className="flex flex-col">
            <span className="font-medium">{item.topic}</span>
            {item.resources && item.resources.length > 0 && (
              <ul className="mt-1 ml-4 list-disc text-sm text-muted-foreground">
                {item.resources.map((resource, idx) => (
                  <li key={idx}>{resource}</li>
                ))}
              </ul>
            )}
            {item.tags && item.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2">
                {item.tags.map((tag, idx) => (
                  <Badge key={idx} variant="outline" className="text-xs">
                    {tag}
                  </Badge>
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>
    </NowCard>
  )
}

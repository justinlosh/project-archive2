"use client"

import { useState, useEffect, useCallback } from "react"
import { Feed, type FeedItemType } from "@/components/microfeed/feed"
import { FeedFilter } from "@/components/microfeed/feed-filter"
import { generateGitHubItems, generateSocialItems } from "@/lib/data/sample-microfeed-data"
import { getReadingData, convertReadingToFeedItems } from "@/lib/services/reading-service"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"
import { logError } from "@/lib/utils/error-logger"

export function MicrofeedSection() {
  const [allItems, setAllItems] = useState<FeedItemType[]>([])
  const [filteredItems, setFilteredItems] = useState<FeedItemType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeFilters, setActiveFilters] = useState<string[]>(["github", "bluesky", "mastodon", "reading"])

  // Load data safely
  const loadData = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      // Generate sample data for other sources (excluding Last.fm)
      const githubItems = generateGitHubItems(3)
      const socialItems = generateSocialItems(3)

      // Fetch reading data from API - get both currently reading and recently read
      let readingItems: FeedItemType[] = []
      let readItems: FeedItemType[] = []
      let toReadItems: FeedItemType[] = []

      try {
        const readingResponse = await getReadingData(3, "reading")
        if (readingResponse.success) {
          readingItems = convertReadingToFeedItems(readingResponse.items)
        }
      } catch (err) {
        console.error("Error fetching reading data:", err)
        // Continue with empty array
      }

      try {
        const readResponse = await getReadingData(2, "read")
        if (readResponse.success) {
          readItems = convertReadingToFeedItems(readResponse.items)
        }
      } catch (err) {
        console.error("Error fetching read data:", err)
        // Continue with empty array
      }

      try {
        const toReadResponse = await getReadingData(1, "to-read")
        if (toReadResponse.success) {
          toReadItems = convertReadingToFeedItems(toReadResponse.items)
        }
      } catch (err) {
        console.error("Error fetching to-read data:", err)
        // Continue with empty array
      }

      // Combine all items (excluding Last.fm)
      const allReadingItems = [...readingItems, ...readItems, ...toReadItems]
      const items = [...githubItems, ...socialItems, ...allReadingItems]

      // Sort by timestamp (newest first)
      const sortedItems = items.sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())

      setAllItems(sortedItems)
      setFilteredItems(sortedItems)
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Error loading feed data"
      console.error("Error loading feed data:", error)
      logError("Error loading microfeed data", error instanceof Error ? error : new Error(errorMessage))
      setError("Failed to load activity feed. Please try refreshing the page.")
    } finally {
      setIsLoading(false)
    }
  }, [])

  // Initial data load
  useEffect(() => {
    loadData()
  }, [loadData])

  // Handle filter changes
  const handleFilterChange = useCallback(
    (filters: string[]) => {
      setActiveFilters(filters)

      try {
        // Apply filters to items
        const filtered = allItems.filter((item) => {
          if (item.type === "github") return filters.includes("github")
          if (item.type === "reading") return filters.includes("reading")
          if (item.type === "social") {
            return filters.includes(item.post.platform)
          }
          return false
        })

        setFilteredItems(filtered)
      } catch (error) {
        console.error("Error filtering items:", error)
        logError("Error filtering microfeed items", error instanceof Error ? error : new Error("Unknown error"))
        // Keep the current filtered items if there's an error
      }
    },
    [allItems],
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between mb-4">
        <FeedFilter
          onFilterChange={handleFilterChange}
          className="flex-1"
          // Remove lastfm from available filters
          availableFilters={[
            { id: "github", label: "GitHub" },
            { id: "bluesky", label: "Bluesky" },
            { id: "mastodon", label: "Mastodon" },
            { id: "reading", label: "Reading" },
          ]}
        />

        <Button variant="outline" size="sm" onClick={() => loadData()} disabled={isLoading} className="ml-4">
          <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? "animate-spin" : ""}`} />
          Refresh
        </Button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-md text-red-700 dark:text-red-300 text-sm mb-4">
          {error}
          <Button
            variant="link"
            size="sm"
            className="ml-2 p-0 h-auto text-red-700 dark:text-red-300"
            onClick={() => loadData()}
          >
            Try again
          </Button>
        </div>
      )}

      <Feed items={filteredItems} isLoading={isLoading} />
    </div>
  )
}

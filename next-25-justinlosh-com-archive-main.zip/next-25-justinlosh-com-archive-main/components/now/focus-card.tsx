import { Target } from "lucide-react"
import { NowCard } from "./now-card"

interface FocusItem {
  title: string
  description: string
}

interface FocusCardProps {
  items: FocusItem[]
  className?: string
}

export function FocusCard({ items, className }: FocusCardProps) {
  return (
    <NowCard title="Current Focus" icon={Target} className={className}>
      <ul className="space-y-4">
        {items.map((item, index) => (
          <li key={index} className="flex flex-col">
            <span className="font-medium">{item.title}</span>
            <p className="text-sm text-muted-foreground mt-1">{item.description}</p>
          </li>
        ))}
      </ul>
    </NowCard>
  )
}

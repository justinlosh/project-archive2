"use client"

import type React from "react"

import { Headphones, ExternalLink, Music, Disc, User, Heart } from "lucide-react"
import { NowCard } from "./now-card"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { getBestImageUrl } from "@/lib/services/lastfm-service"
import Image from "next/image"
import type { LastFmStats, LastFmTrack } from "@/types/lastfm"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface ListeningCardProps {
  className?: string
}

export function ListeningCard({ className }: ListeningCardProps) {
  const [lastFmData, setLastFmData] = useState<LastFmStats | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("recent")

  useEffect(() => {
    const fetchLastFmData = async () => {
      setIsLoading(true)
      try {
        const response = await fetch("/api/lastfm?period=7day")

        if (!response.ok) {
          throw new Error(`Failed to fetch Last.fm data: ${response.status}`)
        }

        const data = await response.json()

        if (data.success && data.stats) {
          setLastFmData(data.stats)
        } else {
          setError(data.error || "Failed to fetch Last.fm data")
        }
      } catch (error) {
        console.error("Error fetching Last.fm data:", error)
        setError(error instanceof Error ? error.message : "Failed to fetch Last.fm data")
      } finally {
        setIsLoading(false)
      }
    }

    fetchLastFmData()

    // Refresh data every 15 minutes
    const intervalId = setInterval(fetchLastFmData, 15 * 60 * 1000)

    return () => clearInterval(intervalId)
  }, [])

  // Format the date to a readable string
  const formatLastUpdated = (dateString: string) => {
    try {
      const date = new Date(dateString)
      return date.toLocaleString()
    } catch (error) {
      console.error("Error formatting date:", error)
      return "Unknown"
    }
  }

  // Handle image loading errors
  const handleImageError = (event: React.SyntheticEvent<HTMLImageElement, Event>) => {
    event.currentTarget.src = "/placeholder.svg?height=100&width=100"
  }

  // Render track list
  const renderTrackList = (tracks: LastFmTrack[] | undefined, limit = 3) => {
    if (!tracks || tracks.length === 0) {
      return <p className="text-sm text-muted-foreground">No tracks available.</p>
    }

    return (
      <ul className="space-y-3">
        {tracks.slice(0, limit).map((track: LastFmTrack, index: number) => (
          <li key={`${track.name}-${index}`} className="flex items-center gap-3">
            <div className="relative h-10 w-10 flex-shrink-0 overflow-hidden rounded bg-muted">
              <Image
                src={getBestImageUrl(track.image, "small") || "/placeholder.svg?height=100&width=100"}
                alt={`${track.name} by ${track.artist.name}`}
                fill
                className="object-cover"
                sizes="40px"
                onError={handleImageError}
              />
              {track.loved === "1" && (
                <div className="absolute top-0 right-0 bg-red-500 rounded-bl p-0.5">
                  <Heart className="h-3 w-3 text-white" fill="white" />
                </div>
              )}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium">{track.name}</p>
              <p className="truncate text-xs text-muted-foreground">{track.artist.name}</p>
            </div>
          </li>
        ))}
      </ul>
    )
  }

  return (
    <NowCard
      title="Listening"
      icon={Headphones}
      className={className}
      action={
        lastFmData && (
          <a
            href={lastFmData.profileUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs text-muted-foreground hover:text-primary transition-colors"
          >
            View on Last.fm
          </a>
        )
      }
    >
      {isLoading ? (
        <div className="space-y-4 animate-pulse">
          <div className="h-20 bg-muted rounded"></div>
          <div className="space-y-2">
            <div className="h-4 bg-muted rounded w-3/4"></div>
            <div className="h-4 bg-muted rounded w-1/2"></div>
          </div>
          <div className="h-24 bg-muted rounded"></div>
        </div>
      ) : error ? (
        <div className="text-sm text-muted-foreground py-4">
          {error}
          <Button variant="link" size="sm" className="mt-2 p-0 h-auto" onClick={() => window.location.reload()}>
            Try again
          </Button>
        </div>
      ) : lastFmData ? (
        <div className="space-y-4">
          {/* Weekly stats */}
          <div className="grid grid-cols-3 gap-2 bg-muted/40 rounded-lg p-4">
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 text-primary rounded-full w-10 h-10 mb-2">
                <Music className="h-5 w-5" />
              </div>
              <span className="text-xl font-semibold">{lastFmData.total.tracks}</span>
              <span className="text-xs text-muted-foreground">Tracks</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 text-primary rounded-full w-10 h-10 mb-2">
                <User className="h-5 w-5" />
              </div>
              <span className="text-xl font-semibold">{lastFmData.total.artists}</span>
              <span className="text-xs text-muted-foreground">Artists</span>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center justify-center bg-primary/10 text-primary rounded-full w-10 h-10 mb-2">
                <Disc className="h-5 w-5" />
              </div>
              <span className="text-xl font-semibold">{lastFmData.total.albums}</span>
              <span className="text-xs text-muted-foreground">Albums</span>
            </div>
          </div>

          {/* Tabs for different track lists */}
          <Tabs defaultValue="recent" value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="loved">Loved</TabsTrigger>
              <TabsTrigger value="top">Top</TabsTrigger>
            </TabsList>

            <TabsContent value="recent" className="mt-4">
              <h4 className="text-sm font-medium mb-2">Recently Played</h4>
              {renderTrackList(lastFmData.recentTracks)}
            </TabsContent>

            <TabsContent value="loved" className="mt-4">
              <h4 className="text-sm font-medium mb-2">Loved Tracks</h4>
              {renderTrackList(lastFmData.lovedTracks)}
            </TabsContent>

            <TabsContent value="top" className="mt-4">
              <h4 className="text-sm font-medium mb-2">Top Artists This Week</h4>
              <ul className="space-y-1">
                {lastFmData.topArtists &&
                  lastFmData.topArtists.slice(0, 3).map((artist, index) => (
                    <li key={`${artist.name}-${index}`} className="text-sm">
                      {artist.name} <span className="text-xs text-muted-foreground">({artist.playcount} plays)</span>
                    </li>
                  ))}
              </ul>
            </TabsContent>
          </Tabs>

          {/* Last.fm profile link */}
          <div className="pt-2">
            <Button variant="outline" size="sm" className="w-full" asChild>
              <a
                href={lastFmData.profileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-1"
              >
                <span>View Last.fm Profile</span>
                <ExternalLink className="h-3.5 w-3.5" />
              </a>
            </Button>
            <p className="text-xs text-muted-foreground text-center mt-2">
              Last updated: {formatLastUpdated(lastFmData.lastUpdated)}
            </p>
          </div>
        </div>
      ) : (
        <div className="text-sm text-muted-foreground py-4">
          No listening data available.
          <Button variant="link" size="sm" className="mt-2 p-0 h-auto" onClick={() => window.location.reload()}>
            Try again
          </Button>
        </div>
      )}
    </NowCard>
  )
}

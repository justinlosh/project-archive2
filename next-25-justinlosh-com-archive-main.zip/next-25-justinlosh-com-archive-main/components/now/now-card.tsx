import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ArrowRight, Clock } from "lucide-react"

export function NowCard() {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div className="flex items-center space-x-2">
          <Clock className="h-5 w-5 text-muted-foreground" />
          <CardTitle className="text-lg font-medium">What I'm doing now</CardTitle>
        </div>
      </CardHeader>
      <CardDescription className="px-6">A snapshot of my current focus, projects, and interests.</CardDescription>
      <CardContent className="pt-4">
        <div className="space-y-4">
          <div>
            <h3 className="font-medium">Current Focus</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Working on improving my Next.js skills and building personal projects.
            </p>
          </div>
          <div>
            <h3 className="font-medium">Learning</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Exploring TypeScript, Tailwind CSS, and server-side rendering techniques.
            </p>
          </div>
          <div>
            <h3 className="font-medium">Reading</h3>
            <p className="text-sm text-muted-foreground mt-1">
              "The Pragmatic Programmer" and "Clean Code" for improving software development practices.
            </p>
          </div>
          <div className="pt-2">
            <Button variant="outline" size="sm" className="w-full" asChild>
              <Link href="/now" className="flex items-center justify-center">
                <span>View full Now page</span>
                <ArrowRight className="ml-2 h-3.5 w-3.5" />
              </Link>
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

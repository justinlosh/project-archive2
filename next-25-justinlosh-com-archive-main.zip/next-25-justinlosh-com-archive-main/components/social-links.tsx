import type React from "react"
import Link from "next/link"
import { Github, Twitter, Linkedin } from "lucide-react"
import { SOCIAL_LINKS } from "@/lib/constants"

export function SocialLinks() {
  const iconMap: Record<string, React.ReactNode> = {
    github: <Github className="h-5 w-5" />,
    twitter: <Twitter className="h-5 w-5" />,
    linkedin: <Linkedin className="h-5 w-5" />,
  }

  return (
    <div className="flex space-x-4">
      {SOCIAL_LINKS.map((link) => (
        <Link
          key={link.name}
          href={link.url}
          target="_blank"
          rel="noopener noreferrer"
          className="text-muted-foreground hover:text-foreground transition-colors"
          aria-label={link.name}
        >
          {iconMap[link.icon] || <span>{link.name}</span>}
        </Link>
      ))}
    </div>
  )
}

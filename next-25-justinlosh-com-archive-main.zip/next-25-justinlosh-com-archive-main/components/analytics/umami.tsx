"use client"

import Script from "next/script"
import { useEffect, useState } from "react"

export function UmamiAnalytics() {
  const [mounted, setMounted] = useState(false)

  // Get environment variables with fallbacks
  const isEnabled = process.env.NEXT_PUBLIC_UMAMI_ENABLED === "true"
  const websiteId = process.env.NEXT_PUBLIC_UMAMI_WEBSITE_ID || ""
  const scriptUrl = process.env.NEXT_PUBLIC_UMAMI_URL || "https://analytics.umami.is/script.js"

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  // Only render in production and when enabled
  if (!mounted || process.env.NODE_ENV !== "production" || !isEnabled || !websiteId) {
    return null
  }

  return <Script src={scriptUrl} data-website-id={websiteId} strategy="lazyOnload" async defer />
}

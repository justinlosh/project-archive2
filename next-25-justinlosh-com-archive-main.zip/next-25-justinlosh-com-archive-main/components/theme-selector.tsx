"use client"

import * as React from "react"
import { Check, Palette } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { useTheme } from "next-themes"

const themes = [
  {
    value: "light",
    label: "Light",
  },
  {
    value: "dark",
    label: "Dark",
  },
  {
    value: "theme-blue",
    label: "Blue",
  },
  {
    value: "theme-blue-dark",
    label: "Blue Dark",
  },
  {
    value: "theme-purple",
    label: "Purple",
  },
  {
    value: "theme-purple-dark",
    label: "Purple Dark",
  },
  {
    value: "theme-green",
    label: "Green",
  },
  {
    value: "theme-green-dark",
    label: "Green Dark",
  },
  {
    value: "theme-amber",
    label: "Amber",
  },
  {
    value: "theme-amber-dark",
    label: "Amber Dark",
  },
]

export function ThemeSelector() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  // Ensure component is mounted to avoid hydration mismatch
  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <Button variant="ghost" size="icon" disabled>
        <Palette className="h-5 w-5" />
        <span className="sr-only">Select theme</span>
      </Button>
    )
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Select a theme">
          <Palette className="h-5 w-5" />
          <span className="sr-only">Select theme</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {themes.map((themeOption) => (
          <DropdownMenuItem
            key={themeOption.value}
            onClick={() => setTheme(themeOption.value)}
            className={cn("flex items-center gap-2", theme === themeOption.value && "bg-accent")}
          >
            {themeOption.label}
            {theme === themeOption.value && <Check className="h-4 w-4 ml-auto" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

"use client"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Shield } from "lucide-react"
import { cn } from "@/lib/utils"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import dynamic from "next/dynamic"

// Lazy load the contact form content
const ContactFormContent = dynamic(
  () => import("@/components/contact/contact-form-content").then((mod) => mod.ContactFormContent),
  {
    loading: () => (
      <CardContent className="p-6 flex justify-center items-center min-h-[300px]">
        <div className="flex flex-col items-center gap-2">
          <LoadingSpinner size="lg" />
          <span className="text-sm text-muted-foreground">Loading form...</span>
        </div>
      </CardContent>
    ),
    ssr: false, // Disable server-side rendering for this component
  },
)

interface ProtectedContactFormProps {
  title: string
  description: string
}

export function ProtectedContactForm({ title, description }: ProtectedContactFormProps) {
  const [isRevealed, setIsRevealed] = useState(false)
  const [isFormLoaded, setIsFormLoaded] = useState(false)

  const handleReveal = useCallback(() => {
    setIsRevealed(true)
    // Set a timeout to ensure the form is loaded after the animation completes
    setTimeout(() => {
      setIsFormLoaded(true)
    }, 500)
  }, [])

  return (
    <Card className="overflow-hidden shadow-md">
      {/* Only render CardHeader if title or description is provided */}
      {(title || description) && (
        <CardHeader>
          {title && <CardTitle>{title}</CardTitle>}
          {description && <CardDescription>{description}</CardDescription>}
        </CardHeader>
      )}

      <div className="relative">
        {/* Overlay with blur effect */}
        <div
          className={cn(
            "absolute inset-0 z-10 flex flex-col items-center justify-center p-6 bg-background/60 backdrop-blur-[6px] transition-all duration-500 ease-in-out",
            isRevealed ? "opacity-0 pointer-events-none" : "opacity-100",
          )}
          aria-hidden={isRevealed}
        >
          <div className="text-center max-w-md bg-card p-8 rounded-lg shadow-lg border">
            <Shield className="w-12 h-12 mx-auto mb-5 text-primary" />
            <h3 className="text-xl font-medium mb-3">Protected Contact Form</h3>
            <p className="text-muted-foreground mb-6">
              This form is protected to prevent spam. Click the button below to access the contact form.
            </p>
            <Button onClick={handleReveal} size="lg" className="px-6">
              Show Contact Form
            </Button>
          </div>
        </div>

        {/* Form placeholder before reveal */}
        {!isRevealed && (
          <CardContent className="min-h-[450px] flex items-center justify-center opacity-0">
            <div className="w-full h-full" />
          </CardContent>
        )}

        {/* Actual form content - only loaded after reveal */}
        {isRevealed && (
          <div className={cn("transition-opacity duration-500", isRevealed ? "opacity-100" : "opacity-0")}>
            {isFormLoaded ? (
              <ContactFormContent />
            ) : (
              <CardContent className="p-6 flex justify-center items-center min-h-[450px]">
                <div className="flex flex-col items-center gap-3">
                  <LoadingSpinner size="lg" />
                  <span className="text-sm text-muted-foreground">Loading form...</span>
                </div>
              </CardContent>
            )}
          </div>
        )}
      </div>
    </Card>
  )
}

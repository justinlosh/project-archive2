"use client"

import type React from "react"

import { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { contactFormSchema, type ContactFormValues } from "@/lib/validations/contact-schema"
import { toast } from "@/components/ui/use-toast"
import { z } from "zod"
import { ButtonLoading } from "@/components/ui/button-loading"
import { logError } from "@/lib/utils/error-logger"
import { sanitizeUserInput } from "@/lib/utils/sanitize"
import { Turnstile } from "@/components/ui/turnstile"
import { turnstileConfig } from "@/lib/config/turnstile"

export function ContactFormContent() {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<ContactFormValues>({
    name: "",
    email: "",
    subject: "",
    message: "",
  })
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof ContactFormValues, string>>>({})
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [honeypot, setHoneypot] = useState("")
  const [mounted, setMounted] = useState(false)
  const [turnstileToken, setTurnstileToken] = useState<string | null>(null)
  const [turnstileError, setTurnstileError] = useState<boolean>(false)
  const formRef = useRef<HTMLFormElement>(null)
  const submittingRef = useRef(false)

  // Prevent form submission until client-side JS is loaded
  useEffect(() => {
    setMounted(true)
    return () => {
      setMounted(false)
      submittingRef.current = false
    }
  }, [])

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const { name, value } = e.target
      setFormData((prev) => ({ ...prev, [name]: sanitizeUserInput(value) }))

      // Clear error when field is edited
      if (formErrors[name as keyof ContactFormValues]) {
        setFormErrors((prev) => ({ ...prev, [name]: undefined }))
      }
    },
    [formErrors],
  )

  const handleSelectChange = useCallback(
    (value: string) => {
      setFormData((prev) => ({ ...prev, subject: value }))

      // Clear error when field is edited
      if (formErrors.subject) {
        setFormErrors((prev) => ({ ...prev, subject: undefined }))
      }
    },
    [formErrors],
  )

  const validateForm = useCallback((): boolean => {
    try {
      contactFormSchema.parse(formData)
      setFormErrors({})
      return true
    } catch (error) {
      if (error instanceof z.ZodError) {
        const errors: Partial<Record<keyof ContactFormValues, string>> = {}
        error.errors.forEach((err) => {
          if (err.path[0]) {
            errors[err.path[0] as keyof ContactFormValues] = err.message
          }
        })
        setFormErrors(errors)
      }
      return false
    }
  }, [formData])

  const verifyTurnstileToken = useCallback(async (token: string): Promise<boolean> => {
    try {
      // Skip verification if Turnstile is disabled
      if (!turnstileConfig.enabled) {
        return true
      }

      const response = await fetch("/api/verify-turnstile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token }),
      })

      const data = await response.json()
      return data.success
    } catch (error) {
      console.error("Error verifying Turnstile token:", error)
      return false
    }
  }, [])

  const handleSubmit = useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault()

      // Prevent double submissions
      if (submittingRef.current) return
      submittingRef.current = true

      // Security check: If honeypot field is filled, silently reject the submission
      if (honeypot) {
        console.log("Potential bot submission detected")
        // Pretend to submit successfully to avoid alerting bots
        setIsSubmitting(true)
        await new Promise((resolve) => setTimeout(resolve, 1500))
        setFormSubmitted(true)
        setIsSubmitting(false)
        submittingRef.current = false
        return
      }

      if (!validateForm()) {
        toast({
          title: "Form validation error",
          description: "Please check the form for errors and try again.",
          variant: "destructive",
        })
        submittingRef.current = false
        return
      }

      // Verify Turnstile token if enabled
      if (turnstileConfig.enabled && !turnstileToken) {
        toast({
          title: "Verification required",
          description: "Please complete the Cloudflare Turnstile challenge.",
          variant: "destructive",
        })
        setTurnstileError(true)
        submittingRef.current = false
        return
      }

      setIsSubmitting(true)

      try {
        // Verify Turnstile token if enabled
        if (turnstileConfig.enabled && turnstileToken) {
          const isValid = await verifyTurnstileToken(turnstileToken)
          if (!isValid) {
            toast({
              title: "Verification failed",
              description: "The security verification failed. Please try again.",
              variant: "destructive",
            })
            setTurnstileError(true)
            setIsSubmitting(false)
            submittingRef.current = false
            return
          }
        }

        // Simulate form submission
        await new Promise((resolve) => setTimeout(resolve, 1500))

        // Show success message
        setFormSubmitted(true)
        toast({
          title: "Message sent",
          description: "Thank you for your message. I will get back to you as soon as possible.",
        })

        // Reset form after submission
        setFormData({
          name: "",
          email: "",
          subject: "",
          message: "",
        })
        setTurnstileToken(null)

        if (formRef.current) {
          formRef.current.reset()
        }
      } catch (error) {
        logError("Error submitting contact form", error as Error, { formData })
        toast({
          title: "Error",
          description: "There was a problem sending your message. Please try again.",
          variant: "destructive",
        })
      } finally {
        setIsSubmitting(false)
        submittingRef.current = false
      }
    },
    [formData, honeypot, validateForm, turnstileToken, verifyTurnstileToken],
  )

  const resetForm = useCallback(() => {
    setFormSubmitted(false)
    setFormData({
      name: "",
      email: "",
      subject: "",
      message: "",
    })
    setFormErrors({})
    setTurnstileToken(null)
    setTurnstileError(false)
    if (formRef.current) {
      formRef.current.reset()
    }
  }, [])

  const handleTurnstileVerify = useCallback((token: string) => {
    setTurnstileToken(token)
    setTurnstileError(false)
  }, [])

  const handleTurnstileError = useCallback(() => {
    setTurnstileError(true)
    setTurnstileToken(null)
  }, [])

  const handleTurnstileExpire = useCallback(() => {
    setTurnstileToken(null)
  }, [])

  return (
    <CardContent className="p-6 pt-8">
      {formSubmitted ? (
        <div className="text-center py-8">
          <h3 className="text-xl font-medium mb-3">Thank you for your message!</h3>
          <p className="text-muted-foreground mb-6">I'll get back to you as soon as possible.</p>
          <Button onClick={resetForm} className="px-6">
            Send another message
          </Button>
        </div>
      ) : (
        <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2.5">
            <Label htmlFor="name" className="text-sm font-medium">
              Full Name
            </Label>
            <Input
              id="name"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="Your name"
              aria-required="true"
              aria-invalid={!!formErrors.name}
              aria-describedby={formErrors.name ? "name-error" : undefined}
              autoComplete="name"
              maxLength={100}
              className="h-11"
            />
            {formErrors.name && (
              <p id="name-error" className="text-sm text-destructive mt-1.5">
                {formErrors.name}
              </p>
            )}
          </div>

          <div className="space-y-2.5">
            <Label htmlFor="email" className="text-sm font-medium">
              Email
            </Label>
            <Input
              id="email"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="your@email.com"
              aria-required="true"
              aria-invalid={!!formErrors.email}
              aria-describedby={formErrors.email ? "email-error" : undefined}
              autoComplete="email"
              maxLength={100}
              className="h-11"
            />
            {formErrors.email && (
              <p id="email-error" className="text-sm text-destructive mt-1.5">
                {formErrors.email}
              </p>
            )}
          </div>

          <div className="space-y-2.5">
            <Label htmlFor="subject" className="text-sm font-medium">
              Subject
            </Label>
            <Select value={formData.subject} onValueChange={handleSelectChange}>
              <SelectTrigger id="subject" aria-required="true" className="h-11">
                <SelectValue placeholder="Select a subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="general">General</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
            {formErrors.subject && (
              <p id="subject-error" className="text-sm text-destructive mt-1.5">
                {formErrors.subject}
              </p>
            )}
          </div>

          <div className="space-y-2.5">
            <Label htmlFor="message" className="text-sm font-medium">
              Your Message
            </Label>
            <Textarea
              id="message"
              name="message"
              value={formData.message}
              onChange={handleChange}
              placeholder="Your message..."
              rows={6}
              aria-required="true"
              aria-invalid={!!formErrors.message}
              aria-describedby={formErrors.message ? "message-error" : undefined}
              maxLength={1000}
              className="min-h-[120px] resize-y"
            />
            {formErrors.message && (
              <p id="message-error" className="text-sm text-destructive mt-1.5">
                {formErrors.message}
              </p>
            )}
          </div>

          {/* Turnstile widget */}
          {turnstileConfig.enabled && (
            <div className="mt-6 flex justify-center">
              <div className={turnstileError ? "border border-destructive rounded-md p-1" : ""}>
                <Turnstile
                  onVerify={handleTurnstileVerify}
                  onError={handleTurnstileError}
                  onExpire={handleTurnstileExpire}
                />
                {turnstileError && (
                  <p className="text-sm text-destructive mt-2 text-center">Please complete the security verification</p>
                )}
                {turnstileConfig.testMode && (
                  <p className="text-xs text-muted-foreground mt-1 text-center">
                    Turnstile is in test mode. No real verification will be performed.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Honeypot field to catch bots */}
          <div className="hidden" aria-hidden="true">
            <label htmlFor="website">Website (leave this empty)</label>
            <input
              type="text"
              id="website"
              name="website"
              tabIndex={-1}
              autoComplete="off"
              value={honeypot}
              onChange={(e) => setHoneypot(e.target.value)}
            />
          </div>

          <ButtonLoading
            type="submit"
            isLoading={isSubmitting}
            loadingText="Sending..."
            className="w-full h-11 mt-8"
            disabled={!mounted || isSubmitting || (turnstileConfig.enabled && !turnstileToken)}
          >
            Send Message
          </ButtonLoading>
        </form>
      )}
    </CardContent>
  )
}

// GitHub types
export interface GitHubEvent {
  id: string
  type: string
  actor: {
    login: string
    avatar_url: string
    url: string
  }
  repo: {
    name: string
    url: string
  }
  payload: {
    action?: string
    ref?: string
    ref_type?: string
    description?: string
    master_branch?: string
    pusher_type?: string
    push_id?: number
    size?: number
    distinct_size?: number
    commits?: GitHubCommit[]
    pull_request?: {
      title: string
      html_url: string
      number: number
    }
    issue?: {
      title: string
      html_url: string
      number: number
    }
    comment?: {
      body: string
      html_url: string
    }
  }
  created_at: string
  public: boolean
}

export interface GitHubCommit {
  sha: string
  author: {
    email: string
    name: string
  }
  message: string
  distinct: boolean
  url: string
}

// Bluesky types
export interface BlueskyPost {
  uri: string
  cid: string
  author: {
    did: string
    handle: string
    displayName?: string
    avatar?: string
  }
  record: {
    text: string
    createdAt: string
    $type: string
    embed?: {
      $type: string
      images?: {
        alt: string
        image: {
          ref: string
          mimeType: string
        }
      }[]
      external?: {
        uri: string
        title: string
        description: string
      }
    }
  }
  indexedAt: string
  replyCount: number
  repostCount: number
  likeCount: number
  viewer: {
    like?: string
    repost?: string
  }
}

// Mastodon types
export interface MastodonPost {
  id: string
  created_at: string
  content: string
  account: {
    id: string
    username: string
    acct: string
    display_name: string
    avatar: string
    avatar_static: string
    url: string
  }
  media_attachments: {
    id: string
    type: string
    url: string
    preview_url: string
    description?: string
  }[]
  url: string
  favourites_count: number
  reblogs_count: number
  replies_count: number
  visibility: string
}

import type React from "react"

// Note type
export interface Note {
  slug: string
  title: string
  date: string
  excerpt: string
  content: string
  category?: string
  tags?: string[]
  author?: string
  readingTime?: string
}

// Project type
export interface Project {
  id: number
  title: string
  description: string
  imageUrl: string
  category: string
  tags: string[]
  url?: string
  githubUrl?: string
  isFeatured?: boolean
}

// Social link type
export interface SocialLink {
  name: string
  url: string
  icon: React.ReactNode
}

export interface NavItem {
  href: string
  label: string
  children?: NavItem[]
  icon?: string
}

export interface FooterLink {
  href: string
  label: string
}

export interface SiteConfig {
  name: string
  description: string
  url: string
  ogImage: string
  links: {
    twitter: string
    github: string
  }
}

export interface ThemeConfig {
  defaultTheme: string
  enableSystem: boolean
  themes?: string[]
}

export interface Post {
  id: number | string
  title: string
  excerpt?: string
  date: string
  slug?: string
  content?: string
  category?: string
  author?: string
  image?: string
}

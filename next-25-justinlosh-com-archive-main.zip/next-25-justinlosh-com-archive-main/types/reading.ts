export interface ReadingItem {
  id: string
  title: string
  author: string
  coverUrl?: string
  summary?: string
  status: "reading" | "read" | "to-read"
  rating?: number
  review?: string
  dateUpdated: string
  goodreadsUrl: string
  progress?: number
  hasRating?: boolean // Flag to indicate if the book has a rating
}

export interface ReadingResponse {
  items: ReadingItem[]
  totalItems: number
  success: boolean
  error?: string
}

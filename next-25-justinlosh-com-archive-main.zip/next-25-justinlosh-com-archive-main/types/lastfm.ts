export interface LastFmTrack {
  name: string
  artist: {
    name: string
    url: string
  }
  album?: {
    name: string
    url: string
  }
  url: string
  image: {
    size: string
    "#text": string
  }[]
  date?: {
    uts: string
    "#text": string
  }
  loved?: "0" | "1" // Added loved property
}

export interface LastFmArtist {
  name: string
  playcount: string
  url: string
  image: {
    size: string
    "#text": string
  }[]
}

export interface LastFmAlbum {
  name: string
  artist: {
    name: string
    url: string
  }
  playcount: string
  url: string
  image: {
    size: string
    "#text": string
  }[]
}

export interface LastFmStats {
  user: string
  period: string
  total: {
    tracks: number
    artists: number
    albums: number
  }
  recentTracks: LastFmTrack[]
  topArtists: LastFmArtist[]
  topAlbums: LastFmAlbum[]
  lovedTracks?: LastFmTrack[] // Added lovedTracks property
  profileUrl: string
  lastUpdated: string
}

export interface LastFmApiResponse {
  success: boolean
  stats?: LastFmStats
  error?: string
}

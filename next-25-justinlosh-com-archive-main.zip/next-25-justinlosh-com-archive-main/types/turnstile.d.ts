interface TurnstileObject {
  render: (
    container: HTMLElement,
    options: {
      sitekey: string
      callback: (token: string) => void
      "error-callback"?: () => void
      "expired-callback"?: () => void
      theme?: "light" | "dark" | "auto"
      action?: string
    },
  ) => string
  reset: (widgetId: string) => void
  remove: (widgetId: string) => void
}

declare global {
  interface Window {
    turnstile?: TurnstileObject
  }
}

export {}

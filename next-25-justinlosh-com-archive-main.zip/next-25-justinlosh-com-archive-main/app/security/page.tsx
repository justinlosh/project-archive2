import { LastUpdated } from "@/components/ui/last-updated"
import Link from "next/link"

export const metadata = {
  title: "Security - Justin Losh",
  description: "Security information and responsible disclosure policy",
}

export default function SecurityPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-4">Security</h1>
      <p className="text-lg text-muted-foreground mb-8">
        This page is currently a placeholder, but overall please refer to the security.txt file on this website.
      </p>
      <div className="prose dark:prose-invert">
        <h2>Responsible Disclosure</h2>
        <p>
          Please refer to the{" "}
          <Link href="/.well-known/security.txt" className="font-medium underline underline-offset-4">
            security.txt
          </Link>{" "}
          file on this website.
        </p>

        <h2>Acknowledgements</h2>
        <p>Nothing to report here!</p>
      </div>

      <LastUpdated date="2024-03-18" className="mt-12" />
    </div>
  )
}

import { LastUpdated } from "@/components/ui/last-updated"
import Link from "next/link"

export const metadata = {
  title: "Disclaimer - Justin Losh",
  description: "Legal disclaimer and terms of use for justinlosh.com",
}

export default function DisclaimerPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-4">Disclaimer</h1>
      <p className="text-lg text-muted-foreground mb-8">
        This disclaimer clarifies the terms of use for this website and its content. While I strive for accuracy and
        reliability in all published materials, this page outlines important limitations and considerations for
        visitors.
      </p>
      <div className="prose dark:prose-invert">
        <h2>Affiliate & Referral Links</h2>
        <p>
          This website may contain affiliate links or referral codes. If you click on a link or use a code to make a
          purchase, I may earn a small commission at no extra cost to you. These help support the site and allow me to
          continue providing valuable content.
        </p>

        <h2>Transparency & Integrity</h2>
        <p>
          I only recommend products and services that I personally use, trust, or have thoroughly researched. I will
          never promote anything I do not believe in or that may be harmful to my audience.
        </p>

        <h2>Your Choice, Your Support</h2>
        <p>
          Using affiliate links or referral codes is entirely optional. Your trust is my priority, and I strive to
          provide honest, unbiased information regardless of any potential commission.
        </p>

        <h2>Additional Disclaimers</h2>
        <ul>
          <li>
            Content on this website is for informational purposes only and should not be considered professional advice.
          </li>
          <li>Opinions expressed are my own and do not reflect those of my employer, projects, or affiliates.</li>
          <li>I am not responsible for any actions taken by readers based on the content provided.</li>
          <li>This disclaimer is subject to change at any time.</li>
        </ul>

        <p>
          For more details, please review the{" "}
          <Link href="/privacy" className="font-medium underline underline-offset-4">
            Privacy Policy
          </Link>
          .
        </p>
      </div>

      <LastUpdated date="2024-03-18" className="mt-12" />
    </div>
  )
}

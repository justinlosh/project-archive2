import { ProjectCardEnhanced } from "@/components/project-card-enhanced"
import { getAllProjects } from "@/lib/services/project-service"
import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "Projects - Justin Losh",
  description: "A showcase of my recent projects and open source contributions in web development and technology.",
}

export default async function ProjectsPage() {
  // Fetch projects with error handling
  let projects = []

  try {
    projects = await getAllProjects()

    // Sort projects to ensure featured projects appear at the top
    projects = projects.sort((a, b) => {
      // If a is featured and b is not, a comes first
      if (a.isFeatured && !b.isFeatured) return -1
      // If b is featured and a is not, b comes first
      if (!a.isFeatured && b.isFeatured) return 1
      // Otherwise, maintain the original order
      return 0
    })
  } catch (error) {
    console.error("Error fetching projects:", error)
  }

  return (
    <div className="container max-w-5xl py-12">
      <div className="w-full mb-12 text-center">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Projects</h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          A showcase of my work, side projects, and open source contributions. Each project represents a unique
          challenge and learning experience.
        </p>
      </div>

      {/* Projects Section with consistent card layout */}
      <section>
        <div className="grid gap-8">
          {projects.map((project) => (
            <ProjectCardEnhanced key={project.id} project={project} featured={project.isFeatured} className="h-full" />
          ))}

          {projects.length === 0 && (
            <div className="text-center py-12 text-muted-foreground">No projects available at the moment.</div>
          )}
        </div>
      </section>
      <LastUpdated date="2024-03-25" className="mt-12" />
    </div>
  )
}

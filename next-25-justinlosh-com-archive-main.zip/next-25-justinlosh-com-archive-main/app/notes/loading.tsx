import { Skeleton } from "@/components/ui/skeleton"

export default function NotesLoading() {
  return (
    <div className="container max-w-4xl py-10">
      <div className="mb-10">
        <Skeleton className="h-12 w-32 mb-4" />
        <Skeleton className="h-6 w-3/4" />
      </div>

      <div className="space-y-8">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="space-y-3 pb-6 border-b">
            {/* Update the loading skeleton to match the new structure */}
            <Skeleton className="h-8 w-full" />
            <div className="flex items-center gap-4">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-5 w-20 rounded-full" />
            </div>
            <Skeleton className="h-4 w-5/6" />
          </div>
        ))}
      </div>
    </div>
  )
}

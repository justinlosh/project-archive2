import { notFound, redirect } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { format } from "date-fns"
import { ArrowLeft, Calendar, Tag } from "lucide-react"
import { BlogPostJSONLD } from "@/components/json-ld"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { getNoteBySlug, getAvailableYears } from "@/lib/services/notes-service"
import { env } from "@/lib/env"
import { Card, CardContent } from "@/components/ui/card"
import { getGravatarUrl } from "@/lib/utils/gravatar"
import { NoteContentWrapper } from "@/components/notes/note-content-wrapper"
import { ShareButtonWrapper } from "@/components/notes/share-button-wrapper"
import { CategoryBadgeWrapper } from "@/components/ui/category-badge-wrapper"
import { ErrorBoundary } from "@/components/error-boundary"

export async function generateMetadata({ params }: { params: { slug: string[] } }) {
  // Validate slug format
  if (!params.slug || !Array.isArray(params.slug) || params.slug.length === 0) {
    return {
      title: "Notes - Justin Losh",
      description: "Thoughts, articles, and documentation on web development and technology.",
    }
  }

  // Join the slug parts to form the complete slug
  const fullSlug = params.slug.join("/")

  let note
  try {
    note = await getNoteBySlug(fullSlug)
  } catch (error) {
    console.error(`Error fetching note metadata for slug ${fullSlug}:`, error)
  }

  if (!note) {
    return {
      title: "Note Not Found - Justin Losh",
      description: "The requested note could not be found.",
    }
  }

  return {
    title: note.title,
    description: note.excerpt || "",
    openGraph: {
      title: note.title,
      description: note.excerpt || "",
      type: "article",
      publishedTime: note.date,
      url: `${env.SITE_URL}/notes/${note.slug}`,
      images: [
        {
          url: note.image || `${env.SITE_URL}/og-image.jpg`,
          width: 1200,
          height: 630,
          alt: note.title,
        },
      ],
    },
    twitter: {
      card: "summary_large_image",
      title: note.title,
      description: note.excerpt || "",
    },
  }
}

export default async function NotePage({ params }: { params: { slug: string[] } }) {
  // Validate slug format
  if (!params.slug || !Array.isArray(params.slug) || params.slug.length === 0) {
    redirect("/notes")
  }

  // Join the slug parts to form the complete slug
  const fullSlug = params.slug.join("/")

  let note
  try {
    note = await getNoteBySlug(fullSlug)
  } catch (error) {
    console.error(`Error fetching note for slug ${fullSlug}:`, error)
  }

  if (!note) {
    notFound()
  }

  const noteUrl = `${env.SITE_URL}/notes/${note.slug}`
  const formattedDate = format(new Date(note.date), "MMMM d, yyyy")
  const authorName = note.author || env.AUTHOR_NAME
  const gravatarUrl = getGravatarUrl(96)

  // Extract year from the slug for the "Back to Year" link
  const year = note.slug.split("/")[0]

  // Validate that the year exists in our available years
  const availableYears = await getAvailableYears()
  const isValidYear = year && /^\d{4}$/.test(year) && availableYears.includes(year)

  return (
    <>
      <BlogPostJSONLD
        url={noteUrl}
        title={note.title}
        description={note.excerpt || ""}
        datePublished={note.date}
        authorName={authorName}
        imageUrl={note.image}
      />

      <article className="container max-w-3xl py-10">
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-6">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/notes" className="flex items-center text-muted-foreground hover:text-foreground">
                <ArrowLeft className="mr-2 h-4 w-4" />
                All notes
              </Link>
            </Button>

            {isValidYear && (
              <Button variant="ghost" size="sm" asChild>
                <Link href={`/notes/${year}`} className="flex items-center text-muted-foreground hover:text-foreground">
                  <Calendar className="mr-2 h-4 w-4" />
                  {year} archive
                </Link>
              </Button>
            )}
          </div>

          <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">{note.title}</h1>

          {note.excerpt && <p className="text-xl text-muted-foreground mb-6">{note.excerpt}</p>}

          <div className="flex items-center text-sm text-muted-foreground">
            <Calendar className="mr-1 h-3.5 w-3.5" />
            <time dateTime={note.date}>{formattedDate}</time>
          </div>
        </div>

        {note.image && (
          <div className="relative w-full h-[300px] md:h-[400px] mb-8 rounded-lg overflow-hidden">
            <Image
              src={note.image || "/placeholder.svg?height=800&width=1200"}
              alt={note.title}
              fill
              className="object-cover"
              priority
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 80vw, 1200px"
            />
          </div>
        )}

        <Separator className="mb-8" />

        <ErrorBoundary>
          <NoteContentWrapper content={note.content} />
        </ErrorBoundary>

        <Separator className="my-8" />

        <Card className="mt-8 bg-muted/50 border-muted">
          <CardContent className="pt-6">
            <div className="flex flex-col space-y-6">
              <div className="flex items-center gap-4">
                <Avatar className="h-12 w-12 border-2 border-background">
                  <AvatarImage src={gravatarUrl} alt={authorName} />
                  <AvatarFallback className="text-base font-medium">{authorName.charAt(0)}</AvatarFallback>
                </Avatar>

                <div className="flex-1">
                  <p className="text-sm text-muted-foreground">Written by</p>
                  <p className="font-medium">{authorName}</p>
                </div>
              </div>

              <Separator />

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex flex-col gap-2">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <time className="text-muted-foreground" dateTime={note.date}>
                      {formattedDate}
                    </time>
                  </div>

                  {note.category && (
                    <div className="flex items-center gap-2 text-sm">
                      <Tag className="h-4 w-4 text-muted-foreground" />
                      <CategoryBadgeWrapper category={note.category} />
                    </div>
                  )}
                </div>

                <ShareButtonWrapper title={note.title} url={noteUrl} />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-center mt-8">
          <Button variant="outline" asChild>
            <Link href={isValidYear ? `/notes/${year}` : "/notes"}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              {isValidYear ? `Back to ${year} Archive` : "Back to All Notes"}
            </Link>
          </Button>
        </div>
      </article>
    </>
  )
}

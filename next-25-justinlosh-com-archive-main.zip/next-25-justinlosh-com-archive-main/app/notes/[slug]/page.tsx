"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowLeft, Calendar, Tag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent } from "@/components/ui/card"
import { useParams } from "next/navigation"

// Sample notes data for static rendering
const notes = [
  {
    slug: "getting-started-with-nextjs",
    title: "Getting Started with Next.js",
    date: "2023-05-01",
    excerpt: "Learn the basics of Next.js and start building amazing web applications with the React framework.",
    content:
      "Next.js is a powerful React framework that makes it easy to build server-side rendered and statically generated web applications. In this post, we'll explore the basics of Next.js and how to get started with your first project.",
    category: "Development",
    tags: ["Next.js", "React", "Web Development"],
  },
  {
    slug: "mastering-typescript",
    title: "Mastering TypeScript",
    date: "2023-04-15",
    excerpt:
      "Discover how TypeScript can improve your development workflow and help catch errors before they reach production.",
    content:
      "TypeScript is a strongly typed programming language that builds on JavaScript. In this post, we'll explore how TypeScript can help you write more robust code and catch errors before they reach production.",
    category: "Development",
    tags: ["TypeScript", "JavaScript", "Web Development"],
  },
  {
    slug: "responsive-design-principles",
    title: "Responsive Design Principles",
    date: "2023-03-20",
    excerpt:
      "Essential principles for creating websites that work well on devices of all sizes, from mobile to desktop.",
    content:
      "Responsive design is an approach to web design that makes your web pages look good on all devices. In this post, we'll explore the key principles of responsive design and how to implement them in your projects.",
    category: "Design",
    tags: ["CSS", "Responsive Design", "Web Development"],
  },
  {
    slug: "introduction-to-tailwind-css",
    title: "Introduction to Tailwind CSS",
    date: "2023-02-10",
    excerpt: "Learn how to use Tailwind CSS to rapidly build modern websites without ever leaving your HTML.",
    content:
      "Tailwind CSS is a utility-first CSS framework that allows you to build custom designs without ever leaving your HTML. In this post, we'll explore the basics of Tailwind CSS and how to get started with it in your projects.",
    category: "Design",
    tags: ["CSS", "Tailwind CSS", "Web Development"],
  },
]

// Constants
const AUTHOR_NAME = "Justin Losh"

export default function NotePage() {
  const params = useParams()
  const [note, setNote] = useState(null)
  const [formattedDate, setFormattedDate] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(false)

  useEffect(() => {
    try {
      // Get the slug from params
      const slug = params?.slug

      if (!slug) {
        setError(true)
        setLoading(false)
        return
      }

      // Find the note by slug
      const foundNote = notes.find((n) => n.slug === slug)

      if (!foundNote) {
        setError(true)
        setLoading(false)
        return
      }

      // Set the note
      setNote(foundNote)

      // Format the date
      const date = new Date(foundNote.date)
      setFormattedDate(
        date.toLocaleDateString("en-US", {
          year: "numeric",
          month: "long",
          day: "numeric",
        }),
      )

      setLoading(false)
    } catch (err) {
      console.error("Error loading note:", err)
      setError(true)
      setLoading(false)
    }
  }, [params])

  if (loading) {
    return (
      <div className="container max-w-3xl py-10">
        <div className="animate-pulse">
          <div className="h-8 w-32 bg-muted rounded mb-6"></div>
          <div className="h-12 w-3/4 bg-muted rounded mb-4"></div>
          <div className="h-6 w-full bg-muted rounded mb-6"></div>
          <div className="h-4 w-24 bg-muted rounded mb-8"></div>
          <div className="h-64 w-full bg-muted rounded"></div>
        </div>
      </div>
    )
  }

  if (error || !note) {
    return (
      <div className="container max-w-3xl py-10">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Note Not Found</h1>
          <p className="text-muted-foreground mb-6">The note you're looking for doesn't exist or has been moved.</p>
          <Button asChild>
            <Link href="/notes">Back to Notes</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <article className="container max-w-3xl py-10">
      <div className="mb-8">
        <Button variant="ghost" size="sm" asChild className="mb-6">
          <Link href="/notes" className="flex items-center text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to all notes
          </Link>
        </Button>

        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">{note.title}</h1>

        {note.excerpt && <p className="text-xl text-muted-foreground mb-6">{note.excerpt}</p>}

        <div className="flex items-center text-sm text-muted-foreground">
          <Calendar className="mr-1 h-3.5 w-3.5" />
          <time dateTime={note.date}>{formattedDate}</time>
        </div>
      </div>

      <Separator className="mb-8" />

      <div className="prose dark:prose-invert max-w-none">{note.content}</div>

      <Separator className="my-8" />

      <Card className="mt-8 bg-muted/50 border-muted">
        <CardContent className="pt-6">
          <div className="flex flex-col space-y-6">
            <div className="flex items-center gap-4">
              <Avatar className="h-12 w-12 border-2 border-background">
                <AvatarImage src="/placeholder.svg?height=96&width=96&text=JL" alt={AUTHOR_NAME} />
                <AvatarFallback className="text-base font-medium">{AUTHOR_NAME.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <p className="text-sm text-muted-foreground">Written by</p>
                <p className="font-medium">{AUTHOR_NAME}</p>
              </div>
            </div>

            <Separator />

            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <time className="text-muted-foreground" dateTime={note.date}>
                    {formattedDate}
                  </time>
                </div>

                {note.category && (
                  <div className="flex items-center gap-2 text-sm">
                    <Tag className="h-4 w-4 text-muted-foreground" />
                    <span className="px-1.5 py-0.5 bg-muted text-muted-foreground rounded-md text-xs">
                      {note.category}
                    </span>
                  </div>
                )}
              </div>

              <Button variant="outline" size="sm" asChild>
                <Link href="/notes" className="flex items-center">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to all notes
                </Link>
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </article>
  )
}

import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"

export default function NoteLoading() {
  return (
    <div className="container max-w-3xl py-10">
      <div className="mb-8">
        <Skeleton className="h-10 w-32 mb-6" />
        <Skeleton className="h-12 w-full mb-4" />
        <Skeleton className="h-6 w-3/4 mb-6" />
        <Skeleton className="h-4 w-24" />
      </div>

      <Skeleton className="w-full h-[300px] md:h-[400px] mb-8 rounded-lg" />

      <div className="space-y-4 mb-8">
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-6 w-5/6" />
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-6 w-4/5" />
        <Skeleton className="h-6 w-full" />
      </div>

      {/* Author metadata card skeleton */}
      <Card className="mt-8 bg-muted/50">
        <CardContent className="pt-6">
          <div className="flex flex-col space-y-6">
            {/* Author skeleton */}
            <div className="flex items-center gap-4">
              <Skeleton className="h-12 w-12 rounded-full" />
              <div className="flex-1">
                <Skeleton className="h-3 w-20 mb-2" />
                <Skeleton className="h-5 w-32" />
              </div>
            </div>

            <Separator />

            {/* Metadata and share button skeleton */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex flex-col gap-2">
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-5 w-24 rounded-full" />
              </div>

              <Skeleton className="h-9 w-32 sm:w-40" />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center mt-8">
        <Skeleton className="h-10 w-40" />
      </div>
    </div>
  )
}

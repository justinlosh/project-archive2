export const metadata = {
  title: "Note | Justin Losh",
  description: "Read my thoughts and notes on web development, design, and technology.",
}

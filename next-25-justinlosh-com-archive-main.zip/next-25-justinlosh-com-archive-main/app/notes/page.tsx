import { Suspense } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Calendar, Clock } from "lucide-react"

// Sample notes data for static rendering
const notes = [
  {
    slug: "getting-started-with-nextjs",
    title: "Getting Started with Next.js",
    date: "2023-05-01",
    excerpt: "Learn the basics of Next.js and start building amazing web applications with the React framework.",
    content:
      "Next.js is a powerful React framework that makes it easy to build server-side rendered and statically generated web applications. In this post, we'll explore the basics of Next.js and how to get started with your first project.",
    category: "Development",
    tags: ["Next.js", "React", "Web Development"],
    readTime: "5 min read",
  },
  {
    slug: "mastering-typescript",
    title: "Mastering TypeScript",
    date: "2023-04-15",
    excerpt:
      "Discover how TypeScript can improve your development workflow and help catch errors before they reach production.",
    content:
      "TypeScript is a strongly typed programming language that builds on JavaScript. In this post, we'll explore how TypeScript can help you write more robust code and catch errors before they reach production.",
    category: "Development",
    tags: ["TypeScript", "JavaScript", "Web Development"],
    readTime: "8 min read",
  },
  {
    slug: "responsive-design-principles",
    title: "Responsive Design Principles",
    date: "2023-03-20",
    excerpt:
      "Essential principles for creating websites that work well on devices of all sizes, from mobile to desktop.",
    content:
      "Responsive design is an approach to web design that makes your web pages look good on all devices. In this post, we'll explore the key principles of responsive design and how to implement them in your projects.",
    category: "Design",
    tags: ["CSS", "Responsive Design", "Web Development"],
    readTime: "6 min read",
  },
  {
    slug: "introduction-to-tailwind-css",
    title: "Introduction to Tailwind CSS",
    date: "2023-02-10",
    excerpt: "Learn how to use Tailwind CSS to rapidly build modern websites without ever leaving your HTML.",
    content:
      "Tailwind CSS is a utility-first CSS framework that allows you to build custom designs without ever leaving your HTML. In this post, we'll explore the basics of Tailwind CSS and how to get started with it in your projects.",
    category: "Design",
    tags: ["CSS", "Tailwind CSS", "Web Development"],
    readTime: "4 min read",
  },
]

export const metadata = {
  title: "Notes - Justin Losh",
  description: "Thoughts, articles, and documentation on web development and technology.",
}

export default function NotesPage() {
  return (
    <div className="container max-w-4xl py-10">
      <div className="mb-10">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Notes</h1>
        <p className="text-xl text-muted-foreground">
          Thoughts, articles, and documentation on web development and technology.
        </p>
      </div>

      <Suspense
        fallback={
          <div className="space-y-6">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="space-y-3 p-6 border rounded-lg">
                <Skeleton className="h-6 w-3/4" />
                <div className="flex items-center gap-4">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-5/6" />
              </div>
            ))}
          </div>
        }
      >
        <div className="space-y-6">
          {notes.map((note) => (
            <Link key={note.slug} href={`/notes/${note.slug}`} className="group block">
              <article className="p-6 border rounded-lg transition-colors hover:border-primary/50 hover:bg-muted/50">
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-4">
                    <h2 className="text-xl font-semibold group-hover:text-primary transition-colors">{note.title}</h2>
                    {note.category && (
                      <Badge variant="secondary" className="text-xs shrink-0">
                        {note.category}
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-4 w-4" />
                      {format(new Date(note.date), "MMM d, yyyy")}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {note.readTime}
                    </div>
                  </div>

                  <p className="text-muted-foreground leading-relaxed">{note.excerpt}</p>

                  {note.tags && note.tags.length > 0 && (
                    <div className="flex flex-wrap gap-2 pt-2">
                      {note.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>
              </article>
            </Link>
          ))}
        </div>
      </Suspense>
    </div>
  )
}

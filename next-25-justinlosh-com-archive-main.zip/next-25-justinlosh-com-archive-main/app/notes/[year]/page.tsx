import type { Metadata } from "next"
import { redirect } from "next/navigation"
import { getNotesByYear, getAvailableYears } from "@/lib/services/notes-service"
import { Suspense } from "react"
import { Skeleton } from "@/components/ui/skeleton"
import { NotesListClient } from "@/components/notes/notes-list-client"
import { ErrorBoundary } from "@/components/error-boundary"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft, AlertCircle } from "lucide-react"
import { YearArchiveNav } from "@/components/notes/year-archive-nav"

export async function generateMetadata({ params }: { params: { year: string } }): Promise<Metadata> {
  const year = params.year

  // Validate year format
  if (!/^\d{4}$/.test(year)) {
    return {
      title: "Notes - Justin Losh",
      description: "Thoughts, articles, and documentation on web development and technology.",
    }
  }

  return {
    title: `${year} Notes - Justin Losh`,
    description: `Archive of blog posts and notes from ${year}.`,
  }
}

export default async function YearArchivePage({ params }: { params: { year: string } }) {
  const year = params.year

  // Validate year format
  if (!/^\d{4}$/.test(year)) {
    // Redirect to the main notes page if the year format is invalid
    redirect("/notes")
  }

  // Get available years for navigation
  const availableYears = await getAvailableYears()

  // If the year doesn't exist in our archives, don't 404, just show empty state
  const yearExists = availableYears.includes(year)

  // Get notes for the specified year (will be empty if year doesn't exist)
  const notes = yearExists ? await getNotesByYear(year) : []

  return (
    <div className="container max-w-4xl py-10">
      <div className="mb-6">
        <Button variant="ghost" size="sm" asChild className="mb-4">
          <Link href="/notes" className="flex items-center text-muted-foreground hover:text-foreground">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to all notes
          </Link>
        </Button>

        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Notes from {year}</h1>
        <p className="text-xl text-muted-foreground">Browse through all articles and notes published in {year}.</p>
      </div>

      {/* Year navigation */}
      <YearArchiveNav currentYear={year} availableYears={availableYears} className="mb-8" />

      {!yearExists && (
        <div className="py-8 px-6 bg-muted/30 rounded-lg border border-muted mb-8">
          <div className="flex items-start gap-4">
            <AlertCircle className="h-6 w-6 text-muted-foreground mt-1" />
            <div>
              <h3 className="text-lg font-medium mb-2">No content for {year}</h3>
              <p className="text-muted-foreground mb-4">
                There are no notes published for the year {year}. Please select another year or browse all notes.
              </p>
              <Button asChild>
                <Link href="/notes">View all notes</Link>
              </Button>
            </div>
          </div>
        </div>
      )}

      {yearExists && (
        <Suspense
          fallback={
            <div className="space-y-8">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="space-y-3 pb-6 border-b">
                  <Skeleton className="h-8 w-full" />
                  <div className="flex items-center gap-4">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-5 w-20 rounded-full" />
                  </div>
                  <Skeleton className="h-4 w-5/6" />
                </div>
              ))}
            </div>
          }
        >
          <ErrorBoundary>
            <NotesListClient initialNotes={notes} />
          </ErrorBoundary>
        </Suspense>
      )}

      {yearExists && notes.length === 0 && (
        <div className="py-12 text-center">
          <p className="text-muted-foreground mb-4">No notes found for {year}.</p>
          <Button asChild>
            <Link href="/notes">View all notes</Link>
          </Button>
        </div>
      )}
    </div>
  )
}

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "Style Guide - Justin Losh",
  description: "Design system and component documentation for justinlosh.com",
}

export default function StyleGuidePage() {
  return (
    <div className="container max-w-4xl py-12">
      <h1 className="text-4xl font-bold mb-8">Style Guide</h1>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Typography</h2>
        <div className="space-y-4">
          <div>
            <h1 className="text-4xl font-bold">Heading 1</h1>
            <p className="text-sm text-muted-foreground">4xl / Bold</p>
          </div>
          <div>
            <h2 className="text-3xl font-semibold">Heading 2</h2>
            <p className="text-sm text-muted-foreground">3xl / Semibold</p>
          </div>
          <div>
            <h3 className="text-2xl font-semibold">Heading 3</h3>
            <p className="text-sm text-muted-foreground">2xl / Semibold</p>
          </div>
          <div>
            <p className="text-lg">Body Large</p>
            <p className="text-sm text-muted-foreground">lg / Regular</p>
          </div>
          <div>
            <p>Body Regular</p>
            <p className="text-sm text-muted-foreground">base / Regular</p>
          </div>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Colors</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="space-y-2">
            <div className="h-12 w-full bg-primary rounded-md"></div>
            <p className="text-sm font-medium">Primary</p>
          </div>
          <div className="space-y-2">
            <div className="h-12 w-full bg-secondary rounded-md"></div>
            <p className="text-sm font-medium">Secondary</p>
          </div>
          <div className="space-y-2">
            <div className="h-12 w-full bg-muted rounded-md"></div>
            <p className="text-sm font-medium">Muted</p>
          </div>
          <div className="space-y-2">
            <div className="h-12 w-full bg-accent rounded-md"></div>
            <p className="text-sm font-medium">Accent</p>
          </div>
        </div>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Components</h2>
        <div className="space-y-8">
          <div>
            <h3 className="text-xl font-medium mb-4">Buttons</h3>
            <div className="flex flex-wrap gap-4">
              <Button>Default</Button>
              <Button variant="secondary">Secondary</Button>
              <Button variant="outline">Outline</Button>
              <Button variant="ghost">Ghost</Button>
            </div>
          </div>

          <div>
            <h3 className="text-xl font-medium mb-4">Cards</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle>Card Title</CardTitle>
                  <CardDescription>Card description goes here.</CardDescription>
                </CardHeader>
                <CardContent>
                  <p>Card content and other elements.</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      <LastUpdated date="2024-03-20" className="mt-12" />
    </div>
  )
}

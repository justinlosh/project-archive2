import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "Privacy Policy - Justin Losh",
  description: "Privacy policy and data handling practices for justinlosh.com",
}

export default function PrivacyPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-4">Privacy Policy</h1>
      <p className="text-lg text-muted-foreground mb-8">
        I believe in the fundamental right to privacy and strive to collect as little data as possible. I do not sell
        your data, use analytical tracking cookies, or collect unique user data.
      </p>
      <div className="prose dark:prose-invert">
        <h2>Data Collection</h2>
        <p>
          I use a self-hosted instance of Ackee to gather minimal, anonymous analytics. The collected data serves two
          primary purposes:
        </p>

        <h3>Content Optimization</h3>
        <p>The following information helps improve and tailor content:</p>
        <ul>
          <li>Visit Duration</li>
          <li>Total Number of Visits</li>
          <li>Referrers</li>
          <li>Language</li>
        </ul>

        <h3>Bug Fixing & Troubleshooting</h3>
        <p>The following information aids in identifying and resolving technical issues:</p>
        <ul>
          <li>Operating System</li>
          <li>Screen Dimensions</li>
          <li>Browser</li>
          <li>Display Colors</li>
          <li>Device</li>
        </ul>

        <p>No personally identifiable information (PII) is collected or stored.</p>
      </div>

      <LastUpdated date="2024-03-18" className="mt-12" />
    </div>
  )
}

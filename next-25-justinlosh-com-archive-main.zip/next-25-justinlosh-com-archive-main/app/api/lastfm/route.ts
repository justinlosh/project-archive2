import { type NextRequest, NextResponse } from "next/server"
import { fetchLastFmData } from "@/lib/services/lastfm-service"
import type { LastFmApiResponse } from "@/types/lastfm"

export async function GET(request: NextRequest): Promise<NextResponse<LastFmApiResponse>> {
  try {
    // Get period from query params (default to 7day)
    const searchParams = request.nextUrl.searchParams
    const period = searchParams.get("period") || "7day"

    // Validate period
    const validPeriods = ["overall", "7day", "1month", "3month", "6month", "12month"]
    if (!validPeriods.includes(period)) {
      return NextResponse.json(
        {
          success: false,
          error: `Invalid period: ${period}. Valid periods are: ${validPeriods.join(", ")}`,
        },
        { status: 400 },
      )
    }

    // Fetch Last.fm data
    const stats = await fetchLastFmData(period)

    if (!stats) {
      return NextResponse.json(
        {
          success: false,
          error: "Failed to fetch Last.fm data",
        },
        { status: 500 },
      )
    }

    return NextResponse.json({
      success: true,
      stats,
    })
  } catch (error) {
    console.error("Error in Last.fm API route:", error)
    return NextResponse.json(
      {
        success: false,
        error: "Failed to fetch Last.fm data",
      },
      { status: 500 },
    )
  }
}

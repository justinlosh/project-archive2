import { NextResponse } from "next/server"
import * as cheerio from "cheerio"
import { goodreadsConfig } from "@/lib/config/goodreads"

// Helper function to safely parse dates
function parseDate(dateString: string): Date {
  try {
    // Try to parse the date string
    const date = new Date(dateString)

    // Check if the date is valid
    if (isNaN(date.getTime())) {
      console.warn(`Invalid date string: "${dateString}". Using current date as fallback.`)
      return new Date()
    }

    return date
  } catch (error) {
    console.warn(`Error parsing date string: "${dateString}". Using current date as fallback.`, error)
    return new Date()
  }
}

// Mock data for development without scraping
const mockData = {
  items: [
    {
      id: "1",
      title: "The Pragmatic Programmer",
      author: "Andrew Hunt, David Thomas",
      coverUrl: "/abstract-book-cover.png",
      goodreadsUrl: "https://www.goodreads.com/book/show/4099.The_Pragmatic_Programmer",
      status: "reading",
      dateUpdated: new Date().toISOString(),
      progress: 65,
      rating: 5,
      hasRating: true,
      summary: "A guide to pragmatic programming techniques.",
    },
    {
      id: "2",
      title: "Clean Code",
      author: "Robert C. Martin",
      coverUrl: "/abstract-book-cover.png",
      goodreadsUrl: "https://www.goodreads.com/book/show/3735293-clean-code",
      status: "read",
      dateUpdated: new Date().toISOString(),
      progress: 100,
      rating: 4,
      hasRating: true,
      summary: "A handbook of agile software craftsmanship.",
    },
    {
      id: "3",
      title: "Design Patterns",
      author: "Erich Gamma, Richard Helm, Ralph Johnson, John Vlissides",
      coverUrl: "/abstract-book-cover.png",
      goodreadsUrl: "https://www.goodreads.com/book/show/85009.Design_Patterns",
      status: "to-read",
      dateUpdated: new Date().toISOString(),
      progress: 0,
      rating: 0,
      hasRating: false,
      summary: "Elements of Reusable Object-Oriented Software.",
    },
  ],
  totalItems: 3,
  success: true,
}

/**
 * Fetches reading data from Goodreads
 * @param limit Maximum number of items to return
 * @param status Filter by reading status
 * @returns Promise with reading data
 */
async function fetchGoodreadsData(limit = 5, status?: string) {
  try {
    // Use mock data if configured
    if (goodreadsConfig.useMockData) {
      console.log("Using mock reading data")

      // Filter by status if provided
      let items = mockData.items
      if (status) {
        items = items.filter((item) => item.status === status)
      }

      // Apply limit
      items = items.slice(0, limit)

      return {
        ...mockData,
        items,
        totalItems: items.length,
      }
    }

    // Determine which shelf to scrape based on status
    let shelf = "read"
    if (status === "reading") {
      shelf = "currently-reading"
    } else if (status === "to-read") {
      shelf = "to-read"
    }

    // Construct the URL
    const url = `${goodreadsConfig.baseUrl}/review/list/${goodreadsConfig.userId}?shelf=${shelf}`

    // Fetch the page
    const response = await fetch(url)
    if (!response.ok) {
      throw new Error(`Failed to fetch Goodreads data: ${response.status} ${response.statusText}`)
    }

    const html = await response.text()
    const $ = cheerio.load(html)

    // Extract book data
    const books = []
    const bookElements = $(".bookalike")

    // Process each book element
    bookElements.each((i, element) => {
      if (i >= limit) return false // Stop after reaching the limit

      try {
        // Get book ID
        const id = $(element).attr("id")?.replace("review_", "") || `unknown-${i}`

        // Get book title
        const titleElement = $(element).find(".field.title a")
        const title = titleElement.text().trim()
        const goodreadsUrl = titleElement.attr("href") || ""

        // Get author
        const author = $(element).find(".field.author a").text().trim()

        // Get cover URL
        const coverUrl = $(element).find(".cover img").attr("src") || ""

        // Get rating
        const ratingElement = $(element).find(".field.rating .staticStars")
        const ratingText = ratingElement.attr("title") || ""
        const rating = ratingText.includes("it was amazing")
          ? 5
          : ratingText.includes("really liked it")
            ? 4
            : ratingText.includes("liked it")
              ? 3
              : ratingText.includes("it was ok")
                ? 2
                : ratingText.includes("did not like it")
                  ? 1
                  : 0
        const hasRating = rating > 0

        // Get progress
        const progressText = $(element).find(".field.status .value").text().trim()
        const progressMatch = progressText.match(/(\d+)%/)
        const progress = progressMatch ? Number.parseInt(progressMatch[1], 10) : status === "read" ? 100 : 0

        // Get date updated
        const dateText = $(element).find(".date_added").text().trim()
        const dateUpdated = dateText ? parseDate(dateText).toISOString() : new Date().toISOString()

        // Get summary (description)
        const summary = $(element).find(".field.description .value").text().trim()

        // Add book to the list
        books.push({
          id,
          title,
          author,
          coverUrl,
          goodreadsUrl,
          status: status || shelf === "currently-reading" ? "reading" : shelf === "to-read" ? "to-read" : "read",
          dateUpdated,
          progress,
          rating,
          hasRating,
          summary,
        })
      } catch (error) {
        console.error("Error processing book element:", error)
      }
    })

    return {
      items: books,
      totalItems: books.length,
      success: true,
    }
  } catch (error) {
    console.error("Error scraping Goodreads:", error)
    throw error
  }
}

/**
 * GET handler for the reading API
 * @param request The request object
 * @returns Response with reading data
 */
export async function GET(request: Request) {
  try {
    // Get query parameters
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || goodreadsConfig.defaultLimit.toString(), 10)
    const status = searchParams.get("status") || undefined

    // Fetch data
    const data = await fetchGoodreadsData(limit, status)

    // Return the data
    return NextResponse.json(data)
  } catch (error) {
    console.error("Error in reading API:", error)

    // Return an error response
    return NextResponse.json(
      {
        items: [],
        totalItems: 0,
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}

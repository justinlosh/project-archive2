import { type NextRequest, NextResponse } from "next/server"
import { turnstileConfig } from "@/lib/config/turnstile"

export async function POST(request: NextRequest) {
  try {
    const { token } = await request.json()

    // Skip verification if Turnstile is disabled
    if (!turnstileConfig.enabled) {
      return NextResponse.json({ success: true, message: "Turnstile verification skipped" })
    }

    // If in test mode and using test keys, always return success
    if (turnstileConfig.testMode && turnstileConfig.siteKey === "1x00000000000000000000AA") {
      return NextResponse.json({ success: true, message: "Turnstile test mode verification successful" })
    }

    // Verify the token with Cloudflare
    const formData = new URLSearchParams()
    formData.append("secret", turnstileConfig.secretKey)
    formData.append("response", token)
    formData.append("remoteip", request.headers.get("x-forwarded-for") || "")

    const result = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      body: formData,
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
    })

    const outcome = await result.json()

    if (outcome.success) {
      return NextResponse.json({ success: true, message: "Turnstile verification successful" })
    } else {
      console.error("Turnstile verification failed:", outcome)
      return NextResponse.json(
        { success: false, message: "Turnstile verification failed", errors: outcome["error-codes"] },
        { status: 400 },
      )
    }
  } catch (error) {
    console.error("Error verifying Turnstile token:", error)
    return NextResponse.json({ success: false, message: "Error verifying Turnstile token" }, { status: 500 })
  }
}

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "Verify - Justin Losh",
  description: "Verify the authenticity of Justin Losh's online presence",
}

export default function VerifyPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-4">Verify</h1>

      <p className="text-lg text-muted-foreground mb-8">
        This page provides methods to verify my digital identity and ensure secure communications. In an era of
        impersonation and digital fraud, these verification tools help establish trust and authenticate my online
        presence across various platforms.
      </p>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>PGP Key</CardTitle>
            <CardDescription>Use this key to verify signed messages or encrypt communications</CardDescription>
          </CardHeader>
          <CardContent>
            <pre className="bg-muted p-4 rounded-lg overflow-x-auto text-sm">
              <code>
                -----BEGIN PGP PUBLIC KEY BLOCK----- [Your PGP key would go here] -----END PGP PUBLIC KEY BLOCK-----
              </code>
            </pre>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Social Verification</CardTitle>
            <CardDescription>Verify my identity across platforms</CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              <li>GitHub: @yourusername</li>
              <li>Twitter: @yourusername</li>
              <li>Mastodon: @yourusername@mastodon.social</li>
            </ul>
          </CardContent>
        </Card>

        <div className="prose dark:prose-invert">
          <h2>Website Verification</h2>
          <p>
            This website is deployed on Vercel and uses HTTPS for secure communication. You can verify the SSL
            certificate in your browser.
          </p>

          <h2>Contact Verification</h2>
          <p>
            For sensitive communications, please use the PGP key above to encrypt your messages or verify signed
            communications from me.
          </p>
        </div>
      </div>

      <LastUpdated date="2024-03-15" className="mt-12" />
    </div>
  )
}

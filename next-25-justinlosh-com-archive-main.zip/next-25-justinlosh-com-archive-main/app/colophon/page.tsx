import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "Colophon - Justin Losh",
  description: "Technical details and specifications for justinlosh.com",
}

export default function ColophonPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-4">Colophon</h1>
      <p className="text-lg text-muted-foreground mb-8">
        This page details the technical specifications, platforms, and services used to create and operate this website.
        For those interested in the craft behind digital experiences, this provides insight into the technology stack
        that powers this site.
      </p>
      <div className="prose dark:prose-invert">
        <h2>Core Technologies</h2>
        <ul>
          <li>Built with Next.js 14, leveraging the App Router architecture</li>
          <li>TypeScript for type-safe development</li>
          <li>Tailwind CSS for styling and responsive design</li>
          <li>React Server Components for optimized rendering</li>
          <li>shadcn/ui component library for consistent UI elements</li>
        </ul>

        <h2>Infrastructure & Hosting</h2>
        <ul>
          <li>Deployed on Vercel's Edge Network</li>
          <li>Content delivery optimized through Vercel's global CDN</li>
          <li>DNS management via Cloudflare</li>
          <li>Automated CI/CD pipeline for seamless deployments</li>
        </ul>

        <h2>Content Management</h2>
        <ul>
          <li>MDX for rich content authoring</li>
          <li>Custom data fetching layer for external content sources</li>
          <li>Structured content modeling for consistent presentation</li>
        </ul>

        <h2>Performance & Analytics</h2>
        <ul>
          <li>Umami Analytics for privacy-focused visitor insights</li>
          <li>Image optimization through Next.js Image component</li>
          <li>Edge caching strategies for improved load times</li>
          <li>Core Web Vitals optimization</li>
        </ul>

        <h2>Security</h2>
        <ul>
          <li>Cloudflare Turnstile for bot protection</li>
          <li>Content Security Policy implementation</li>
          <li>Regular security audits and dependency updates</li>
          <li>HTTPS enforcement with modern TLS protocols</li>
        </ul>

        <h2>Typography & Design</h2>
        <p>
          The site uses Inter for its clean, modern appearance and excellent readability across devices. The design
          system emphasizes content clarity, accessibility, and consistent visual hierarchy throughout the user
          experience.
        </p>
      </div>

      <LastUpdated date="2024-03-22" className="mt-12" />
    </div>
  )
}

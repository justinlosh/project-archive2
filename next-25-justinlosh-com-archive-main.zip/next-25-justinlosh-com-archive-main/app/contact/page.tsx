import { SectionHeading } from "@/components/ui/section-heading"
import { ProtectedContactForm } from "@/components/contact/protected-contact-form"

export default function ContactPage() {
  return (
    <div className="container max-w-2xl py-16">
      <SectionHeading
        title="Contact"
        description="Thank you for your interest in getting in touch! Please fill out the form below and I'll get back to you as soon as possible."
        className="mb-10"
      />

      <ProtectedContactForm title="" description="" />
    </div>
  )
}

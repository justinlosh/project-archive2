import type { MetadataRoute } from "next"
import { env } from "@/lib/env"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: env.SITE_NAME,
    short_name: "Justin Losh",
    description: env.SITE_DESCRIPTION,
    start_url: "/",
    display: "standalone",
    background_color: "#ffffff",
    theme_color: "#000000",
    icons: [
      {
        src: "/favicon.ico",
        sizes: "any",
        type: "image/x-icon",
      },
    ],
  }
}

import { ReadingCard } from "@/components/now/reading-card"
import { LearningCard } from "@/components/now/learning-card"
import { ListeningCard } from "@/components/now/listening-card"
import { FocusCard } from "@/components/now/focus-card"
import { ErrorBoundary } from "@/components/error-boundary"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LastUpdated } from "@/components/ui/last-updated"
import Link from "next/link"
import { ArrowRight } from "lucide-react"

export const metadata = {
  title: "Now - Justin Losh",
  description: "What I'm currently working on, focused on, and my latest activity across platforms.",
}

export default function NowPage() {
  // Sample data for each card (except reading, which now comes from API)
  const learningItems = [
    {
      topic: "Web Components",
      resources: ["MDN Web Docs", "Google Developers"],
      tags: ["Frontend", "JavaScript", "HTML"],
    },
    {
      topic: "System Design Patterns",
      resources: ["Distributed Systems Architecture", "Microservices Patterns"],
      tags: ["Architecture", "Backend", "Scalability"],
    },
    {
      topic: "AI/ML Applications in Web Development",
      resources: ["TensorFlow.js", "Hugging Face Transformers"],
      tags: ["AI", "ML", "JavaScript"],
    },
  ]

  const focusItems = [
    {
      title: "Building and improving web development tools",
      description: "Creating tools and libraries to improve developer experience and productivity.",
    },
    {
      title: "Writing technical articles",
      description: "Sharing knowledge and insights about modern web development practices and techniques.",
    },
    {
      title: "Contributing to open source projects",
      description: "Giving back to the community by contributing to projects that I use and value.",
    },
  ]

  return (
    <div className="container max-w-4xl py-12">
      <h1 className="text-4xl font-bold mb-4">Now</h1>

      <p className="text-xl text-muted-foreground mb-8">
        This page shows what I'm currently focused on, learning, and my latest activity across various platforms. It's
        regularly updated to reflect my current interests and activities, inspired by{" "}
        <a
          href="https://nownownow.com/about"
          className="text-primary hover:underline"
          target="_blank"
          rel="noopener noreferrer"
        >
          nownownow.com
        </a>
        .
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <ErrorBoundary>
          <FocusCard items={focusItems} />
        </ErrorBoundary>
        <ErrorBoundary>
          <ReadingCard />
        </ErrorBoundary>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
        <ErrorBoundary>
          <LearningCard items={learningItems} />
        </ErrorBoundary>
        <ErrorBoundary>
          <ListeningCard />
        </ErrorBoundary>
      </div>

      <Card className="mb-12">
        <CardHeader>
          <CardTitle>Microfeed</CardTitle>
          <CardDescription>
            Check out my recent activity across various platforms on the Microfeed page.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <p className="text-muted-foreground">
                View my latest posts, commits, music, and reading activity all in one place.
              </p>
            </div>
            <Link href="/microfeed">
              <Button className="gap-2 ml-4">
                View Microfeed
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>

      <LastUpdated date="2024-03-24" className="mt-12" />
    </div>
  )
}

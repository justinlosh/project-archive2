import { Skeleton } from "@/components/ui/skeleton"
import { getAllNotes, getPaginatedNotes } from "@/lib/services/notes-service"
import dynamic from "next/dynamic"
import { ErrorBoundary } from "@/components/error-boundary"
import { notFound } from "next/navigation"

// Import HomePage with no SSR to avoid hydration issues
const HomePage = dynamic(() => import("@/app/home-page"), {
  ssr: false,
  loading: () => (
    <div className="container py-20">
      <div className="max-w-2xl mx-auto space-y-8">
        <Skeleton className="h-12 w-3/4 mx-auto" />
        <Skeleton className="h-6 w-full" />
        <Skeleton className="h-6 w-5/6" />
        <div className="space-y-4 mt-12">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      </div>
    </div>
  ),
})

export async function generateMetadata({ params }: { params: { page: string } }) {
  const page = Number.parseInt(params.page, 10)

  if (isNaN(page) || page < 2) {
    return {
      title: "Page Not Found - Justin Losh",
    }
  }

  return {
    title: `Page ${page} - Justin Losh`,
    description: `Page ${page} of Justin Losh's blog posts and notes.`,
  }
}

export default async function PaginatedHomePage({ params }: { params: { page: string } }) {
  const page = Number.parseInt(params.page, 10)

  // Validate page number
  if (isNaN(page) || page < 2) {
    notFound()
  }

  // Fetch posts with error handling
  let posts = []
  let totalPosts = 0
  const postsPerPage = 3

  try {
    const allNotes = await getAllNotes()
    totalPosts = allNotes.length

    // Calculate pagination
    const totalPages = Math.ceil(totalPosts / postsPerPage)

    // If page is out of range, return 404
    if (page > totalPages) {
      notFound()
    }

    // Get posts for the current page
    posts = await getPaginatedNotes(page, postsPerPage)
  } catch (error) {
    console.error("Error fetching paginated posts:", error)
  }

  return (
    <ErrorBoundary>
      <HomePage recentPosts={posts} totalPosts={totalPosts} currentPage={page} />
    </ErrorBoundary>
  )
}

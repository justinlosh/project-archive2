import type { MetadataRoute } from "next"
import { getPosts } from "@/lib/services/post-service"
import { getProjects } from "@/lib/services/project-service"
import { getNotes } from "@/lib/services/notes-service"
import { env } from "@/lib/env"

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = env.SITE_URL || "https://justinlosh.com"

  // Get dynamic content
  const posts = await getPosts({ limit: 100 })
  const projects = await getProjects()
  const notes = await getNotes({ limit: 100 })

  // Static routes
  const routes = [
    "",
    "/about",
    "/projects",
    "/notes",
    "/now",
    "/contact",
    "/microfeed",
    "/colophon",
    "/privacy",
    "/disclaimer",
    "/security",
    "/styleguide",
  ].map((route) => ({
    url: `${baseUrl}${route}`,
    lastModified: new Date(),
    changeFrequency: "weekly" as const,
    priority: route === "" ? 1 : 0.8,
  }))

  // Dynamic routes
  const postRoutes = posts.map((post) => ({
    url: `${baseUrl}/posts/${post.id}`,
    lastModified: new Date(post.date),
    changeFrequency: "monthly" as const,
    priority: 0.6,
  }))

  const noteRoutes = notes.map((note) => ({
    url: `${baseUrl}/notes/${note.slug}`,
    lastModified: new Date(note.date),
    changeFrequency: "monthly" as const,
    priority: 0.6,
  }))

  return [...routes, ...postRoutes, ...noteRoutes]
}

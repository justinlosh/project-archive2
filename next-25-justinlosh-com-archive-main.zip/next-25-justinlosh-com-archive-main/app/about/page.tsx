import { LastUpdated } from "@/components/ui/last-updated"

export const metadata = {
  title: "About - Justin Losh",
  description: "Learn more about Justin Losh and his work in web development and technology.",
}

export default function AboutPage() {
  return (
    <div className="container max-w-2xl py-12">
      <h1 className="text-4xl font-bold mb-8">About</h1>
      <div className="prose">
        <p className="text-xl text-muted-foreground mb-8">
          Hello, I'm Justin Losh. Welcome to my corner of the internet. A collection of periodic ramblings, thoughts,
          ideas, and notes.
        </p>

        <p>
          This site makes up about 0.00000000000083% of the internet—a single pixel in a galaxy of data, code, and cat
          videos. But like every star in the sky, it has its own light to shine. Built with curiosity, secured with
          care, and served with pride, this little patch of the web is here to share knowledge, spark ideas, and
          occasionally nerd out over tech, BBQ, or the latest security rabbit hole.
          <br />
          <em>
            <sub>* According to AI</sub>
          </em>
        </p>

        <h2>Background</h2>
        <p>
          A strategic technology leader with extensive experience driving IT initiatives, cybersecurity programs, and
          digital transformation across organizations of varying sizes. As an IT director, I align technology
          investments with business objectives across architecture, infrastructure, security, and operations within
          small to mid-sized business environments.
        </p>
        <p>
          My expertise spans cloud computing, cybersecurity frameworks, IT governance, and business technology
          integration, demonstrated through a track record of implementing resilient solutions, strengthening security
          postures, and optimizing operational efficiency. I've led teams, architected systems, and developed strategic
          roadmaps that balance innovation with long-term stability while managing relationships with contractors and
          subcontractors.
        </p>
        <p>
          Beyond traditional IT leadership, I've contributed to startup ecosystems, technology advisory boards, and
          product strategy initiatives, consistently applying a business-first approach to technology decisions. My
          focus remains on transforming technology into a strategic differentiator that enhances organizational agility,
          security posture, and scalable growth in resource-conscious environments.
        </p>
      </div>

      <LastUpdated date="2024-03-18" className="mt-12" />
    </div>
  )
}

import type React from "react"
import { Providers } from "@/components/providers"
import { MainNav } from "@/components/layout/main-nav"
import { FooterNav } from "@/components/layout/footer-nav"
import { WebsiteJSONLD } from "@/components/json-ld"
import { UmamiAnalytics } from "@/components/analytics/umami"
import { SITE_NAME, SITE_DESCRIPTION, DEFAULT_KEYWORDS, SITE_URL } from "@/lib/constants"
import "@/app/globals.css"
import { SkipLink } from "@/components/ui/skip-link"
import { Toaster } from "@/components/ui/toaster"
import { ErrorBoundary } from "@/components/error-boundary"
import { ClientErrorHandler } from "@/components/client-error-handler"
import { Suspense } from "react"

export const metadata = {
  title: {
    default: SITE_NAME,
    template: `%s | ${SITE_NAME}`,
  },
  description: SITE_DESCRIPTION,
  keywords: DEFAULT_KEYWORDS,
  metadataBase: new URL(SITE_URL || "https://justinlosh.com"),
  openGraph: {
    type: "website",
    locale: "en_US",
    url: SITE_URL,
    title: SITE_NAME,
    description: SITE_DESCRIPTION,
    siteName: SITE_NAME,
  },
  twitter: {
    card: "summary_large_image",
    title: SITE_NAME,
    description: SITE_DESCRIPTION,
  },
  robots: {
    index: true,
    follow: true,
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const currentYear = new Date().getFullYear()

  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <WebsiteJSONLD />
        <UmamiAnalytics />
        <link rel="icon" href="/favicon.ico" sizes="any" />
      </head>
      <body className="min-h-screen bg-background font-sans antialiased">
        <ClientErrorHandler />
        <Providers defaultTheme="light" storageKey="justin-losh-theme">
          <ErrorBoundary>
            <div className="flex min-h-screen flex-col">
              <SkipLink />
              <header className="w-full border-b bg-background">
                <div className="container flex h-16 items-center">
                  <Suspense fallback={<div className="h-8 w-32 bg-muted animate-pulse rounded" />}>
                    <MainNav />
                  </Suspense>
                </div>
              </header>
              <main id="main-content" className="flex-1">
                {children}
              </main>
              <footer className="border-t bg-muted/40">
                <div className="container flex flex-col items-center justify-between gap-4 py-10 md:h-24 md:flex-row md:py-0">
                  <div className="text-center md:text-left">
                    <p className="text-sm text-muted-foreground">
                      &copy; {currentYear} Justin Losh, All Rights Reserved.
                    </p>
                  </div>
                  <FooterNav />
                </div>
              </footer>
            </div>
          </ErrorBoundary>
          <Toaster />
        </Providers>
      </body>
    </html>
  )
}

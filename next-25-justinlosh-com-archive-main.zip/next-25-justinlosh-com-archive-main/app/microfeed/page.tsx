"use client"

import { useState } from "react"
import { MicrofeedSidebar } from "@/components/microfeed/microfeed-sidebar"
import { MicrofeedContent } from "@/components/microfeed/microfeed-content"
import "./bluesky-icon.css"
import "./action-indicators.css"

export default function MicrofeedPage() {
  const [activeFilters, setActiveFilters] = useState<string[]>(["github", "reading", "bluesky", "lastfm"])

  return (
    <div className="container max-w-7xl py-10">
      <div className="mb-10">
        <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-4">Microfeed</h1>
        <p className="text-xl text-muted-foreground">
          A stream of my recent activity across various platforms and services.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-6">
            <MicrofeedSidebar activeFilters={activeFilters} onFilterChange={setActiveFilters} />
          </div>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3">
          <MicrofeedContent activeFilters={activeFilters} />
        </div>
      </div>
    </div>
  )
}

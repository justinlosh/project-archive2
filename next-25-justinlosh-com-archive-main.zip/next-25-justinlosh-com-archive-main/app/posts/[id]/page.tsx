import { notFound } from "next/navigation"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { BlogPostJSONLD } from "@/components/json-ld"
import { env } from "@/lib/env"

// Mock data for a single blog post
const post = {
  id: 1,
  title: "Getting Started with Next.js",
  content:
    "Next.js is a powerful React framework that makes it easy to build server-side rendered and statically generated web applications. In this post, we'll explore the basics of Next.js and how to get started with your first project.",
  date: "2023-05-01",
}

export function generateMetadata({ params }: { params: { id: string } }) {
  // In a real app, you would fetch the post data here
  if (Number.parseInt(params.id) !== post.id) {
    return {
      title: "Post Not Found",
      description: "The requested post could not be found.",
    }
  }

  return {
    title: post.title,
    description: post.content.substring(0, 160),
    openGraph: {
      title: post.title,
      description: post.content.substring(0, 160),
      type: "article",
      publishedTime: post.date,
      url: `${env.SITE_URL}/posts/${post.id}`,
    },
    twitter: {
      card: "summary_large_image",
      title: post.title,
      description: post.content.substring(0, 160),
    },
  }
}

export default function BlogPost({ params }: { params: { id: string } }) {
  // In a real application, you would fetch the post data based on the ID
  // For this example, we'll just use the mock data
  if (Number.parseInt(params.id) !== post.id) {
    notFound()
  }

  const postUrl = `${env.SITE_URL}/posts/${post.id}`

  return (
    <>
      <BlogPostJSONLD
        url={postUrl}
        title={post.title}
        description={post.content.substring(0, 160)}
        datePublished={post.date}
      />
      <article className="container py-8 max-w-2xl mx-auto">
        <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
        <time className="text-sm text-muted-foreground mb-8 block">{post.date}</time>
        <div className="prose dark:prose-invert max-w-none">
          <p>{post.content}</p>
        </div>
        <div className="mt-8">
          <Button asChild>
            <Link href="/">Back to Home</Link>
          </Button>
        </div>
      </article>
    </>
  )
}

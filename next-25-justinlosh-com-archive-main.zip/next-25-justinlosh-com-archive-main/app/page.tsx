import type { Metadata } from "next"
import Link from "next/link"
import { HeroSection } from "@/components/hero-section"
import { SectionHeading } from "@/components/ui/section-heading"
import { ArrowRight } from "lucide-react"
import { SITE_NAME, SITE_DESCRIPTION } from "@/lib/constants"

// First, let's update the sample notes data to include categories
const sampleNotes = [
  {
    id: "getting-started-with-nextjs",
    title: "Getting Started with Next.js",
    date: "2023-05-01",
    category: "Development",
    excerpt: "Learn the basics of Next.js and start building amazing web applications with the React framework.",
  },
  {
    id: "mastering-typescript",
    title: "Mastering TypeScript",
    date: "2023-04-15",
    category: "Development",
    excerpt:
      "Discover how TypeScript can improve your development workflow and help catch errors before they reach production.",
  },
  {
    id: "responsive-design-principles",
    title: "Responsive Design Principles",
    date: "2023-03-20",
    category: "Design",
    excerpt:
      "Essential principles for creating websites that work well on devices of all sizes, from mobile to desktop.",
  },
]

export const metadata: Metadata = {
  title: SITE_NAME,
  description: SITE_DESCRIPTION,
}

export default function HomePage() {
  return (
    <div className="container max-w-4xl mx-auto px-4 py-12">
      {/* Hero Section - Keep this */}
      <HeroSection
        title="Justin Losh"
        description="Software engineer and web developer building digital products with a focus on user experience and performance."
      />

      {/* Recent Notes Section - Keep this */}
      <section className="mt-20">
        <SectionHeading
          title="Recent Notes"
          description="Thoughts, tutorials, and insights"
          link="/notes"
          linkText="View all notes"
        />
        <div className="mt-8 space-y-4">
          {sampleNotes.map((note) => (
            <article key={note.id} className="border-b pb-4 last:border-0">
              <Link href={`/notes/${note.id}`} className="flex items-center justify-between group">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <h3 className="text-lg font-medium group-hover:text-primary transition-colors">{note.title}</h3>
                    {note.category && (
                      <span className="px-2 py-0.5 bg-muted text-muted-foreground rounded-full text-xs">
                        {note.category}
                      </span>
                    )}
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    <time dateTime={new Date(note.date).toISOString()}>
                      {new Date(note.date).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </time>
                  </div>
                </div>
                <ArrowRight className="h-5 w-5 text-muted-foreground group-hover:text-primary group-hover:translate-x-0.5 transition-all" />
              </Link>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

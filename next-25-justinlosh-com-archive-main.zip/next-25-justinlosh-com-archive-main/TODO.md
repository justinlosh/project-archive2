# A Todo List

## ```v0.9.0```
* [] Content Review (Pages)
  * [] About
  * [] Verify
  * [] Colophon

* [] Microfeed Page
  * [] Add Tags for all types of social media posts (e.g. Added to reading list)
  * [] Adjust card formatting to be consistant across post types (e.g. Time Posted on Left, View on Right)
  * [] For GitHub, only show commit and stared activities 
  * [] Only load X number of post activities
  * [] Add social media icons below the page title for quick access (e.g. Find me around the internet)

* [] Now Page
  * [] Add View Goodreads Profile Button (e.g. Last.fm Listening Card)
  * [] Fix feed generation for Listening Card, currently not pulling live profile data
  * [] Add heading at the bottom of the page for Microfeed

* [] Remove PGP Key information, as this isn't going to be used for a while, if ever.
* [] Add "Last Updated" to the verify page
* [] Adjust Footer Navigiation to the following order: Colophon, Privacy, Disclaimer, Verify, Security, Contact

## ```v0.9.5```
* [] Rework Notes so that I can pull posts in markdown from a Github Repo.

## ```v0.9.6```
* [] Create Readme file, updated with site configuration and settings.
* [] Perform entire site code review, otimizion, refactoring (as required), and prepare for production deployment
* 

## ```v1.0.0```
* 
* 
*

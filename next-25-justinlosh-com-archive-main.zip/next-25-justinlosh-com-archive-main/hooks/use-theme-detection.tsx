"use client"

import { useTheme } from "next-themes"
import { useState, useEffect } from "react"

export function useThemeDetection() {
  const { resolvedTheme, theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    return () => setMounted(false)
  }, [])

  return {
    isDark: mounted && resolvedTheme === "dark",
    isLight: mounted && resolvedTheme === "light",
    theme: mounted ? theme : undefined,
    resolvedTheme: mounted ? resolvedTheme : undefined,
    setTheme: (newTheme: string) => {
      if (mounted) {
        setTheme(newTheme)
      }
    },
    toggleTheme: () => {
      if (mounted) {
        setTheme(resolvedTheme === "dark" ? "light" : "dark")
      }
    },
    mounted,
  }
}

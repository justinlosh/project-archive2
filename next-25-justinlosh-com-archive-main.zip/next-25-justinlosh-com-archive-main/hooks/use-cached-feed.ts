"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import type { FeedItemType } from "@/components/microfeed/feed"

const CACHE_KEY = "microfeed_cache"
const CACHE_EXPIRY = 1000 * 60 * 15 // 15 minutes

interface CacheData {
  items: FeedItemType[]
  timestamp: number
}

export function useCachedFeed(initialPageSize = 5) {
  const [allItems, setAllItems] = useState<FeedItemType[]>([])
  const [visibleItems, setVisibleItems] = useState<FeedItemType[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [hasMore, setHasMore] = useState(true)
  const [pageSize, setPageSize] = useState(initialPageSize)
  const observerRef = useRef<IntersectionObserver | null>(null)
  const loadingRef = useRef<HTMLDivElement | null>(null)

  // Load data from cache or fetch new data
  const loadData = useCallback(
    async (fetchDataFn: () => Promise<FeedItemType[]>) => {
      setIsLoading(true)
      setError(null)

      try {
        // Try to get data from cache first
        const cachedData = localStorage.getItem(CACHE_KEY)

        if (cachedData) {
          const parsedCache: CacheData = JSON.parse(cachedData)
          const now = Date.now()

          // Check if cache is still valid (not expired)
          if (now - parsedCache.timestamp < CACHE_EXPIRY) {
            // Convert string dates back to Date objects
            const items = parsedCache.items.map((item) => ({
              ...item,
              timestamp: new Date(item.timestamp),
            }))

            setAllItems(items)
            setVisibleItems(items.slice(0, pageSize))
            setIsLoading(false)
            setHasMore(items.length > pageSize)
            return
          }
        }

        // If no valid cache, fetch fresh data
        const freshItems = await fetchDataFn()

        // Save to cache
        const cacheData: CacheData = {
          items: freshItems,
          timestamp: Date.now(),
        }
        localStorage.setItem(CACHE_KEY, JSON.stringify(cacheData))

        setAllItems(freshItems)
        setVisibleItems(freshItems.slice(0, pageSize))
        setHasMore(freshItems.length > pageSize)
      } catch (error) {
        console.error("Error loading feed data:", error)
        setError("Failed to load activity feed. Please try refreshing the page.")
      } finally {
        setIsLoading(false)
      }
    },
    [pageSize],
  )

  // Load more items when scrolling
  const loadMore = useCallback(() => {
    if (!hasMore || isLoading) return

    const nextItems = allItems.slice(0, visibleItems.length + pageSize)
    setVisibleItems(nextItems)
    setHasMore(nextItems.length < allItems.length)
  }, [allItems, visibleItems, pageSize, hasMore, isLoading])

  // Set up intersection observer for infinite scrolling
  useEffect(() => {
    if (!loadingRef.current) return

    observerRef.current = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          loadMore()
        }
      },
      { threshold: 0.1 },
    )

    observerRef.current.observe(loadingRef.current)

    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect()
      }
    }
  }, [loadMore])

  // Apply filters to the cached items
  const applyFilters = useCallback(
    (filters: string[]) => {
      const filtered = allItems.filter((item) => {
        if (item.type === "github") return filters.includes("github")
        if (item.type === "reading") return filters.includes("reading")
        if (item.type === "social") {
          return filters.includes(item.post.platform)
        }
        return false
      })

      setVisibleItems(filtered.slice(0, pageSize))
      setHasMore(filtered.length > pageSize)
    },
    [allItems, pageSize],
  )

  // Clear cache manually
  const clearCache = useCallback(() => {
    localStorage.removeItem(CACHE_KEY)
  }, [])

  return {
    items: visibleItems,
    isLoading,
    error,
    hasMore,
    loadingRef,
    loadData,
    loadMore,
    applyFilters,
    clearCache,
  }
}

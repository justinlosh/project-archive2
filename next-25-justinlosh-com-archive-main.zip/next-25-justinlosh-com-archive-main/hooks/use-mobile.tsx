"use client"

import { useEffect, useState, useCallback } from "react"

export function useMobile(breakpoint = 768) {
  // Start with a default value of false to avoid hydration mismatch
  const [isMobile, setIsMobile] = useState(false)
  const [mounted, setMounted] = useState(false)

  // Memoize the check function to avoid recreating it on each render
  const checkMobile = useCallback(() => {
    if (typeof window !== "undefined") {
      setIsMobile(window.innerWidth < breakpoint)
    }
  }, [breakpoint])

  // Only run on the client side
  useEffect(() => {
    setMounted(true)

    // Initial check
    checkMobile()

    // Add event listener for window resize
    window.addEventListener("resize", checkMobile)

    // Cleanup
    return () => {
      window.removeEventListener("resize", checkMobile)
    }
  }, [checkMobile])

  // Return false during SSR to avoid hydration mismatch
  return mounted ? isMobile : false
}

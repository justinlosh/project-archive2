// Environment variables with fallbacks
export const env = {
  // Site Configuration
  SITE_NAME: process.env.SITE_NAME || "Justin Losh",
  SITE_DESCRIPTION:
    process.env.SITE_DESCRIPTION ||
    "Software engineer and web developer building digital products with a focus on user experience and performance.",
  SITE_URL:
    process.env.SITE_URL || process.env.VERCEL_URL ? `https://${process.env.VERCEL_URL}` : "https://justinlosh.com",
  DEFAULT_KEYWORDS: process.env.DEFAULT_KEYWORDS || "web development, software engineering, react, nextjs, typescript",
  TWITTER_HANDLE: process.env.TWITTER_HANDLE || "@justinlosh",

  // Analytics
  UMAMI_ENABLED: process.env.UMAMI_ENABLED === "true",
  NEXT_PUBLIC_UMAMI_ENABLED: process.env.NEXT_PUBLIC_UMAMI_ENABLED === "true",
  NEXT_PUBLIC_UMAMI_WEBSITE_ID: process.env.NEXT_PUBLIC_UMAMI_WEBSITE_ID,
  NEXT_PUBLIC_UMAMI_URL: process.env.NEXT_PUBLIC_UMAMI_URL,

  // Social Media
  GITHUB_USERNAME: process.env.GITHUB_USERNAME || "justinlosh",
  BLUESKY_HANDLE: process.env.BLUESKY_HANDLE || "justinlosh.com",
  LASTFM_USERNAME: process.env.LASTFM_USERNAME || "justinlosh",

  // Feature Flags
  GITHUB_USE_MOCK_DATA: process.env.GITHUB_USE_MOCK_DATA === "true",
  LASTFM_USE_MOCK_DATA: process.env.LASTFM_USE_MOCK_DATA === "true",
  BLUESKY_USE_MOCK_DATA: process.env.BLUESKY_USE_MOCK_DATA === "true",
  TURNSTILE_ENABLED: process.env.TURNSTILE_ENABLED === "true",
  TURNSTILE_TEST_MODE: process.env.TURNSTILE_TEST_MODE === "true",
}

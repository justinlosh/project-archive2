import type { GitHubEvent } from "@/types/social"
import type { FeedItemType } from "@/components/microfeed/feed"
import { socialConfig } from "@/lib/config/social"
import { generateGitHubItems } from "@/lib/data/sample-microfeed-data"
import { logError } from "@/lib/utils/error-logger"

// Cache for GitHub events
let githubCache: {
  events: GitHubEvent[]
  timestamp: number
} | null = null

/**
 * Fetch GitHub events for a user
 */
export async function fetchGitHubEvents(username: string = socialConfig.github.username): Promise<GitHubEvent[]> {
  // Check if we have a valid cache
  if (githubCache && Date.now() - githubCache.timestamp < socialConfig.github.cacheDuration * 1000) {
    return githubCache.events
  }

  try {
    // If no username is provided and mock data is enabled, return mock data
    if (!username && socialConfig.github.useMockData) {
      console.log("Using mock GitHub data")
      return [] // We'll convert mock data later
    }

    if (!username) {
      throw new Error("GitHub username not configured")
    }

    // Fetch GitHub events
    const response = await fetch(
      `${socialConfig.github.apiUrl}/users/${username}/events?per_page=${socialConfig.github.eventsLimit}`,
      {
        headers: {
          Accept: "application/vnd.github.v3+json",
        },
        next: { revalidate: socialConfig.github.cacheDuration },
      },
    )

    if (!response.ok) {
      throw new Error(`GitHub API error: ${response.status} ${response.statusText}`)
    }

    const events: GitHubEvent[] = await response.json()

    // Filter out certain event types if needed
    const filteredEvents = events.filter((event) => {
      // Only include certain event types (e.g., PushEvent, CreateEvent, WatchEvent)
      return [
        "PushEvent",
        "CreateEvent",
        "WatchEvent",
        "PullRequestEvent",
        "IssuesEvent",
        "IssueCommentEvent",
      ].includes(event.type)
    })

    // Update cache
    githubCache = {
      events: filteredEvents,
      timestamp: Date.now(),
    }

    return filteredEvents
  } catch (error) {
    logError("Error fetching GitHub events", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.github.useMockData) {
      console.log("Using mock GitHub data due to error")
      return [] // We'll convert mock data later
    }

    return []
  }
}

// Update the convertGitHubEventsToFeedItems function to include eventType
export function convertGitHubEventsToFeedItems(events: GitHubEvent[]): FeedItemType[] {
  if (events.length === 0 && socialConfig.github.useMockData) {
    // Use mock data if no events and mock data is enabled
    return generateGitHubItems(5)
  }

  return events.map((event) => {
    try {
      let title = ""
      let description = ""
      let url = ""

      switch (event.type) {
        case "PushEvent":
          const commitCount = event.payload.commits?.length || 0
          title = `Pushed ${commitCount} commit${commitCount !== 1 ? "s" : ""} to ${event.repo.name}`
          description = event.payload.commits?.[0]?.message || ""
          url = `https://github.com/${event.repo.name}/commit/${event.payload.commits?.[0]?.sha}`
          break

        case "CreateEvent":
          title = `Created ${event.payload.ref_type} ${event.payload.ref || ""} in ${event.repo.name}`
          description = event.payload.description || ""
          url = `https://github.com/${event.repo.name}`
          break

        case "PullRequestEvent":
          title = `${event.payload.action === "opened" ? "Opened" : "Updated"} pull request in ${event.repo.name}`
          description = event.payload.pull_request?.title || ""
          url = event.payload.pull_request?.html_url || `https://github.com/${event.repo.name}`
          break

        case "IssuesEvent":
          title = `${event.payload.action === "opened" ? "Opened" : "Updated"} issue in ${event.repo.name}`
          description = event.payload.issue?.title || ""
          url = event.payload.issue?.html_url || `https://github.com/${event.repo.name}`
          break

        case "IssueCommentEvent":
          title = `Commented on issue in ${event.repo.name}`
          description = event.payload.comment?.body?.substring(0, 100) || ""
          if (description.length === 100) description += "..."
          url = event.payload.comment?.html_url || `https://github.com/${event.repo.name}`
          break

        case "WatchEvent":
          title = `Starred ${event.repo.name}`
          description = "Added repository to starred list"
          url = `https://github.com/${event.repo.name}`
          break

        default:
          title = `Activity on ${event.repo.name}`
          description = ""
          url = `https://github.com/${event.repo.name}`
      }

      return {
        id: event.id,
        type: "github",
        timestamp: new Date(event.created_at),
        url,
        github: {
          username: event.actor.login,
          avatarUrl: event.actor.avatar_url,
          repoName: event.repo.name,
          eventType: event.type,
          title,
          description,
          url,
        },
      }
    } catch (error) {
      console.error("Error converting GitHub event:", error)
      // Return a placeholder item instead of crashing
      return {
        id: event.id || `github-error-${Date.now()}`,
        type: "github",
        timestamp: new Date(event.created_at || Date.now()),
        url: `https://github.com/${event.repo?.name || socialConfig.github.username}`,
        github: {
          username: event.actor?.login || socialConfig.github.username,
          avatarUrl: event.actor?.avatar_url || "/placeholder.svg?height=40&width=40&text=GH",
          repoName: event.repo?.name || "unknown-repo",
          eventType: event.type || "unknown",
          title: "GitHub activity",
          description: "Unable to parse event details",
          url: `https://github.com/${event.repo?.name || socialConfig.github.username}`,
        },
      }
    }
  })
}

/**
 * Get GitHub feed items
 */
export async function getGitHubFeedItems(limit = 5): Promise<FeedItemType[]> {
  try {
    const events = await fetchGitHubEvents()
    const feedItems = convertGitHubEventsToFeedItems(events)
    return feedItems.slice(0, limit)
  } catch (error) {
    logError("Error getting GitHub feed items", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.github.useMockData) {
      return generateGitHubItems(limit)
    }

    return []
  }
}

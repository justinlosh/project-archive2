import type { ReadingItem, ReadingResponse } from "@/types/reading"
import { goodreadsConfig } from "@/lib/config/goodreads"

/**
 * Fetches reading data from the API
 * @param limit Maximum number of items to return
 * @param status Filter by reading status
 * @returns Promise with reading data
 */
export async function getReadingData(limit = goodreadsConfig.defaultLimit, status?: string): Promise<ReadingResponse> {
  try {
    // Build query parameters
    const params = new URLSearchParams()
    if (limit) params.append("limit", limit.toString())
    if (status) params.append("status", status)

    // Fetch data from API
    const response = await fetch(`/api/reading?${params.toString()}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store", // Don't cache the response
    })

    if (!response.ok) {
      console.warn(`API returned status ${response.status}: ${response.statusText}`)
      return {
        items: [],
        totalItems: 0,
        success: false,
        error: `API error: ${response.status}`,
      }
    }

    const data = await response.json()
    return data
  } catch (error) {
    console.error("Error fetching reading data:", error)
    return {
      items: [],
      totalItems: 0,
      success: false,
      error: error instanceof Error ? error.message : "Unknown error",
    }
  }
}

/**
 * Converts reading items to feed items for the microfeed
 * @param readingItems Reading items from the API
 * @returns Feed items for the microfeed
 */
export function convertReadingToFeedItems(readingItems: ReadingItem[]) {
  if (!readingItems || !Array.isArray(readingItems)) {
    console.warn("Invalid reading items provided to convertReadingToFeedItems:", readingItems)
    return []
  }

  return readingItems.map((item) => ({
    type: "reading" as const,
    id: `reading-${item.id}`,
    timestamp: new Date(item.dateUpdated || new Date()),
    url: item.goodreadsUrl,
    book: {
      title: item.title || "Unknown Title",
      author: item.author || "Unknown Author",
      coverUrl: item.coverUrl,
      summary: item.summary,
      status: item.status,
      rating: item.rating,
      progress: item.progress,
      hasRating: item.hasRating,
      // Intentionally omitting review
    },
  }))
}

/**
 * Gets the URL for a Goodreads shelf
 * @param shelf The shelf name (reading, read, to-read)
 * @returns The URL for the shelf
 */
export function getGoodreadsShelfUrl(shelf: keyof typeof goodreadsConfig.shelves): string {
  const shelfName = goodreadsConfig.shelves[shelf]
  return `${goodreadsConfig.baseUrl}/review/list/${goodreadsConfig.userId}?shelf=${shelfName}`
}

/**
 * Gets the URL for a Goodreads user profile
 * @returns The URL for the user profile
 */
export function getGoodreadsProfileUrl(): string {
  return `${goodreadsConfig.baseUrl}/user/show/${goodreadsConfig.userId}`
}

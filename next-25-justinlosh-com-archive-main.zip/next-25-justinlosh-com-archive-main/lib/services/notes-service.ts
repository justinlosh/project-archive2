import type { Note } from "@/types"

// Sample notes data
const notes: Note[] = [
  {
    slug: "getting-started-with-nextjs",
    title: "Getting Started with Next.js",
    date: "2023-05-01",
    excerpt: "Learn the basics of Next.js and start building amazing web applications with the React framework.",
    content:
      "Next.js is a powerful React framework that makes it easy to build server-side rendered and statically generated web applications. In this post, we'll explore the basics of Next.js and how to get started with your first project.",
    category: "Development",
    tags: ["Next.js", "React", "Web Development"],
  },
  {
    slug: "mastering-typescript",
    title: "Mastering TypeScript",
    date: "2023-04-15",
    excerpt:
      "Discover how TypeScript can improve your development workflow and help catch errors before they reach production.",
    content:
      "TypeScript is a strongly typed programming language that builds on JavaScript. In this post, we'll explore how TypeScript can help you write more robust code and catch errors before they reach production.",
    category: "Development",
    tags: ["TypeScript", "JavaScript", "Web Development"],
  },
  {
    slug: "responsive-design-principles",
    title: "Responsive Design Principles",
    date: "2023-03-20",
    excerpt:
      "Essential principles for creating websites that work well on devices of all sizes, from mobile to desktop.",
    content:
      "Responsive design is an approach to web design that makes your web pages look good on all devices. In this post, we'll explore the key principles of responsive design and how to implement them in your projects.",
    category: "Design",
    tags: ["CSS", "Responsive Design", "Web Development"],
  },
  {
    slug: "introduction-to-tailwind-css",
    title: "Introduction to Tailwind CSS",
    date: "2023-02-10",
    excerpt: "Learn how to use Tailwind CSS to rapidly build modern websites without ever leaving your HTML.",
    content:
      "Tailwind CSS is a utility-first CSS framework that allows you to build custom designs without ever leaving your HTML. In this post, we'll explore the basics of Tailwind CSS and how to get started with it in your projects.",
    category: "Design",
    tags: ["CSS", "Tailwind CSS", "Web Development"],
  },
]

// Get all notes
export async function getAllNotes(): Promise<Note[]> {
  // In a real app, this would fetch from an API or database
  return notes
}

// Get a note by slug
export async function getNoteBySlug(slug: string): Promise<Note | null> {
  // In a real app, this would fetch from an API or database
  const note = notes.find((note) => note.slug === slug)
  return note || null
}

// Get recent notes
export async function getRecentNotes(count = 3): Promise<Note[]> {
  // In a real app, this would fetch from an API or database
  // Sort by date (newest first) and limit to count
  return [...notes].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, count)
}

// Get notes by category
export async function getNotesByCategory(category: string): Promise<Note[]> {
  // In a real app, this would fetch from an API or database
  return notes.filter((note) => note.category === category)
}

// Get notes by tag
export async function getNotesByTag(tag: string): Promise<Note[]> {
  // In a real app, this would fetch from an API or database
  return notes.filter((note) => note.tags?.includes(tag))
}

// Get notes by year
export async function getNotesByYear(year: string): Promise<Note[]> {
  // In a real app, this would fetch from an API or database
  return notes.filter((note) => new Date(note.date).getFullYear().toString() === year)
}

// Get all available years from notes
export async function getAvailableYears(): Promise<string[]> {
  // Extract years from note dates
  const years = notes.map((note) => new Date(note.date).getFullYear().toString())
  // Remove duplicates and sort in descending order (newest first)
  return [...new Set(years)].sort((a, b) => Number.parseInt(b) - Number.parseInt(a))
}

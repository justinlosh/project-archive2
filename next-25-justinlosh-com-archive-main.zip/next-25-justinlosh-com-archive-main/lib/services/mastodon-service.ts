import { socialConfig } from "@/lib/config/social"
import type { MastodonPost } from "@/types/social"
import type { FeedItemType } from "@/components/microfeed/feed"
import { generateSocialItems } from "@/lib/data/sample-microfeed-data"
import { logError } from "@/lib/utils/error-logger"

// Cache for Mastodon posts
let mastodonCache: {
  posts: MastodonPost[]
  timestamp: number
} | null = null

/**
 * Fetch Mastodon posts for a user
 */
export async function fetchMastodonPosts(
  username: string = socialConfig.mastodon.username,
  server: string = socialConfig.mastodon.server,
): Promise<MastodonPost[]> {
  // Check if we have a valid cache
  if (mastodonCache && Date.now() - mastodonCache.timestamp < socialConfig.mastodon.cacheDuration * 1000) {
    return mastodonCache.posts
  }

  try {
    // If no username is provided and mock data is enabled, return mock data
    if (!username && socialConfig.mastodon.useMockData) {
      console.log("Using mock Mastodon data")
      return [] // We'll convert mock data later
    }

    if (!username) {
      throw new Error("Mastodon username not configured")
    }

    // Verify server is accessible
    try {
      const serverCheckResponse = await fetch(`https://${server}/api/v1/instance`, {
        method: "GET",
        headers: {
          Accept: "application/json",
        },
        next: { revalidate: 3600 }, // Cache for an hour
      })

      if (!serverCheckResponse.ok) {
        throw new Error(`Mastodon server not accessible: ${serverCheckResponse.status}`)
      }
    } catch (serverError) {
      console.error("Mastodon server check failed:", serverError)
      throw new Error(`Mastodon server ${server} not accessible`)
    }

    // First, get the user's account ID
    const accountResponse = await fetch(`https://${server}/api/v1/accounts/lookup?acct=${username}`, {
      headers: {
        Accept: "application/json",
      },
      next: { revalidate: socialConfig.mastodon.cacheDuration },
    })

    if (!accountResponse.ok) {
      throw new Error(`Mastodon API error: ${accountResponse.status} ${accountResponse.statusText}`)
    }

    const account = await accountResponse.json()
    const accountId = account.id

    // Now fetch the user's posts
    const postsResponse = await fetch(
      `https://${server}/api/v1/accounts/${accountId}/statuses?limit=${socialConfig.mastodon.postsLimit}&exclude_replies=true&exclude_reblogs=true`,
      {
        headers: {
          Accept: "application/json",
        },
        next: { revalidate: socialConfig.mastodon.cacheDuration },
      },
    )

    if (!postsResponse.ok) {
      throw new Error(`Mastodon API error: ${postsResponse.status} ${postsResponse.statusText}`)
    }

    const posts: MastodonPost[] = await postsResponse.json()

    // Update cache
    mastodonCache = {
      posts,
      timestamp: Date.now(),
    }

    return posts
  } catch (error) {
    logError("Error fetching Mastodon posts", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.mastodon.useMockData) {
      console.log("Using mock Mastodon data due to error")
      return [] // We'll convert mock data later
    }

    return []
  }
}

/**
 * Convert Mastodon posts to feed items
 */
export function convertMastodonPostsToFeedItems(posts: MastodonPost[]): FeedItemType[] {
  if (posts.length === 0 && socialConfig.mastodon.useMockData) {
    // Use mock data if no posts and mock data is enabled
    return generateSocialItems(3).filter((item) => item.post.platform === "mastodon")
  }

  return posts.map((post) => {
    // Strip HTML tags from content
    const content = post.content.replace(/<[^>]*>?/gm, "")

    return {
      id: post.id,
      type: "social",
      timestamp: new Date(post.created_at),
      post: {
        platform: "mastodon",
        username: post.account.username,
        displayName: post.account.display_name || post.account.username,
        avatarUrl: post.account.avatar || "/placeholder.svg?height=40&width=40",
        content: content,
        url: post.url,
        likes: post.favourites_count,
        reposts: post.reblogs_count,
        replies: post.replies_count,
        hasMedia: post.media_attachments.length > 0,
      },
    }
  })
}

/**
 * Get Mastodon feed items
 */
export async function getMastodonFeedItems(limit = 3): Promise<FeedItemType[]> {
  try {
    const posts = await fetchMastodonPosts()
    const feedItems = convertMastodonPostsToFeedItems(posts)
    return feedItems.slice(0, limit)
  } catch (error) {
    logError("Error getting Mastodon feed items", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.mastodon.useMockData) {
      return generateSocialItems(limit).filter((item) => item.post.platform === "mastodon")
    }

    return []
  }
}

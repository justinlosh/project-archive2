import { socialConfig } from "@/lib/config/social"
import type { BlueskyPost } from "@/types/social"
import type { FeedItemType } from "@/components/microfeed/feed"
import { generateSocialItems } from "@/lib/data/sample-microfeed-data"
import { logError } from "@/lib/utils/error-logger"

// Cache for Bluesky posts
const blueskyCache: {
  posts: BlueskyPost[]
  timestamp: number
} | null = null

/**
 * Fetch Bluesky posts for a user
 */
export async function fetchBlueskyPosts(handle: string = socialConfig.bluesky.handle): Promise<BlueskyPost[]> {
  // Check if we have a valid cache
  if (blueskyCache && Date.now() - blueskyCache.timestamp < socialConfig.bluesky.cacheDuration * 1000) {
    return blueskyCache.posts
  }

  try {
    // If no handle is provided and mock data is enabled, return mock data
    if (!handle && socialConfig.bluesky.useMockData) {
      console.log("Using mock Bluesky data")
      return [] // We'll convert mock data later
    }

    if (!handle) {
      throw new Error("Bluesky handle not configured")
    }

    // Bluesky requires authentication for most endpoints
    // Since we're just fetching public data and don't have auth credentials in env vars,
    // we'll fall back to mock data for now
    if (socialConfig.bluesky.useMockData) {
      console.log("Using mock Bluesky data - API requires authentication")
      return []
    }

    throw new Error("Bluesky API requires authentication credentials")
  } catch (error) {
    logError("Error fetching Bluesky posts", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.bluesky.useMockData) {
      console.log("Using mock Bluesky data due to error")
      return [] // We'll convert mock data later
    }

    return []
  }
}

/**
 * Convert Bluesky posts to feed items
 */
export function convertBlueskyPostsToFeedItems(posts: BlueskyPost[]): FeedItemType[] {
  if (posts.length === 0 && socialConfig.bluesky.useMockData) {
    // Use mock data if no posts and mock data is enabled
    return generateSocialItems(3).filter((item) => item.post.platform === "bluesky")
  }

  return posts.map((post) => {
    return {
      id: post.uri,
      type: "social",
      timestamp: new Date(post.record.createdAt),
      post: {
        platform: "bluesky",
        username: post.author.handle,
        displayName: post.author.displayName || post.author.handle,
        avatarUrl: post.author.avatar || "/placeholder.svg?height=40&width=40",
        content: post.record.text,
        url: `https://bsky.app/profile/${post.author.handle}/post/${post.uri.split("/").pop()}`,
        likes: post.likeCount,
        reposts: post.repostCount,
        replies: post.replyCount,
        hasMedia: !!post.record.embed?.images?.length || !!post.record.embed?.external,
      },
    }
  })
}

/**
 * Get Bluesky feed items
 */
export async function getBlueskyFeedItems(limit = 3): Promise<FeedItemType[]> {
  try {
    const posts = await fetchBlueskyPosts()
    const feedItems = convertBlueskyPostsToFeedItems(posts)
    return feedItems.slice(0, limit)
  } catch (error) {
    logError("Error getting Bluesky feed items", error instanceof Error ? error : new Error(String(error)))

    // If mock data is enabled, return mock data on error
    if (socialConfig.bluesky.useMockData) {
      return generateSocialItems(limit).filter((item) => item.post.platform === "bluesky")
    }

    return []
  }
}

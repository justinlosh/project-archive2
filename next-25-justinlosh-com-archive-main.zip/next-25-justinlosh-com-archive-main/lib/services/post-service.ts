import type { Note } from "@/types"
import { getAllNotes, getRecentNotes as getStaticRecentNotes } from "@/lib/services/notes-service"

// Interface for post query options
interface PostQueryOptions {
  limit?: number
  page?: number
  category?: string
}

// Get all posts with optional filtering and pagination
export async function getPosts(options: PostQueryOptions = {}): Promise<Note[]> {
  try {
    const { limit, page = 1, category } = options

    // Get all notes
    let posts = await getAllNotes()

    // Filter by category if provided
    if (category) {
      posts = posts.filter((post) => post.category === category)
    }

    // Apply pagination if limit is provided
    if (limit) {
      const startIndex = (page - 1) * limit
      posts = posts.slice(startIndex, startIndex + limit)
    }

    return posts
  } catch (error) {
    console.error("Error fetching posts:", error)
    return []
  }
}

// Get a single post by slug
export async function getPostBySlug(slug: string): Promise<Note | null> {
  try {
    const { getNoteBySlug } = await import("@/lib/services/notes-service")
    const note = await getNoteBySlug(slug)
    return note || null
  } catch (error) {
    console.error(`Error fetching post with slug ${slug}:`, error)
    return null
  }
}

// Get recent posts
export async function getRecentPosts(count = 3): Promise<Note[]> {
  try {
    return getStaticRecentNotes(count)
  } catch (error) {
    console.error("Error fetching recent posts:", error)
    return []
  }
}

/**
 * Data service layer for handling all data operations
 */
import { AppError, ErrorType, handleError } from "@/lib/services/error-service"
import type { Note, Project } from "@/types"

// Generic fetch function with error handling
export async function fetchData<T>(url: string, options?: RequestInit): Promise<T> {
  try {
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

    const response = await fetch(url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
      signal: controller.signal,
    })

    clearTimeout(timeoutId)

    if (!response.ok) {
      let errorType = ErrorType.SERVER

      if (response.status === 404) errorType = ErrorType.NOT_FOUND
      if (response.status === 401) errorType = ErrorType.UNAUTHORIZED
      if (response.status === 403) errorType = ErrorType.FORBIDDEN

      throw new AppError(`API error: ${response.statusText}`, errorType, response.status)
    }

    return await response.json()
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new AppError("Request timeout", ErrorType.NETWORK, 408)
    }
    throw handleError(error)
  }
}

// Note data service
export const NoteService = {
  async getAllNotes(): Promise<Note[]> {
    try {
      // In a real app, this would use fetchData to get notes from an API
      // For now, we'll import from the mock service
      const { getAllNotes } = await import("@/lib/services/notes-service")
      return getAllNotes()
    } catch (error) {
      console.error("Error fetching all notes:", error)
      return []
    }
  },

  async getNoteBySlug(slug: string): Promise<Note> {
    try {
      const { getNoteBySlug } = await import("@/lib/services/notes-service")
      const note = await getNoteBySlug(slug)

      if (!note) {
        throw new AppError("Note not found", ErrorType.NOT_FOUND, 404)
      }

      return note
    } catch (error) {
      console.error(`Error fetching note by slug ${slug}:`, error)
      throw error
    }
  },

  async getRecentNotes(count = 4): Promise<Note[]> {
    try {
      const { getRecentNotes } = await import("@/lib/services/notes-service")
      return getRecentNotes(count)
    } catch (error) {
      console.error("Error fetching recent notes:", error)
      return []
    }
  },
}

// Project data service
export const ProjectService = {
  async getAllProjects(): Promise<Project[]> {
    try {
      const { getAllProjects } = await import("@/lib/services/project-service")
      return getAllProjects()
    } catch (error) {
      console.error("Error fetching all projects:", error)
      return []
    }
  },

  async getFeaturedProject(): Promise<Project | null> {
    try {
      const { getFeaturedProject } = await import("@/lib/services/project-service")
      return getFeaturedProject()
    } catch (error) {
      console.error("Error fetching featured project:", error)
      return null
    }
  },

  async getProjectById(id: number | string): Promise<Project> {
    try {
      const { getProjectById } = await import("@/lib/services/project-service")
      const project = await getProjectById(id)

      if (!project) {
        throw new AppError("Project not found", ErrorType.NOT_FOUND, 404)
      }

      return project
    } catch (error) {
      console.error(`Error fetching project by id ${id}:`, error)
      throw error
    }
  },
}

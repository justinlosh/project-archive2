import type { Project } from "@/types"
import { staticProjects } from "@/lib/data/static-data"

// Get all projects
export async function getAllProjects(): Promise<Project[]> {
  // In a real app, this would fetch from an API or database
  // For now, we'll use static data
  return staticProjects
}

// Get a specific project by ID
export async function getProjectById(id: number): Promise<Project | null> {
  const project = staticProjects.find((p) => p.id === id)
  return project || null
}

// Get the featured project
export async function getFeaturedProject(): Promise<Project | null> {
  const featuredProject = staticProjects.find((p) => p.isFeatured)
  return featuredProject || null
}

// Get projects by category
export async function getProjectsByCategory(category: string): Promise<Project[]> {
  return staticProjects.filter((p) => p.category === category)
}

// Get projects by tag
export async function getProjectsByTag(tag: string): Promise<Project[]> {
  return staticProjects.filter((p) => p.tags.includes(tag))
}

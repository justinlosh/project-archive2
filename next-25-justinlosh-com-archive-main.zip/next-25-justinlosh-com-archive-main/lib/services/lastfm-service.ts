import { lastfmConfig } from "@/lib/config/lastfm"
import type { LastFmStats, LastFmTrack, LastFmArtist, LastFmAlbum } from "@/types/lastfm"

// Cache for Last.fm data
let lastFmCache: {
  stats: LastFmStats | null
  timestamp: number
} = {
  stats: null,
  timestamp: 0,
}

/**
 * Fetches Last.fm data from the API
 * @param period Time period for stats (overall, 7day, 1month, 3month, 6month, 12month)
 * @returns Promise with Last.fm stats
 */
export async function fetchLastFmData(period = "7day"): Promise<LastFmStats | null> {
  try {
    // Check if we have cached data that's still valid
    const now = Date.now()
    if (lastFmCache.stats && lastFmCache.timestamp > now - lastfmConfig.cacheDuration * 1000) {
      return lastFmCache.stats
    }

    // If no API key is provided or mock data is enabled, return mock data
    if (!lastfmConfig.apiKey || lastfmConfig.useMockData) {
      console.log("Using mock Last.fm data")
      return getMockLastFmData(period)
    }

    // Fetch recent tracks
    const recentTracksResponse = await fetch(
      `${lastfmConfig.baseUrl}?method=user.getrecenttracks&user=${lastfmConfig.username}&api_key=${lastfmConfig.apiKey}&format=json&limit=5`,
      { next: { revalidate: 3600 } }, // Cache for 1 hour
    )

    // Fetch top artists
    const topArtistsResponse = await fetch(
      `${lastfmConfig.baseUrl}?method=user.gettopartists&user=${lastfmConfig.username}&api_key=${lastfmConfig.apiKey}&format=json&period=${period}&limit=5`,
      { next: { revalidate: 3600 } }, // Cache for 1 hour
    )

    // Fetch top albums
    const topAlbumsResponse = await fetch(
      `${lastfmConfig.baseUrl}?method=user.gettopalbums&user=${lastfmConfig.username}&api_key=${lastfmConfig.apiKey}&format=json&period=${period}&limit=5`,
      { next: { revalidate: 3600 } }, // Cache for 1 hour
    )

    // Fetch loved tracks
    const lovedTracksResponse = await fetch(
      `${lastfmConfig.baseUrl}?method=user.getlovedtracks&user=${lastfmConfig.username}&api_key=${lastfmConfig.apiKey}&format=json&limit=5`,
      { next: { revalidate: 3600 } }, // Cache for 1 hour
    )

    if (!recentTracksResponse.ok || !topArtistsResponse.ok || !topAlbumsResponse.ok || !lovedTracksResponse.ok) {
      console.error("Last.fm API error:", {
        recentTracks: recentTracksResponse.status,
        topArtists: topArtistsResponse.status,
        topAlbums: topAlbumsResponse.status,
        lovedTracks: lovedTracksResponse.status,
      })
      throw new Error("Failed to fetch Last.fm data")
    }

    const recentTracksData = await recentTracksResponse.json()
    const topArtistsData = await topArtistsResponse.json()
    const topAlbumsData = await topAlbumsResponse.json()
    const lovedTracksData = await lovedTracksResponse.json()

    // Check for error responses from Last.fm
    if (recentTracksData.error || topArtistsData.error || topAlbumsData.error || lovedTracksData.error) {
      console.error("Last.fm API returned an error:", {
        recentTracks: recentTracksData.error,
        topArtists: topArtistsData.error,
        topAlbums: topAlbumsData.error,
        lovedTracks: lovedTracksData.error,
      })
      throw new Error("Last.fm API returned an error")
    }

    // Extract the data we need
    const recentTracks: LastFmTrack[] = recentTracksData.recenttracks?.track || []
    const topArtists: LastFmArtist[] = topArtistsData.topartists?.artist || []
    const topAlbums: LastFmAlbum[] = topAlbumsData.topalbums?.album || []
    const lovedTracks: LastFmTrack[] = lovedTracksData.lovedtracks?.track || []

    // Calculate total unique artists and albums
    const uniqueArtists = new Set(recentTracks.map((track) => track.artist.name))
    const uniqueAlbums = new Set(
      recentTracks.filter((track) => track.album?.name).map((track) => `${track.artist.name}-${track.album?.name}`),
    )

    // Create stats object
    const stats: LastFmStats = {
      user: lastfmConfig.username,
      period,
      total: {
        tracks: Number.parseInt(recentTracksData.recenttracks?.["@attr"]?.total || "0"),
        artists: uniqueArtists.size,
        albums: uniqueAlbums.size,
      },
      recentTracks,
      topArtists,
      topAlbums,
      lovedTracks,
      profileUrl: `https://www.last.fm/user/${lastfmConfig.username}`,
      lastUpdated: new Date().toISOString(),
    }

    // Update cache
    lastFmCache = {
      stats,
      timestamp: now,
    }

    return stats
  } catch (error) {
    console.error("Error fetching Last.fm data:", error)

    // If API fails, return mock data
    return getMockLastFmData(period)
  }
}

/**
 * Returns mock Last.fm data for testing
 * @param period Time period for stats
 * @returns Mock Last.fm stats
 */
function getMockLastFmData(period: string): LastFmStats {
  return {
    user: lastfmConfig.username,
    period,
    total: {
      tracks: 127,
      artists: 42,
      albums: 35,
    },
    recentTracks: [
      {
        name: "Everlong",
        artist: {
          name: "Foo Fighters",
          url: "https://www.last.fm/music/Foo+Fighters",
        },
        album: {
          name: "The Colour and the Shape",
          url: "https://www.last.fm/music/Foo+Fighters/The+Colour+and+the+Shape",
        },
        url: "https://www.last.fm/music/Foo+Fighters/_/Everlong",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Foo%20Fighters",
          },
        ],
        loved: "0",
      },
      {
        name: "Bohemian Rhapsody",
        artist: {
          name: "Queen",
          url: "https://www.last.fm/music/Queen",
        },
        album: {
          name: "A Night at the Opera",
          url: "https://www.last.fm/music/Queen/A+Night+at+the+Opera",
        },
        url: "https://www.last.fm/music/Queen/_/Bohemian+Rhapsody",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Queen",
          },
        ],
        loved: "0",
      },
    ],
    topArtists: [
      {
        name: "Foo Fighters",
        playcount: "42",
        url: "https://www.last.fm/music/Foo+Fighters",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Foo%20Fighters",
          },
        ],
      },
      {
        name: "Queen",
        playcount: "38",
        url: "https://www.last.fm/music/Queen",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Queen",
          },
        ],
      },
    ],
    topAlbums: [
      {
        name: "The Colour and the Shape",
        artist: {
          name: "Foo Fighters",
          url: "https://www.last.fm/music/Foo+Fighters",
        },
        playcount: "24",
        url: "https://www.last.fm/music/Foo+Fighters/The+Colour+and+the+Shape",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Foo%20Fighters",
          },
        ],
      },
      {
        name: "A Night at the Opera",
        artist: {
          name: "Queen",
          url: "https://www.last.fm/music/Queen",
        },
        playcount: "18",
        url: "https://www.last.fm/music/Queen/A+Night+at+the+Opera",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Queen",
          },
        ],
      },
    ],
    lovedTracks: [
      {
        name: "Smells Like Teen Spirit",
        artist: {
          name: "Nirvana",
          url: "https://www.last.fm/music/Nirvana",
        },
        url: "https://www.last.fm/music/Nirvana/_/Smells+Like+Teen+Spirit",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Nirvana",
          },
        ],
        loved: "1",
      },
      {
        name: "Stairway to Heaven",
        artist: {
          name: "Led Zeppelin",
          url: "https://www.last.fm/music/Led+Zeppelin",
        },
        url: "https://www.last.fm/music/Led+Zeppelin/_/Stairway+to+Heaven",
        image: [
          {
            size: "small",
            "#text": "/placeholder.svg?height=100&width=100&text=Led%20Zeppelin",
          },
        ],
        loved: "1",
      },
    ],
    profileUrl: `https://www.last.fm/user/${lastfmConfig.username}`,
    lastUpdated: new Date().toISOString(),
  }
}

/**
 * Gets the best image URL from a Last.fm image array
 * @param images Array of Last.fm images
 * @param size Preferred size (small, medium, large, extralarge)
 * @returns Best image URL or placeholder
 */
export function getBestImageUrl(
  images: { size: string; "#text": string }[] | undefined,
  size: "small" | "medium" | "large" | "extralarge" = "medium",
): string {
  if (!images || images.length === 0) {
    return "/placeholder.svg?height=100&width=100"
  }

  // Try to find the requested size
  const requestedImage = images.find((img) => img.size === size)
  if (requestedImage && requestedImage["#text"] && requestedImage["#text"].trim() !== "") {
    return requestedImage["#text"]
  }

  // If not found, try to find any non-empty image
  const anyImage = images.find((img) => img["#text"] && img["#text"].trim() !== "")
  if (anyImage) {
    return anyImage["#text"]
  }

  // Fallback to placeholder
  return "/placeholder.svg?height=100&width=100"
}

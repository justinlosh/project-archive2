/**
 * Error handling service
 */

// Error types
export enum ErrorType {
  NOT_FOUND = "NOT_FOUND",
  UNAUTHORIZED = "UNAUTHORIZED",
  FORBIDDEN = "FORBIDDEN",
  VALIDATION = "VALIDATION",
  SERVER = "SERVER",
  NETWORK = "NETWORK",
  UNKNOWN = "UNKNOWN",
}

// Custom application error
export class AppError extends Error {
  type: ErrorType
  statusCode: number

  constructor(message: string, type: ErrorType = ErrorType.UNKNOWN, statusCode = 500) {
    super(message)
    this.name = "AppError"
    this.type = type
    this.statusCode = statusCode
  }
}

// Error handling function
export function handleError(error: unknown): AppError {
  if (error instanceof AppError) {
    return error
  }

  // Handle standard errors
  if (error instanceof Error) {
    return new AppError(error.message)
  }

  // Handle unknown errors
  return new AppError("An unknown error occurred")
}

// Not found error helper
export function createNotFoundError(resource: string): AppError {
  return new AppError(`${resource} not found`, ErrorType.NOT_FOUND, 404)
}

// Site information
export const SITE_NAME = "Justin Losh"
export const SITE_DESCRIPTION = "Personal website and blog of Justin Losh, software engineer and web developer."
export const SITE_URL = "https://justinlosh.com"
export const DEFAULT_KEYWORDS = "blog, portfolio, web development, javascript, react, nextjs, typescript"
export const DEFAULT_TITLE_TEMPLATE = "%s | Justin Losh"
export const AUTHOR_NAME = "Justin Losh"

// Navigation
export const MAIN_NAV_ITEMS = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
  { href: "/notes", label: "Notes" },
  { href: "/now", label: "Now" },
  { href: "/projects", label: "Projects" },
  { href: "/contact", label: "Contact" },
]

export const FOOTER_NAV_ITEMS = [
  { href: "/colophon", label: "Colophon" },
  { href: "/security", label: "Security" },
  { href: "/privacy", label: "Privacy" },
  { href: "/disclaimer", label: "Disclaimer" },
  { href: "/verify", label: "Verify" },
  { href: "/contact", label: "Contact" },
]

// Social links
export const SOCIAL_LINKS = [
  {
    name: "GitHub",
    url: "https://github.com/yourusername",
    icon: "github",
  },
  {
    name: "Twitter",
    url: "https://twitter.com/yourusername",
    icon: "twitter",
  },
  {
    name: "LinkedIn",
    url: "https://linkedin.com/in/yourusername",
    icon: "linkedin",
  },
]

// API endpoints
export const API_ENDPOINTS = {
  LASTFM: "/api/lastfm",
  READING: "/api/reading",
  VERIFY_TURNSTILE: "/api/verify-turnstile",
}

// Cache durations (in seconds)
export const CACHE_TIMES = {
  LASTFM: 60 * 15, // 15 minutes
  READING: 60 * 60, // 1 hour
  GITHUB: 60 * 30, // 30 minutes
  SOCIAL: 60 * 10, // 10 minutes
}

// Pagination
export const POSTS_PER_PAGE = 10
export const NOTES_PER_PAGE = 12

// Microfeed
export const MICROFEED_ITEMS_LIMIT = 20

import type { FeedItemType } from "@/components/microfeed/feed"

// Sample data for development
export const sampleFeedItems: FeedItemType[] = [
  {
    type: "github",
    id: "gh-1",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
    url: "https://github.com/username/repo/commit/abc123",
    github: {
      username: "justinlosh",
      avatarUrl: "/placeholder.svg?height=40&width=40",
      repoName: "next-portfolio",
      eventType: "PushEvent",
      title: "Pushed to main",
      description: "Update homepage layout and fix responsive issues",
      url: "https://github.com/username/repo/commit/abc123",
    },
  },
  {
    type: "social",
    id: "social-1",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 5), // 5 hours ago
    url: "https://twitter.com/username/status/123456789",
    post: {
      username: "justinlosh",
      displayName: "Justin Losh",
      content: "Just launched my new portfolio website built with Next.js and Tailwind CSS!",
      avatarUrl: "/placeholder.svg?height=40&width=40",
      platform: "bluesky",
      likes: 12,
      reposts: 3,
      replies: 2,
      hasMedia: false,
    },
  },
  {
    type: "reading",
    id: "reading-1",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    url: "https://goodreads.com/book/show/123",
    book: {
      title: "The Pragmatic Programmer",
      author: "Andrew Hunt, David Thomas",
      coverUrl: "/abstract-book-cover.png",
      summary: "A guide to pragmatic programming techniques.",
      status: "reading",
      rating: 5,
      progress: 65,
    },
  },
  {
    type: "lastfm",
    id: "lastfm-1",
    timestamp: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
    url: "https://last.fm/user/username/library",
    track: {
      title: "Bohemian Rhapsody",
      artist: "Queen",
      album: "A Night at the Opera",
      albumArt: "/placeholder.svg?height=60&width=60",
    },
  },
  {
    type: "github",
    id: "gh-2",
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 8), // 8 hours ago
    url: "https://github.com/username/repo/pull/42",
    github: {
      username: "justinlosh",
      avatarUrl: "/placeholder.svg?height=40&width=40",
      repoName: "react-components",
      eventType: "PullRequestEvent",
      title: "Created pull request",
      description: "Add new Button component with variants",
      url: "https://github.com/username/repo/pull/42",
    },
  },
]

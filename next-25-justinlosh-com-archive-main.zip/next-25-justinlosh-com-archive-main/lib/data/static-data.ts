import type { Project } from "@/types"

// Static project data
export const staticProjects: Project[] = [
  {
    id: 2,
    title: "Base Command",
    slug: "base-command",
    description:
      "A command-line interface (CLI) tool for managing development environments and workflows. Built with Node.js and TypeScript.",
    longDescription:
      "Base Command is a powerful CLI tool designed to streamline development workflows and environment management. It provides a unified interface for common development tasks, configuration management, and project scaffolding. Built with Node.js and TypeScript, it offers extensibility through plugins and a robust architecture for handling complex operations.",
    image: "/images/basecmd-icon.png",
    link: "https://github.com/yourusername/base-command",
    demoLink: "https://basecmd.dev",
    category: "Developer Tools",
    tags: ["Node.js", "TypeScript", "CLI", "Developer Tools"],
    isFeatured: false,
    date: "2023-05-15",
    status: "Active Development",
  },
  {
    id: 4,
    title: "Full-Stack SaaS Platform",
    slug: "saas-platform",
    description:
      "A complete SaaS platform with authentication, billing, and user management. Built with Next.js, Prisma, and Stripe.",
    longDescription:
      "This full-stack SaaS platform provides everything needed to launch a subscription-based service. It includes user authentication, role-based access control, subscription management with Stripe integration, and a comprehensive admin dashboard. The platform is built with Next.js for the frontend and API routes, Prisma for database access, and integrates with various third-party services for additional functionality.",
    image: "/images/zsrc-project-dark-icon.png",
    link: "https://github.com/yourusername/saas-platform",
    demoLink: "https://saas-demo.yourdomain.com",
    category: "Web Application",
    tags: ["Next.js", "React", "Prisma", "Stripe", "TypeScript"],
    isFeatured: true,
    date: "2023-08-10",
    status: "Launched",
  },
]

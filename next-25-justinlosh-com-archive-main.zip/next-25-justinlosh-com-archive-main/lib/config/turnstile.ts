export const turnstileConfig = {
  enabled: process.env.TURNSTILE_ENABLED === "true",
  siteKey: process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY || "",
  secretKey: process.env.TURNSTILE_SECRET_KEY || "",
  testMode: process.env.TURNSTILE_TEST_MODE === "true",
}

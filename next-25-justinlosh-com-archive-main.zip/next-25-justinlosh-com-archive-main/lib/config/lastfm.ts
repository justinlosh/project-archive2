/**
 * Last.fm configuration
 */

export const lastfmConfig = {
  // Your Last.fm API key
  apiKey: process.env.LASTFM_API_KEY || "",

  // Your Last.fm username
  username: process.env.LASTFM_USERNAME || "justinlosh",

  // API base URL
  baseUrl: "https://ws.audioscrobbler.com/2.0/",

  // Cache duration in seconds (1 hour)
  cacheDuration: 3600,

  // Whether to use mock data when API is unavailable
  useMockData: process.env.LASTFM_USE_MOCK_DATA !== "false",
}

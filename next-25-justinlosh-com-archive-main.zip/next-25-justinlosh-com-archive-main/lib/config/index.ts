/**
 * Application configuration
 */
import { env } from "@/lib/env"
import type { SiteConfig, ThemeConfig } from "@/types"

export const siteConfig: SiteConfig = {
  name: env.SITE_NAME,
  description: env.SITE_DESCRIPTION,
  url: env.SITE_URL,
  ogImage: `${env.SITE_URL}/og-image.jpg`,
  links: {
    twitter: `https://twitter.com/${env.TWITTER_HANDLE}`,
    github: `https://github.com/${env.GITHUB_HANDLE}`,
  },
}

export const themeConfig: ThemeConfig = {
  defaultTheme: "dark",
  enableSystem: false,
  themes: [
    "light",
    "dark",
    "theme-blue",
    "theme-blue-dark",
    "theme-purple",
    "theme-purple-dark",
    "theme-green",
    "theme-green-dark",
    "theme-amber",
    "theme-amber-dark",
  ],
}

export const maintenanceConfig = {
  enabled: false,
  message: "We're currently undergoing scheduled maintenance. Please check back later.",
  estimatedReturnTime: null,
  contactEmail: "support@justinlosh.com",
}

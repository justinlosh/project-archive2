/**
 * Analytics configuration
 */

interface AnalyticsConfig {
  umami: {
    enabled: boolean
    websiteId: string
    scriptUrl: string
    dataDomains: string[]
  }
}

export const analyticsConfig: AnalyticsConfig = {
  umami: {
    enabled: process.env.UMAMI_ENABLED === "true",
    websiteId: process.env.NEXT_PUBLIC_UMAMI_WEBSITE_ID || "",
    scriptUrl: process.env.NEXT_PUBLIC_UMAMI_URL || "",
    dataDomains: (process.env.UMAMI_DATA_DOMAINS || "").split(","),
  },
}

/**
 * Goodreads configuration
 */

export const goodreadsConfig = {
  // Your Goodreads user ID
  userId: process.env.GOODREADS_USER_ID || "61381488",

  // Your Goodreads username (used for generating URLs)
  username: process.env.GOODREADS_USERNAME || "justinlosh",

  // Shelf IDs for different reading statuses
  shelves: {
    reading: process.env.GOODREADS_SHELF_READING || "currently-reading",
    read: process.env.GOODREADS_SHELF_READ || "read",
    toRead: process.env.GOODREADS_SHELF_TO_READ || "to-read",
  },

  // Number of books to fetch by default
  defaultLimit: Number.parseInt(process.env.GOODREADS_DEFAULT_LIMIT || "10", 10),

  // Base URL for Goodreads (useful if you need to change it for scraping)
  baseUrl: process.env.GOODREADS_BASE_URL || "https://www.goodreads.com",

  // Always use real data
  useMockData: false,
}

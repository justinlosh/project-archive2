/**
 * Social media configuration
 */

export const socialConfig = {
  // GitHub configuration
  github: {
    username: process.env.GITHUB_USERNAME || "justinlosh",
    apiUrl: "https://api.github.com",
    get profileUrl() {
      return `https://github.com/${this.username}`
    },
    // Number of events to fetch
    eventsLimit: 10,
    // Cache duration in seconds (15 minutes)
    cacheDuration: 900,
    // Whether to use mock data when API is unavailable
    useMockData: process.env.GITHUB_USE_MOCK_DATA !== "false",
  },

  // Bluesky configuration
  bluesky: {
    handle: process.env.BLUESKY_HANDLE || "justinlosh.com",
    apiUrl: "https://bsky.social/xrpc",
    get profileUrl() {
      return `https://bsky.app/profile/${this.handle}`
    },
    // Number of posts to fetch
    postsLimit: 10,
    // Cache duration in seconds (15 minutes)
    cacheDuration: 900,
    // Whether to use mock data when API is unavailable
    useMockData: process.env.BLUESKY_USE_MOCK_DATA !== "false",
  },

  // Mastodon configuration
  mastodon: {
    server: process.env.MASTODON_SERVER || "infosec.exchange",
    username: process.env.MASTODON_USERNAME || "justinlosh",
    get apiUrl() {
      return `https://${this.server}/api/v1`
    },
    get profileUrl() {
      return `https://${this.server}/@${this.username}`
    },
    // Number of posts to fetch
    postsLimit: 10,
    // Cache duration in seconds (15 minutes)
    cacheDuration: 900,
    // Whether to use mock data when API is unavailable
    useMockData: process.env.MASTODON_USE_MOCK_DATA !== "false",
  },
}

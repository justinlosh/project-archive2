/**
 * Utility functions for sanitizing user-generated content
 */

// Simple HTML sanitizer for basic text
export function sanitizeText(text: string | null | undefined): string {
  if (text === null || text === undefined || typeof text !== "string") {
    return ""
  }

  try {
    // Comprehensive sanitization
    let sanitized = text
      // Remove potentially dangerous script tags
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
      // Remove iframe tags
      .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "")
      // Remove object tags
      .replace(/<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi, "")
      // Remove embed tags
      .replace(/<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*<\/embed>/gi, "")
      // Remove style tags
      .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
      // Remove link tags
      .replace(/<link\b[^<]*(?:(?!<\/link>)<[^<]*)*<\/link>/gi, "")
      // Remove meta tags
      .replace(/<meta\b[^<]*(?:(?!<\/meta>)<[^<]*)*<\/meta>/gi, "")
      // Remove base tags
      .replace(/<base\b[^<]*(?:(?!<\/base>)<[^<]*)*<\/base>/gi, "")
      // Remove form tags
      .replace(/<form\b[^<]*(?:(?!<\/form>)<[^<]*)*<\/form>/gi, "")

    // Remove dangerous attributes
    sanitized = sanitized
      // Remove event handlers
      .replace(/on\w+="[^"]*"/gi, "")
      .replace(/on\w+='[^']*'/gi, "")
      .replace(/on\w+=\S+/gi, "")
      // Remove javascript: URLs
      .replace(/javascript:[^\s"']+/gi, "")
      // Remove data: URLs
      .replace(/data:[^\s"']+/gi, "")
      // Remove other potentially dangerous attributes
      .replace(/formaction="[^"]*"/gi, "")
      .replace(/formaction='[^']*'/gi, "")
      .replace(/formaction=\S+/gi, "")
      // Remove href attributes with javascript:
      .replace(/href="javascript:[^"]*"/gi, "")
      .replace(/href='javascript:[^']*'/gi, "")
      .replace(/href=javascript:[^\s>]*/gi, "")

    return sanitized
  } catch (error) {
    console.error("Error sanitizing text:", error)
    return ""
  }
}

// For use with dangerouslySetInnerHTML (when absolutely necessary)
export function createSafeHTML(html: string | null | undefined): { __html: string } {
  return { __html: sanitizeText(html) }
}

// Sanitize user input for forms
export function sanitizeUserInput(input: string): string {
  if (!input) return ""

  try {
    // Remove HTML tags completely
    const noTags = input.replace(/<[^>]*>/g, "")

    // Trim whitespace
    const trimmed = noTags.trim()

    // Encode special characters
    return trimmed
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;")
  } catch (error) {
    console.error("Error sanitizing user input:", error)
    return ""
  }
}

// Validate and sanitize URLs
export function sanitizeUrl(url: string): string {
  if (!url) return ""

  try {
    // Check if URL is valid
    const urlObj = new URL(url)

    // Only allow http and https protocols
    if (urlObj.protocol !== "http:" && urlObj.protocol !== "https:") {
      return ""
    }

    return url
  } catch (error) {
    // If URL is invalid, return empty string
    return ""
  }
}

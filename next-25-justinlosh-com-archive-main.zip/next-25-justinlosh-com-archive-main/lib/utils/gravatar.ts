/**
 * Gravatar utility functions
 */

// Pre-computed MD5 hash for justin@justinlosh.com
const JUSTIN_EMAIL_HASH = "9e9c21d53f778d2e373a52b98eb9f8e1"

/**
 * Get a Gravatar URL for an email
 * @param email - The email to get a Gravatar for
 * @param size - The size of the Gravatar image in pixels
 * @returns The Gravatar URL
 */
export function getGravatarUrl(size = 80): string {
  // Use a placeholder for now
  return `/placeholder.svg?height=${size}&width=${size}&text=JL`
}

/**
 * Get a UI Avatar URL as a fallback
 * @param name - The name to generate an avatar for
 * @param size - The size of the avatar image in pixels
 * @returns The UI Avatars URL
 */
export function getUIAvatarUrl(name: string, size = 80): string {
  // UI Avatars is a service that generates avatars from names
  const encodedName = encodeURIComponent(name.trim())
  return `https://ui-avatars.com/api/?name=${encodedName}&size=${size}&background=random`
}

type ErrorContext = Record<string, any>

/**
 * Logs an error with additional context
 * @param message - Error message
 * @param error - Error object
 * @param context - Additional context for the error
 */
export function logError(message: string, error: Error, context: ErrorContext = {}): void {
  // In a production app, you would send this to a logging service
  console.error(`[ERROR] ${message}`, {
    error: {
      name: error.name,
      message: error.message,
      stack: error.stack,
    },
    context,
    timestamp: new Date().toISOString(),
    url: typeof window !== "undefined" ? window.location.href : "",
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "",
  })
}

/**
 * Logs a warning with additional context
 * @param message - Warning message
 * @param context - Additional context for the warning
 */
export function logWarning(message: string, context: ErrorContext = {}): void {
  // In a production app, you would send this to a logging service
  console.warn(`[WARNING] ${message}`, {
    context,
    timestamp: new Date().toISOString(),
    url: typeof window !== "undefined" ? window.location.href : "",
  })
}

export { default as DotsSVG } from './dots'
export { default as LogoSVG } from './logo'
export { default as MarkSVG } from './mark'

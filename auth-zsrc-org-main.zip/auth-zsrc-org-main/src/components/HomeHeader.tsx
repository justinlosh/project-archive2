import Header from "@/components/MainHeader";

export default async function HomeHeader() {
  return <Header showNav={false} />;
}

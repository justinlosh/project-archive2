const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

// Colors for console output
const colors = {
  reset: "\x1b[0m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  blue: "\x1b[34m",
  magenta: "\x1b[35m",
  cyan: "\x1b[36m",
}

console.log(`${colors.cyan}Starting pre-deployment checks...${colors.reset}`)

// Check for required files
const requiredFiles = [
  "next.config.mjs",
  "package.json",
  "tsconfig.json",
  "tailwind.config.js",
  "postcss.config.js",
  ".eslintrc.json",
  "vercel.json",
]

console.log(`${colors.blue}Checking for required files...${colors.reset}`)
let missingFiles = false
for (const file of requiredFiles) {
  if (!fs.existsSync(path.join(process.cwd(), file))) {
    console.log(`${colors.red}Missing required file: ${file}${colors.reset}`)
    missingFiles = true
  }
}

if (missingFiles) {
  console.log(`${colors.red}Some required files are missing. Please add them before deploying.${colors.reset}`)
  process.exit(1)
}

console.log(`${colors.green}All required files are present.${colors.reset}`)

// Check for TypeScript errors
console.log(`${colors.blue}Checking for TypeScript errors...${colors.reset}`)
try {
  execSync("npx tsc --noEmit", { stdio: "inherit" })
  console.log(`${colors.green}No TypeScript errors found.${colors.reset}`)
} catch (error) {
  console.log(`${colors.red}TypeScript errors found. Please fix them before deploying.${colors.reset}`)
  process.exit(1)
}

// Check for ESLint errors
console.log(`${colors.blue}Checking for ESLint errors...${colors.reset}`)
try {
  execSync("npx eslint . --ext .js,.jsx,.ts,.tsx", { stdio: "inherit" })
  console.log(`${colors.green}No ESLint errors found.${colors.reset}`)
} catch (error) {
  console.log(`${colors.yellow}ESLint errors found. Consider fixing them before deploying.${colors.reset}`)
  // Don't exit, just warn
}

// Run tests
console.log(`${colors.blue}Running tests...${colors.reset}`)
try {
  execSync("npm test", { stdio: "inherit" })
  console.log(`${colors.green}All tests passed.${colors.reset}`)
} catch (error) {
  console.log(`${colors.red}Tests failed. Please fix them before deploying.${colors.reset}`)
  process.exit(1)
}

// Try a build
console.log(`${colors.blue}Attempting a build...${colors.reset}`)
try {
  execSync("npm run build", { stdio: "inherit" })
  console.log(`${colors.green}Build successful.${colors.reset}`)
} catch (error) {
  console.log(`${colors.red}Build failed. Please fix the errors before deploying.${colors.reset}`)
  process.exit(1)
}

console.log(`${colors.cyan}All checks passed. Ready for deployment!${colors.reset}`)

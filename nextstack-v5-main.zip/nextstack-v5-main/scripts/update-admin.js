#!/usr/bin/env node

import fs from "fs/promises"
import path from "path"
import crypto from "crypto"
import readline from "readline"
import { fileURLToPath } from "url"

// Get the current file's directory
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// Get admin credentials from environment variables or use defaults
const CONTENT_DIR = process.env.CONTENT_DIRECTORY || "content"
const USERS_FILE = path.join(process.cwd(), CONTENT_DIR, "users.json")

// Create readline interface
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})

// Hash password
function hashPassword(password) {
  return crypto.createHash("sha256").update(password).digest("hex")
}

// Ask for input
function prompt(question) {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer)
    })
  })
}

async function updateAdmin() {
  try {
    console.log("Interactive Admin User Update")
    console.log("============================")

    // Ask for admin credentials
    const username = (await prompt("Enter admin username [admin]: ")) || "admin"
    const email = (await prompt("Enter admin email [admin@example.com]: ")) || "admin@example.com"
    const password = (await prompt("Enter admin password [admin123]: ")) || "admin123"

    console.log(`\nUpdating admin user with username: ${username}`)

    // Ensure directory exists
    await fs.mkdir(path.dirname(USERS_FILE), { recursive: true })

    // Create admin user object
    const adminUser = {
      id: crypto.randomUUID(),
      username,
      email,
      password: hashPassword(password),
      role: "admin",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // Read existing users
    let users = []
    try {
      const data = await fs.readFile(USERS_FILE, "utf-8")
      users = JSON.parse(data)

      // Remove any existing admin user with the same username
      const previousAdmins = users.filter(
        (user) => user.role === "admin" && user.username.toLowerCase() === username.toLowerCase(),
      )
      if (previousAdmins.length > 0) {
        console.log(`Found ${previousAdmins.length} existing admin user(s) with username: ${username}`)

        // Update instead of removing if there's an existing admin
        const existingAdmin = previousAdmins[0]
        existingAdmin.email = email
        existingAdmin.password = hashPassword(password)
        existingAdmin.updatedAt = new Date().toISOString()
        console.log(`Updated existing admin user: ${existingAdmin.username}`)
      } else {
        // Add new admin user if no matching admin was found
        users.push(adminUser)
        console.log(`Added new admin user: ${username}`)
      }
    } catch (error) {
      console.log("Creating new users file")
      users = [adminUser]
    }

    // Write users file
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2))
    console.log(`\n✅ Admin user '${username}' updated successfully`)
    console.log("\nYou can now log in with:")
    console.log(`Username: ${username}`)
    console.log(`Password: ${password}`)

    // Update .env.local file
    const envPrompt = await prompt("\nDo you want to update the .env.local file with these credentials? (y/n): ")
    if (envPrompt.toLowerCase() === "y") {
      try {
        // Read existing .env.local file or create new one
        let envContent = ""
        try {
          envContent = await fs.readFile(".env.local", "utf-8")
        } catch (error) {
          console.log("Creating new .env.local file")
        }

        // Update environment variables in the content
        const lines = envContent.split("\n")
        const updatedLines = []

        // Keep track of variables we've updated
        const updated = {
          ADMIN_USERNAME: false,
          ADMIN_EMAIL: false,
          ADMIN_PASSWORD: false,
        }

        // Update existing lines
        for (const line of lines) {
          if (line.trim().startsWith("ADMIN_USERNAME=")) {
            updatedLines.push(`ADMIN_USERNAME=${username}`)
            updated.ADMIN_USERNAME = true
          } else if (line.trim().startsWith("ADMIN_EMAIL=")) {
            updatedLines.push(`ADMIN_EMAIL=${email}`)
            updated.ADMIN_EMAIL = true
          } else if (line.trim().startsWith("ADMIN_PASSWORD=")) {
            updatedLines.push(`ADMIN_PASSWORD=${password}`)
            updated.ADMIN_PASSWORD = true
          } else {
            updatedLines.push(line)
          }
        }

        // Add any missing variables
        if (!updated.ADMIN_USERNAME) {
          updatedLines.push(`ADMIN_USERNAME=${username}`)
        }
        if (!updated.ADMIN_EMAIL) {
          updatedLines.push(`ADMIN_EMAIL=${email}`)
        }
        if (!updated.ADMIN_PASSWORD) {
          updatedLines.push(`ADMIN_PASSWORD=${password}`)
        }

        // Write updated content back to .env.local
        await fs.writeFile(".env.local", updatedLines.join("\n"))
        console.log("\n✅ Updated .env.local file with new admin credentials")
      } catch (error) {
        console.error("\n❌ Failed to update .env.local file:", error)
      }
    }

    console.log("\n✨ Done! You need to restart your application for changes to take effect.")
  } catch (error) {
    console.error("\n❌ Failed to update admin user:", error)
    process.exit(1)
  } finally {
    rl.close()
  }
}

updateAdmin()

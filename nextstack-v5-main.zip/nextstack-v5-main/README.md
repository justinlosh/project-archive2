# Next.js Flat-File CMS

A modern, flexible flat-file CMS built with Next.js, TypeScript, and Tailwind CSS.

## Features

- File-based content management
- Support for Markdown, JSON, and YAML
- Real-time preview
- Content versioning
- API routes for content access
- Admin dashboard
- Theme customization
- Module system
- Responsive design

## Getting Started

1. Clone the repository
2. Install dependencies: `npm install`
3. Run the development server: `npm run dev`
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Documentation

See the `docs` directory for detailed documentation on:

- Data service
- File system adapters
- API routes
- Content components
- Module system
- Theme customization
- Live preview
- Content versioning
- Deployment guide

## License

MIT
\`\`\`

Let's create a simple build script to help with deployment:

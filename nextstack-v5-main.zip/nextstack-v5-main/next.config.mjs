// Ensure environment variables are loaded properly
import { ensureAdminUser } from "./lib/auth/ensure-admin.js"

// Try to initialize admin user during build preparation
try {
  console.log("Checking admin configuration...")
  await ensureAdminUser()
    .then(result => {
      console.log(`✅ Admin user configuration verified: ${result.username}`)
    })
    .catch(err => {
      console.warn("⚠️ Admin user initialization failed:", err.message)
    })
} catch (error) {
  console.warn("⚠️ Could not verify admin configuration:", error.message)
}

/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Existing config...
  
  // Ensure environment variables are available
  env: {
    ADMIN_USERNAME: process.env.ADMIN_USERNAME || "admin",
    ADMIN_EMAIL: process.env.ADMIN_EMAIL || "admin@example.com",
    CONTENT_DIRECTORY: process.env.CONTENT_DIRECTORY || "content",
  },
  
  // Existing config...
}

export default nextConfig

import { NextResponse } from "next/server"

export async function GET() {
  // Get the admin username from environment variables or use default
  const username = process.env.ADMIN_USERNAME || "admin"

  return NextResponse.json({ username })
}

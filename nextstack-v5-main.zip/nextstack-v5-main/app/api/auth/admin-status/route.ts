import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"
import { logger } from "@/lib/utils/logger"
import { ensureAdminUser, logAdminCredentials } from "@/lib/auth/ensure-admin"

export async function GET() {
  try {
    const contentDir = process.env.CONTENT_DIRECTORY || "content"
    const usersFile = path.join(process.cwd(), contentDir, "users.json")

    // Check if users file exists
    let fileExists = false
    let userCount = 0
    let adminExists = false
    let adminUsername = null
    const envAdminUsername = process.env.ADMIN_USERNAME || "admin"

    try {
      await fs.access(usersFile)
      fileExists = true

      // Read users file
      const data = await fs.readFile(usersFile, "utf-8")
      const users = JSON.parse(data)
      userCount = users.length

      // Check if admin exists
      const admin = users.find(
        (user: any) => user.role === "admin" && user.username.toLowerCase() === envAdminUsername.toLowerCase(),
      )

      if (admin) {
        adminExists = true
        adminUsername = admin.username
      }
    } catch (error) {
      logger.error("Error checking users file:", error)
    }

    // Log admin credentials for debugging
    logAdminCredentials()

    return NextResponse.json({
      usersFileExists: fileExists,
      userCount,
      adminExists,
      adminUsername,
      envAdminUsername,
      contentDirectory: contentDir,
      environmentVariables: {
        ADMIN_USERNAME: process.env.ADMIN_USERNAME ? "[SET]" : "[NOT SET]",
        ADMIN_EMAIL: process.env.ADMIN_EMAIL ? "[SET]" : "[NOT SET]",
        ADMIN_PASSWORD: process.env.ADMIN_PASSWORD ? "[SET]" : "[NOT SET]",
        CONTENT_DIRECTORY: contentDir,
      },
    })
  } catch (error) {
    logger.error("Error in admin status:", error)
    return NextResponse.json({ error: "Failed to get admin status" }, { status: 500 })
  }
}

export async function POST() {
  try {
    const result = await ensureAdminUser()
    return NextResponse.json({
      success: true,
      message: `Admin user created/updated successfully`,
      username: result.username,
    })
  } catch (error) {
    logger.error("Error ensuring admin user:", error)
    return NextResponse.json({ error: "Failed to ensure admin user" }, { status: 500 })
  }
}

import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"
import { getUserByUsername, verifyPassword, createSession } from "@/lib/auth/auth-utils"
import { logger } from "@/lib/utils/logger"
import crypto from "crypto"

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const username = formData.get("username") as string
    const password = formData.get("password") as string

    logger.info(`Login attempt for username: ${username}`)

    if (!username || !password) {
      logger.warn("Login attempt without username or password")
      return NextResponse.json({ error: "Username and password are required" }, { status: 400 })
    }

    // Get user by username
    const user = await getUserByUsername(username)

    // Log more details about the login attempt
    if (!user) {
      logger.warn(`Login attempt with non-existent username: ${username}`)

      // Check if this is the environment-defined admin trying to log in
      const envAdminUsername = process.env.ADMIN_USERNAME || "admin"
      if (username.toLowerCase() === envAdminUsername.toLowerCase()) {
        logger.warn(`Failed login for environment-defined admin. User not found in database.`)
        return NextResponse.json(
          {
            error: "Admin user not found in database. Please run the reset-admin script.",
          },
          { status: 401 },
        )
      }

      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Verify password
    const isPasswordValid = verifyPassword(password, user.password)

    // Log more details about password verification
    logger.info(`Password verification for ${username}: ${isPasswordValid ? "Successful" : "Failed"}`)

    if (!isPasswordValid) {
      // If this is the env-defined admin but password doesn't match, log more details
      const envAdminUsername = process.env.ADMIN_USERNAME || "admin"
      if (username.toLowerCase() === envAdminUsername.toLowerCase()) {
        const envPassword = process.env.ADMIN_PASSWORD || "admin123"
        const envPasswordHash = crypto.createHash("sha256").update(envPassword).digest("hex")
        logger.warn(`Admin password mismatch: 
          Input password hash: ${crypto.createHash("sha256").update(password).digest("hex")}
          User stored hash: ${user.password}
          Env password hash: ${envPasswordHash}
        `)
      }

      return NextResponse.json({ error: "Invalid username or password" }, { status: 401 })
    }

    // Create session
    const sessionId = await createSession(user.id)

    // Set session cookie
    cookies().set("session_id", sessionId, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 7, // 7 days
      path: "/",
    })

    logger.info(`User logged in successfully: ${username}`)
    return NextResponse.json({ success: true })
  } catch (error) {
    logger.error("Login error:", error)
    return NextResponse.json({ error: "An unexpected error occurred" }, { status: 500 })
  }
}

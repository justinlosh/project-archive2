import { NextResponse } from "next/server"
import { getAuthUser } from "@/lib/auth/auth-utils"

export async function GET() {
  try {
    const user = await getAuthUser()

    if (!user) {
      return NextResponse.json({ authenticated: false }, { status: 401 })
    }

    // Return user info without sensitive data
    return NextResponse.json({
      authenticated: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
      },
    })
  } catch (error) {
    console.error("Auth status error:", error)
    return NextResponse.json({ error: "Failed to check authentication status" }, { status: 500 })
  }
}

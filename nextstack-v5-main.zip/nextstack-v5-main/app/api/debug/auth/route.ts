import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"
import { cookies } from "next/headers"
import { getAuthUser } from "@/lib/auth/auth-utils"

const USERS_FILE = path.join(process.cwd(), "content", "users.json")
const SESSIONS_FILE = path.join(process.cwd(), "content", "sessions.json")

export async function GET() {
  try {
    // Get current user
    const user = await getAuthUser()

    // Get session cookie
    const cookieStore = cookies()
    const sessionId = cookieStore.get("session_id")?.value

    // Read users file
    let users = []
    try {
      const usersData = await fs.readFile(USERS_FILE, "utf-8")
      users = JSON.parse(usersData)
    } catch (error) {
      console.error("Error reading users file:", error)
    }

    // Read sessions file
    let sessions = []
    try {
      const sessionsData = await fs.readFile(SESSIONS_FILE, "utf-8")
      sessions = JSON.parse(sessionsData)
    } catch (error) {
      console.error("Error reading sessions file:", error)
    }

    // Get environment variables (without exposing sensitive values)
    const envVars = {
      ADMIN_USERNAME: process.env.ADMIN_USERNAME ? "[SET]" : "[NOT SET]",
      ADMIN_EMAIL: process.env.ADMIN_EMAIL ? "[SET]" : "[NOT SET]",
      ADMIN_PASSWORD: process.env.ADMIN_PASSWORD ? "[SET]" : "[NOT SET]",
      CONTENT_DIRECTORY: process.env.CONTENT_DIRECTORY || "content",
    }

    // Return debug info
    return NextResponse.json({
      authenticated: !!user,
      user: user
        ? {
            id: user.id,
            username: user.username,
            email: user.email,
            role: user.role,
          }
        : null,
      sessionId,
      userCount: users.length,
      sessionCount: sessions.length,
      filesExist: {
        usersFile: await fileExists(USERS_FILE),
        sessionsFile: await fileExists(SESSIONS_FILE),
      },
      contentDir: await listContentDir(),
      environmentVariables: envVars,
    })
  } catch (error) {
    console.error("Debug auth error:", error)
    return NextResponse.json({ error: "Failed to get debug info" }, { status: 500 })
  }
}

async function fileExists(filePath: string): Promise<boolean> {
  try {
    await fs.access(filePath)
    return true
  } catch {
    return false
  }
}

async function listContentDir(): Promise<string[]> {
  try {
    const contentDir = path.join(process.cwd(), "content")
    const files = await fs.readdir(contentDir)
    return files
  } catch {
    return []
  }
}

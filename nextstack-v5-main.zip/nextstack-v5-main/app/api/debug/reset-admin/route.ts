import { NextResponse } from "next/server"
import fs from "fs/promises"
import path from "path"
import crypto from "crypto"
import { logger } from "@/lib/utils/logger"

const USERS_FILE = path.join(process.cwd(), "content", "users.json")
const LOCK_FILE = path.join(process.cwd(), "content", "users.lock")

// Get admin credentials from environment variables or use defaults
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin"
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@example.com"
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123"

function hashPassword(password: string): string {
  return crypto.createHash("sha256").update(password).digest("hex")
}

// File locking mechanism
async function acquireLock(timeout = 5000): Promise<boolean> {
  const startTime = Date.now()

  while (Date.now() - startTime < timeout) {
    try {
      await fs.writeFile(LOCK_FILE, Date.now().toString(), { flag: "wx" })
      return true
    } catch (error) {
      // Check if lock is stale (older than 30 seconds)
      try {
        const stats = await fs.stat(LOCK_FILE)
        if (Date.now() - stats.mtimeMs > 30000) {
          // Lock is stale, remove it
          await fs.unlink(LOCK_FILE)
          continue
        }
      } catch (statError) {
        // Lock file doesn't exist or was just removed
      }

      // Wait a bit before retrying
      await new Promise((resolve) => setTimeout(resolve, 100))
    }
  }

  return false
}

async function releaseLock(): Promise<boolean> {
  try {
    await fs.unlink(LOCK_FILE)
    return true
  } catch (error) {
    logger.error("Error releasing lock:", error)
    return false
  }
}

export async function POST() {
  let lockAcquired = false

  try {
    // Ensure directory exists
    await fs.mkdir(path.dirname(USERS_FILE), { recursive: true })

    // Acquire lock
    lockAcquired = await acquireLock()
    if (!lockAcquired) {
      return NextResponse.json({ error: "Could not acquire lock, another operation is in progress" }, { status: 503 })
    }

    // Create or update admin user
    const adminUser = {
      id: crypto.randomUUID(),
      username: ADMIN_USERNAME,
      email: ADMIN_EMAIL,
      password: hashPassword(ADMIN_PASSWORD),
      role: "admin",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // Read existing users
    let users = []
    try {
      const data = await fs.readFile(USERS_FILE, "utf-8")
      users = JSON.parse(data)

      // Remove any existing admin user with the same username
      users = users.filter(
        (user) => !(user.role === "admin" && user.username.toLowerCase() === ADMIN_USERNAME.toLowerCase()),
      )
    } catch (error) {
      logger.info("Creating new users file")
    }

    // Add admin user
    users.push(adminUser)

    // Write users file
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2))

    return NextResponse.json({
      success: true,
      message: `Admin user '${ADMIN_USERNAME}' reset successfully`,
      username: ADMIN_USERNAME,
    })
  } catch (error) {
    logger.error("Reset admin error:", error)
    return NextResponse.json({ error: "Failed to reset admin user" }, { status: 500 })
  } finally {
    if (lockAcquired) {
      await releaseLock()
    }
  }
}

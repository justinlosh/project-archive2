"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Save, Palette, Type, Layout } from "lucide-react"

interface ThemeColors {
  primary: string
  secondary: string
  accent: string
  background: string
  foreground: string
  muted: string
  card: string
}

export default function ThemeCustomizer() {
  const [colors, setColors] = useState<ThemeColors>({
    primary: "#3b82f6",
    secondary: "#10b981",
    accent: "#f59e0b",
    background: "#ffffff",
    foreground: "#020617",
    muted: "#f1f5f9",
    card: "#ffffff",
  })
  const [fonts, setFonts] = useState({
    heading: "Inter, sans-serif",
    body: "Inter, sans-serif",
  })
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [successMessage, setSuccessMessage] = useState<string | null>(null)

  function handleColorChange(key: keyof ThemeColors, value: string) {
    setColors((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  function handleFontChange(key: "heading" | "body", value: string) {
    setFonts((prev) => ({
      ...prev,
      [key]: value,
    }))
  }

  async function handleSave() {
    setIsSaving(true)
    setError(null)
    setSuccessMessage(null)

    try {
      // In a real implementation, you would save the theme settings to a file or database
      // For now, we'll simulate a delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Generate CSS variables
      const cssVariables = `
:root {
  --primary: ${colors.primary};
  --secondary: ${colors.secondary};
  --accent: ${colors.accent};
  --background: ${colors.background};
  --foreground: ${colors.foreground};
  --muted: ${colors.muted};
  --card: ${colors.card};
  
  --font-heading: ${fonts.heading};
  --font-body: ${fonts.body};
}
      `.trim()

      console.log("Generated CSS variables:", cssVariables)

      setSuccessMessage("Theme settings saved successfully")
    } catch (err) {
      setError("Failed to save theme settings")
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Palette className="mr-2 h-5 w-5" />
          Theme Customization
        </CardTitle>
        <CardDescription>Customize the appearance of your website</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {successMessage && (
          <Alert className="mb-4 border-green-200 bg-green-50 text-green-700">
            <AlertDescription>{successMessage}</AlertDescription>
          </Alert>
        )}

        <Tabs defaultValue="colors">
          <TabsList className="mb-4">
            <TabsTrigger value="colors">
              <Palette className="mr-2 h-4 w-4" />
              Colors
            </TabsTrigger>
            <TabsTrigger value="typography">
              <Type className="mr-2 h-4 w-4" />
              Typography
            </TabsTrigger>
            <TabsTrigger value="layout">
              <Layout className="mr-2 h-4 w-4" />
              Layout
            </TabsTrigger>
          </TabsList>

          <TabsContent value="colors" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="primary-color">Primary Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="primary-color"
                    type="color"
                    value={colors.primary}
                    onChange={(e) => handleColorChange("primary", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.primary}
                    onChange={(e) => handleColorChange("primary", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="secondary-color">Secondary Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="secondary-color"
                    type="color"
                    value={colors.secondary}
                    onChange={(e) => handleColorChange("secondary", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.secondary}
                    onChange={(e) => handleColorChange("secondary", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accent-color">Accent Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="accent-color"
                    type="color"
                    value={colors.accent}
                    onChange={(e) => handleColorChange("accent", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.accent}
                    onChange={(e) => handleColorChange("accent", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="background-color">Background Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="background-color"
                    type="color"
                    value={colors.background}
                    onChange={(e) => handleColorChange("background", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.background}
                    onChange={(e) => handleColorChange("background", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="foreground-color">Foreground Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="foreground-color"
                    type="color"
                    value={colors.foreground}
                    onChange={(e) => handleColorChange("foreground", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.foreground}
                    onChange={(e) => handleColorChange("foreground", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="muted-color">Muted Color</Label>
                <div className="flex items-center gap-2">
                  <Input
                    id="muted-color"
                    type="color"
                    value={colors.muted}
                    onChange={(e) => handleColorChange("muted", e.target.value)}
                    className="h-10 w-16"
                  />
                  <Input
                    value={colors.muted}
                    onChange={(e) => handleColorChange("muted", e.target.value)}
                    className="flex-1"
                  />
                </div>
              </div>
            </div>

            <div className="mt-4 rounded-md border p-4">
              <h3 className="mb-2 font-medium">Preview</h3>
              <div className="grid gap-2">
                <div className="h-8 rounded-md" style={{ backgroundColor: colors.primary }}></div>
                <div className="h-8 rounded-md" style={{ backgroundColor: colors.secondary }}></div>
                <div className="h-8 rounded-md" style={{ backgroundColor: colors.accent }}></div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="typography" className="space-y-4">
            <div className="grid gap-4">
              <div className="space-y-2">
                <Label htmlFor="heading-font">Heading Font</Label>
                <Input
                  id="heading-font"
                  value={fonts.heading}
                  onChange={(e) => handleFontChange("heading", e.target.value)}
                  placeholder="Enter font family for headings"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="body-font">Body Font</Label>
                <Input
                  id="body-font"
                  value={fonts.body}
                  onChange={(e) => handleFontChange("body", e.target.value)}
                  placeholder="Enter font family for body text"
                />
              </div>
            </div>

            <div className="mt-4 rounded-md border p-4">
              <h3 className="mb-2 font-medium">Preview</h3>
              <div className="space-y-2">
                <h1 style={{ fontFamily: fonts.heading }} className="text-2xl font-bold">
                  Heading Text
                </h1>
                <p style={{ fontFamily: fonts.body }} className="text-base">
                  This is an example of body text. It should be easy to read and have good contrast.
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="layout" className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="container-width">Container Width</Label>
                <Input id="container-width" defaultValue="1200px" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="border-radius">Border Radius</Label>
                <Input id="border-radius" defaultValue="0.5rem" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="spacing-unit">Spacing Unit</Label>
                <Input id="spacing-unit" defaultValue="4px" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="content-padding">Content Padding</Label>
                <Input id="content-padding" defaultValue="2rem" />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="mt-6 flex justify-end">
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 h-4 w-4" />
            {isSaving ? "Saving..." : "Save Theme Settings"}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import { useRouter, usePathname } from "next/navigation"

interface AuthContextType {
  isAuthenticated: boolean
  isLoading: boolean
  checkAuth: () => Promise<boolean>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)
  const router = useRouter()
  const pathname = usePathname()

  const checkAuth = async (): Promise<boolean> => {
    try {
      // Check if session cookie exists
      const hasCookie = document.cookie.includes("session_id=")
      setIsAuthenticated(hasCookie)
      return hasCookie
    } catch (error) {
      console.error("Auth check error:", error)
      setIsAuthenticated(false)
      return false
    } finally {
      setIsLoading(false)
    }
  }

  const logout = async (): Promise<void> => {
    try {
      await fetch("/api/auth/logout", { method: "POST" })
      setIsAuthenticated(false)
      router.push("/admin/login")
    } catch (error) {
      console.error("Logout error:", error)
    }
  }

  useEffect(() => {
    // Skip auth check on login and unauthorized pages
    if (pathname === "/admin/login" || pathname === "/admin/unauthorized") {
      setIsLoading(false)
      return
    }

    checkAuth()
  }, [pathname])

  return (
    <AuthContext.Provider value={{ isAuthenticated, isLoading, checkAuth, logout }}>{children}</AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}

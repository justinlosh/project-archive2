"use server"

import { createUser, getUserById, deleteUser, updateUser } from "@/lib/auth/auth-utils"
import { revalidatePath } from "next/cache"
import { redirect } from "next/navigation"
import { logger } from "@/lib/utils/logger"

export async function createUserAction(formData: FormData) {
  try {
    const username = formData.get("username") as string
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const role = formData.get("role") as string

    if (!username || !email || !password || !role) {
      return { error: "All fields are required" }
    }

    const newUser = await createUser({
      username,
      email,
      password,
      role,
    })

    revalidatePath("/admin/users")
    return { success: true, user: newUser }
  } catch (error: any) {
    logger.error("Error creating user:", error)
    return { error: error.message }
  }
}

export async function getUserByIdAction(id: string) {
  try {
    const user = await getUserById(id)

    if (!user) {
      return { error: "User not found" }
    }

    return { success: true, user }
  } catch (error: any) {
    logger.error("Error getting user by ID:", error)
    return { error: error.message }
  }
}

export async function updateUserAction(formData: FormData) {
  try {
    const id = formData.get("id") as string
    const username = formData.get("username") as string
    const email = formData.get("email") as string
    const password = formData.get("password") as string
    const role = formData.get("role") as string

    if (!id || !username || !email || !role) {
      return { error: "All fields are required" }
    }

    const updateData: any = {
      username,
      email,
      role,
    }

    if (password) {
      updateData.password = password
    }

    const updatedUser = await updateUser(id, updateData)

    revalidatePath("/admin/users")
    return { success: true, user: updatedUser }
  } catch (error: any) {
    logger.error("Error updating user:", error)
    return { error: error.message }
  }
}

export async function deleteUserAction(formData: FormData) {
  try {
    const id = formData.get("id") as string

    if (!id) {
      return { error: "User ID is required" }
    }

    await deleteUser(id)

    revalidatePath("/admin/users")
    redirect("/admin/users")
    return { success: true }
  } catch (error: any) {
    logger.error("Error deleting user:", error)
    return { error: error.message }
  }
}

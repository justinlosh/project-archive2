import { requireAuth } from "@/lib/auth/auth-utils"
import ContentList from "../components/content-list"

export default async function PagesListPage() {
  // Ensure user is authenticated
  await requireAuth()

  return (
    <ContentList
      contentType="page"
      title="Pages"
      description="Manage website pages"
      columns={[
        {
          key: "title",
          label: "Title",
        },
        {
          key: "slug",
          label: "Slug",
        },
        {
          key: "updatedAt",
          label: "Last Updated",
          render: (value) => new Date(value).toLocaleDateString(),
        },
      ]}
    />
  )
}

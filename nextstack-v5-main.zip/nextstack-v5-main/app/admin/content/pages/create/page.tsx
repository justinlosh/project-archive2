import { requireRole } from "@/lib/auth/auth-utils"
import ContentForm from "../../components/content-form"

export default async function CreatePagePage() {
  // Ensure user has at least editor role
  await requireRole("editor")

  return (
    <ContentForm
      contentType="page"
      title="Page"
      description="Create a new website page"
      fields={[
        {
          name: "title",
          label: "Title",
          type: "text",
          required: true,
          placeholder: "Enter page title",
        },
        {
          name: "slug",
          label: "Slug",
          type: "text",
          required: true,
          placeholder: "Enter page slug (e.g., about-us)",
        },
        {
          name: "content",
          label: "Content",
          type: "textarea",
          required: true,
          placeholder: "Enter page content",
        },
        {
          name: "metaTitle",
          label: "Meta Title",
          type: "text",
          placeholder: "Enter meta title for SEO",
        },
        {
          name: "metaDescription",
          label: "Meta Description",
          type: "textarea",
          placeholder: "Enter meta description for SEO",
        },
      ]}
    />
  )
}

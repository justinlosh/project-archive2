import type React from "react"
import { redirect } from "next/navigation"
import { getAuthUser } from "@/lib/auth/auth-utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { FileText, MessageSquare, ClipboardList, FileQuestion, ImageIcon, FolderKanban, Clock } from "lucide-react"

interface ContentTypeCard {
  title: string
  description: string
  icon: React.ReactNode
  href: string
  color: string
}

export default async function ContentPage() {
  // Check if user is authenticated
  const user = await getAuthUser()

  // If not authenticated, redirect to login
  if (!user) {
    redirect("/admin/login")
  }

  const contentTypes: ContentTypeCard[] = [
    {
      title: "Pages",
      description: "Manage website pages",
      icon: <FileText className="h-8 w-8" />,
      href: "/admin/content/pages",
      color: "bg-blue-100 text-blue-600",
    },
    {
      title: "Notes",
      description: "Manage notes and articles",
      icon: <MessageSquare className="h-8 w-8" />,
      href: "/admin/content/notes",
      color: "bg-green-100 text-green-600",
    },
    {
      title: "Forms",
      description: "Manage forms",
      icon: <ClipboardList className="h-8 w-8" />,
      href: "/admin/content/forms",
      color: "bg-yellow-100 text-yellow-600",
    },
    {
      title: "Submissions",
      description: "View form submissions",
      icon: <FileQuestion className="h-8 w-8" />,
      href: "/admin/content/submissions",
      color: "bg-purple-100 text-purple-600",
    },
    {
      title: "Media",
      description: "Manage media files",
      icon: <ImageIcon className="h-8 w-8" />,
      href: "/admin/content/media",
      color: "bg-pink-100 text-pink-600",
    },
    {
      title: "Collections",
      description: "Manage content collections",
      icon: <FolderKanban className="h-8 w-8" />,
      href: "/admin/content/collections",
      color: "bg-orange-100 text-orange-600",
    },
    {
      title: "Timelines",
      description: "Manage timelines",
      icon: <Clock className="h-8 w-8" />,
      href: "/admin/content/timelines",
      color: "bg-indigo-100 text-indigo-600",
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Content Management</h1>
        <p className="text-gray-500">Manage all content types in your CMS</p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {contentTypes.map((type) => (
          <Link key={type.title} href={type.href}>
            <Card className="h-full transition-all hover:shadow-md">
              <CardHeader>
                <div className={`mb-2 inline-flex rounded-lg p-3 ${type.color}`}>{type.icon}</div>
                <CardTitle>{type.title}</CardTitle>
                <CardDescription>{type.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-blue-600">Manage {type.title.toLowerCase()} →</p>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

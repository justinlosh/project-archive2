"use client"

import { requireRole } from "@/lib/auth/auth-utils"
import ContentForm from "../../../components/content-form"
import TimelineEditor from "../../../components/timeline-editor"

export default async function EditTimelinePage({ params }: { params: { id: string } }) {
  // Ensure user has at least editor role
  await requireRole("editor")

  return (
    <ContentForm
      contentType="timeline"
      title="Timeline"
      description="Edit timeline"
      fields={[
        {
          name: "title",
          label: "Title",
          type: "text",
          required: true,
          placeholder: "Enter timeline title",
        },
        {
          name: "description",
          label: "Description",
          type: "textarea",
          placeholder: "Enter timeline description",
        },
        {
          name: "events",
          label: "Timeline Events",
          type: "custom",
          defaultValue: [],
          render: (value, onChange) => <TimelineEditor events={value} onChange={onChange} />,
        },
      ]}
      id={params.id}
    />
  )
}

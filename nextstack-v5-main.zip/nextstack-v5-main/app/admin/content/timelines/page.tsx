import { requireAuth } from "@/lib/auth/auth-utils"
import ContentList from "../components/content-list"

export default async function TimelinesListPage() {
  // Ensure user is authenticated
  await requireAuth()

  return (
    <ContentList
      contentType="timeline"
      title="Timelines"
      description="Manage timeline content"
      columns={[
        {
          key: "title",
          label: "Title",
        },
        {
          key: "events",
          label: "Events",
          render: (value) => value?.length || 0,
        },
        {
          key: "updatedAt",
          label: "Last Updated",
          render: (value) => new Date(value).toLocaleDateString(),
        },
      ]}
    />
  )
}

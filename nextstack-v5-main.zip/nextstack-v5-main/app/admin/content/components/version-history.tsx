"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getVersionsAction, restoreVersionAction } from "../version-actions"
import type { ContentType } from "@/lib/data/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, History, RotateCcw } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface VersionHistoryProps {
  contentType: ContentType
  contentId: string
}

export default function VersionHistory({ contentType, contentId }: VersionHistoryProps) {
  const [versions, setVersions] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isRestoring, setIsRestoring] = useState(false)
  const [selectedVersion, setSelectedVersion] = useState<any>(null)
  const router = useRouter()

  useEffect(() => {
    loadVersions()
  }, [contentType, contentId])

  async function loadVersions() {
    setIsLoading(true)
    setError(null)

    try {
      const result = await getVersionsAction(contentType, contentId)

      if (result.error) {
        setError(result.error)
      } else {
        setVersions(result.versions || [])
      }
    } catch (err) {
      setError("Failed to load version history")
    } finally {
      setIsLoading(false)
    }
  }

  async function handleRestore(versionId: string) {
    setIsRestoring(true)
    setError(null)

    try {
      const result = await restoreVersionAction(contentType, contentId, versionId)

      if (result.error) {
        setError(result.error)
      } else {
        // Refresh the page to show the restored content
        router.refresh()
      }
    } catch (err) {
      setError("Failed to restore version")
    } finally {
      setIsRestoring(false)
      setSelectedVersion(null)
    }
  }

  if (isLoading) {
    return (
      <div className="flex h-40 items-center justify-center">
        <p>Loading version history...</p>
      </div>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <History className="mr-2 h-5 w-5" />
          Version History
        </CardTitle>
        <CardDescription>Previous versions of this content</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {versions.length === 0 ? (
          <div className="flex h-20 items-center justify-center rounded-md border border-dashed">
            <p className="text-sm text-gray-500">No version history available</p>
          </div>
        ) : (
          <div className="space-y-4">
            {versions.map((version) => (
              <div key={version._versionId} className="flex items-center justify-between rounded-md border p-4">
                <div>
                  <p className="font-medium">Version from {new Date(version._versionCreatedAt).toLocaleString()}</p>
                  <p className="text-sm text-gray-500">
                    {version.title || "Untitled"} - ID: {version._versionId}
                  </p>
                </div>
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm" onClick={() => setSelectedVersion(version)}>
                      <RotateCcw className="mr-2 h-4 w-4" />
                      Restore
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Restore Version</DialogTitle>
                      <DialogDescription>
                        Are you sure you want to restore this version? This will overwrite the current content.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="py-4">
                      <p className="font-medium">Version from {new Date(version._versionCreatedAt).toLocaleString()}</p>
                      <p className="text-sm text-gray-500">{version.title || "Untitled"}</p>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setSelectedVersion(null)}>
                        Cancel
                      </Button>
                      <Button onClick={() => handleRestore(version._versionId)} disabled={isRestoring}>
                        {isRestoring ? "Restoring..." : "Restore Version"}
                      </Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}

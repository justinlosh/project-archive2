"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getContentByIdAction, createContentAction, updateContentAction } from "../actions"
import type { ContentType } from "@/lib/data/types"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"
import VersionHistory from "./version-history"

interface Field {
  name: string
  label: string
  type: "text" | "textarea" | "number" | "date" | "custom"
  required?: boolean
  placeholder?: string
  defaultValue?: any
  render?: (value: any, onChange: (value: any) => void) => React.ReactNode
}

interface ContentFormProps {
  contentType: ContentType
  title: string
  description: string
  fields: Field[]
  id?: string // If provided, we're editing an existing item
}

export default function ContentForm({ contentType, title, description, fields, id }: ContentFormProps) {
  const [formData, setFormData] = useState<Record<string, any>>({})
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingContent, setIsLoadingContent] = useState(!!id)
  const [error, setError] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    if (id) {
      loadContent()
    }
  }, [id])

  async function loadContent() {
    setIsLoadingContent(true)
    setError(null)

    try {
      const result = await getContentByIdAction(contentType, id!)

      if (result.error) {
        setError(result.error)
      } else if (result.content) {
        setFormData(result.content)
      } else {
        setError("Content not found")
      }
    } catch (err) {
      setError("Failed to load content")
    } finally {
      setIsLoadingContent(false)
    }
  }

  function handleChange(name: string, value: any) {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)
    setError(null)

    try {
      let result

      if (id) {
        // Update existing content
        result = await updateContentAction(contentType, id, formData)
      } else {
        // Create new content
        result = await createContentAction(contentType, formData)
      }

      if (result.error) {
        setError(result.error)
      } else {
        router.push(`/admin/content/${contentType}`)
      }
    } catch (err) {
      setError("An unexpected error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoadingContent) {
    return (
      <div className="flex h-full items-center justify-center">
        <p>Loading content...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">{id ? `Edit ${title}` : `Create ${title}`}</h1>
        <p className="text-gray-500">{description}</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>{id ? "Edit Content" : "New Content"}</CardTitle>
              <CardDescription>{id ? "Update the content details" : "Enter the content details"}</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-4">
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {fields.map((field) => (
                  <div key={field.name} className="space-y-2">
                    <Label htmlFor={field.name}>{field.label}</Label>

                    {field.type === "text" && (
                      <Input
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ""}
                        onChange={(e) => handleChange(field.name, e.target.value)}
                        placeholder={field.placeholder}
                        required={field.required}
                      />
                    )}

                    {field.type === "textarea" && (
                      <Textarea
                        id={field.name}
                        name={field.name}
                        value={formData[field.name] || ""}
                        onChange={(e) => handleChange(field.name, e.target.value)}
                        placeholder={field.placeholder}
                        required={field.required}
                        rows={5}
                      />
                    )}

                    {field.type === "number" && (
                      <Input
                        id={field.name}
                        name={field.name}
                        type="number"
                        value={formData[field.name] || ""}
                        onChange={(e) => handleChange(field.name, Number.parseFloat(e.target.value))}
                        placeholder={field.placeholder}
                        required={field.required}
                      />
                    )}

                    {field.type === "date" && (
                      <Input
                        id={field.name}
                        name={field.name}
                        type="date"
                        value={formData[field.name] ? new Date(formData[field.name]).toISOString().split("T")[0] : ""}
                        onChange={(e) => handleChange(field.name, e.target.value)}
                        required={field.required}
                      />
                    )}

                    {field.type === "custom" &&
                      field.render &&
                      field.render(formData[field.name] || field.defaultValue, (value) =>
                        handleChange(field.name, value),
                      )}
                  </div>
                ))}
              </CardContent>
              <CardFooter className="border-t bg-gray-50 px-6 py-3 space-x-4">
                <Button type="submit" disabled={isLoading}>
                  {isLoading ? (id ? "Updating..." : "Creating...") : id ? "Update" : "Create"}
                </Button>
                <Button type="button" variant="outline" onClick={() => router.push(`/admin/content/${contentType}`)}>
                  Cancel
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>

        {id && (
          <div>
            <VersionHistory contentType={contentType} contentId={id} />
          </div>
        )}
      </div>
    </div>
  )
}

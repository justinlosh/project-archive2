"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Upload, X, ImageIcon } from "lucide-react"
import Image from "next/image"

interface MediaUploaderProps {
  value: string
  onChange: (url: string) => void
  onMetadataChange?: (metadata: { alt: string; caption: string }) => void
  metadata?: {
    alt: string
    caption: string
  }
}

export default function MediaUploader({
  value,
  onChange,
  onMetadataChange,
  metadata = { alt: "", caption: "" },
}: MediaUploaderProps) {
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [preview, setPreview] = useState<string | null>(value || null)
  const [alt, setAlt] = useState(metadata.alt || "")
  const [caption, setCaption] = useState(metadata.caption || "")
  const fileInputRef = useRef<HTMLInputElement>(null)

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setError("Only image files are allowed")
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError("File size must be less than 5MB")
      return
    }

    setIsUploading(true)
    setError(null)

    try {
      // Create a local preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)

      // In a real implementation, you would upload the file to a server or storage service
      // For now, we'll simulate an upload delay and use the local preview URL
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // In a real implementation, the server would return the URL of the uploaded file
      // For now, we'll use the file name as a placeholder
      const uploadedUrl = `/uploads/${file.name}`
      onChange(uploadedUrl)

      // Set default alt text if not provided
      if (!alt) {
        const defaultAlt = file.name.split(".")[0].replace(/[-_]/g, " ")
        setAlt(defaultAlt)
        if (onMetadataChange) {
          onMetadataChange({ alt: defaultAlt, caption })
        }
      }
    } catch (err) {
      setError("Failed to upload file")
      console.error(err)
    } finally {
      setIsUploading(false)
    }
  }

  function handleRemove() {
    setPreview(null)
    onChange("")
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  function handleAltChange(e: React.ChangeEvent<HTMLInputElement>) {
    const newAlt = e.target.value
    setAlt(newAlt)
    if (onMetadataChange) {
      onMetadataChange({ alt: newAlt, caption })
    }
  }

  function handleCaptionChange(e: React.ChangeEvent<HTMLInputElement>) {
    const newCaption = e.target.value
    setCaption(newCaption)
    if (onMetadataChange) {
      onMetadataChange({ alt, caption: newCaption })
    }
  }

  return (
    <div className="space-y-4">
      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {preview ? (
        <Card>
          <CardContent className="p-4">
            <div className="relative">
              <div className="relative aspect-video w-full overflow-hidden rounded-md">
                <Image
                  src={preview || "/placeholder.svg"}
                  alt={alt || "Preview"}
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
              <Button variant="destructive" size="icon" className="absolute right-2 top-2" onClick={handleRemove}>
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="mt-4 space-y-2">
              <div className="grid gap-2">
                <Label htmlFor="alt-text">Alt Text</Label>
                <Input
                  id="alt-text"
                  value={alt}
                  onChange={handleAltChange}
                  placeholder="Describe the image for accessibility"
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="caption">Caption</Label>
                <Input
                  id="caption"
                  value={caption}
                  onChange={handleCaptionChange}
                  placeholder="Add a caption (optional)"
                />
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-md border border-dashed p-8">
          <div className="mb-4 rounded-full bg-gray-100 p-3">
            <ImageIcon className="h-6 w-6 text-gray-400" />
          </div>
          <p className="mb-2 text-sm text-gray-500">Drag and drop an image, or click to browse</p>
          <p className="mb-4 text-xs text-gray-400">PNG, JPG, GIF up to 5MB</p>
          <Button disabled={isUploading} onClick={() => fileInputRef.current?.click()}>
            <Upload className="mr-2 h-4 w-4" />
            {isUploading ? "Uploading..." : "Upload Image"}
          </Button>
          <Input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileChange}
            disabled={isUploading}
          />
        </div>
      )}

      {value && !preview && (
        <div className="mt-2 text-sm text-gray-500">
          Current image: <span className="font-medium">{value}</span>
        </div>
      )}
    </div>
  )
}

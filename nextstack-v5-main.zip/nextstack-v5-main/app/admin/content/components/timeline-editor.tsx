"use client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import type { TimelineEvent } from "@/lib/data/types"
import { Plus, Trash2, MoveUp, MoveDown } from "lucide-react"

interface TimelineEditorProps {
  events: TimelineEvent[]
  onChange: (events: TimelineEvent[]) => void
}

export default function TimelineEditor({ events = [], onChange }: TimelineEditorProps) {
  function addEvent() {
    const newEvent: TimelineEvent = {
      title: "",
      date: "",
      description: "",
      media: {
        url: "",
        alt: "",
      },
    }

    onChange([...events, newEvent])
  }

  function updateEvent(index: number, field: keyof TimelineEvent, value: any) {
    const updatedEvents = [...events]

    if (field === "media") {
      updatedEvents[index].media = {
        ...updatedEvents[index].media,
        ...value,
      }
    } else {
      updatedEvents[index][field] = value
    }

    onChange(updatedEvents)
  }

  function removeEvent(index: number) {
    const updatedEvents = [...events]
    updatedEvents.splice(index, 1)
    onChange(updatedEvents)
  }

  function moveEvent(index: number, direction: "up" | "down") {
    if ((direction === "up" && index === 0) || (direction === "down" && index === events.length - 1)) {
      return
    }

    const updatedEvents = [...events]
    const newIndex = direction === "up" ? index - 1 : index + 1

    // Swap events
    const temp = updatedEvents[index]
    updatedEvents[index] = updatedEvents[newIndex]
    updatedEvents[newIndex] = temp

    onChange(updatedEvents)
  }

  return (
    <div className="space-y-4">
      {events.length === 0 ? (
        <div className="flex h-40 flex-col items-center justify-center space-y-4 rounded-md border border-dashed p-4">
          <p className="text-center text-gray-500">No timeline events yet</p>
          <Button onClick={addEvent}>
            <Plus className="mr-2 h-4 w-4" /> Add First Event
          </Button>
        </div>
      ) : (
        <>
          {events.map((event, index) => (
            <Card key={index} className="relative">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Event {index + 1}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor={`event-${index}-title`}>Title</Label>
                  <Input
                    id={`event-${index}-title`}
                    value={event.title}
                    onChange={(e) => updateEvent(index, "title", e.target.value)}
                    placeholder="Event title"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor={`event-${index}-date`}>Date</Label>
                  <Input
                    id={`event-${index}-date`}
                    value={event.date}
                    onChange={(e) => updateEvent(index, "date", e.target.value)}
                    placeholder="Event date (e.g., Jan 2023, 2023-01-15)"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor={`event-${index}-description`}>Description</Label>
                  <Textarea
                    id={`event-${index}-description`}
                    value={event.description || ""}
                    onChange={(e) => updateEvent(index, "description", e.target.value)}
                    placeholder="Event description"
                    rows={3}
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor={`event-${index}-media-url`}>Media URL</Label>
                  <Input
                    id={`event-${index}-media-url`}
                    value={event.media?.url || ""}
                    onChange={(e) => updateEvent(index, "media", { url: e.target.value })}
                    placeholder="Image URL"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor={`event-${index}-media-alt`}>Media Alt Text</Label>
                  <Input
                    id={`event-${index}-media-alt`}
                    value={event.media?.alt || ""}
                    onChange={(e) => updateEvent(index, "media", { alt: e.target.value })}
                    placeholder="Image alt text"
                  />
                </div>
              </CardContent>
              <CardFooter className="border-t bg-gray-50 px-6 py-3 justify-between">
                <div className="flex space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => moveEvent(index, "up")}
                    disabled={index === 0}
                  >
                    <MoveUp className="h-4 w-4" />
                    <span className="sr-only">Move Up</span>
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => moveEvent(index, "down")}
                    disabled={index === events.length - 1}
                  >
                    <MoveDown className="h-4 w-4" />
                    <span className="sr-only">Move Down</span>
                  </Button>
                </div>
                <Button type="button" variant="destructive" size="sm" onClick={() => removeEvent(index)}>
                  <Trash2 className="mr-2 h-4 w-4" /> Remove
                </Button>
              </CardFooter>
            </Card>
          ))}

          <Button onClick={addEvent} className="w-full">
            <Plus className="mr-2 h-4 w-4" /> Add Event
          </Button>
        </>
      )}
    </div>
  )
}

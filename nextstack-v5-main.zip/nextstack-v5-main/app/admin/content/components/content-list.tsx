"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { getAllContentAction, deleteContentAction } from "../actions"
import type { ContentType } from "@/lib/data/types"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Plus, Pencil, Trash2 } from "lucide-react"

interface ContentListProps {
  contentType: ContentType
  title: string
  description: string
  columns: {
    key: string
    label: string
    render?: (value: any, item: any) => React.ReactNode
  }[]
}

export default function ContentList({ contentType, title, description, columns }: ContentListProps) {
  const [content, setContent] = useState<any[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [itemToDelete, setItemToDelete] = useState<string | null>(null)
  const router = useRouter()

  useEffect(() => {
    loadContent()
  }, [contentType])

  async function loadContent() {
    setIsLoading(true)
    setError(null)

    try {
      const result = await getAllContentAction(contentType)

      if (result.error) {
        setError(result.error)
      } else {
        setContent(result.content || [])
      }
    } catch (err) {
      setError("Failed to load content")
    } finally {
      setIsLoading(false)
    }
  }

  async function handleDelete(id: string) {
    setError(null)

    try {
      const result = await deleteContentAction(contentType, id)

      if (result.error) {
        setError(result.error)
      } else {
        // Refresh content list
        loadContent()
      }
    } catch (err) {
      setError("Failed to delete content")
    } finally {
      setItemToDelete(null)
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">{title}</h1>
          <p className="text-gray-500">{description}</p>
        </div>
        <Button asChild>
          <Link href={`/admin/content/${contentType}/create`}>
            <Plus className="mr-2 h-4 w-4" /> Add New
          </Link>
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle>All {title}</CardTitle>
          <CardDescription>Manage your {contentType} content</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex h-40 items-center justify-center">
              <p>Loading content...</p>
            </div>
          ) : content.length === 0 ? (
            <div className="flex h-40 flex-col items-center justify-center space-y-4">
              <p className="text-center text-gray-500">No {contentType} content found</p>
              <Button asChild>
                <Link href={`/admin/content/${contentType}/create`}>
                  <Plus className="mr-2 h-4 w-4" /> Create your first {contentType}
                </Link>
              </Button>
            </div>
          ) : (
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    {columns.map((column) => (
                      <TableHead key={column.key}>{column.label}</TableHead>
                    ))}
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {content.map((item) => (
                    <TableRow key={item.id}>
                      {columns.map((column) => (
                        <TableCell key={`${item.id}-${column.key}`}>
                          {column.render ? column.render(item[column.key], item) : item[column.key] || "-"}
                        </TableCell>
                      ))}
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => router.push(`/admin/content/${contentType}/edit/${item.id}`)}
                          >
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                          <AlertDialog
                            open={itemToDelete === item.id}
                            onOpenChange={(open) => !open && setItemToDelete(null)}
                          >
                            <AlertDialogTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-red-600 hover:bg-red-50 hover:text-red-700"
                                onClick={() => setItemToDelete(item.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                                <span className="sr-only">Delete</span>
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  This action cannot be undone. This will permanently delete this content.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>Cancel</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-red-600 hover:bg-red-700"
                                  onClick={() => handleDelete(item.id)}
                                >
                                  Delete
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

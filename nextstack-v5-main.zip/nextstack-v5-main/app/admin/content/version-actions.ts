"use server"

import { getVersions, getVersion, restoreVersion } from "@/lib/data/version-service"
import type { ContentType } from "@/lib/data/types"
import { requireRole } from "@/lib/auth/auth-utils"

// Get all versions of content
export async function getVersionsAction(type: ContentType, id: string) {
  // Ensure user has at least viewer role
  await requireRole("viewer")

  try {
    const versions = await getVersions(type, id)
    return { success: true, versions }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Get a specific version of content
export async function getVersionAction(type: ContentType, id: string, versionId: string) {
  // Ensure user has at least viewer role
  await requireRole("viewer")

  try {
    const version = await getVersion(type, id, versionId)
    return { success: true, version }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Restore a specific version of content
export async function restoreVersionAction(type: ContentType, id: string, versionId: string) {
  // Ensure user has at least editor role
  await requireRole("editor")

  try {
    const restoredContent = await restoreVersion(type, id, versionId)
    return { success: true, content: restoredContent }
  } catch (error: any) {
    return { error: error.message }
  }
}

import { requireAuth } from "@/lib/auth/auth-utils"
import ContentList from "../components/content-list"
import Image from "next/image"

export default async function MediaListPage() {
  // Ensure user is authenticated
  await requireAuth()

  return (
    <ContentList
      contentType="media"
      title="Media"
      description="Manage media files and images"
      columns={[
        {
          key: "title",
          label: "Title",
        },
        {
          key: "url",
          label: "Preview",
          render: (value) =>
            value ? (
              <div className="relative h-12 w-12 overflow-hidden rounded-md">
                <Image
                  src={value || "/placeholder.svg"}
                  alt="Media preview"
                  fill
                  className="object-cover"
                  unoptimized
                />
              </div>
            ) : (
              <span className="text-gray-400">No preview</span>
            ),
        },
        {
          key: "fileType",
          label: "Type",
        },
        {
          key: "fileSize",
          label: "Size",
          render: (value) => {
            if (!value) return "Unknown"
            // Convert bytes to KB or MB
            if (value < 1024) return `${value} B`
            if (value < 1024 * 1024) return `${(value / 1024).toFixed(1)} KB`
            return `${(value / (1024 * 1024)).toFixed(1)} MB`
          },
        },
        {
          key: "updatedAt",
          label: "Last Updated",
          render: (value) => new Date(value).toLocaleDateString(),
        },
      ]}
    />
  )
}

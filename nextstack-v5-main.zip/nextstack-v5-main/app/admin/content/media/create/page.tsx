"use client"

import { requireRole } from "@/lib/auth/auth-utils"
import ContentForm from "../../components/content-form"
import MediaUploader from "../../components/media-uploader"

export default async function CreateMediaPage() {
  // Ensure user has at least editor role
  await requireRole("editor")

  return (
    <ContentForm
      contentType="media"
      title="Media"
      description="Upload a new media file"
      fields={[
        {
          name: "title",
          label: "Title",
          type: "text",
          required: true,
          placeholder: "Enter media title",
        },
        {
          name: "description",
          label: "Description",
          type: "textarea",
          placeholder: "Enter media description",
        },
        {
          name: "url",
          label: "Media File",
          type: "custom",
          required: true,
          render: (value, onChange) => (
            <MediaUploader
              value={value || ""}
              onChange={onChange}
              onMetadataChange={(metadata) => {
                // This would update the form data with the metadata
                // In a real implementation, you would update the form state
              }}
            />
          ),
        },
        {
          name: "tags",
          label: "Tags (comma separated)",
          type: "text",
          placeholder: "Enter tags",
        },
      ]}
    />
  )
}

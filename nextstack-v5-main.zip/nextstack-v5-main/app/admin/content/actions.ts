"use server"

import { getAllContent, getContentById, createContent, updateContent, deleteContent } from "@/lib/data/content-service"
import type { ContentType } from "@/lib/data/types"
import { requireRole } from "@/lib/auth/auth-utils"

// Get all content of a specific type
export async function getAllContentAction(type: ContentType) {
  // Ensure user has at least viewer role
  await requireRole("viewer")

  try {
    const content = await getAllContent(type)
    return { success: true, content }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Get content by ID
export async function getContentByIdAction(type: ContentType, id: string) {
  // Ensure user has at least viewer role
  await requireRole("viewer")

  try {
    const content = await getContentById(type, id)
    return { success: true, content }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Create content
export async function createContentAction(type: ContentType, content: any) {
  // Ensure user has at least editor role
  await requireRole("editor")

  try {
    const newContent = await createContent(type, content)
    return { success: true, content: newContent }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Update content
export async function updateContentAction(type: ContentType, id: string, content: any) {
  // Ensure user has at least editor role
  await requireRole("editor")

  try {
    const updatedContent = await updateContent(type, id, content)
    return { success: true, content: updatedContent }
  } catch (error: any) {
    return { error: error.message }
  }
}

// Delete content
export async function deleteContentAction(type: ContentType, id: string) {
  // Ensure user has admin role
  await requireRole("admin")

  try {
    await deleteContent(type, id)
    return { success: true }
  } catch (error: any) {
    return { error: error.message }
  }
}

import type React from "react"
import { Card, CardContent } from "@/components/ui/card"
import { cn } from "@/lib/utils"
import { ArrowUpIcon, ArrowDownIcon } from "lucide-react"

interface DashboardMetricProps {
  title: string
  value: string | number
  change?: number
  icon?: React.ReactNode
}

export function DashboardMetric({ title, value, change = 0, icon }: DashboardMetricProps) {
  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-gray-500">{title}</p>
          {icon}
        </div>
        <div className="mt-2 flex items-baseline">
          <p className="text-2xl font-semibold">{value}</p>
          {change !== 0 && (
            <p className={cn("ml-2 text-xs", change > 0 ? "text-green-600" : "text-red-600")}>
              <span className="flex items-center">
                {change > 0 ? <ArrowUpIcon className="mr-0.5 h-3 w-3" /> : <ArrowDownIcon className="mr-0.5 h-3 w-3" />}
                {Math.abs(change)}%
              </span>
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

"use client"

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
} from "recharts"
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart"

interface Series {
  key: string
  name: string
  color: string
}

interface DashboardChartProps {
  data: any[]
  type?: "line" | "bar" | "pie"
  xKey?: string
  nameKey?: string
  valueKey?: string
  series?: Series[]
  height?: number
}

const COLORS = [
  "hsl(var(--chart-1))",
  "hsl(var(--chart-2))",
  "hsl(var(--chart-3))",
  "hsl(var(--chart-4))",
  "hsl(var(--chart-5))",
  "hsl(var(--chart-6))",
]

export function DashboardChart({
  data,
  type = "line",
  xKey = "name",
  nameKey = "name",
  valueKey = "value",
  series = [],
  height = 300,
}: DashboardChartProps) {
  if (!data || data.length === 0) {
    return (
      <div className="flex h-full items-center justify-center">
        <p className="text-sm text-gray-500">No data available</p>
      </div>
    )
  }

  // Create config for ChartContainer
  const config: Record<string, { label: string; color: string }> = {}

  if (series.length > 0) {
    series.forEach((s) => {
      config[s.key] = {
        label: s.name,
        color: s.color,
      }
    })
  } else if (type === "pie") {
    data.forEach((item, index) => {
      config[item[nameKey]] = {
        label: item[nameKey],
        color: COLORS[index % COLORS.length],
      }
    })
  } else {
    config[valueKey] = {
      label: valueKey.charAt(0).toUpperCase() + valueKey.slice(1),
      color: COLORS[0],
    }
  }

  return (
    <ChartContainer config={config} className="h-full">
      <ResponsiveContainer width="100%" height="100%">
        {type === "line" ? (
          <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={xKey} />
            <YAxis />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            {series.length > 0 ? (
              series.map((s) => (
                <Line key={s.key} type="monotone" dataKey={s.key} stroke={`var(--color-${s.key})`} name={s.name} />
              ))
            ) : (
              <Line type="monotone" dataKey={valueKey} stroke={`var(--color-${valueKey})`} name={valueKey} />
            )}
          </LineChart>
        ) : type === "bar" ? (
          <BarChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={xKey} />
            <YAxis />
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
            {series.length > 0 ? (
              series.map((s) => <Bar key={s.key} dataKey={s.key} fill={`var(--color-${s.key})`} name={s.name} />)
            ) : (
              <Bar dataKey={valueKey} fill={`var(--color-${valueKey})`} name={valueKey} />
            )}
          </BarChart>
        ) : (
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              labelLine={false}
              outerRadius={80}
              fill="#8884d8"
              dataKey={valueKey}
              nameKey={nameKey}
              label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            >
              {data.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <ChartTooltip content={<ChartTooltipContent />} />
            <Legend />
          </PieChart>
        )}
      </ResponsiveContainer>
    </ChartContainer>
  )
}

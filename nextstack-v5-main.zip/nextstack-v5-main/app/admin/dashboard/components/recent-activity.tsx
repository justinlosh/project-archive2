import { formatDistanceToNow } from "date-fns"
import { FileText, Edit, Plus, ImageIcon, Clock, MessageSquare, ClipboardList } from "lucide-react"

interface Activity {
  id: string
  title: string
  type: string
  action: "created" | "updated"
  timestamp: string
}

interface RecentActivityProps {
  activities: Activity[]
}

export function RecentActivity({ activities }: RecentActivityProps) {
  if (!activities || activities.length === 0) {
    return (
      <div className="flex h-40 items-center justify-center">
        <p className="text-sm text-gray-500">No recent activity</p>
      </div>
    )
  }

  // Get icon based on content type
  const getIcon = (type: string) => {
    switch (type) {
      case "page":
        return <FileText className="h-4 w-4 text-blue-500" />
      case "note":
        return <MessageSquare className="h-4 w-4 text-green-500" />
      case "form":
        return <ClipboardList className="h-4 w-4 text-yellow-500" />
      case "media":
        return <ImageIcon className="h-4 w-4 text-purple-500" />
      case "timeline":
        return <Clock className="h-4 w-4 text-indigo-500" />
      default:
        return <FileText className="h-4 w-4 text-gray-500" />
    }
  }

  // Get action icon
  const getActionIcon = (action: string) => {
    switch (action) {
      case "created":
        return <Plus className="h-3 w-3" />
      case "updated":
        return <Edit className="h-3 w-3" />
      default:
        return null
    }
  }

  return (
    <div className="space-y-4">
      {activities.map((activity) => (
        <div key={activity.id} className="flex items-start space-x-3">
          <div className="mt-0.5">{getIcon(activity.type)}</div>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <p className="text-sm font-medium">{activity.title}</p>
              <span className="flex items-center text-xs text-gray-500">
                {formatDistanceToNow(new Date(activity.timestamp), { addSuffix: true })}
              </span>
            </div>
            <p className="flex items-center text-xs text-gray-500">
              <span className="mr-1 flex items-center rounded-full bg-gray-100 px-1.5 py-0.5">
                {getActionIcon(activity.action)}
                <span className="ml-0.5 capitalize">{activity.action}</span>
              </span>
              <span className="capitalize">{activity.type}</span>
            </p>
          </div>
        </div>
      ))}
    </div>
  )
}

import { requireAuth } from "@/lib/auth/auth-utils"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, FileText, ImageIcon, Database } from "lucide-react"
import { getSystemStats } from "@/lib/utils/system-stats"
import { formatBytes, formatNumber, formatDate } from "@/lib/utils/formatters"
import { DashboardChart } from "./components/dashboard-chart"
import { DashboardMetric } from "./components/dashboard-metric"
import { RecentActivity } from "./components/recent-activity"

export default async function AdminDashboard() {
  // Ensure user is authenticated
  const user = await requireAuth()

  // Get system stats
  const stats = await getSystemStats()

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Dashboard</h1>
        <p className="text-gray-500">Welcome back, {user.username}! Here's an overview of your CMS.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <DashboardMetric
          title="Total Content"
          value={formatNumber(stats.contentCount)}
          change={stats.contentChange}
          icon={<FileText className="h-4 w-4 text-gray-500" />}
        />
        <DashboardMetric
          title="Media Files"
          value={formatNumber(stats.mediaCount)}
          change={stats.mediaChange}
          icon={<ImageIcon className="h-4 w-4 text-gray-500" />}
        />
        <DashboardMetric
          title="Storage Used"
          value={formatBytes(stats.storageUsed)}
          change={stats.storageChange}
          icon={<Database className="h-4 w-4 text-gray-500" />}
        />
        <DashboardMetric
          title="Users"
          value={formatNumber(stats.userCount)}
          change={0}
          icon={<Users className="h-4 w-4 text-gray-500" />}
        />
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="content">Content</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="col-span-2">
              <CardHeader>
                <CardTitle>Content Activity</CardTitle>
                <CardDescription>Content creation and updates over time</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <DashboardChart
                  data={stats.contentActivity}
                  xKey="date"
                  series={[
                    { key: "created", name: "Created", color: "hsl(var(--chart-1))" },
                    { key: "updated", name: "Updated", color: "hsl(var(--chart-2))" },
                  ]}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Content Distribution</CardTitle>
                <CardDescription>Content types breakdown</CardDescription>
              </CardHeader>
              <CardContent className="h-80">
                <DashboardChart data={stats.contentDistribution} type="pie" nameKey="type" valueKey="count" />
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Latest updates to your content</CardDescription>
              </CardHeader>
              <CardContent>
                <RecentActivity activities={stats.recentActivity} />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>System Information</CardTitle>
                <CardDescription>Information about your CMS</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">CMS Version</p>
                      <p className="text-sm text-gray-500">{stats.version}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Next.js Version</p>
                      <p className="text-sm text-gray-500">{stats.nextVersion}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Environment</p>
                      <p className="text-sm text-gray-500">{stats.environment}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Last Backup</p>
                      <p className="text-sm text-gray-500">
                        {stats.lastBackup ? formatDate(stats.lastBackup) : "Never"}
                      </p>
                    </div>
                  </div>

                  <div className="rounded-md bg-muted p-4">
                    <h4 className="mb-2 text-sm font-medium">System Health</h4>
                    <div className="space-y-2">
                      {stats.healthChecks.map((check) => (
                        <div key={check.name} className="flex items-center justify-between">
                          <span className="text-sm">{check.name}</span>
                          <span
                            className={`text-xs font-medium ${check.status === "healthy" ? "text-green-500" : "text-red-500"}`}
                          >
                            {check.status}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Additional tabs content */}
      </Tabs>
    </div>
  )
}

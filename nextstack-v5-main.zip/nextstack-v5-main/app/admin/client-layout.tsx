"use client"

import type { ReactNode } from "react"
import { usePathname } from "next/navigation"
import AdminHeader from "./components/admin-header"
import AdminSidebar from "./components/admin-sidebar"
import { AuthProvider } from "./providers/auth-provider"

export default function ClientLayout({ children }: { children: ReactNode }) {
  const pathname = usePathname()
  const isLoginPage = pathname === "/admin/login"
  const isUnauthorizedPage = pathname === "/admin/unauthorized"
  const showLayout = !isLoginPage && !isUnauthorizedPage

  return (
    <AuthProvider>
      {showLayout ? (
        <div className="min-h-screen bg-gray-100">
          <AdminHeader />
          <div className="flex">
            <AdminSidebar />
            <main className="flex-1 p-6">{children}</main>
          </div>
        </div>
      ) : (
        children
      )}
    </AuthProvider>
  )
}

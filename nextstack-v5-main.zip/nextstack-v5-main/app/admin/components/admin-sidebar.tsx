"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  FileText,
  Users,
  Settings,
  ImageIcon,
  FileQuestion,
  ClipboardList,
  MessageSquare,
  FolderKanban,
  Clock,
  ChevronDown,
  ChevronRight,
  BarChart,
} from "lucide-react"

interface NavItem {
  title: string
  href: string
  icon: React.ReactNode
  submenu?: NavItem[]
}

export default function AdminSidebar() {
  const pathname = usePathname()
  const [openSubmenu, setOpenSubmenu] = useState<string | null>(null)

  const navItems: NavItem[] = [
    {
      title: "Dashboard",
      href: "/admin",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      title: "Content",
      href: "/admin/content",
      icon: <FileText className="h-5 w-5" />,
      submenu: [
        {
          title: "Pages",
          href: "/admin/content/pages",
          icon: <FileText className="h-4 w-4" />,
        },
        {
          title: "Notes",
          href: "/admin/content/notes",
          icon: <MessageSquare className="h-4 w-4" />,
        },
        {
          title: "Forms",
          href: "/admin/content/forms",
          icon: <ClipboardList className="h-4 w-4" />,
        },
        {
          title: "Submissions",
          href: "/admin/content/submissions",
          icon: <FileQuestion className="h-4 w-4" />,
        },
        {
          title: "Media",
          href: "/admin/content/media",
          icon: <ImageIcon className="h-4 w-4" />,
        },
        {
          title: "Collections",
          href: "/admin/content/collections",
          icon: <FolderKanban className="h-4 w-4" />,
        },
        {
          title: "Timelines",
          href: "/admin/content/timelines",
          icon: <Clock className="h-4 w-4" />,
        },
      ],
    },
    {
      title: "Analytics",
      href: "/admin/analytics",
      icon: <BarChart className="h-5 w-5" />,
    },
    {
      title: "Users",
      href: "/admin/users",
      icon: <Users className="h-5 w-5" />,
    },
    {
      title: "Settings",
      href: "/admin/settings",
      icon: <Settings className="h-5 w-5" />,
    },
  ]

  const toggleSubmenu = (title: string) => {
    if (openSubmenu === title) {
      setOpenSubmenu(null)
    } else {
      setOpenSubmenu(title)
    }
  }

  return (
    <aside className="w-64 bg-white shadow">
      <div className="h-full py-4">
        <nav className="space-y-1 px-2">
          {navItems.map((item) => {
            const isActive = pathname === item.href || pathname?.startsWith(`${item.href}/`)
            const hasSubmenu = item.submenu && item.submenu.length > 0
            const isSubmenuOpen = openSubmenu === item.title

            return (
              <div key={item.href}>
                {hasSubmenu ? (
                  <button
                    onClick={() => toggleSubmenu(item.title)}
                    className={cn(
                      "flex w-full items-center rounded-md px-3 py-2 text-sm font-medium",
                      isActive ? "bg-gray-100 text-gray-900" : "text-gray-700 hover:bg-gray-50 hover:text-gray-900",
                    )}
                  >
                    <span className="mr-3">{item.icon}</span>
                    <span className="flex-1 text-left">{item.title}</span>
                    {isSubmenuOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                  </button>
                ) : (
                  <Link
                    href={item.href}
                    className={cn(
                      "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                      isActive ? "bg-gray-100 text-gray-900" : "text-gray-700 hover:bg-gray-50 hover:text-gray-900",
                    )}
                  >
                    <span className="mr-3">{item.icon}</span>
                    {item.title}
                  </Link>
                )}

                {hasSubmenu && isSubmenuOpen && (
                  <div className="mt-1 space-y-1 pl-10">
                    {item.submenu?.map((subItem) => {
                      const isSubActive = pathname === subItem.href
                      return (
                        <Link
                          key={subItem.href}
                          href={subItem.href}
                          className={cn(
                            "flex items-center rounded-md px-3 py-2 text-sm font-medium",
                            isSubActive
                              ? "bg-gray-100 text-gray-900"
                              : "text-gray-700 hover:bg-gray-50 hover:text-gray-900",
                          )}
                        >
                          <span className="mr-3">{subItem.icon}</span>
                          {subItem.title}
                        </Link>
                      )
                    })}
                  </div>
                )}
              </div>
            )
          })}
        </nav>
      </div>
    </aside>
  )
}

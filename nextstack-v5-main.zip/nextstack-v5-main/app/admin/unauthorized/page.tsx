import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function UnauthorizedPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gray-50">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-red-600">Access Denied</h1>
        <p className="mt-4 text-lg text-gray-600">You do not have permission to access this page.</p>
        <div className="mt-8 flex justify-center gap-4">
          <Button asChild>
            <Link href="/admin">Back to Dashboard</Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/">Back to Website</Link>
          </Button>
        </div>
      </div>
    </div>
  )
}

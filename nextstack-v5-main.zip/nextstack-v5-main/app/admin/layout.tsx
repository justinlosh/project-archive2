import type { ReactNode } from "react"
import { headers } from "next/headers"
import AdminHeader from "./components/admin-header"
import AdminSidebar from "./components/admin-sidebar"

export default function AdminLayout({
  children,
}: {
  children: ReactNode
}) {
  // Get the current pathname from headers
  const headersList = headers()
  const pathname = headersList.get("x-pathname") || headersList.get("x-url") || ""

  // Check if we're on the login or unauthorized page
  const isLoginPage = pathname.includes("/admin/login")
  const isUnauthorizedPage = pathname.includes("/admin/unauthorized")

  // For login and unauthorized pages, render without admin layout
  if (isLoginPage || isUnauthorizedPage) {
    return <>{children}</>
  }

  // For other admin pages, render with admin layout
  return (
    <div className="min-h-screen bg-gray-100">
      <AdminHeader />
      <div className="flex">
        <AdminSidebar />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

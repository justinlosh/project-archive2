"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Loader2, RefreshCw } from "lucide-react"

export default function LoginPage() {
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isResetting, setIsResetting] = useState(false)
  const [defaultUsername, setDefaultUsername] = useState("admin")
  const router = useRouter()

  // Fetch the admin status
  useEffect(() => {
    async function fetchAdminStatus() {
      try {
        const response = await fetch("/api/auth/admin-status")
        if (response.ok) {
          const data = await response.json()
          if (data.envAdminUsername) {
            setDefaultUsername(data.envAdminUsername)
          }
        }
      } catch (error) {
        console.error("Failed to fetch admin status:", error)
      }
    }

    fetchAdminStatus()
  }, [])

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setIsLoading(true)
    setError(null)
    setSuccess(null)

    const formData = new FormData(event.currentTarget)
    const username = formData.get("username") as string
    const password = formData.get("password") as string

    // Basic validation
    if (!username || !password) {
      setError("Username and password are required")
      setIsLoading(false)
      return
    }

    try {
      console.log("Attempting login with:", { username })

      // Use fetch to call the login API endpoint
      const response = await fetch("/api/auth/login", {
        method: "POST",
        body: formData,
      })

      const result = await response.json()
      console.log("Login result:", result)

      if (result.error) {
        setError(result.error)
      } else if (result.success) {
        // Force a refresh to ensure the auth state is updated
        router.refresh()
        // Redirect to admin dashboard
        router.push("/admin")
      } else {
        setError("An unexpected error occurred")
      }
    } catch (err) {
      console.error("Login error:", err)
      setError("An unexpected error occurred during login")
    } finally {
      setIsLoading(false)
    }
  }

  async function resetAdmin() {
    setIsResetting(true)
    setError(null)
    setSuccess(null)

    try {
      const response = await fetch("/api/auth/admin-status", {
        method: "POST",
      })

      const result = await response.json()

      if (result.error) {
        setError(result.error)
      } else if (result.success) {
        setSuccess(
          `Admin user "${result.username}" has been reset. You can now log in with your environment variables.`,
        )
        // Update the default username
        if (result.username) {
          setDefaultUsername(result.username)
        }
      } else {
        setError("An unexpected error occurred")
      }
    } catch (err) {
      console.error("Reset admin error:", err)
      setError("An unexpected error occurred during admin reset")
    } finally {
      setIsResetting(false)
    }
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="text-2xl">Admin Login</CardTitle>
        <CardDescription>Sign in to access the admin dashboard</CardDescription>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert variant="destructive" className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}
        {success && (
          <Alert className="mb-4 bg-green-50 text-green-800 border-green-200">
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                name="username"
                defaultValue={defaultUsername}
                placeholder="Enter your username"
                required
                disabled={isLoading}
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Enter your password"
                required
                disabled={isLoading}
              />
            </div>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Signing in...
                </>
              ) : (
                "Sign In"
              )}
            </Button>
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col gap-2">
        <div className="text-sm text-gray-500 text-center w-full">Default username: {defaultUsername}</div>
        <Button variant="outline" size="sm" className="w-full" onClick={resetAdmin} disabled={isResetting}>
          {isResetting ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Resetting admin...
            </>
          ) : (
            <>
              <RefreshCw className="mr-2 h-4 w-4" />
              Reset Admin User
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  )
}

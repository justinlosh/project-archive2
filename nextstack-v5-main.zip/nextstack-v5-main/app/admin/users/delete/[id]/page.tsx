"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getUserByIdAction, deleteUserAction } from "../../../actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function DeleteUserPage({ params }: { params: { id: string } }) {
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingUser, setIsLoadingUser] = useState(true)
  const [user, setUser] = useState<any>(null)
  const router = useRouter()
  const { id } = params

  useEffect(() => {
    async function loadUser() {
      setIsLoadingUser(true)
      try {
        const result = await getUserByIdAction(id)
        if (result.user) {
          setUser(result.user)
        } else {
          setError("User not found")
        }
      } catch (err) {
        setError("Failed to load user")
      } finally {
        setIsLoadingUser(false)
      }
    }

    loadUser()
  }, [id])

  async function handleDelete(formData: FormData) {
    setIsLoading(true)
    setError(null)

    // Add ID to form data
    formData.set("id", id)

    try {
      const result = await deleteUserAction(formData)

      if (result.error) {
        setError(result.error)
      } else {
        router.push("/admin/users")
      }
    } catch (err) {
      setError("An unexpected error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoadingUser) {
    return (
      <div className="flex h-full items-center justify-center">
        <p>Loading user...</p>
      </div>
    )
  }

  if (!user) {
    return (
      <div className="flex h-full items-center justify-center">
        <p>User not found</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Delete User</h1>
        <p className="text-gray-500">Permanently remove this user</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Confirm Deletion</CardTitle>
          <CardDescription>This action cannot be undone</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <div className="space-y-4">
            <p>
              Are you sure you want to delete the user <strong>{user.username}</strong>?
            </p>
            <p className="text-sm text-gray-500">This will permanently remove the user and all associated data.</p>
          </div>
        </CardContent>
        <CardFooter className="border-t bg-gray-50 px-6 py-3 space-x-4">
          <form action={handleDelete}>
            <Button variant="destructive" type="submit" disabled={isLoading}>
              {isLoading ? "Deleting..." : "Delete User"}
            </Button>
          </form>
          <Button variant="outline" onClick={() => router.push("/admin/users")}>
            Cancel
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

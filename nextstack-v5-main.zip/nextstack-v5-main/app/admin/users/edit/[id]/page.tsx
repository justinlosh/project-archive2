"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getUserByIdAction, updateUserAction } from "../../../actions"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle } from "lucide-react"

export default function EditUserPage({ params }: { params: { id: string } }) {
  const [error, setError] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isLoadingUser, setIsLoadingUser] = useState(true)
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [role, setRole] = useState<string>("viewer")
  const router = useRouter()
  const { id } = params

  useEffect(() => {
    async function loadUser() {
      setIsLoadingUser(true)
      try {
        const result = await getUserByIdAction(id)
        if (result.user) {
          setUsername(result.user.username)
          setEmail(result.user.email)
          setRole(result.user.role)
        } else {
          setError("User not found")
        }
      } catch (err) {
        setError("Failed to load user")
      } finally {
        setIsLoadingUser(false)
      }
    }

    loadUser()
  }, [id])

  async function handleSubmit(formData: FormData) {
    setIsLoading(true)
    setError(null)

    // Add ID and role to form data
    formData.set("id", id)
    formData.set("role", role)

    try {
      const result = await updateUserAction(formData)

      if (result.error) {
        setError(result.error)
      } else {
        router.push("/admin/users")
      }
    } catch (err) {
      setError("An unexpected error occurred")
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoadingUser) {
    return (
      <div className="flex h-full items-center justify-center">
        <p>Loading user...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Edit User</h1>
        <p className="text-gray-500">Update user information</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>User Information</CardTitle>
          <CardDescription>Update the details for this user</CardDescription>
        </CardHeader>
        <CardContent>
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <form action={handleSubmit} className="space-y-4">
            <div className="grid gap-2">
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                name="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter username"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                name="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Enter email address"
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                name="password"
                type="password"
                placeholder="Enter new password (leave blank to keep current)"
              />
              <p className="text-xs text-gray-500">Leave blank to keep the current password</p>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="role">Role</Label>
              <Select value={role} onValueChange={setRole}>
                <SelectTrigger id="role">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="editor">Editor</SelectItem>
                  <SelectItem value="viewer">Viewer</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button type="submit" className="mt-4" disabled={isLoading}>
              {isLoading ? "Updating..." : "Update User"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="border-t bg-gray-50 px-6 py-3">
          <Button variant="outline" onClick={() => router.push("/admin/users")}>
            Cancel
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

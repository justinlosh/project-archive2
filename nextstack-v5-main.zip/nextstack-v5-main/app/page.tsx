const Page = () => {
  return (
    <div>
      <h1>Welcome to the Next.js Flat-File CMS</h1>
      <p>This is a basic page. You can replace this with your own content.</p>
      {/* Example usage of ContentRenderer (replace with actual content and contentType) */}
      {/* <ContentRenderer content={{ title: 'Example Timeline', description: 'A timeline example', events: [] }} contentType="timeline" /> */}
    </div>
  )
}

export default Page

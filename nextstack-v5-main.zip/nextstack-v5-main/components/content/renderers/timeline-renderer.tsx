import type React from "react"
import { Card, CardContent } from "@/components/ui/card"
import type { Timeline } from "@/lib/data/types"

interface TimelineRendererProps {
  timeline: Timeline
  isPreview?: boolean
}

const TimelineRenderer: React.FC<TimelineRendererProps> = ({ timeline, isPreview = false }) => {
  if (!timeline || !timeline.events || timeline.events.length === 0) {
    return <div>No timeline events to display</div>
  }

  return (
    <div className="timeline-container">
      <h2 className="text-2xl font-bold mb-4">{timeline.title}</h2>
      {timeline.description && <p className="mb-6">{timeline.description}</p>}

      <div className="relative border-l-2 border-gray-300 ml-4">
        {timeline.events.map((event, index) => (
          <div key={index} className="mb-8 ml-6">
            <div className="absolute w-4 h-4 bg-blue-500 rounded-full -left-[9px] mt-1.5"></div>
            <Card className={isPreview ? "border-dashed border-blue-300" : ""}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-start">
                  <h3 className="text-lg font-semibold">{event.title}</h3>
                  <span className="text-sm text-gray-500">{event.date}</span>
                </div>
                {event.description && <p className="mt-2">{event.description}</p>}
                {event.media && (
                  <div className="mt-4">
                    <img
                      src={event.media.url || "/placeholder.svg"}
                      alt={event.media.alt || event.title}
                      className="rounded-md max-h-48 object-cover"
                    />
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        ))}
      </div>
    </div>
  )
}

export default TimelineRenderer

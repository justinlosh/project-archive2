import type React from "react"
import type { ContentType } from "@/lib/data/types"
import PageRenderer from "../renderers/page-renderer"
import NoteRenderer from "../renderers/note-renderer"
import FormRenderer from "../renderers/form-renderer"
import SubmissionRenderer from "../renderers/submission-renderer"
import MediaRenderer from "../renderers/media-renderer"
import CollectionRenderer from "../renderers/collection-renderer"
import TimelineRenderer from "../renderers/timeline-renderer"

interface ContentRendererProps {
  content: any
  contentType: ContentType
  isPreview?: boolean
}

const ContentRenderer: React.FC<ContentRendererProps> = ({ content, contentType, isPreview = false }) => {
  if (!content) {
    return <div>No content to display</div>
  }

  switch (contentType) {
    case "page":
      return <PageRenderer page={content} isPreview={isPreview} />
    case "note":
      return <NoteRenderer note={content} isPreview={isPreview} />
    case "form":
      return <FormRenderer form={content} isPreview={isPreview} />
    case "submission":
      return <SubmissionRenderer submission={content} isPreview={isPreview} />
    case "media":
      return <MediaRenderer media={content} isPreview={isPreview} />
    case "collection":
      return <CollectionRenderer collection={content} isPreview={isPreview} />
    case "timeline":
      return <TimelineRenderer timeline={content} isPreview={isPreview} />
    default:
      return <div>Unknown content type: {contentType}</div>
  }
}

export default ContentRenderer

"use client"

import { useEffect, useState } from "react"
import { cn } from "@/lib/utils"

interface SkipLinkProps {
  className?: string
  contentId?: string
  label?: string
}

export function SkipLink({ className, contentId = "main-content", label = "Skip to content" }: SkipLinkProps) {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <a
      href={`#${contentId}`}
      className={cn(
        "fixed left-4 top-4 z-50 -translate-y-20 rounded-md bg-background px-4 py-2 text-sm font-medium text-foreground shadow-md transition-transform focus:translate-y-0",
        className,
      )}
    >
      {label}
    </a>
  )
}

"use client"

import type React from "react"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { cn } from "@/lib/utils"

interface FormFieldProps {
  id: string
  label: string
  type?: "text" | "email" | "password" | "number" | "textarea" | "select"
  placeholder?: string
  description?: string
  error?: string
  required?: boolean
  disabled?: boolean
  className?: string
  options?: { value: string; label: string }[]
  value?: string | number
  onChange?: (value: string) => void
  [key: string]: any
}

export function FormField({
  id,
  label,
  type = "text",
  placeholder,
  description,
  error,
  required = false,
  disabled = false,
  className,
  options = [],
  value,
  onChange,
  ...props
}: FormFieldProps) {
  const fieldId = `field-${id}`
  const descriptionId = description ? `${fieldId}-description` : undefined
  const errorId = error ? `${fieldId}-error` : undefined

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    onChange?.(e.target.value)
  }

  const handleSelectChange = (value: string) => {
    onChange?.(value)
  }

  return (
    <div className={cn("space-y-2", className)}>
      <Label htmlFor={fieldId} className={cn(required && "after:content-['*'] after:ml-0.5 after:text-red-500")}>
        {label}
      </Label>

      {type === "textarea" ? (
        <Textarea
          id={fieldId}
          placeholder={placeholder}
          disabled={disabled}
          aria-describedby={cn(descriptionId, errorId)}
          aria-invalid={!!error}
          value={value}
          onChange={handleChange}
          {...props}
        />
      ) : type === "select" ? (
        <Select value={value?.toString()} onValueChange={handleSelectChange} disabled={disabled}>
          <SelectTrigger id={fieldId} aria-describedby={cn(descriptionId, errorId)} aria-invalid={!!error}>
            <SelectValue placeholder={placeholder} />
          </SelectTrigger>
          <SelectContent>
            {options.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      ) : (
        <Input
          id={fieldId}
          type={type}
          placeholder={placeholder}
          disabled={disabled}
          aria-describedby={cn(descriptionId, errorId)}
          aria-invalid={!!error}
          value={value}
          onChange={handleChange}
          {...props}
        />
      )}

      {description && (
        <p id={descriptionId} className="text-sm text-muted-foreground">
          {description}
        </p>
      )}

      {error && (
        <p id={errorId} className="text-sm font-medium text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}

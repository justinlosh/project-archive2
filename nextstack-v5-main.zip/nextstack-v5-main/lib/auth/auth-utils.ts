import fs from "fs/promises"
import path from "path"
import crypto from "crypto"
import { cookies } from "next/headers"
import type { User, UserRole } from "./types"
import { logger } from "../utils/logger"
import { ensureAdminUser } from "./ensure-admin"

// Add these lines near the top of the file, after the imports
const ADMIN_USERNAME = process.env.ADMIN_USERNAME || "admin"
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || "admin@example.com"
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123"

const USERS_FILE = path.join(process.cwd(), "content", "users.json")
const SESSIONS_FILE = path.join(process.cwd(), "content", "sessions.json")
const LOCK_FILE = path.join(process.cwd(), "content", "users.lock")

// Validate environment variables
function validateEnvironmentVariables() {
  if (process.env.ADMIN_USERNAME && process.env.ADMIN_USERNAME.length < 3) {
    logger.warn("ADMIN_USERNAME should be at least 3 characters long")
  }

  if (process.env.ADMIN_PASSWORD && process.env.ADMIN_PASSWORD.length < 8) {
    logger.warn("ADMIN_PASSWORD should be at least 8 characters long for security")
  }

  if (process.env.ADMIN_EMAIL && !process.env.ADMIN_EMAIL.includes("@")) {
    logger.warn("ADMIN_EMAIL should be a valid email address")
  }
}

// Call validation during module initialization
validateEnvironmentVariables()

// File locking mechanism
async function acquireLock(timeout = 5000): Promise<boolean> {
  const startTime = Date.now()

  while (Date.now() - startTime < timeout) {
    try {
      await fs.writeFile(LOCK_FILE, Date.now().toString(), { flag: "wx" })
      return true
    } catch (error) {
      // Check if lock is stale (older than 30 seconds)
      try {
        const stats = await fs.stat(LOCK_FILE)
        if (Date.now() - stats.mtimeMs > 30000) {
          // Lock is stale, remove it
          await fs.unlink(LOCK_FILE)
          continue
        }
      } catch (statError) {
        // Lock file doesn't exist or was just removed
      }

      // Wait a bit before retrying
      await new Promise((resolve) => setTimeout(resolve, 100))
    }
  }

  return false
}

async function releaseLock(): Promise<boolean> {
  try {
    await fs.unlink(LOCK_FILE)
    return true
  } catch (error) {
    logger.error("Error releasing lock:", error)
    return false
  }
}

// Helper to ensure the content directory exists
async function ensureContentDirectory() {
  const contentDir = path.dirname(USERS_FILE)
  try {
    await fs.access(contentDir)
  } catch (error) {
    // Create directory if it doesn't exist
    await fs.mkdir(contentDir, { recursive: true })
    logger.info(`Created content directory: ${contentDir}`)
  }
}

// Helper to ensure the users file exists
export async function ensureUsersFile() {
  await ensureContentDirectory()

  try {
    await fs.access(USERS_FILE)
  } catch (error) {
    // Create empty users file
    await fs.writeFile(USERS_FILE, JSON.stringify([]))
    logger.info(`Created users file: ${USERS_FILE}`)
  }
}

// Helper to ensure the sessions file exists
export async function ensureSessionsFile() {
  await ensureContentDirectory()

  try {
    await fs.access(SESSIONS_FILE)
  } catch (error) {
    // Create empty sessions file
    await fs.writeFile(SESSIONS_FILE, JSON.stringify([]))
    logger.info(`Created sessions file: ${SESSIONS_FILE}`)
  }
}

// Hash password
export function hashPassword(password: string): string {
  // For simplicity, we'll use a basic hash for now
  // In production, use a proper password hashing library like bcrypt
  return crypto.createHash("sha256").update(password).digest("hex")
}

// Verify password
export function verifyPassword(password: string, hashedPassword: string): boolean {
  const hashedInput = crypto.createHash("sha256").update(password).digest("hex")
  return hashedInput === hashedPassword
}

// Get all users
export async function getUsers(): Promise<User[]> {
  await ensureUsersFile()
  try {
    const data = await fs.readFile(USERS_FILE, "utf-8")
    return JSON.parse(data)
  } catch (error) {
    if (error instanceof SyntaxError) {
      logger.error("Error parsing users file, file may be corrupted:", error)
      // Create a backup of the corrupted file
      const backupFile = `${USERS_FILE}.backup.${Date.now()}`
      await fs.copyFile(USERS_FILE, backupFile)
      logger.info(`Backed up corrupted file to ${backupFile}`)
      // Return empty array and recreate the file
      await fs.writeFile(USERS_FILE, JSON.stringify([]))
      return []
    }
    logger.error("Error reading users file:", error)
    return []
  }
}

// Get user by ID
export async function getUserById(id: string): Promise<User | null> {
  const users = await getUsers()
  return users.find((user) => user.id === id) || null
}

// Get user by username
export async function getUserByUsername(username: string): Promise<User | null> {
  const users = await getUsers()
  return users.find((user) => user.username.toLowerCase() === username.toLowerCase()) || null
}

// Create user
export async function createUser(user: Omit<User, "id" | "createdAt" | "updatedAt">): Promise<User> {
  await ensureUsersFile()

  let lockAcquired = false
  try {
    lockAcquired = await acquireLock()
    if (!lockAcquired) {
      throw new Error("Could not acquire lock, another operation is in progress")
    }

    const users = await getUsers()

    // Check if username already exists
    if (users.some((u) => u.username.toLowerCase() === user.username.toLowerCase())) {
      throw new Error("Username already exists")
    }

    // Check if email already exists
    if (users.some((u) => u.email.toLowerCase() === user.email.toLowerCase())) {
      throw new Error("Email already exists")
    }

    const newUser: User = {
      ...user,
      id: crypto.randomUUID(),
      password: hashPassword(user.password),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    users.push(newUser)
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2))

    return newUser
  } catch (error) {
    logger.error("Error creating user:", error)
    throw error
  } finally {
    if (lockAcquired) {
      await releaseLock()
    }
  }
}

// Update user
export async function updateUser(id: string, userData: Partial<Omit<User, "id" | "createdAt">>): Promise<User> {
  await ensureUsersFile()

  let lockAcquired = false
  try {
    lockAcquired = await acquireLock()
    if (!lockAcquired) {
      throw new Error("Could not acquire lock, another operation is in progress")
    }

    const users = await getUsers()
    const userIndex = users.findIndex((user) => user.id === id)

    if (userIndex === -1) {
      throw new Error("User not found")
    }

    // If updating username, check if it already exists
    if (
      userData.username &&
      userData.username.toLowerCase() !== users[userIndex].username.toLowerCase() &&
      users.some((u) => u.id !== id && u.username.toLowerCase() === userData.username!.toLowerCase())
    ) {
      throw new Error("Username already exists")
    }

    // If updating email, check if it already exists
    if (
      userData.email &&
      userData.email.toLowerCase() !== users[userIndex].email.toLowerCase() &&
      users.some((u) => u.id !== id && u.email.toLowerCase() === userData.email!.toLowerCase())
    ) {
      throw new Error("Email already exists")
    }

    // If updating password, hash it
    if (userData.password) {
      userData.password = hashPassword(userData.password)
    }

    const updatedUser = {
      ...users[userIndex],
      ...userData,
      updatedAt: new Date().toISOString(),
    }

    users[userIndex] = updatedUser
    await fs.writeFile(USERS_FILE, JSON.stringify(users, null, 2))

    return updatedUser
  } catch (error) {
    logger.error("Error updating user:", error)
    throw error
  } finally {
    if (lockAcquired) {
      await releaseLock()
    }
  }
}

// Delete user
export async function deleteUser(id: string): Promise<void> {
  await ensureUsersFile()

  let lockAcquired = false
  try {
    lockAcquired = await acquireLock()
    if (!lockAcquired) {
      throw new Error("Could not acquire lock, another operation is in progress")
    }

    const users = await getUsers()

    // Prevent deleting the last admin user
    const adminUsers = users.filter((user) => user.role === "admin")
    const userToDelete = users.find((user) => user.id === id)

    if (adminUsers.length === 1 && userToDelete?.role === "admin") {
      throw new Error("Cannot delete the last admin user")
    }

    const filteredUsers = users.filter((user) => user.id !== id)

    if (filteredUsers.length === users.length) {
      throw new Error("User not found")
    }

    await fs.writeFile(USERS_FILE, JSON.stringify(filteredUsers, null, 2))

    // Also delete any sessions for this user
    await deleteUserSessions(id)
  } catch (error) {
    logger.error("Error deleting user:", error)
    throw error
  } finally {
    if (lockAcquired) {
      await releaseLock()
    }
  }
}

// Delete all sessions for a user
async function deleteUserSessions(userId: string): Promise<void> {
  await ensureSessionsFile()
  try {
    const sessionsData = await fs.readFile(SESSIONS_FILE, "utf-8")
    const sessions = JSON.parse(sessionsData)

    const filteredSessions = sessions.filter((s: any) => s.userId !== userId)
    await fs.writeFile(SESSIONS_FILE, JSON.stringify(filteredSessions, null, 2))
  } catch (error) {
    logger.error("Error deleting user sessions:", error)
  }
}

// Create session
export async function createSession(userId: string): Promise<string> {
  await ensureSessionsFile()
  try {
    let sessions = []
    try {
      const sessionsData = await fs.readFile(SESSIONS_FILE, "utf-8")
      sessions = JSON.parse(sessionsData)
    } catch (error) {
      logger.error("Error reading sessions file, creating new one:", error)
      sessions = []
    }

    // Clean up expired sessions
    const now = new Date()
    const validSessions = sessions.filter((session: any) => new Date(session.expires) > now)

    // Create new session
    const sessionId = crypto.randomUUID()
    const expiresAt = new Date()
    expiresAt.setDate(expiresAt.getDate() + 7) // 7 days from now

    const newSession = {
      id: sessionId,
      userId,
      expires: expiresAt.toISOString(),
      createdAt: now.toISOString(),
    }

    validSessions.push(newSession)
    await fs.writeFile(SESSIONS_FILE, JSON.stringify(validSessions, null, 2))

    return sessionId
  } catch (error) {
    logger.error("Error creating session:", error)
    throw new Error("Failed to create session")
  }
}

// Get session
export async function getSession(sessionId: string): Promise<any | null> {
  await ensureSessionsFile()
  try {
    const sessionsData = await fs.readFile(SESSIONS_FILE, "utf-8")
    const sessions = JSON.parse(sessionsData)

    const session = sessions.find((s: any) => s.id === sessionId)

    if (!session) {
      return null
    }

    // Check if session is expired
    if (new Date(session.expires) < new Date()) {
      return null
    }

    return session
  } catch (error) {
    logger.error("Error getting session:", error)
    return null
  }
}

// Delete session
export async function deleteSession(sessionId: string): Promise<void> {
  await ensureSessionsFile()
  try {
    const sessionsData = await fs.readFile(SESSIONS_FILE, "utf-8")
    const sessions = JSON.parse(sessionsData)

    const filteredSessions = sessions.filter((s: any) => s.id !== sessionId)
    await fs.writeFile(SESSIONS_FILE, JSON.stringify(filteredSessions, null, 2))
  } catch (error) {
    logger.error("Error deleting session:", error)
  }
}

// Get current user from session
export async function getCurrentUser(): Promise<User | null> {
  try {
    const cookieStore = cookies()
    const sessionId = cookieStore.get("session_id")?.value

    if (!sessionId) {
      return null
    }

    const session = await getSession(sessionId)

    if (!session) {
      return null
    }

    return getUserById(session.userId)
  } catch (error) {
    logger.error("Error getting current user:", error)
    return null
  }
}

// Initialize admin user if no users exist
export async function initializeAdminUser() {
  // Force ensure the admin user on startup
  await ensureAdminUser()
    .then((result) => {
      logger.info(`Admin user initialized: ${result.username}`)
    })
    .catch((error) => {
      logger.error("Failed to initialize admin user:", error)
    })
}

// Check if user has required role
export async function checkUserRole(requiredRole: UserRole): Promise<boolean> {
  const user = await getCurrentUser()

  if (!user) {
    return false
  }

  // Admin role has access to everything
  if (user.role === "admin") {
    return true
  }

  // Editor role has access to editor and viewer permissions
  if (user.role === "editor" && (requiredRole === "editor" || requiredRole === "viewer")) {
    return true
  }

  // Viewer role only has access to viewer permissions
  if (user.role === "viewer" && requiredRole === "viewer") {
    return true
  }

  return false
}

// Get auth user without redirecting
export async function getAuthUser() {
  try {
    return await getCurrentUser()
  } catch (error) {
    logger.error("Auth error:", error)
    return null
  }
}

// Require authentication
export async function requireAuth() {
  const user = await getAuthUser()
  if (!user) {
    throw new Error("Authentication required")
  }
  return user
}

// Require specific role
export async function requireRole(role: UserRole) {
  const user = await getAuthUser()
  if (!user) {
    throw new Error("Authentication required")
  }

  const hasRole = await checkUserRole(role)
  if (!hasRole) {
    throw new Error(`Role '${role}' required`)
  }

  return user
}

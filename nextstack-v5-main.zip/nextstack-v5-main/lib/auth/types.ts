export interface User {
  id: string
  username: string
  email: string
  password: string // Hashed password
  role: UserRole
  createdAt: string
  updatedAt: string
}

export type UserRole = "admin" | "editor" | "viewer"

export interface Session {
  id: string
  userId: string
  expires: string
  createdAt: string
}

export interface AuthState {
  user: User | null
  isLoading: boolean
  error: string | null
}

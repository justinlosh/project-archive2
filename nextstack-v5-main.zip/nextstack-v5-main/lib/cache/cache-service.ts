import fs from "fs/promises"
import path from "path"
import crypto from "crypto"

// Cache configuration
const CACHE_ENABLED = process.env.ENABLE_API_CACHE === "true"
const CACHE_TTL = Number.parseInt(process.env.API_CACHE_TTL || "300", 10) // Default 5 minutes
const CACHE_DIR = path.join(process.cwd(), process.env.CACHE_PATH || ".cache")

// In-memory cache
const memoryCache: Record<string, { data: any; expires: number }> = {}

// Generate cache key
function generateCacheKey(key: string): string {
  return crypto.createHash("md5").update(key).digest("hex")
}

// Ensure cache directory exists
async function ensureCacheDir(): Promise<void> {
  try {
    await fs.access(CACHE_DIR)
  } catch (error) {
    await fs.mkdir(CACHE_DIR, { recursive: true })
  }
}

// Get cache file path
function getCacheFilePath(key: string): string {
  const cacheKey = generateCacheKey(key)
  return path.join(CACHE_DIR, `${cacheKey}.json`)
}

// Set cache
export async function setCache(key: string, data: any, ttl = CACHE_TTL): Promise<void> {
  if (!CACHE_ENABLED) return

  const cacheKey = generateCacheKey(key)
  const expires = Date.now() + ttl * 1000

  // Set in memory cache
  memoryCache[cacheKey] = { data, expires }

  // Set in file cache
  try {
    await ensureCacheDir()
    const cacheData = { data, expires }
    await fs.writeFile(getCacheFilePath(key), JSON.stringify(cacheData))
  } catch (error) {
    console.error("Cache write error:", error)
  }
}

// Get from cache
export async function getCache<T>(key: string): Promise<T | null> {
  if (!CACHE_ENABLED) return null

  const cacheKey = generateCacheKey(key)
  const now = Date.now()

  // Try memory cache first
  if (memoryCache[cacheKey] && memoryCache[cacheKey].expires > now) {
    return memoryCache[cacheKey].data as T
  }

  // Try file cache
  try {
    const filePath = getCacheFilePath(key)
    const fileData = await fs.readFile(filePath, "utf-8")
    const cacheData = JSON.parse(fileData)

    if (cacheData.expires > now) {
      // Update memory cache
      memoryCache[cacheKey] = cacheData
      return cacheData.data as T
    }

    // Cache expired, delete file
    await fs.unlink(filePath).catch(() => {})
    return null
  } catch (error) {
    return null
  }
}

// Clear cache for a specific key
export async function clearCache(key: string): Promise<void> {
  const cacheKey = generateCacheKey(key)

  // Clear from memory cache
  delete memoryCache[cacheKey]

  // Clear from file cache
  try {
    const filePath = getCacheFilePath(key)
    await fs.unlink(filePath).catch(() => {})
  } catch (error) {
    // Ignore errors
  }
}

// Clear all cache
export async function clearAllCache(): Promise<void> {
  // Clear memory cache
  Object.keys(memoryCache).forEach((key) => {
    delete memoryCache[key]
  })

  // Clear file cache
  try {
    await ensureCacheDir()
    const files = await fs.readdir(CACHE_DIR)
    await Promise.all(
      files.map((file) => {
        return fs.unlink(path.join(CACHE_DIR, file)).catch(() => {})
      }),
    )
  } catch (error) {
    console.error("Error clearing cache:", error)
  }
}

// Cache decorator for async functions
export function withCache<T>(fn: (...args: any[]) => Promise<T>, keyPrefix: string, ttl = CACHE_TTL) {
  return async (...args: any[]): Promise<T> => {
    const cacheKey = `${keyPrefix}:${JSON.stringify(args)}`

    // Try to get from cache
    const cachedData = await getCache<T>(cacheKey)
    if (cachedData !== null) {
      return cachedData
    }

    // Execute function
    const result = await fn(...args)

    // Store in cache
    await setCache(cacheKey, result, ttl)

    return result
  }
}

import fs from "fs/promises"
import path from "path"
import crypto from "crypto"
import sharp from "sharp"

// Configuration
const UPLOADS_DIR = path.join(process.cwd(), "public", "uploads")
const CACHE_DIR = path.join(process.cwd(), "public", "cache")
const MAX_IMAGE_SIZE = 5 * 1024 * 1024 // 5MB
const ALLOWED_FORMATS = ["jpeg", "jpg", "png", "webp", "avif", "gif"]

// Ensure directories exist
async function ensureDirectories() {
  await fs.mkdir(UPLOADS_DIR, { recursive: true })
  await fs.mkdir(CACHE_DIR, { recursive: true })
}

// Generate a unique filename
function generateUniqueFilename(originalFilename: string): string {
  const ext = path.extname(originalFilename).toLowerCase()
  const hash = crypto.randomBytes(8).toString("hex")
  const timestamp = Date.now()
  const sanitizedName = path
    .basename(originalFilename, ext)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, "-")
    .replace(/-+/g, "-")
    .substring(0, 40)

  return `${sanitizedName}-${timestamp}-${hash}${ext}`
}

// Get image metadata
export async function getImageMetadata(filePath: string) {
  try {
    const metadata = await sharp(filePath).metadata()
    return {
      width: metadata.width,
      height: metadata.height,
      format: metadata.format,
      size: metadata.size,
    }
  } catch (error) {
    console.error("Error getting image metadata:", error)
    throw new Error("Failed to process image")
  }
}

// Save uploaded image
export async function saveUploadedImage(buffer: Buffer, originalFilename: string) {
  await ensureDirectories()

  // Validate file size
  if (buffer.length > MAX_IMAGE_SIZE) {
    throw new Error("Image exceeds maximum size of 5MB")
  }

  // Validate file format
  const ext = path.extname(originalFilename).toLowerCase().substring(1)
  if (!ALLOWED_FORMATS.includes(ext)) {
    throw new Error(`Unsupported image format. Allowed formats: ${ALLOWED_FORMATS.join(", ")}`)
  }

  // Generate unique filename
  const filename = generateUniqueFilename(originalFilename)
  const filePath = path.join(UPLOADS_DIR, filename)

  // Save the file
  await fs.writeFile(filePath, buffer)

  // Get metadata
  const metadata = await getImageMetadata(filePath)

  return {
    filename,
    path: `/uploads/${filename}`,
    ...metadata,
  }
}

// Resize image
export async function resizeImage(
  sourcePath: string,
  width?: number,
  height?: number,
  format?: "jpeg" | "png" | "webp" | "avif",
) {
  await ensureDirectories()

  // Generate cache key
  const sourceFilename = path.basename(sourcePath)
  const resizeParams = `w${width || "auto"}_h${height || "auto"}_f${format || "original"}`
  const cacheFilename = `${path.basename(sourceFilename, path.extname(sourceFilename))}-${resizeParams}${format ? `.${format}` : path.extname(sourceFilename)}`
  const cachePath = path.join(CACHE_DIR, cacheFilename)

  // Check if cached version exists
  try {
    await fs.access(cachePath)
    return {
      path: `/cache/${cacheFilename}`,
    }
  } catch (error) {
    // Cache miss, generate resized image
  }

  // Resolve full source path
  const fullSourcePath = sourcePath.startsWith("/uploads/")
    ? path.join(process.cwd(), "public", sourcePath)
    : sourcePath

  // Create sharp instance
  let image = sharp(fullSourcePath)

  // Resize if dimensions provided
  if (width || height) {
    image = image.resize(width, height, {
      fit: "inside",
      withoutEnlargement: true,
    })
  }

  // Convert format if specified
  if (format) {
    image = image.toFormat(format, { quality: 80 })
  }

  // Save to cache
  await image.toFile(cachePath)

  return {
    path: `/cache/${cacheFilename}`,
  }
}

// Delete image
export async function deleteImage(filename: string) {
  const filePath = path.join(UPLOADS_DIR, path.basename(filename))

  try {
    await fs.access(filePath)
    await fs.unlink(filePath)
    return true
  } catch (error) {
    console.error("Error deleting image:", error)
    return false
  }
}

// Clean cache (can be called periodically)
export async function cleanImageCache(maxAge = 7 * 24 * 60 * 60 * 1000) {
  // 7 days
  try {
    const files = await fs.readdir(CACHE_DIR)
    const now = Date.now()

    for (const file of files) {
      const filePath = path.join(CACHE_DIR, file)
      const stats = await fs.stat(filePath)

      // Delete files older than maxAge
      if (now - stats.mtimeMs > maxAge) {
        await fs.unlink(filePath)
      }
    }
  } catch (error) {
    console.error("Error cleaning image cache:", error)
  }
}

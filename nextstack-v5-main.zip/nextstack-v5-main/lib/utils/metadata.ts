import type { Metadata } from "next"

interface SeoProps {
  title: string
  description?: string
  keywords?: string[]
  image?: string
  type?: "website" | "article"
  publishedTime?: string
  modifiedTime?: string
  author?: string
  section?: string
  noIndex?: boolean
}

export function generateMetadata({
  title,
  description,
  keywords,
  image,
  type = "website",
  publishedTime,
  modifiedTime,
  author,
  section,
  noIndex = false,
}: SeoProps): Metadata {
  // Base URL from environment or default
  const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"

  // Default site name
  const siteName = process.env.NEXT_PUBLIC_SITE_NAME || "Next.js Flat-File CMS"

  // Format title
  const formattedTitle = `${title} | ${siteName}`

  // Default image
  const defaultImage = `${baseUrl}/api/og?title=${encodeURIComponent(title)}`

  // Full image URL
  const imageUrl = image ? (image.startsWith("http") ? image : `${baseUrl}${image}`) : defaultImage

  return {
    title: formattedTitle,
    description: description,
    keywords: keywords,
    authors: author ? [{ name: author }] : undefined,
    openGraph: {
      title: formattedTitle,
      description: description,
      url: baseUrl,
      siteName: siteName,
      images: [
        {
          url: imageUrl,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
      locale: "en_US",
      type: type,
      publishedTime: publishedTime,
      modifiedTime: modifiedTime,
      authors: author ? [author] : undefined,
      section: section,
    },
    twitter: {
      card: "summary_large_image",
      title: formattedTitle,
      description: description,
      images: [imageUrl],
    },
    robots: noIndex ? { index: false, follow: false } : undefined,
  }
}

import { NextResponse } from "next/server"

type ApiResponseData = {
  success: boolean
  message?: string
  data?: any
  errors?: Record<string, string[]>
}

export function apiResponse(data: ApiResponseData, status = 200, headers?: Record<string, string>): NextResponse {
  // Add default headers for API responses
  const responseHeaders = {
    "Content-Type": "application/json",
    ...headers,
  }

  return NextResponse.json(data, {
    status,
    headers: responseHeaders,
  })
}

export function successResponse(data?: any, message?: string): NextResponse {
  return apiResponse({
    success: true,
    message,
    data,
  })
}

export function errorResponse(message: string, errors?: Record<string, string[]>, status = 400): NextResponse {
  return apiResponse(
    {
      success: false,
      message,
      errors,
    },
    status,
  )
}

export function notFoundResponse(message = "Resource not found"): NextResponse {
  return errorResponse(message, undefined, 404)
}

export function unauthorizedResponse(message = "Unauthorized"): NextResponse {
  return errorResponse(message, undefined, 401)
}

export function forbiddenResponse(message = "Forbidden"): NextResponse {
  return errorResponse(message, undefined, 403)
}

export function validationErrorResponse(errors: Record<string, string[]>): NextResponse {
  return errorResponse("Validation failed", errors, 422)
}

export function serverErrorResponse(message = "Internal server error"): NextResponse {
  return errorResponse(message, undefined, 500)
}

import fs from "fs/promises"
import path from "path"
import { getUsers } from "@/lib/auth/auth-utils"
import { getAllContent } from "@/lib/data/content-service"
import { logger } from "./logger"

// Get content directory size
async function getDirectorySize(dirPath: string): Promise<number> {
  try {
    let size = 0
    const files = await fs.readdir(dirPath, { withFileTypes: true })

    for (const file of files) {
      const filePath = path.join(dirPath, file.name)

      if (file.isDirectory()) {
        size += await getDirectorySize(filePath)
      } else {
        const stats = await fs.stat(filePath)
        size += stats.size
      }
    }

    return size
  } catch (error) {
    logger.error(`Error getting directory size for ${dirPath}:`, error)
    return 0
  }
}

// Get content activity data
async function getContentActivity() {
  try {
    // Get all content types
    const contentTypes = ["page", "note", "form", "media", "collection", "timeline"]
    let allContent: any[] = []

    // Collect all content
    for (const type of contentTypes) {
      const content = await getAllContent(type)
      allContent = [...allContent, ...content.map((item) => ({ ...item, type }))]
    }

    // Group by date
    const now = new Date()
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000)

    // Generate date range
    const dateRange: string[] = []
    for (let i = 0; i < 30; i++) {
      const date = new Date(thirtyDaysAgo.getTime() + i * 24 * 60 * 60 * 1000)
      dateRange.push(date.toISOString().split("T")[0])
    }

    // Initialize activity data
    const activityData = dateRange.map((date) => ({
      date,
      created: 0,
      updated: 0,
    }))

    // Fill activity data
    allContent.forEach((item) => {
      const createdDate = new Date(item.createdAt).toISOString().split("T")[0]
      const updatedDate = new Date(item.updatedAt).toISOString().split("T")[0]

      // Count creations
      if (dateRange.includes(createdDate)) {
        const index = dateRange.indexOf(createdDate)
        activityData[index].created += 1
      }

      // Count updates (only if different from creation date)
      if (dateRange.includes(updatedDate) && updatedDate !== createdDate) {
        const index = dateRange.indexOf(updatedDate)
        activityData[index].updated += 1
      }
    })

    return activityData
  } catch (error) {
    logger.error("Error getting content activity:", error)
    return []
  }
}

// Get content distribution data
async function getContentDistribution() {
  try {
    // Get all content types
    const contentTypes = ["page", "note", "form", "media", "collection", "timeline"]
    const distribution = []

    // Count content by type
    for (const type of contentTypes) {
      const content = await getAllContent(type)
      distribution.push({
        type: type.charAt(0).toUpperCase() + type.slice(1), // Capitalize first letter
        count: content.length,
      })
    }

    return distribution
  } catch (error) {
    logger.error("Error getting content distribution:", error)
    return []
  }
}

// Get recent activity
async function getRecentActivity(limit = 10) {
  try {
    // Get all content types
    const contentTypes = ["page", "note", "form", "media", "collection", "timeline"]
    let allContent: any[] = []

    // Collect all content
    for (const type of contentTypes) {
      const content = await getAllContent(type)
      allContent = [...allContent, ...content.map((item) => ({ ...item, type }))]
    }

    // Sort by updated date (descending)
    allContent.sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())

    // Take the most recent items
    const recentActivity = allContent.slice(0, limit).map((item) => ({
      id: item.id,
      title: item.title,
      type: item.type,
      action: new Date(item.createdAt).getTime() === new Date(item.updatedAt).getTime() ? "created" : "updated",
      timestamp: item.updatedAt,
    }))

    return recentActivity
  } catch (error) {
    logger.error("Error getting recent activity:", error)
    return []
  }
}

// Check system health
async function checkSystemHealth() {
  const healthChecks = [
    {
      name: "Content Directory",
      status: "unknown",
    },
    {
      name: "Cache Directory",
      status: "unknown",
    },
    {
      name: "User Authentication",
      status: "unknown",
    },
    {
      name: "Media Storage",
      status: "unknown",
    },
  ]

  try {
    // Check content directory
    await fs.access(path.join(process.cwd(), process.env.CONTENT_DIRECTORY || "content"))
    healthChecks[0].status = "healthy"
  } catch (error) {
    healthChecks[0].status = "unhealthy"
  }

  try {
    // Check cache directory
    await fs.access(path.join(process.cwd(), process.env.CACHE_PATH || ".cache"))
    healthChecks[1].status = "healthy"
  } catch (error) {
    healthChecks[1].status = "unhealthy"
  }

  try {
    // Check user authentication
    const users = await getUsers()
    healthChecks[2].status = users.length > 0 ? "healthy" : "unhealthy"
  } catch (error) {
    healthChecks[2].status = "unhealthy"
  }

  try {
    // Check media storage
    await fs.access(path.join(process.cwd(), "public", "uploads"))
    healthChecks[3].status = "healthy"
  } catch (error) {
    healthChecks[3].status = "unhealthy"
  }

  return healthChecks
}

// Get system stats
export async function getSystemStats() {
  try {
    // Get content stats
    const contentTypes = ["page", "note", "form", "media", "collection", "timeline"]
    let contentCount = 0
    let mediaCount = 0

    for (const type of contentTypes) {
      const content = await getAllContent(type)
      contentCount += content.length

      if (type === "media") {
        mediaCount = content.length
      }
    }

    // Get storage stats
    const contentDir = path.join(process.cwd(), process.env.CONTENT_DIRECTORY || "content")
    const uploadsDir = path.join(process.cwd(), "public", "uploads")

    const contentSize = await getDirectorySize(contentDir)
    const uploadsSize = await getDirectorySize(uploadsDir)
    const storageUsed = contentSize + uploadsSize

    // Get user stats
    const users = await getUsers()

    // Get activity data
    const contentActivity = await getContentActivity()
    const contentDistribution = await getContentDistribution()
    const recentActivity = await getRecentActivity()

    // Get health checks
    const healthChecks = await checkSystemHealth()

    return {
      contentCount,
      contentChange: 0, // Would need historical data to calculate
      mediaCount,
      mediaChange: 0, // Would need historical data to calculate
      storageUsed,
      storageChange: 0, // Would need historical data to calculate
      userCount: users.length,
      contentActivity,
      contentDistribution,
      recentActivity,
      healthChecks,
      version: "0.1.0",
      nextVersion: "13.5.4",
      environment: process.env.NODE_ENV || "development",
      lastBackup: null, // Would need backup system to track this
    }
  } catch (error) {
    logger.error("Error getting system stats:", error)

    // Return default stats on error
    return {
      contentCount: 0,
      contentChange: 0,
      mediaCount: 0,
      mediaChange: 0,
      storageUsed: 0,
      storageChange: 0,
      userCount: 0,
      contentActivity: [],
      contentDistribution: [],
      recentActivity: [],
      healthChecks: [],
      version: "0.1.0",
      nextVersion: "13.5.4",
      environment: process.env.NODE_ENV || "development",
      lastBackup: null,
    }
  }
}

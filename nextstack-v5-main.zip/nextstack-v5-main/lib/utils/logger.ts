type LogLevel = "debug" | "info" | "warn" | "error"

interface LogEntry {
  timestamp: string
  level: LogLevel
  message: string
  data?: any
}

// Configure log level based on environment
const LOG_LEVEL = process.env.LOG_LEVEL || (process.env.NODE_ENV === "production" ? "info" : "debug")
const DEBUG_MODE = process.env.DEBUG === "true"

// In-memory log storage for development
const logHistory: LogEntry[] = []
const MAX_LOG_HISTORY = 1000

// Log level hierarchy
const logLevels: Record<LogLevel, number> = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3,
}

// Should this level be logged based on configured level?
function shouldLog(level: LogLevel): boolean {
  return logLevels[level] >= logLevels[LOG_LEVEL as LogLevel]
}

// Format data for logging
function formatData(data: any): string {
  if (typeof data === "undefined") return ""

  try {
    if (data instanceof Error) {
      return `${data.message}\n${data.stack || ""}`
    }
    return JSON.stringify(data, null, 2)
  } catch (e) {
    return String(data)
  }
}

// Add entry to log history
function addToHistory(entry: LogEntry) {
  logHistory.push(entry)
  if (logHistory.length > MAX_LOG_HISTORY) {
    logHistory.shift()
  }
}

// Core logging function
function log(level: LogLevel, message: string, data?: any) {
  if (!shouldLog(level)) return

  const timestamp = new Date().toISOString()
  const entry: LogEntry = { timestamp, level, message, data }

  // Add to history
  addToHistory(entry)

  // Format console output
  const formattedData = data ? `\n${formatData(data)}` : ""

  // Log to console with appropriate method
  switch (level) {
    case "debug":
      console.debug(`[${timestamp}] [DEBUG] ${message}${formattedData}`)
      break
    case "info":
      console.info(`[${timestamp}] [INFO] ${message}${formattedData}`)
      break
    case "warn":
      console.warn(`[${timestamp}] [WARN] ${message}${formattedData}`)
      break
    case "error":
      console.error(`[${timestamp}] [ERROR] ${message}${formattedData}`)
      break
  }
}

// Public API
export const logger = {
  debug: (message: string, data?: any) => log("debug", message, data),
  info: (message: string, data?: any) => log("info", message, data),
  warn: (message: string, data?: any) => log("warn", message, data),
  error: (message: string, data?: any) => log("error", message, data),

  // Get log history (for admin panel)
  getHistory: () => [...logHistory],

  // Clear log history
  clearHistory: () => {
    logHistory.length = 0
  },
}

// Error handler for async functions
export function withErrorHandling<T>(fn: (...args: any[]) => Promise<T>, errorMessage: string) {
  return async (...args: any[]): Promise<T> => {
    try {
      return await fn(...args)
    } catch (error) {
      logger.error(`${errorMessage}`, error)
      throw error
    }
  }
}

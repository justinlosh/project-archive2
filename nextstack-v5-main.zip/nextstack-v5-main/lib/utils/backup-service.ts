import fs from "fs/promises"
import path from "path"
import { logger } from "./logger"

// Configuration
const BACKUP_DIR = path.join(process.cwd(), "backups")
const CONTENT_DIR = process.env.CONTENT_DIRECTORY || "content"

// Ensure backup directory exists
async function ensureBackupDir() {
  try {
    await fs.access(BACKUP_DIR)
  } catch (error) {
    await fs.mkdir(BACKUP_DIR, { recursive: true })
  }
}

// Create a backup of the content directory
export async function createBackup() {
  try {
    await ensureBackupDir()

    const timestamp = new Date().toISOString().replace(/[:.]/g, "-")
    const backupFilename = `backup-${timestamp}.tar.gz`
    const backupPath = path.join(BACKUP_DIR, backupFilename)

    // Create a list of files to backup
    const contentPath = path.join(process.cwd(), CONTENT_DIR)
    const files = await listFilesRecursively(contentPath)

    // Create tar.gz archive
    await createArchive(files, contentPath, backupPath)

    // Get file size
    const stats = await fs.stat(backupPath)

    logger.info(`Backup created: ${backupFilename} (${formatBytes(stats.size)})`)

    return {
      filename: backupFilename,
      path: backupPath,
      size: stats.size,
      timestamp: new Date().toISOString(),
    }
  } catch (error) {
    logger.error("Error creating backup:", error)
    throw new Error("Failed to create backup")
  }
}

// List all backups
export async function listBackups() {
  try {
    await ensureBackupDir()

    const files = await fs.readdir(BACKUP_DIR)
    const backups = []

    for (const file of files) {
      if (file.startsWith("backup-") && file.endsWith(".tar.gz")) {
        const filePath = path.join(BACKUP_DIR, file)
        const stats = await fs.stat(filePath)

        backups.push({
          filename: file,
          path: filePath,
          size: stats.size,
          timestamp: stats.mtime.toISOString(),
        })
      }
    }

    // Sort by timestamp (newest first)
    backups.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    return backups
  } catch (error) {
    logger.error("Error listing backups:", error)
    return []
  }
}

// Delete a backup
export async function deleteBackup(filename: string) {
  try {
    const backupPath = path.join(BACKUP_DIR, filename)

    // Check if file exists
    await fs.access(backupPath)

    // Delete file
    await fs.unlink(backupPath)

    logger.info(`Backup deleted: ${filename}`)

    return true
  } catch (error) {
    logger.error(`Error deleting backup ${filename}:`, error)
    return false
  }
}

// Helper function to list files recursively
async function listFilesRecursively(dir: string): Promise<string[]> {
  const entries = await fs.readdir(dir, { withFileTypes: true })

  const files = await Promise.all(
    entries.map(async (entry) => {
      const fullPath = path.join(dir, entry.name)
      return entry.isDirectory() ? listFilesRecursively(fullPath) : [fullPath]
    }),
  )

  return files.flat()
}

// Helper function to create a tar.gz archive
async function createArchive(files: string[], baseDir: string, outputPath: string) {
  const tar = require("tar")

  return new Promise((resolve, reject) => {
    tar
      .c(
        {
          gzip: true,
          file: outputPath,
          cwd: baseDir,
          filter: (path: string) => !path.includes("node_modules"),
        },
        files.map((file) => path.relative(baseDir, file)),
      )
      .then(resolve)
      .catch(reject)
  })
}

// Helper function to format bytes
function formatBytes(bytes: number, decimals = 2): string {
  if (bytes === 0) return "0 Bytes"

  const k = 1024
  const dm = decimals < 0 ? 0 : decimals
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"]

  const i = Math.floor(Math.log(bytes) / Math.log(k))

  return Number.parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i]
}

import fs from "fs/promises"
import path from "path"
import type { ContentType } from "./types"

// Get content directory from environment variable or use default
const CONTENT_DIR = process.env.CONTENT_DIRECTORY || "content"
const VERSIONS_DIR = "versions"

// Helper to ensure the versions directory exists
async function ensureVersionsDirectory(type: ContentType, id: string) {
  const dirPath = path.join(process.cwd(), CONTENT_DIR, VERSIONS_DIR, type, id)
  try {
    await fs.access(dirPath)
  } catch (error) {
    // Create directory if it doesn't exist
    await fs.mkdir(dirPath, { recursive: true })
  }
  return dirPath
}

// Create a version of content
export async function createVersion(type: ContentType, id: string, content: any) {
  const dirPath = await ensureVersionsDirectory(type, id)

  // Add version metadata
  const versionId = Date.now().toString()
  const versionData = {
    ...content,
    _versionId: versionId,
    _versionCreatedAt: new Date().toISOString(),
  }

  const filePath = path.join(dirPath, `${versionId}.json`)

  try {
    await fs.writeFile(filePath, JSON.stringify(versionData, null, 2))
    return versionData
  } catch (error) {
    console.error(`Error creating version for ${type} content with ID ${id}:`, error)
    throw error
  }
}

// Get all versions of content
export async function getVersions(type: ContentType, id: string) {
  try {
    const dirPath = path.join(process.cwd(), CONTENT_DIR, VERSIONS_DIR, type, id)

    try {
      await fs.access(dirPath)
    } catch (error) {
      // Directory doesn't exist, no versions available
      return []
    }

    const files = await fs.readdir(dirPath)
    const jsonFiles = files.filter((file) => file.endsWith(".json"))

    // Sort files by version ID (timestamp) in descending order
    jsonFiles.sort((a, b) => {
      const versionA = Number.parseInt(a.split(".")[0])
      const versionB = Number.parseInt(b.split(".")[0])
      return versionB - versionA
    })

    const versions = await Promise.all(
      jsonFiles.map(async (file) => {
        const filePath = path.join(dirPath, file)
        const content = await fs.readFile(filePath, "utf-8")
        return JSON.parse(content)
      }),
    )

    return versions
  } catch (error) {
    console.error(`Error getting versions for ${type} content with ID ${id}:`, error)
    return []
  }
}

// Get a specific version of content
export async function getVersion(type: ContentType, id: string, versionId: string) {
  try {
    const dirPath = path.join(process.cwd(), CONTENT_DIR, VERSIONS_DIR, type, id)
    const filePath = path.join(dirPath, `${versionId}.json`)

    const content = await fs.readFile(filePath, "utf-8")
    return JSON.parse(content)
  } catch (error) {
    console.error(`Error getting version ${versionId} for ${type} content with ID ${id}:`, error)
    return null
  }
}

// Restore a specific version of content
export async function restoreVersion(type: ContentType, id: string, versionId: string) {
  try {
    // Get the version content
    const version = await getVersion(type, id, versionId)

    if (!version) {
      throw new Error(`Version ${versionId} not found`)
    }

    // Remove version metadata
    const { _versionId, _versionCreatedAt, ...contentWithoutVersionMeta } = version

    // Update the content file
    const contentFilePath = path.join(process.cwd(), CONTENT_DIR, type, `${id}.json`)

    // Update the content with the version data, but keep the original ID and update the timestamps
    const restoredContent = {
      ...contentWithoutVersionMeta,
      id,
      updatedAt: new Date().toISOString(),
    }

    await fs.writeFile(contentFilePath, JSON.stringify(restoredContent, null, 2))

    return restoredContent
  } catch (error) {
    console.error(`Error restoring version ${versionId} for ${type} content with ID ${id}:`, error)
    throw error
  }
}

import { z } from "zod"
import type { ContentType } from "./types"

// Base schema for all content types
const baseContentSchema = z.object({
  id: z.string().optional(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
})

// Page schema
const pageSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  slug: z
    .string()
    .min(1, "Slug is required")
    .regex(/^[a-z0-9-]+$/, "Slug must contain only lowercase letters, numbers, and hyphens"),
  content: z.string().min(1, "Content is required"),
  metaTitle: z.string().optional(),
  metaDescription: z.string().optional(),
})

// Note schema
const noteSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  content: z.string().min(1, "Content is required"),
  tags: z.array(z.string()).optional(),
})

// Form schema
const formSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  fields: z.array(
    z.object({
      name: z.string().min(1, "Field name is required"),
      label: z.string().min(1, "Field label is required"),
      type: z.enum(["text", "email", "number", "textarea", "select", "checkbox", "radio"]),
      required: z.boolean().optional(),
      options: z
        .array(
          z.object({
            value: z.string(),
            label: z.string(),
          }),
        )
        .optional(),
    }),
  ),
  submitButtonText: z.string().optional(),
  successMessage: z.string().optional(),
})

// Submission schema
const submissionSchema = baseContentSchema.extend({
  formId: z.string().min(1, "Form ID is required"),
  data: z.record(z.any()),
  submittedAt: z.string().optional(),
})

// Media schema
const mediaSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  url: z.string().min(1, "URL is required"),
  description: z.string().optional(),
  fileType: z.string().optional(),
  fileSize: z.number().optional(),
  width: z.number().optional(),
  height: z.number().optional(),
  alt: z.string().optional(),
  tags: z.array(z.string()).optional(),
})

// Collection schema
const collectionSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  items: z.array(z.any()).optional(),
})

// Timeline event schema
const timelineEventSchema = z.object({
  title: z.string().min(1, "Event title is required"),
  date: z.string().min(1, "Event date is required"),
  description: z.string().optional(),
  media: z
    .object({
      url: z.string(),
      alt: z.string().optional(),
    })
    .optional(),
})

// Timeline schema
const timelineSchema = baseContentSchema.extend({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  events: z.array(timelineEventSchema),
})

// Map content type to schema
const contentSchemas: Record<ContentType, z.ZodType<any>> = {
  page: pageSchema,
  note: noteSchema,
  form: formSchema,
  submission: submissionSchema,
  media: mediaSchema,
  collection: collectionSchema,
  timeline: timelineSchema,
}

// Validate content
export function validateContent(type: ContentType, content: any): { valid: boolean; errors?: z.ZodError } {
  const schema = contentSchemas[type]

  if (!schema) {
    throw new Error(`No validation schema found for content type: ${type}`)
  }

  const result = schema.safeParse(content)

  if (!result.success) {
    return {
      valid: false,
      errors: result.error,
    }
  }

  return { valid: true }
}

// Format validation errors
export function formatValidationErrors(error: z.ZodError): Record<string, string[]> {
  const errors: Record<string, string[]> = {}

  error.errors.forEach((err) => {
    const path = err.path.join(".")
    if (!errors[path]) {
      errors[path] = []
    }
    errors[path].push(err.message)
  })

  return errors
}

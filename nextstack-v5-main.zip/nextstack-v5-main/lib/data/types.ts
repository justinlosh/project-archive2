// Existing types...

export type ContentType = "page" | "note" | "form" | "submission" | "media" | "collection" | "timeline"

// Add Timeline type
export interface TimelineEvent {
  title: string
  date: string
  description?: string
  media?: {
    url: string
    alt?: string
  }
}

export interface Timeline {
  id: string
  title: string
  description?: string
  events: TimelineEvent[]
  createdAt: string
  updatedAt: string
}

// Other existing types...

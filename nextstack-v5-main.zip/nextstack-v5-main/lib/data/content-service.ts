import fs from "fs/promises"
import path from "path"
import type { ContentType } from "./types"
import { createVersion } from "./version-service"
import { clearCache, withCache } from "../cache/cache-service"

// Get content directory from environment variable or use default
const CONTENT_DIR = process.env.CONTENT_DIRECTORY || "content"

// Helper to ensure the content directory exists
async function ensureContentDirectory(type: ContentType) {
  const dirPath = path.join(process.cwd(), CONTENT_DIR, type)
  try {
    await fs.access(dirPath)
  } catch (error) {
    // Create directory if it doesn't exist
    await fs.mkdir(dirPath, { recursive: true })
  }
  return dirPath
}

// Get all content items of a specific type
export const getAllContent = withCache(async (type: ContentType) => {
  const dirPath = await ensureContentDirectory(type)

  try {
    const files = await fs.readdir(dirPath)
    const jsonFiles = files.filter((file) => file.endsWith(".json"))

    const contentItems = await Promise.all(
      jsonFiles.map(async (file) => {
        const filePath = path.join(dirPath, file)
        const content = await fs.readFile(filePath, "utf-8")
        return JSON.parse(content)
      }),
    )

    return contentItems
  } catch (error) {
    console.error(`Error reading ${type} content:`, error)
    return []
  }
}, "getAllContent")

// Get a single content item by ID
export const getContentById = withCache(async (type: ContentType, id: string) => {
  const dirPath = await ensureContentDirectory(type)
  const filePath = path.join(dirPath, `${id}.json`)

  try {
    const content = await fs.readFile(filePath, "utf-8")
    return JSON.parse(content)
  } catch (error) {
    console.error(`Error reading ${type} content with ID ${id}:`, error)
    return null
  }
}, "getContentById")

// Create a new content item
export async function createContent(type: ContentType, content: any) {
  const dirPath = await ensureContentDirectory(type)

  // Generate ID if not provided
  if (!content.id) {
    content.id = crypto.randomUUID()
  }

  // Add timestamps
  content.createdAt = new Date().toISOString()
  content.updatedAt = new Date().toISOString()

  const filePath = path.join(dirPath, `${content.id}.json`)

  try {
    await fs.writeFile(filePath, JSON.stringify(content, null, 2))

    // Create initial version
    await createVersion(type, content.id, content)

    // Clear cache for this content type
    await clearCache(`getAllContent:["${type}"]`)

    return content
  } catch (error) {
    console.error(`Error creating ${type} content:`, error)
    throw error
  }
}

// Update an existing content item
export async function updateContent(type: ContentType, id: string, content: any) {
  const dirPath = await ensureContentDirectory(type)
  const filePath = path.join(dirPath, `${id}.json`)

  try {
    // Check if file exists
    await fs.access(filePath)

    // Get existing content
    const existingContentRaw = await fs.readFile(filePath, "utf-8")
    const existingContent = JSON.parse(existingContentRaw)

    // Create a version of the existing content before updating
    await createVersion(type, id, existingContent)

    // Update content
    const updatedContent = {
      ...existingContent,
      ...content,
      id, // Ensure ID doesn't change
      updatedAt: new Date().toISOString(),
      createdAt: existingContent.createdAt, // Preserve original creation date
    }

    await fs.writeFile(filePath, JSON.stringify(updatedContent, null, 2))

    // Clear cache for this content
    await clearCache(`getAllContent:["${type}"]`)
    await clearCache(`getContentById:["${type}","${id}"]`)

    return updatedContent
  } catch (error) {
    console.error(`Error updating ${type} content with ID ${id}:`, error)
    throw error
  }
}

// Delete a content item
export async function deleteContent(type: ContentType, id: string) {
  const dirPath = await ensureContentDirectory(type)
  const filePath = path.join(dirPath, `${id}.json`)

  try {
    // Create a final version before deleting
    const existingContent = await getContentById(type, id)
    if (existingContent) {
      await createVersion(type, id, existingContent)
    }

    await fs.unlink(filePath)

    // Clear cache for this content
    await clearCache(`getAllContent:["${type}"]`)
    await clearCache(`getContentById:["${type}","${id}"]`)

    return true
  } catch (error) {
    console.error(`Error deleting ${type} content with ID ${id}:`, error)
    throw error
  }
}

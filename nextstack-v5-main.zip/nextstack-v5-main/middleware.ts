import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { initializeAdminUser } from "@/lib/auth/auth-utils"

// Security headers
const securityHeaders = {
  "X-DNS-Prefetch-Control": "on",
  "X-XSS-Protection": "1; mode=block",
  "X-Frame-Options": "SAMEORIGIN",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=(), interest-cohort=()",
  "Strict-Transport-Security": "max-age=63072000; includeSubDomains; preload",
}

// Initialize admin user (this runs when the middleware is loaded)
initializeAdminUser()
  .then(() => console.log("Admin user initialized"))
  .catch((error) => console.error("Failed to initialize admin user:", error))

export function middleware(request: NextRequest) {
  // Get the pathname of the request
  const path = request.nextUrl.pathname

  // Define public paths that don't require authentication
  const isPublicPath = path === "/admin/login" || path === "/admin/unauthorized"

  // Check if the request is for an admin path
  const isAdminPath = path.startsWith("/admin")

  // Get the session cookie
  const sessionCookie = request.cookies.get("session_id")?.value

  // Create response object
  const response = NextResponse.next()

  // Add security headers to all responses
  Object.entries(securityHeaders).forEach(([key, value]) => {
    response.headers.set(key, value)
  })

  // If the path is an admin path and not a public path, check for authentication
  if (isAdminPath && !isPublicPath && !sessionCookie) {
    console.log(`Redirecting unauthenticated request from ${path} to /admin/login`)
    // Redirect to login if no session cookie is found
    return NextResponse.redirect(new URL(`/admin/login?from=${encodeURIComponent(path)}`, request.url))
  }

  // If user is already logged in and trying to access login page, redirect to admin dashboard
  if (path === "/admin/login" && sessionCookie) {
    console.log("User already logged in, redirecting to admin dashboard")
    return NextResponse.redirect(new URL("/admin", request.url))
  }

  // Add the pathname to the request headers so layouts can access it
  const requestHeaders = new Headers(request.headers)
  requestHeaders.set("x-pathname", path)

  // Continue with the request, but with the modified headers
  return NextResponse.next({
    request: {
      headers: requestHeaders,
    },
    headers: response.headers,
  })
}

// Configure the middleware to run only on admin routes
export const config = {
  matcher: ["/admin/:path*"],
}

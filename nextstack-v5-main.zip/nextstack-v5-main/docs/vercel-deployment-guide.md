# Vercel Deployment Guide for Next.js Flat-File CMS

This guide provides instructions for deploying the Next.js Flat-File CMS to Vercel.

## Prerequisites

- A Vercel account
- Git repository with your project code
- Node.js and npm installed locally

## Deployment Steps

### 1. Prepare Your Project

Ensure your project has the following files:

- `vercel.json` - Configuration file for Vercel
- `next.config.mjs` - Next.js configuration
- `package.json` - Project dependencies and scripts

### 2. Configure Environment Variables

Set up the following environment variables in your Vercel project:

- `NODE_ENV`: Set to "production" for production deployments
- `NEXT_PUBLIC_API_URL`: Your API URL
- `NEXT_PUBLIC_SITE_URL`: Your site URL
- `CONTENT_DIRECTORY`: Directory for content files (default: "./content")
- `ENABLE_API_CACHE`: Enable API caching (true/false)
- `API_CACHE_TTL`: Cache TTL in seconds
- `CACHE_LEVELS`: Cache levels to use (memory,file)
- `CACHE_MAX_MEMORY_SIZE`: Maximum memory cache size in MB
- `CACHE_MAX_FILE_SIZE`: Maximum file cache size in MB
- `CACHE_PATH`: Path for file cache
- `CACHE_LOG_STATS`: Enable cache stats logging (true/false)
- `DEBUG`: Enable debug mode (true/false)

### 3. Deploy to Vercel

#### Using Vercel CLI

1. Install Vercel CLI:
   \`\`\`
   npm install -g vercel
   \`\`\`

2. Login to Vercel:
   \`\`\`
   vercel login
   \`\`\`

3. Deploy your project:
   \`\`\`
   vercel
   \`\`\`

4. For production deployment:
   \`\`\`
   vercel --prod
   \`\`\`

#### Using Vercel Dashboard

1. Push your code to a Git repository (GitHub, GitLab, or Bitbucket)
2. Import your project in the Vercel dashboard
3. Configure your project settings
4. Deploy

### 4. Verify Deployment

After deployment, verify that:

1. The site is accessible at the provided URL
2. API endpoints are working correctly
3. Content is being served properly
4. Environment variables are correctly set

### 5. Troubleshooting

If you encounter issues during deployment:

1. Check the Vercel deployment logs
2. Verify your environment variables
3. Ensure your `vercel.json` configuration is correct
4. Check for build errors in your code

### 6. Common Issues and Solutions

#### Build Fails Due to Missing Dependencies

Ensure all dependencies are listed in your `package.json` file.

#### API Routes Not Working

Check your `vercel.json` configuration for proper API route handling.

#### Environment Variables Not Available

Verify that all required environment variables are set in your Vercel project settings.

#### Content Not Being Served

Check that your content directory is properly configured and accessible.

## Advanced Configuration

### Custom Domains

To set up a custom domain:

1. Go to your project settings in the Vercel dashboard
2. Navigate to the "Domains" section
3. Add your custom domain
4. Follow the instructions to configure DNS settings

### Continuous Deployment

Vercel automatically sets up continuous deployment when you connect a Git repository. Each push to your repository will trigger a new deployment.

### Preview Deployments

Vercel creates preview deployments for pull requests, allowing you to test changes before merging to production.

## Resources

- [Vercel Documentation](https://vercel.com/docs)
- [Next.js Documentation](https://nextjs.org/docs)
- [Environment Variables in Vercel](https://vercel.com/docs/concepts/projects/environment-variables)

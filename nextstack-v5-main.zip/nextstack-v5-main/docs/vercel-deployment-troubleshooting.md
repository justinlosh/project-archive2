# Vercel Deployment Troubleshooting

## Common Deployment Issues

### Conflicting Configuration Properties

One common issue when deploying to Vercel is conflicting configuration properties in the `vercel.json` file. Specifically, the `functions` property cannot be used in conjunction with the `builds` property [^1][^2].

#### Solution

Choose either the `functions` property or the `builds` property for your `vercel.json` file, but not both. Since `builds` is considered a legacy configuration property, it's recommended to use the `functions` property instead.

### Missing Serverless Functions

If you receive an error like `The pattern "api/**/*.js" defined in 'functions' doesn't match any Serverless Functions`, it means Vercel couldn't find any functions matching the pattern you specified.

#### Solution

1. Make sure your serverless functions exist in the correct location:
   - For Next.js Pages Router: `pages/api/**/*`
   - For Next.js App Router: `app/api/**/*`

2. Update your `vercel.json` to match the correct pattern:

\`\`\`json
{
  "functions": {
    "app/api/**/*": {
      "memory": 1024,
      "maxDuration": 10
    }
  }
}
\`\`\`

3. Alternatively, if you don't have any serverless functions yet, you can remove the `functions` property entirely and add it later when needed.

### Other Common Issues

1. **Missing Environment Variables**
   - Ensure all required environment variables are set in the Vercel dashboard
   - Check for typos in environment variable names

2. **Build Failures**
   - Check your build logs for specific error messages
   - Ensure all dependencies are properly installed
   - Verify your build script in package.json is correct

3. **API Routes Not Working**
   - Verify your API routes are in the correct location
   - Check for any middleware that might be blocking requests
   - Ensure your API routes are properly exported

4. **Static Assets Not Loading**
   - Check your asset paths are correct
   - Verify your public directory is properly configured
   - Ensure your assets are included in the build

## Advanced Configuration

For more advanced Vercel configuration options, refer to the [Vercel documentation](https://vercel.com/docs).
